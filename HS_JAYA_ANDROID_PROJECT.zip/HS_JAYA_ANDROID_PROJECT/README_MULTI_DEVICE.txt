HS JAYA 1.3.0 - MULTI DEVICE + MUNDUR + APP-SIDE COLLECT

TUJUAN
- Satu APK mengontrol stock LEDCAR, stock LEDDMX, dan firmware custom HS JAYA.
- Bisa menghubungkan satu atau beberapa modul secara bersamaan, maksimal 10 koneksi yang dikelola aplikasi.
- Dua atau lebih custom firmware yang sama juga bisa terhubung karena dibedakan berdasarkan address BLE.
- Nama teknis/profil tetap internal; UI tetap memakai RGB HYBRID.

PERUBAHAN UTAMA
1. BleController sekarang menyimpan banyak koneksi GATT sekaligus.
2. Scan manual memakai multi-select. Semua item default terpilih; user boleh menyisakan satu saja.
3. Pilihan device disimpan. Saat aplikasi dibuka lagi, device tersimpan di-scan dan auto-connect.
   Pada instalasi pertama tanpa pilihan tersimpan, semua controller supported yang ditemukan akan dicoba terhubung.
4. Connect dibuat bertahap 220 ms agar stack Bluetooth lebih stabil.
5. Queue write terpisah per device (65 ms antar write per koneksi).
6. Routing protocol dilakukan per device:
   - CUSTOM: packet HS JAYA dengan channel independent.
   - B_COMPACT: LEDCAR-02 / LEDDMX-02 / LEDDMX-04.
   - B_CLASSIC: LEDCAR-01 / LEDDMX klasik.
   - A_GENERIC: LEDCAR-00 / LEDBLE.
7. Custom firmware dideteksi dari OTA service UUID 7e400001-b5a3-f393-e0a9-e50e24dcca9e
   atau nama RGB HYBRID / HS JAYA.
8. MUNDUR aktif sebagai opcode 0x1D mode 1..10.
9. AUTO/COLLECT tidak lagi memakai opcode custom 0x1E/0x1F.
   APK mengirim Mode biasa 0x03 satu per satu sesuai playlist Collect.
10. RESET Auto hanya mengembalikan playback ke mode pertama, tidak menghapus Collect.
11. Layout/assets HS JAYA dari APK terbaru dipertahankan; perubahan difokuskan ke logic BLE.

PERILAKU MULTI DEVICE
Contoh koneksi:
- Device 1: stock LEDCAR
- Device 2: stock LEDDMX
- Device 3: custom RGB HYBRID
- Device 4: custom RGB HYBRID

Saat ALL + Mode 28 ditekan:
- setiap device menerima packet Mode 28 dengan framing sesuai profilnya.

Saat LED1 dipilih:
- custom firmware menerima command channel LED1.
- stock module mengabaikan command channel-specific (tidak dipaksa ke ALL).

Saat ALL dipilih:
- stock dan custom sama-sama menerima command global.

CATATAN TEST
Target software mendukung sampai 10 koneksi, tetapi batas stabil BLE tetap tergantung HP/Android.
Tes disarankan bertahap: 2 -> 4 -> 6 -> 10 device.

TES WAJIB
A. 1 stock LEDCAR: ON/OFF, Mode, Brightness, Speed, Mundur, Collect ALL.
B. 1 stock LEDDMX: fungsi dasar + Collect ALL.
C. 1 custom: fungsi dasar, LED1..4, Mundur, Collect.
D. 2 custom bersamaan: ALL harus mengontrol keduanya; LED1..4 dikirim ke keduanya.
E. campuran stock + custom: ALL mengontrol semua, independent hanya custom.
F. 3+ device: command tidak saling menimpa dan status menunjukkan jumlah koneksi.
