package com.hsjaya.led;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Multi-device BLE manager.
 *
 * Supports multiple stock LEDCAR/LEDDMX controllers and multiple HS JAYA custom
 * controllers at the same time.  Protocol routing is per connection, so one UI
 * action can be translated into different wire packets for different devices.
 */
final class BleController {
    interface Listener {
        void onStatus(String status, int detectedCount, int readyCount, int customCount, int stockLedcarCount, int stockDmxCount);
    }

    static final int PERMISSION_REQUEST = 401;
    private static final long SCAN_MS = 4200L;
    private static final long CONNECT_STAGGER_MS = 220L;
    private static final long WRITE_GAP_MS = 65L;

    private static final UUID SERVICE = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    private static final UUID CHARACTERISTIC = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");
    private static final UUID CUSTOM_OTA_SERVICE = UUID.fromString("7e400001-b5a3-f393-e0a9-e50e24dcca9e");

    private final Activity activity;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, DeviceChoice> found = new LinkedHashMap<>();
    private final Map<String, Connection> connections = new LinkedHashMap<>();

    private BluetoothLeScanner scanner;
    private boolean scanning;
    private boolean pendingPermissionScan;
    private boolean pendingPermissionAuto;
    private boolean shuttingDown;
    private int scanGeneration;

    private static final class DeviceChoice {
        final BluetoothDevice device;
        final String address;
        final String rawName;
        final int rssi;
        final Protocol.Profile profile;
        final boolean custom;
        final boolean supported;

        DeviceChoice(BluetoothDevice device, String address, String rawName, int rssi,
                     Protocol.Profile profile, boolean custom, boolean supported) {
            this.device = device;
            this.address = address;
            this.rawName = rawName;
            this.rssi = rssi;
            this.profile = profile;
            this.custom = custom;
            this.supported = supported;
        }
    }

    private final class Connection {
        final DeviceChoice choice;
        final ArrayDeque<byte[]> pending = new ArrayDeque<>();
        BluetoothGatt gatt;
        BluetoothGattCharacteristic tx;
        boolean connecting;
        boolean ready;
        boolean draining;

        Connection(DeviceChoice choice) { this.choice = choice; }
    }

    BleController(Activity activity, Listener listener) {
        this.activity = activity;
        this.listener = listener;
    }

    boolean permissionsGranted() {
        if (Build.VERSION.SDK_INT >= 31) {
            return activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                    && activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }
        return activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    void autoConnect() { scanInternal(true); }
    void scan() { scanInternal(false); }

    void resumePendingScan() {
        if (!pendingPermissionScan) return;
        boolean auto = pendingPermissionAuto;
        pendingPermissionScan = false;
        pendingPermissionAuto = false;
        scanInternal(auto);
    }

    private void scanInternal(boolean automatic) {
        if (shuttingDown) return;
        if (!permissionsGranted()) {
            pendingPermissionScan = true;
            pendingPermissionAuto = automatic;
            status("Meminta izin Bluetooth dan Lokasi…");
            if (Build.VERSION.SDK_INT >= 31) {
                activity.requestPermissions(new String[]{
                        Manifest.permission.BLUETOOTH_SCAN,
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.ACCESS_FINE_LOCATION
                }, PERMISSION_REQUEST);
            } else {
                activity.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_REQUEST);
            }
            return;
        }

        BluetoothManager manager = (BluetoothManager) activity.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) { status("Bluetooth tidak tersedia"); return; }
        if (!adapter.isEnabled()) {
            status("Aktifkan Bluetooth, lalu buka HS JAYA kembali");
            activity.startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            return;
        }

        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { status("Pemindai BLE tidak tersedia"); return; }
        if (scanning) return;

        found.clear();
        scanning = true;
        final int generation = ++scanGeneration;
        status(automatic ? "Mencari & menghubungkan perangkat otomatis…" : "Mencari perangkat RGB HYBRID…");
        try {
            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .build();
            scanner.startScan(null, settings, scanCallback);
        } catch (SecurityException error) {
            scanning = false;
            status("Izin Bluetooth/Lokasi diperlukan");
            return;
        } catch (Exception error) {
            scanning = false;
            status("Scan BLE gagal dimulai");
            return;
        }

        main.postDelayed(() -> finishScan(automatic, generation), SCAN_MS);
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getDevice() == null) return;
            try {
                BluetoothDevice device = result.getDevice();
                ScanRecord record = result.getScanRecord();
                String name = record == null ? null : record.getDeviceName();
                if (name == null || name.isEmpty()) name = device.getName();
                if (name == null) name = "";
                String address = device.getAddress();
                boolean hasFfe0 = hasService(record, SERVICE);
                boolean custom = hasService(record, CUSTOM_OTA_SERVICE) || looksCustom(name);
                Protocol.Profile profile = classify(name, custom);
                boolean nameLooksSupported = looksSupportedName(name);
                boolean supported = profile != Protocol.Profile.UNKNOWN || hasFfe0 || custom || nameLooksSupported;
                if (!supported) return;

                // If the name is unknown but FFE0 is present, default to compact framing.
                // This is the safest fallback for the user's LEDCAR-02 / LEDDMX-04 modules.
                if (profile == Protocol.Profile.UNKNOWN && hasFfe0) profile = Protocol.Profile.B_COMPACT;

                DeviceChoice choice = new DeviceChoice(device, address, name, result.getRssi(), profile, custom, true);
                boolean isNew;
                int order;
                synchronized (found) {
                    isNew = !found.containsKey(address);
                    found.put(address, choice);
                    order = Math.max(0, found.size() - 1);
                }
                // Every supported device is connected automatically as soon as it is
                // discovered. No checkbox/device-selection step is required. Stagger
                // connection attempts slightly so Android's BLE stack is not flooded.
                if (isNew) {
                    long delay = Math.min(3500L, order * CONNECT_STAGGER_MS);
                    main.postDelayed(() -> connectOne(choice), delay);
                    publishStatus();
                }
            } catch (SecurityException ignored) { }
        }

        @Override public void onScanFailed(int errorCode) {
            main.post(() -> {
                stopScan();
                status("Scan BLE gagal (kode " + errorCode + ")");
            });
        }
    };

    private void finishScan(boolean automatic, int generation) {
        if (!scanning || generation != scanGeneration) return;
        stopScan();
        List<DeviceChoice> choices = supportedChoices();
        if (choices.isEmpty()) {
            if (connections.isEmpty()) status("Modul LED belum ditemukan · cek daya atau koneksi aplikasi lama");
            else publishStatus();
            return;
        }

        // Safety pass: anything discovered but not yet connecting/ready is queued now.
        connectAllFound(choices);
        publishStatus();
    }

    private List<DeviceChoice> supportedChoices() {
        ArrayList<DeviceChoice> list = new ArrayList<>();
        synchronized (found) {
            for (DeviceChoice choice : found.values()) {
                if (choice.supported) list.add(choice);
            }
        }
        return list;
    }

    private void connectAllFound(List<DeviceChoice> choices) {
        if (choices == null || choices.isEmpty()) return;
        int pendingIndex = 0;
        for (DeviceChoice choice : choices) {
            if (choice == null) continue;
            Connection existing = connections.get(choice.address);
            if (existing != null && (existing.ready || existing.connecting)) continue;
            long delay = pendingIndex++ * CONNECT_STAGGER_MS;
            main.postDelayed(() -> connectOne(choice), delay);
        }
        status(choices.size() + " perangkat terdeteksi · menghubungkan otomatis…");
    }

    private void connectOne(DeviceChoice choice) {
        if (choice == null || shuttingDown || !permissionsGranted()) return;
        Connection existing = connections.get(choice.address);
        if (existing != null && (existing.ready || existing.connecting)) return;

        Connection connection = new Connection(choice);
        connection.connecting = true;
        connections.put(choice.address, connection);
        try {
            connection.gatt = choice.device.connectGatt(activity, false, new GattCallback(connection), BluetoothDevice.TRANSPORT_LE);
            if (connection.gatt == null) {
                connections.remove(choice.address);
                publishStatus();
                return;
            }
            BluetoothGatt attempt = connection.gatt;
            main.postDelayed(() -> {
                if (connection.gatt != attempt || connection.ready || !connection.connecting) return;
                closeConnection(connection, false);
                publishStatus();
            }, 14000L);
        } catch (SecurityException error) {
            connections.remove(choice.address);
            publishStatus();
        } catch (Exception error) {
            connections.remove(choice.address);
            publishStatus();
        }
    }

    private final class GattCallback extends BluetoothGattCallback {
        private final Connection connection;
        GattCallback(Connection connection) { this.connection = connection; }

        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            main.post(() -> handleConnectionState(connection, g, status, newState));
        }

        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            main.post(() -> handleServicesDiscovered(connection, g, status));
        }
    }

    private void handleConnectionState(Connection connection, BluetoothGatt g, int status, int newState) {
        if (g != connection.gatt) return;
        if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
            connection.connecting = false;
            try {
                if (permissionsGranted()) g.discoverServices();
            } catch (SecurityException error) {
                closeConnection(connection, false);
                publishStatus();
            }
            return;
        }
        if (newState == BluetoothProfile.STATE_DISCONNECTED) {
            closeConnection(connection, false);
            publishStatus();
        }
    }

    private void handleServicesDiscovered(Connection connection, BluetoothGatt g, int status) {
        if (g != connection.gatt) return;
        if (status != BluetoothGatt.GATT_SUCCESS) {
            closeConnection(connection, false);
            publishStatus();
            return;
        }
        BluetoothGattService service = g.getService(SERVICE);
        BluetoothGattCharacteristic characteristic = service == null ? null : service.getCharacteristic(CHARACTERISTIC);
        if (characteristic == null) {
            closeConnection(connection, false);
            publishStatus();
            return;
        }
        characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
        connection.tx = characteristic;
        connection.ready = true;
        connection.connecting = false;
        publishStatus();
    }

    void send(int command, int value, int channel) {
        for (Connection connection : readyConnections()) {
            byte[] packet = Protocol.simple(connection.choice.profile, command, value, channel);
            if (packet != null) enqueue(connection, packet);
        }
    }

    void rgb(int r, int g, int b, int channel) {
        for (Connection connection : readyConnections()) {
            byte[] packet = Protocol.rgb(connection.choice.profile, r, g, b, channel);
            if (packet != null) enqueue(connection, packet);
        }
    }

    void pixel(int count) {
        for (Connection connection : readyConnections()) {
            byte[] packet = Protocol.ledCount(connection.choice.profile, count);
            if (packet != null) enqueue(connection, packet);
        }
    }

    void remSetting(int command, int value) {
        for (Connection connection : readyConnections()) {
            byte[] packet = Protocol.remSetting(connection.choice.profile, command, value);
            if (packet != null) enqueue(connection, packet);
        }
    }

    void subareaDouble(int area) {
        for (Connection connection : readyConnections()) {
            if (connection.choice.profile != Protocol.Profile.CUSTOM) continue;
            byte[] packet = Protocol.simple(Protocol.Profile.CUSTOM, 0x14, area, Protocol.ALL);
            if (packet == null) continue;
            enqueue(connection, packet);
            main.postDelayed(() -> enqueue(connection, packet.clone()), 160L);
        }
    }

    private List<Connection> readyConnections() {
        ArrayList<Connection> list = new ArrayList<>();
        for (Connection c : connections.values()) if (c.ready && c.tx != null && c.gatt != null) list.add(c);
        return list;
    }

    private void enqueue(Connection connection, byte[] packet) {
        if (connection == null || packet == null || !connection.ready) return;
        synchronized (connection.pending) { connection.pending.offer(packet.clone()); }
        main.post(() -> drain(connection));
    }

    private void drain(Connection connection) {
        if (connection == null || connection.draining || !connection.ready || connection.gatt == null || connection.tx == null) return;
        byte[] packet;
        synchronized (connection.pending) { packet = connection.pending.poll(); }
        if (packet == null) return;
        connection.draining = true;
        try {
            connection.tx.setValue(packet);
            connection.tx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            if (permissionsGranted()) connection.gatt.writeCharacteristic(connection.tx);
        } catch (SecurityException ignored) {
        } catch (Exception ignored) {
        }
        main.postDelayed(() -> {
            connection.draining = false;
            drain(connection);
        }, WRITE_GAP_MS);
    }

    void disconnectAll() {
        stopScan();
        disconnectAllInternal(true);
        publishStatus();
    }

    private void disconnectAllInternal(boolean manual) {
        ArrayList<Connection> copy = new ArrayList<>(connections.values());
        for (Connection connection : copy) closeConnection(connection, manual);
        connections.clear();
    }

    private void closeConnection(Connection connection, boolean manual) {
        if (connection == null) return;
        connection.ready = false;
        connection.connecting = false;
        connection.tx = null;
        connection.draining = false;
        synchronized (connection.pending) { connection.pending.clear(); }
        BluetoothGatt old = connection.gatt;
        connection.gatt = null;
        connections.remove(connection.choice.address);
        if (old != null) {
            try { if (permissionsGranted()) old.disconnect(); } catch (SecurityException ignored) { }
            try { old.close(); } catch (Exception ignored) { }
        }
    }

    void shutdown() {
        shuttingDown = true;
        stopScan();
        disconnectAllInternal(true);
    }

    void permissionsDenied() {
        pendingPermissionScan = false;
        pendingPermissionAuto = false;
        status("Izin Perangkat di sekitar dan Lokasi diperlukan");
    }

    private void publishStatus() {
        main.post(() -> {
            int ready = 0, custom = 0, stockLedcar = 0, stockDmx = 0;
            for (Connection c : connections.values()) {
                if (!c.ready) continue;
                ready++;
                if (c.choice.custom || c.choice.profile == Protocol.Profile.CUSTOM) custom++;
                else if (looksDmx(c.choice.rawName)) stockDmx++;
                else stockLedcar++;
            }
            int detected;
            synchronized (found) { detected = found.size(); }
            detected = Math.max(detected, ready);
            String text;
            if (detected == 0 && ready == 0) text = "Belum terhubung";
            else if (ready == 0) text = detected + " perangkat terdeteksi · menghubungkan otomatis…";
            else if (ready < detected) text = detected + " perangkat terdeteksi · " + ready + " terhubung";
            else text = detected + " perangkat terdeteksi · " + ready + " terhubung";
            listener.onStatus(text, detected, ready, custom, stockLedcar, stockDmx);
        });
    }

    private void status(String text) {
        main.post(() -> {
            int ready = 0, custom = 0, stockLedcar = 0, stockDmx = 0;
            for (Connection c : connections.values()) {
                if (!c.ready) continue;
                ready++;
                if (c.choice.custom || c.choice.profile == Protocol.Profile.CUSTOM) custom++;
                else if (looksDmx(c.choice.rawName)) stockDmx++;
                else stockLedcar++;
            }
            int detected;
            synchronized (found) { detected = found.size(); }
            detected = Math.max(detected, ready);
            listener.onStatus(text, detected, ready, custom, stockLedcar, stockDmx);
        });
    }

    private void stopScan() {
        if (!scanning) return;
        scanning = false;
        try { if (scanner != null && permissionsGranted()) scanner.stopScan(scanCallback); }
        catch (SecurityException ignored) { }
    }

    private static boolean hasService(ScanRecord record, UUID uuid) {
        if (record == null || record.getServiceUuids() == null) return false;
        for (ParcelUuid id : record.getServiceUuids()) if (id != null && uuid.equals(id.getUuid())) return true;
        return false;
    }

    private static boolean looksCustom(String name) {
        String u = name == null ? "" : name.toUpperCase(Locale.ROOT);
        return u.contains("RGB HYBRID") || u.contains("HS JAYA") || u.contains("HS-JAYA");
    }

    private static boolean looksSupportedName(String name) {
        String u = name == null ? "" : name.toUpperCase(Locale.ROOT);
        return u.startsWith("LED") || looksCustom(name);
    }

    private static boolean looksDmx(String name) {
        return name != null && name.toUpperCase(Locale.ROOT).contains("LEDDMX");
    }

    private static Protocol.Profile classify(String name, boolean custom) {
        if (custom) return Protocol.Profile.CUSTOM;
        String u = name == null ? "" : name.toUpperCase(Locale.ROOT);
        if (u.startsWith("LEDCAR-02") || u.startsWith("LEDDMX-02") || u.startsWith("LEDDMX-04"))
            return Protocol.Profile.B_COMPACT;
        if (u.startsWith("LEDDMX") || u.startsWith("LEDCAR-01"))
            return Protocol.Profile.B_CLASSIC;
        if (u.startsWith("LEDCAR-00") || u.startsWith("LEDBLE"))
            return Protocol.Profile.A_GENERIC;
        if (u.startsWith("LEDCAR")) return Protocol.Profile.B_COMPACT;
        return Protocol.Profile.UNKNOWN;
    }

    private void message(String text) {
        main.post(() -> Toast.makeText(activity, text, Toast.LENGTH_SHORT).show());
    }
}
