/* HS JAYA's interface is bundled with the APK; all BLE I/O goes through HsNative. */
(function () {
  'use strict';
  function defaultAutoCollects(){
    const make=(prefix,lists)=>lists.map((modes,index)=>({id:prefix+'-'+(index+1),name:'Collect '+(index+1),modes:modes.slice(),visual:index%6}));
    return {
      led1:make('l1',[[28,53,120,206,15,44,67],[7,33,88,150,44,77],[1,2,5,27,60,101],[9,44,77,120,168],[11,22,33,66,99],[39,72,119,198],[]]),
      led2:make('l2',[[3,14,92],[7,33,88,150],[]]),
      all:make('all',[[1,10,20,30],[210,105,42]]),
      led3:make('l3',[[5,50,150,200],[18,19]]),
      led4:make('l4',[[100,101,102,103,104],[60,61],[9]])
    };
  }
  function normalizeAutoCollects(input){
    const fallback=defaultAutoCollects(),source=input&&typeof input==='object'?input:{};
    return Object.keys(fallback).reduce((result,key)=>{
      const rows=Array.isArray(source[key])?source[key]:fallback[key];
      result[key]=rows.slice(0,30).map((row,index)=>{
        const item=row&&typeof row==='object'?row:{};
        const modes=Array.isArray(item.modes)?item.modes.map(v=>Math.min(210,Math.max(1,Math.round(Number(v)||1)))).slice(0,40):[];
        return {id:String(item.id||key+'-'+(index+1)),name:'Collect '+(index+1),modes,visual:Math.abs(Math.round(Number(item.visual??index)))%6};
      });
      return result;
    },{});
  }
  const storeKey = 'hs-jaya-ui-v1';
  const defaults = {hue:0,rgb:[255,255,255],brightness:50,speed:75,remBrightness:75,remSpeed:60,channel:4,power:true,pixel:120,delay:2,subarea:1,quick:[null,null,null,null,null,null],modes:{welcome:4,standby:4,sein:4,rem:4,mundur:4,mode210:4},channelEnabled:[true,true,true,true],channelModes:{welcome:[4,4,4,4],standby:[4,4,4,4],sein:[4,4,4,4],rem:[4,4,4,4],mundur:[4,4,4,4],mode210:[4,4,4,4]},channelMode210:[4,4,4,4],channelBaseType:['rgb','rgb','rgb','rgb'],channelBaseRgb:[[255,255,255],[255,255,255],[255,255,255],[255,255,255]],localPassword:'',language:'id',autoModes:[true,true,true,true,true,true],autoProfile:'led1',autoCollects:defaultAutoCollects(),autoLastRun:null,autoLock:true,wallpaper:''};
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(storeKey) || '{}') || {}; } catch (_) { /* private storage may be unavailable */ }
  const state = Object.assign({}, defaults, saved);
  state.modes = Object.assign({}, defaults.modes, saved.modes || {});
  state.quick = Array.isArray(saved.quick) ? saved.quick.slice(0,6) : defaults.quick.slice();
  while (state.quick.length < 6) state.quick.push(null);
  if(!Array.isArray(state.rgb)||state.rgb.length!==3)state.rgb=null;
  if(!Array.isArray(state.channelEnabled)||state.channelEnabled.length!==4)state.channelEnabled=defaults.channelEnabled.slice();
  state.channelEnabled=state.channelEnabled.map(v=>v!==false);
  state.power=state.channelEnabled.some(Boolean);
  if(!Array.isArray(state.channelMode210)||state.channelMode210.length!==4)state.channelMode210=[0,1,2,3].map(()=>clamp(state.modes.mode210??4,0,210));
  state.channelMode210=state.channelMode210.map(v=>clamp(v,1,210));
  if(!state.channelModes||typeof state.channelModes!=='object')state.channelModes={};
  ['welcome','standby','sein','rem','mundur','mode210'].forEach(id=>{
    const specDefaults={welcome:[4,4,4,4],standby:[4,4,4,4],sein:[4,4,4,4],rem:[4,4,4,4],mundur:[4,4,4,4],mode210:state.channelMode210.slice()};
    let arr=Array.isArray(state.channelModes[id])&&state.channelModes[id].length===4?state.channelModes[id].slice():specDefaults[id].slice();
    const lo=1,hi=id==='mode210'?210:(id==='welcome'?50:10),fallback=clamp(state.modes[id]??4,lo,hi);
    arr=arr.map(v=>clamp(v,lo,hi));
    if(!saved.channelModes||!Array.isArray(saved.channelModes[id])){
      if(id==='mode210'&&Array.isArray(saved.channelMode210)&&saved.channelMode210.length===4)arr=state.channelMode210.slice();
      else arr=[fallback,fallback,fallback,fallback];
    }
    state.channelModes[id]=arr;
  });
  state.channelMode210=state.channelModes.mode210.slice();
  if(!Array.isArray(state.channelBaseType)||state.channelBaseType.length!==4)state.channelBaseType=defaults.channelBaseType.slice();
  if(!Array.isArray(state.channelBaseRgb)||state.channelBaseRgb.length!==4)state.channelBaseRgb=[0,1,2,3].map(()=>[255,255,255]);
  state.channelBaseRgb=state.channelBaseRgb.map(v=>Array.isArray(v)&&v.length===3?v.map(x=>clamp(x,0,255)):[255,255,255]);
  if(!Array.isArray(state.autoModes)||state.autoModes.length!==6)state.autoModes=[true,true,true,true,true,true];
  state.autoModes=state.autoModes.map(v=>v!==false);
  state.autoProfile=['led1','led2','all','led3','led4'].includes(state.autoProfile)?state.autoProfile:'led1';
  state.autoCollects=normalizeAutoCollects(saved.autoCollects);
  if(!['id','en','zh'].includes(state.language))state.language='id';
  state.subarea=[0,1,2].includes(Number(state.subarea))?Number(state.subarea):0;
  state.autoLock=state.autoLock!==false;
  if(typeof state.wallpaper!=='string'||!state.wallpaper.startsWith('data:image/'))state.wallpaper='';
  const content = document.getElementById('content');
  const drawer = document.getElementById('drawer');
  const backdrop = document.getElementById('drawer-backdrop');
  const toastBox = document.getElementById('toast');
  const nav = document.getElementById('navigation');
  const settingsShortcut = document.getElementById('settings-shortcut');
  const brandEl = document.querySelector('.brand');
  let page = 'home', ready = false, status = 'Belum terhubung', deviceName = '', deviceType = 'unknown', customFirmware = false, detectedCount = 0, connectedCount = 0, customConnectedCount = 0, stockLedcarCount = 0, stockDmxCount = 0, toastTimer, rulerTimer, lastSliderAt = 0, wheelLastAt = 0, wheelStart = null, dialStart = null, sliderGesture = null, pendingQuickSlot = null, channelSyncPending = false;
  let autoEditingId=null,autoSelectedModeIndex=null,autoRunningId=null,autoRunningProfile=null,autoRunningIndex=0,autoRunAll=false,autoRunAllIndex=0,autoTimer=null,autoPreviewTimer=null,autoWheelValue=28,autoWheelFrame=0,autoDeleteId=null;
  const channelCodes = [1,2,4,5,3];
  // Runtime snapshot is intentionally not loaded from localStorage. It is updated
  // only after this app instance actually sends an output to a channel, so ON can
  // never restore an old/default mode over the live hardware state.
  const channelRuntime = [0,1,2,3].map(i=>({enabled:state.channelEnabled[i],known:false,type:null,value:null,rgb:null}));
  const colors = ['#ff278e','#22d8fa','#2ee735','#ffc325','#bd55ff'];
  const presets = ['#ff0000','#00ff00','#0000ff','#ffffff','#ff7a00','#ff00ff'];
  const items = [
    ['home','Beranda','⌂'],['welcome','Mode Welcome','✧'],['standby','Mode Standby','◉'],
    ['sein','Mode Sein','↗'],['rem','Mode Rem','⏸'],['mundur','Mode Mundur','↶'],
    ['auto','Auto Mode','∞'],['subarea','Sub Area','▦'],['mode210','210 Mode','◌'],['bahasa','Bahasa / English / 中文','◎'],['settings','Pengaturan','⚙']
  ];
  const languageText = {
    en:{
      'Beranda':'Home','Mode Welcome':'Welcome Mode','Mode Standby':'Standby Mode','Mode Sein':'Turn Signal Mode','Mode Rem':'Brake Mode','Mode Mundur':'Reverse Mode','Auto Mode Custom':'Custom Auto Mode','Auto Mode':'Auto Mode','Sub Area':'Sub Area','Bahasa / English / 中文':'Language / English / 中文','Pengaturan':'Settings',
      'MODE WELLCOME':'WELCOME MODE','MODE STANDBY':'STANDBY MODE','MODE SEIN':'TURN SIGNAL MODE','MODE REM':'BRAKE MODE','MODE MUNDUR':'REVERSE MODE','AUTO MODE CUSTOM':'CUSTOM AUTO MODE','BAHASA':'LANGUAGE','Kelola perangkat dan koneksi':'Manage devices and connections','Atur efek saat aplikasi pertama kali dibuka':'Set the effect used when the application starts','Atur efek saat LED dalam keadaan on/standby':'Set the effect while the LED is on or on standby','Atur efek lampu sein kiri dan kanan':'Set the left and right turn-signal effects','Atur efek saat lampu rem aktif':'Set the effect while the brake light is active','Atur efek saat gigi mundur aktif':'Set the effect while reverse gear is active','Atur efek otomatis sesuai keinginan':'Configure automatic effects','Informasi aplikasi':'Application information','Kebijakan privasi':'Privacy policy','Atur atau ubah password aplikasi':'Set or change the application password','Pilih wallpaper aplikasi':'Choose the application wallpaper','Pilih bahasa aplikasi':'Choose the application language','KONTROL TAMBAHAN':'ADDITIONAL CONTROLS','Pilih mode firmware 1–210':'Select firmware mode 1–210',
      'DETEKSI OTOMATIS':'AUTO DETECTION','Belum terhubung':'Not connected','Belum terhubung · Hubungkan':'Not connected · Connect','CARI & HUBUNGKAN':'SEARCH & CONNECT','Cara menghubungkan':'How to connect','Profil perangkat dipilih otomatis. Informasi teknis Bluetooth disimpan secara internal.':'The device profile is selected automatically. Technical Bluetooth information is kept internal.','Perangkat yang tidak dikenali tidak akan menerima perintah.':'Unrecognized devices will not receive commands.',
      'Kotak REM dikirim':'Center box: REM CH3/CH4 sent','Panah kiri dikirim':'Left arrow sent','Panah kanan dikirim':'Right arrow sent','Semua SEN diaktifkan':'All turn signals activated','Panah kiri':'Left arrow','Kotak tengah':'Center box','Panah kanan':'Right arrow','Kembali':'Back','KONTROL K1–K3':'K1–K3 CONTROLS','Mengirim fungsi K1, K2, dan K3 asli dari firmware.':'Sends the original K1, K2, and K3 firmware functions.','Pemetaan WELCOME ke Mode 210':'Map WELCOME to Mode 210','Playlist tiga WELCOME':'Three-WELCOME playlist','Edit warna CH1–CH4':'Edit CH1–CH4 colors','Perintah K1 dikirim':'K1 command sent','Perintah K2 dikirim':'K2 command sent','Perintah K3 dikirim':'K3 command sent'
      ,'PILIH MODE':'SELECT MODE','SETTING PIXEL':'PIXEL SETTING','KECERAHAN':'BRIGHTNESS','KECEPATAN':'SPEED','SIMPAN':'SAVE','SIMPAN PENGATURAN':'SAVE SETTINGS','PILIH MODE AUTO':'SELECT AUTO MODE','SETTING AUTO MODE':'AUTO MODE SETTINGS','LAMBAT':'SLOW','CEPAT':'FAST','REDUP':'DIM','TERANG':'BRIGHT','JEDA ANTAR MODE':'DELAY BETWEEN MODES','Mode auto akan berjalan sesuai pengaturan di atas secara otomatis berurutan.':'Auto modes will run sequentially using the settings above.'
    },
    zh:{
      'Beranda':'主页','Mode Welcome':'欢迎模式','Mode Standby':'待机模式','Mode Sein':'转向灯模式','Mode Rem':'刹车模式','Mode Mundur':'倒车模式','Auto Mode Custom':'自定义自动模式','Auto Mode':'自动模式','Sub Area':'分区控制','Bahasa / English / 中文':'语言 / English / 中文','Pengaturan':'设置',
      'SETTINGS':'设置','ABOUT':'关于','OTHER':'其他','DEVICE & CONNECTION':'设备与连接','MODE WELLCOME':'欢迎模式','MODE STANDBY':'待机模式','MODE SEIN':'转向灯模式','MODE REM':'刹车模式','MODE MUNDUR':'倒车模式','AUTO MODE CUSTOM':'自定义自动模式','ABOUT RGB HYBRID':'关于 RGB HYBRID','PRIVACY POLICY':'隐私政策','PASSWORD':'密码','WALLPAPER':'壁纸','BAHASA':'语言','210 MODE':'210 模式','Kelola perangkat dan koneksi':'管理设备和连接','Atur efek saat aplikasi pertama kali dibuka':'设置应用启动时的灯效','Atur efek saat LED dalam keadaan on/standby':'设置 LED 开启或待机时的灯效','Atur efek lampu sein kiri dan kanan':'设置左右转向灯效果','Atur efek saat lampu rem aktif':'设置刹车灯激活时的效果','Atur efek saat gigi mundur aktif':'设置倒车时的灯效','Atur efek otomatis sesuai keinginan':'配置自动灯效','Informasi aplikasi':'应用信息','Kebijakan privasi':'隐私政策','Atur atau ubah password aplikasi':'设置或更改应用密码','Pilih wallpaper aplikasi':'选择应用壁纸','Pilih bahasa aplikasi':'选择应用语言','KONTROL TAMBAHAN':'附加控制','Pilih mode firmware 1–210':'选择固件模式 1–210',
      'DETEKSI OTOMATIS':'自动检测','Belum terhubung':'未连接','Belum terhubung · Hubungkan':'未连接 · 连接','CARI & HUBUNGKAN':'搜索并连接','Cara menghubungkan':'连接方法','Profil perangkat dipilih otomatis. Informasi teknis Bluetooth disimpan secara internal.':'设备配置会自动选择，蓝牙技术信息仅在内部保存。','Perangkat yang tidak dikenali tidak akan menerima perintah.':'无法识别的设备不会接收命令。',
      'Kotak REM dikirim':'中间方框：已发送 CH3/CH4 刹车控制','Panah kiri dikirim':'已发送左箭头控制','Panah kanan dikirim':'已发送右箭头控制','Semua SEN diaktifkan':'已启用全部转向灯','Panah kiri':'左箭头','Kotak tengah':'中间方框','Panah kanan':'右箭头','Kembali':'返回','KONTROL K1–K3':'K1–K3 控制','Mengirim fungsi K1, K2, dan K3 asli dari firmware.':'发送固件原有的 K1、K2 和 K3 功能。','Pemetaan WELCOME ke Mode 210':'将 WELCOME 映射到 210 模式','Playlist tiga WELCOME':'三个 WELCOME 播放列表','Edit warna CH1–CH4':'编辑 CH1–CH4 颜色','Perintah K1 dikirim':'K1 指令已发送','Perintah K2 dikirim':'K2 指令已发送','Perintah K3 dikirim':'K3 指令已发送'
      ,'PILIH MODE':'选择模式','SETTING PIXEL':'像素设置','KECERAHAN':'亮度','KECEPATAN':'速度','SIMPAN':'保存','SIMPAN PENGATURAN':'保存设置','PILIH MODE AUTO':'选择自动模式','SETTING AUTO MODE':'自动模式设置','LAMBAT':'慢','CEPAT':'快','REDUP':'暗','TERANG':'亮','JEDA ANTAR MODE':'模式间隔','Mode auto akan berjalan sesuai pengaturan di atas secara otomatis berurutan.':'自动模式将按照以上设置依次运行。'
    }
  };
  function applyLanguage(root){
    const lang=['id','en','zh'].includes(state.language)?state.language:'id';
    document.documentElement.lang=lang==='zh'?'zh-CN':lang;
    if(lang==='id')return;
    const map=languageText[lang]||{},walker=document.createTreeWalker(root||document,NodeFilter.SHOW_TEXT),nodes=[];
    while(walker.nextNode())nodes.push(walker.currentNode);
    nodes.forEach(node=>{
      const raw=node.nodeValue||'',trimmed=raw.trim();
      if(!trimmed)return;
      let translated=map[trimmed];
      if(!translated)return;
      node.nodeValue=raw.replace(trimmed,translated);
    });
    document.querySelectorAll('[aria-label]').forEach(el=>{const label=el.getAttribute('aria-label');if(map[label])el.setAttribute('aria-label',map[label]);});
  }
  function translatedText(text){const map=languageText[state.language]||{};return map[text]||text;}
  const autoLanguageText={
    id:{list:'DAFTAR COLLECT',available:'collect tersedia',modes:'Mode',empty:'Belum ada mode',edit:'EDIT',editing:'EDITING',remove:'HAPUS',removeMode:'HAPUS MODE',add:'ADD MODE',addCollect:'ADD COLLECT',addHint:'Tekan EDIT pada collect dulu',addReady:'Tambah mode ke Collect',newCollectHint:'Buat Collect baru',createHint:'Buat Collect 1',created:'Collect baru dibuat dan siap diedit',modeRemoved:'Mode dihapus',settings:'PENGATURAN AUTO',settingsHint:'Atur parameter jalannya collect',defaults:'Reset ke default',speed:'Kecepatan',brightness:'Kecerahan',slow:'Lambat',fast:'Cepat',dim:'Redup',bright:'Terang',wheel:'PILIHAN MODE',runAll:'JALANKAN SEMUA',stopAll:'HENTIKAN SEMUA',reset:'RESET',save:'SIMPAN PENGATURAN',deleteTitle:'Hapus Collect?',deleteBody:'Isi mode collect ini ikut terhapus.',cancel:'BATAL',collectEmpty:'Collect kosong',selectEdit:'Tekan EDIT pada Collect dulu',saved:'Pengaturan AUTO tersimpan',running:'Menjalankan',runningAll:'Menjalankan semua Collect berurutan',stopped:'AUTO dihentikan',deleted:'Collect dihapus',resetDone:'Kembali ke mode pertama',noneRunning:'Belum ada Collect berjalan'},
    en:{list:'COLLECT LIST',available:'collects available',modes:'Modes',empty:'No modes yet',edit:'EDIT',editing:'EDITING',remove:'DELETE',removeMode:'DELETE MODE',add:'ADD MODE',addCollect:'ADD COLLECT',addHint:'Tap EDIT on a collect first',addReady:'Add mode to Collect',newCollectHint:'Create a new Collect',createHint:'Create Collect 1',created:'New Collect created and ready to edit',modeRemoved:'Mode deleted',settings:'AUTO SETTINGS',settingsHint:'Set how each collect runs',defaults:'Reset to default',speed:'Speed',brightness:'Brightness',slow:'Slow',fast:'Fast',dim:'Dim',bright:'Bright',wheel:'MODE SELECTION',runAll:'RUN ALL',stopAll:'STOP ALL',reset:'RESET',save:'SAVE SETTINGS',deleteTitle:'Delete Collect?',deleteBody:'All modes in this collect will also be deleted.',cancel:'CANCEL',collectEmpty:'Collect is empty',selectEdit:'Tap EDIT on a Collect first',saved:'AUTO settings saved',running:'Running',runningAll:'Running all Collects in sequence',stopped:'AUTO stopped',deleted:'Collect deleted',resetDone:'Back to first mode',noneRunning:'No Collect is running'},
    zh:{list:'COLLECT 列表',available:'个 Collect 可用',modes:'个模式',empty:'尚未添加模式',edit:'编辑',editing:'正在编辑',remove:'删除',removeMode:'删除模式',add:'添加模式',addCollect:'添加 COLLECT',addHint:'请先点击 Collect 的编辑按钮',addReady:'添加模式到 Collect',newCollectHint:'创建新的 Collect',createHint:'创建 Collect 1',created:'新的 Collect 已创建，可以开始编辑',modeRemoved:'模式已删除',settings:'自动模式设置',settingsHint:'设置 Collect 的运行参数',defaults:'恢复默认',speed:'速度',brightness:'亮度',slow:'慢',fast:'快',dim:'暗',bright:'亮',wheel:'模式选择',runAll:'全部运行',stopAll:'全部停止',reset:'重置',save:'保存设置',deleteTitle:'删除 Collect？',deleteBody:'该 Collect 中的全部模式也会被删除。',cancel:'取消',collectEmpty:'Collect 为空',selectEdit:'请先点击 Collect 的编辑按钮',saved:'自动模式设置已保存',running:'正在运行',runningAll:'正在依次运行全部 Collect',stopped:'自动模式已停止',deleted:'Collect 已删除',resetDone:'已返回第一个模式',noneRunning:'当前没有运行的 Collect'}
  };
  function autoText(key){return (autoLanguageText[state.language]||autoLanguageText.id)[key]||key;}
  function languageModeOverlay(id){
    if(state.language==='id')return '';
    const hasPixel=id==='welcome'||id==='standby'||id==='mode210';
    const hasPalette=id==='mundur'||id==='rem';
    const palette=hasPalette?'<div class="i18n-palette-labels">'+[1,2,3,4,5,6].map((n,i)=>'<span style="--i:'+i+'">'+(state.language==='zh'?'颜色 ':'COLOR ')+n+'</span>').join('')+'</div>':'';
    return '<div class="i18n-mode-layer '+id+'" aria-hidden="true"><span class="i18n-pick">'+translatedText('PILIH MODE')+'</span>'+(hasPixel?'<span class="i18n-pixel">'+translatedText('SETTING PIXEL')+'</span>':'')+palette+'<span class="i18n-save">'+translatedText('SIMPAN')+'</span></div>';
  }
  function languageAutoOverlay(){
    if(state.language==='id')return '';
    return '<div class="i18n-auto-layer" aria-hidden="true"><span class="auto-pick">'+translatedText('PILIH MODE AUTO')+'</span><span class="auto-setting">'+translatedText('SETTING AUTO MODE')+'</span><span class="auto-speed-title">'+translatedText('KECEPATAN')+'</span><span class="auto-slow">'+translatedText('LAMBAT')+'</span><span class="auto-fast">'+translatedText('CEPAT')+'</span><span class="auto-bright-title">'+translatedText('KECERAHAN')+'</span><span class="auto-dim">'+translatedText('REDUP')+'</span><span class="auto-bright">'+translatedText('TERANG')+'</span><span class="auto-delay-title">'+translatedText('JEDA ANTAR MODE')+'</span><span class="auto-info">'+translatedText('Mode auto akan berjalan sesuai pengaturan di atas secara otomatis berurutan.')+'</span><span class="auto-save">'+translatedText('SIMPAN PENGATURAN')+'</span></div>';
  }
  const specs = {
    welcome:{title:'WELCOME',min:0,max:50,cmd:0x18,firmwareGlobal:true,pixel:true},
    standby:{title:'STANDBY',min:0,max:10,local:true,pixel:true},
    sein:{title:'SEIN',min:0,max:10,cmd:0x19,firmwareGlobal:true,palette:true},
    rem:{title:'REM',min:0,max:10,cmd:0x1A,firmwareGlobal:true,palette:true},
    mundur:{title:'MUNDUR',min:0,max:10,cmd:0x1D,firmwareGlobal:true,palette:true},
    mode210:{title:'210 MODE',min:0,max:210,cmd:0x03,pixel:true,perChannel:true}
  };

  function clamp(v,lo,hi){return Math.min(hi,Math.max(lo,Number(v)||0));}
  function persist(){try{localStorage.setItem(storeKey,JSON.stringify(state));}catch(_) { /* UI still works */ }}
  function applyWallpaper(){
    document.body.classList.toggle('custom-wallpaper',!!state.wallpaper);
    document.body.style.setProperty('--custom-wallpaper',state.wallpaper?'url("'+state.wallpaper+'")':'none');
  }
  function flash(message){toastBox.textContent=translatedText(message);toastBox.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastBox.classList.remove('show'),2700);}
  function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function send(method,...args){
    if(!ready){flash('Sambungkan modul LED melalui tombol koneksi dulu');return false;}
    // Native multi-device router translates this logical command separately for
    // each connected controller. Never rewrite channel/profile bytes in JS.
    try {console.info('[BLE COMMAND]',connectedCount+' device',method,...args);window.HsNative[method](...args);return true;} catch (_) {flash('Koneksi aplikasi belum tersedia');return false;}
  }
  function updateConnection(){
    const target=document.getElementById('connection');
    target.innerHTML='<button type="button" class="connect-button '+(ready?'ready':'')+'" id="connect" aria-label="'+(ready?'Putuskan koneksi':'Cari dan hubungkan modul LED')+'">'+escapeHtml(status)+(ready?' · Putus':' · Hubungkan')+'</button>';
    document.querySelectorAll('[data-ble-status]').forEach(el=>el.textContent=status);
    document.querySelectorAll('[data-device-action]').forEach(el=>el.textContent=ready?'SCAN ULANG':'CARI & HUBUNGKAN OTOMATIS');
    document.querySelectorAll('[data-ble-dot]').forEach(el=>el.classList.toggle('connected',ready));
    applyLanguage(document);
  }
  window.hsBleMultiStatus=function(text,detected,count,customCount,ledcarCount,dmxCount){
    const wasReady=ready,previousType=deviceType;
    detectedCount=Math.max(0,Number(detected)||0);
    connectedCount=Math.max(0,Number(count)||0);
    customConnectedCount=Math.max(0,Number(customCount)||0);
    stockLedcarCount=Math.max(0,Number(ledcarCount)||0);
    stockDmxCount=Math.max(0,Number(dmxCount)||0);
    ready=connectedCount>0;
    customFirmware=customConnectedCount>0;
    deviceName=ready?'RGB HYBRID':'';
    if(!ready)deviceType='unknown';
    else if(stockDmxCount===connectedCount)deviceType='dmx';
    else if(stockLedcarCount===connectedCount)deviceType='ledcar';
    else if(customConnectedCount===connectedCount)deviceType='custom';
    else deviceType='mixed';
    status=String(text|| (ready?(connectedCount+' perangkat terhubung'):'Belum terhubung'));
    // If there is no custom controller in the connected set, independent LED1-4
    // cannot be addressed; keep the UI on ALL. Mixed sets retain independent
    // controls for the custom modules while stock modules ignore channel packets.
    if(ready&&customConnectedCount===0)state.channel=4;
    if(ready&&deviceType==='dmx'&&page==='mode210')page='subarea';
    if(previousType!==deviceType||page==='settings'||page==='device')render();else updateConnection();
    if(ready&&!wasReady&&customConnectedCount>0)reapplyChannelPowerState();
  };
  // Backward-compatible callback for older native builds.
  window.hsBleStatus=function(text,isReady,name,type,isCustom){
    const n=isReady?1:0,c=isReady&&isCustom===true?1:0;
    const t=String(type);
    window.hsBleMultiStatus(text,n,n,c,isReady&&t==='ledcar'&&!c?1:0,isReady&&t==='dmx'&&!c?1:0);
  };
  function setDrawer(open){drawer.classList.toggle('open',open);drawer.setAttribute('aria-hidden',String(!open));backdrop.hidden=!open;}
  function dmxConnected(){return ready&&stockDmxCount===connectedCount&&connectedCount>0;}
  function renderLinks(){document.getElementById('drawer-links').innerHTML=items.filter(([id])=>!(id==='mode210'&&dmxConnected())).map(([id,label,icon])=>{if(id==='subarea')label=ready&&deviceType==='ledcar'?'K1–K3':'Sub Area / K1–K3';return '<a href="#'+id+'" data-page="'+id+'" class="'+(page===id?'active':'')+'">'+icon+' &nbsp;'+label+'</a>';}).join('');}
  function navigate(next){if(!['home','settings','device','auto','subarea','bahasa','password','about','privacy','wallpaper'].includes(next)&&!specs[next])return;if(next==='mode210'&&dmxConnected()){flash('210 MODE tidak didukung perangkat ini');return;}page=next;setDrawer(false);render();window.scrollTo(0,0);}
  window.hsGoBack=function(){if(drawer.classList.contains('open'))setDrawer(false);else if(page==='home')flash('Gunakan tombol kembali sekali lagi untuk keluar');else navigate(['device','subarea','bahasa','password','about','privacy','wallpaper'].includes(page)?'settings':'home');};
  function heading(word){return '<div class="mode-sub-brand"><span class="mini-brand-mark">H</span><span><b>HS JAYA LIGHTING</b><small>Hybrid Innovation</small></span></div>'; }
  function slider(which,label,icon,val,pink=false){return '<div class="slider-row '+(pink?'pink':'')+'"><span class="slider-icon" aria-hidden="true">'+icon+'</span><div class="slider-main"><label for="'+which+'">'+label+' <output id="'+which+'-value">'+val+'%</output></label><input id="'+which+'" type="range" min="1" max="100" value="'+val+'" data-slider="'+which+'" aria-label="'+label+'"></div><span class="slider-end" aria-hidden="true">'+(pink?'♧':'☼')+'</span></div>';}
  function channelPicks(){return '<div class="channel-row" aria-label="Pilih kanal warna dasar">'+['LED 1','LED 2','LED 3','LED 4','ALL'].map((x,i)=>{let on=i===4?state.channelEnabled.some(Boolean):state.channelEnabled[i];return '<button class="channel-pick '+(state.channel===i?'active ':'')+(on?'channel-on':'channel-off')+'" data-channel="'+i+'" type="button"><span>'+x+'</span><i aria-hidden="true"></i></button>';}).join('')+'</div>';}
  function targetChannels(selection){return selection===4?[0,1,2,3]:[clamp(selection,0,3)];}
  function allChannelsOn(){return state.channelEnabled.every(Boolean);}
  function anyChannelsOn(){return state.channelEnabled.some(Boolean);}
  function pageModeArray(id){
    if(!state.channelModes[id])state.channelModes[id]=[state.modes[id],state.modes[id],state.modes[id],state.modes[id]];
    return state.channelModes[id];
  }
  function modeMin(id,selection){
    const pick=selection===undefined?state.channel:selection;
    return pick===4&&(id==='welcome'||id==='mode210')?0:1;
  }
  function selectedModeValue(id,selection){
    const arr=pageModeArray(id),pick=selection===undefined?state.channel:selection;
    if(pick<4)return arr[pick];
    if((id==='welcome'||id==='mode210')&&state.modes[id]===0)return 0;
    const first=arr[0];return arr.every(v=>v===first)?first:state.modes[id];
  }
  function setSelectedModeValue(id,value,selection){
    const arr=pageModeArray(id),pick=selection===undefined?state.channel:selection;
    // AUTO belongs to the ALL ring only. Keep the four per-LED cards on their
    // last numeric modes so AUTO never appears inside LED1-LED4.
    if(!(pick===4&&value===0&&(id==='welcome'||id==='mode210'))){
      targetChannels(pick).forEach(i=>arr[i]=value);
    }
    state.modes[id]=value;
    if(id==='mode210')state.channelMode210=arr.slice();
  }
  function cardModeValue(i){
    const arr=pageModeArray(page);
    if(i<4)return arr[i];
    return 'ALL';
  }
  function rememberRgb(rgb,selection){targetChannels(selection).forEach(i=>{state.channelBaseType[i]='rgb';state.channelBaseRgb[i]=rgb.slice(0,3);});}
  function rememberMode210(value,selection){
    if(!(selection===4&&value===0))targetChannels(selection).forEach(i=>{state.channelBaseType[i]='mode210';state.channelMode210[i]=value;state.channelModes.mode210[i]=value;});
    state.modes.mode210=value;
  }
  function rememberRuntimeRgb(rgb,selection){targetChannels(selection).forEach(i=>{channelRuntime[i].known=true;channelRuntime[i].type='rgb';channelRuntime[i].rgb=rgb.slice(0,3);channelRuntime[i].value=null;});}
  function rememberRuntimeMode210(value,selection){targetChannels(selection).forEach(i=>{channelRuntime[i].known=true;channelRuntime[i].type='mode210';channelRuntime[i].value=value;channelRuntime[i].rgb=null;});}
  function restoreChannel(index){
    const i=clamp(index,0,3),snapshot=channelRuntime[i],code=channelCodes[i];
    if(!snapshot.known)return true;
    if(snapshot.type==='mode210')return send('send',0x03,snapshot.value===0?0xFF:snapshot.value,code);
    if(snapshot.type==='rgb'&&Array.isArray(snapshot.rgb))return send('rgb',snapshot.rgb[0],snapshot.rgb[1],snapshot.rgb[2],code);
    return true;
  }
  function sendRgbSelection(rgb,selection){
    const live=targetChannels(selection).filter(i=>state.channelEnabled[i]);
    if(!live.length){flash('Channel yang dipilih sedang OFF');return false;}
    if(selection===4&&live.length===4){const ok=send('rgb',rgb[0],rgb[1],rgb[2],3);if(ok)rememberRuntimeRgb(rgb,4);return ok;}
    for(const i of live){if(!send('rgb',rgb[0],rgb[1],rgb[2],channelCodes[i]))return false;rememberRuntimeRgb(rgb,i);}
    return true;
  }
  function sendMode210Selection(value,selection){
    if(dmxConnected()){flash('210 MODE tidak didukung perangkat yang terhubung');return false;}
    const live=targetChannels(selection).filter(i=>state.channelEnabled[i]);
    if(!live.length){flash('Channel yang dipilih sedang OFF');return false;}
    const wireValue=value===0?0xFF:value;
    if(selection===4&&live.length===4){const ok=send('send',0x03,wireValue,3);if(ok)rememberRuntimeMode210(value,4);return ok;}
    for(const i of live){if(!send('send',0x03,wireValue,channelCodes[i]))return false;rememberRuntimeMode210(value,i);}
    return true;
  }
  function sendPageModeSelection(value,selection){
    const spec=specs[page];if(!spec||spec.local)return true;
    if(page==='mode210')return sendMode210Selection(value,selection);
    // Firmware saat ini membaca Welcome/Sein/Rem sebagai menu global. UI tetap menyimpan
    // angka per LED agar kartu/scroll independen, tetapi paket BLE mengikuti firmware asli.
    if(spec.firmwareGlobal)return send('send',spec.cmd,value,3);
    const live=targetChannels(selection).filter(i=>state.channelEnabled[i]);
    if(!live.length){flash('Channel yang dipilih sedang OFF');return false;}
    if(selection===4&&live.length===4)return send('send',spec.cmd,value,3);
    for(const i of live)if(!send('send',spec.cmd,value,channelCodes[i]))return false;
    return true;
  }
  function reapplyChannelPowerState(){
    if(!ready||customConnectedCount===0)return;
    channelSyncPending=true;
    state.channelEnabled.forEach((on,i)=>{
      channelRuntime[i].enabled=on;
      send('send',0x04,on?1:0,channelCodes[i]);
    });
    // The native BLE queue transmits every packet in order. Keep the logical
    // initialization flag until all four per-channel packets have drained.
    setTimeout(()=>{channelSyncPending=false;},620);
  }
  function refreshChannelVisuals(){
    document.querySelectorAll('[data-mode-card-channel]').forEach(card=>{
      const i=Number(card.dataset.modeCardChannel),mixed=i===4&&anyChannelsOn()&&!allChannelsOn(),on=i===4?allChannelsOn():state.channelEnabled[i];
      card.classList.toggle('channel-on',on);card.classList.toggle('channel-off',!on&&!mixed);card.classList.toggle('channel-mixed',mixed);
      const toggle=card.querySelector('[data-channel-toggle]');if(toggle){toggle.classList.toggle('on',on);toggle.classList.toggle('mixed',mixed);toggle.setAttribute('aria-pressed',String(on));const em=toggle.querySelector('em');if(em)em.textContent=mixed?'MIX':(on?'ON':'OFF');}
    });
    document.querySelectorAll('.channel-pick').forEach(btn=>{const i=Number(btn.dataset.channel),on=i===4?anyChannelsOn():state.channelEnabled[i];btn.classList.toggle('channel-on',on);btn.classList.toggle('channel-off',!on);btn.classList.toggle('active',state.channel===i);});
  }
  function toggleSoftChannel(index){
    const all=index===4;
    if(!all&&ready&&customConnectedCount===0){flash('LED1–4 independen memerlukan minimal satu RGB HYBRID custom. Gunakan ALL untuk modul bawaan.');return;}
    const next=all?!allChannelsOn():!state.channelEnabled[index],targets=all?[0,1,2,3]:[clamp(index,0,3)];
    targets.forEach(i=>state.channelEnabled[i]=next);
    targets.forEach(i=>channelRuntime[i].enabled=next);
    state.power=anyChannelsOn();
    if(ready){
      if(!all){
        // Individual LED must never use ALL/global. Firmware keeps the mode
        // engine running behind the output mask, so ON must not resend the
        // mode: resending would restart only this channel's effect phase.
        send('send',0x04,next?1:0,channelCodes[index]);
      }else if(!next){
        // Global OFF is reserved for the ALL switch.
        send('send',0x04,0,channelCodes[4]);
      }else{
        // Global ON reaches every stock/custom module. Custom channels are then
        // restored independently; stock devices ignore those channel packets.
        send('send',0x04,1,channelCodes[4]);
        targets.forEach(i=>restoreChannel(i));
      }
    }
    persist();refreshChannelVisuals();refreshRefVisuals();
    const powerButton=document.getElementById('power');if(powerButton){powerButton.classList.toggle('on',state.power);powerButton.setAttribute('aria-label','Lampu '+(state.power?'mati':'nyala'));}
    flash(all?(next?'Semua LED ON':'Semua LED OFF'):('LED '+(index+1)+' '+(next?'ON':'OFF')));
  }
  function selectChannel(index){
    index=clamp(index,0,4);
    if(ready&&customConnectedCount===0&&index!==4){flash('Modul bawaan menggunakan kontrol ALL.');index=4;}
    state.channel=index;persist();document.querySelectorAll('[data-channel]').forEach(btn=>btn.classList.toggle('active',Number(btn.dataset.channel)===state.channel));refreshRefVisuals();
  }
  function selectModeChannel(index){
    const spec=specs[page];if(!spec)return;
    index=clamp(index,0,4);
    if(ready&&customConnectedCount===0&&index!==4){flash('Modul bawaan menggunakan kontrol ALL.');index=4;}
    state.channel=index;
    const v=clamp(selectedModeValue(page,state.channel),modeMin(page,state.channel),spec.max);
    if(state.channel<4)state.modes[page]=v;
    persist();
    document.querySelectorAll('[data-mode-card-channel]').forEach(card=>card.classList.toggle('active',Number(card.dataset.modeCardChannel)===state.channel));
    const output=document.getElementById('dial-number');if(output)output.innerHTML=sevenSeg(v);
    refreshCurvedTicks();refreshRefVisuals();
    scrollRuler(v,'auto');
  }
  function rgbForHue(h){
    const n=((360-Math.round(h))%360+360)%360;
    const f=(k)=>{let x=(k+n/60)%6;return Math.round(255*(1-Math.max(0,Math.min(x,4-x,1))));};
    return [f(5),f(3),f(1)];
  }
  function currentRgb(){return state.rgb||rgbForHue(state.hue);}
  function currentHex(){return '#'+currentRgb().map(x=>x.toString(16).padStart(2,'0')).join('');}
  function flame(){return '<svg class="flame-art" viewBox="0 0 82 100" aria-hidden="true"><path class="flame-outer" d="M42 1 C47 15 34 24 32 35 C30 43 36 49 39 52 C27 49 23 40 23 31 C16 42 18 52 17 58 C8 62 5 71 8 80 C13 94 26 100 42 100 C59 100 72 90 75 74 C77 61 68 50 60 45 C61 56 56 61 50 63 C58 42 47 24 42 1 Z" fill="currentColor" opacity=".85"><animate class="flame-shape-anim" attributeName="d" begin="indefinite" dur=".9s" fill="remove" values="M42 1 C47 15 34 24 32 35 C30 43 36 49 39 52 C27 49 23 40 23 31 C16 42 18 52 17 58 C8 62 5 71 8 80 C13 94 26 100 42 100 C59 100 72 90 75 74 C77 61 68 50 60 45 C61 56 56 61 50 63 C58 42 47 24 42 1 Z;M42 1 C40 16 29 24 34 38 C38 46 43 49 42 55 C30 51 28 41 28 31 C18 39 19 52 15 61 C8 67 7 76 12 84 C20 97 31 100 43 100 C60 100 71 88 73 72 C75 60 67 52 58 45 C62 58 56 64 49 64 C55 42 50 20 42 1 Z;M42 1 C51 17 43 28 38 38 C34 46 37 52 40 57 C29 55 20 47 22 33 C13 45 17 55 18 63 C9 64 5 73 9 82 C15 96 28 100 42 100 C58 100 73 91 76 76 C79 64 70 48 62 43 C61 55 58 61 52 65 C64 41 51 23 42 1 Z;M42 1 C47 15 34 24 32 35 C30 43 36 49 39 52 C27 49 23 40 23 31 C16 42 18 52 17 58 C8 62 5 71 8 80 C13 94 26 100 42 100 C59 100 72 90 75 74 C77 61 68 50 60 45 C61 56 56 61 50 63 C58 42 47 24 42 1 Z"/></path><path class="flame-core" d="M40 35 C44 45 37 52 32 59 C27 66 24 73 26 80 C28 89 34 95 43 96 C52 96 60 89 61 80 C62 72 57 66 53 61 C51 70 47 74 43 75 C47 62 42 49 40 35 Z" fill="white" opacity=".78"><animate class="flame-shape-anim" attributeName="d" begin="indefinite" dur=".9s" fill="remove" values="M40 35 C44 45 37 52 32 59 C27 66 24 73 26 80 C28 89 34 95 43 96 C52 96 60 89 61 80 C62 72 57 66 53 61 C51 70 47 74 43 75 C47 62 42 49 40 35 Z;M39 36 C46 44 42 52 35 60 C29 67 27 74 28 81 C30 89 36 94 44 95 C53 94 60 87 59 79 C58 71 54 66 50 62 C50 70 46 75 42 77 C45 63 41 49 39 36 Z;M42 34 C42 45 34 53 30 60 C26 67 24 74 27 82 C30 91 37 96 45 95 C54 94 61 87 62 78 C63 71 58 64 55 59 C52 69 49 73 44 74 C49 61 45 48 42 34 Z;M40 35 C44 45 37 52 32 59 C27 66 24 73 26 80 C28 89 34 95 43 96 C52 96 60 89 61 80 C62 72 57 66 53 61 C51 70 47 74 43 75 C47 62 42 49 40 35 Z"/></path><path class="flame-inner" d="M40 63 C43 70 36 76 33 81 C30 87 34 94 42 95 C50 95 55 88 52 81 C50 76 47 73 45 70 C45 77 42 80 39 81 C42 73 41 67 40 63 Z" fill="currentColor"><animate class="flame-shape-anim" attributeName="d" begin="indefinite" dur=".9s" fill="remove" values="M40 63 C43 70 36 76 33 81 C30 87 34 94 42 95 C50 95 55 88 52 81 C50 76 47 73 45 70 C45 77 42 80 39 81 C42 73 41 67 40 63 Z;M39 64 C45 70 39 76 35 82 C32 88 36 94 43 94 C51 94 54 87 51 81 C49 76 46 74 44 71 C44 78 41 81 38 82 C42 74 40 68 39 64 Z;M42 62 C43 69 35 75 32 81 C29 87 34 95 42 95 C50 95 56 89 53 81 C51 75 48 72 46 68 C46 76 43 79 40 80 C44 72 43 66 42 62 Z;M40 63 C43 70 36 76 33 81 C30 87 34 94 42 95 C50 95 55 88 52 81 C50 76 47 73 45 70 C45 77 42 80 39 81 C42 73 41 67 40 63 Z"/></path></svg>';}
  function home(){
    let rgb=currentRgb();
    return '<div class="home-stage"><div class="hue-shell"><div class="hue-wheel" id="hue-wheel" role="slider" aria-label="Roda pilih warna" aria-valuemin="0" aria-valuemax="359" aria-valuenow="'+state.hue+'" tabindex="0"><div class="hue-handle" id="hue-handle"></div><div class="hue-center">⌖</div></div></div><div class="home-side"><button type="button" class="power '+(state.power?'on':'')+'" id="power" aria-label="Lampu '+(state.power?'mati':'nyala')+'"><svg class="power-glyph" viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M24 5v18"/><path d="M13.2 12.2a17 17 0 1 0 21.6 0"/></svg></button><div class="rgb-readout">'+rgb.map((v,i)=>'<div class="rgb-line"><b>'+['R','G','B'][i]+'</b><output id="rgb-'+i+'">'+v+'</output></div>').join('')+'</div><div class="mini-hue" aria-hidden="true"></div></div></div>'+ 
      '<section class="glass sliders">'+slider('brightness','BRIGHTNESS','☼',state.brightness)+slider('speed','SPEED','◉',state.speed,true)+'</section>'+ 
      '<section class="glass panel"><p class="section-label">PRESET COLOR</p><div class="preset-grid">'+presets.map((c,i)=>'<button type="button" class="preset" data-preset="'+i+'" style="--flame:'+c+'" aria-label="Pilih warna '+(i+1)+'">'+flame()+'</button>').join('')+'</div></section>'+ 
      '<section class="glass panel"><p class="section-label">QUICK SAVE</p><div class="save-grid">'+state.quick.map((v,i)=>'<button type="button" data-quick="'+i+'" class="save-slot '+(v?'saved':'')+'" style="--saved:'+(v||'transparent')+'" aria-label="'+(v?'Gunakan':'Simpan')+' warna '+(i+1)+'">'+(v?'':'+')+'</button>').join('')+'</div><p class="tiny-hint">Ketuk +, pilih warna di lingkaran, lalu lepas jari untuk menyimpan. Ketuk warna tersimpan untuk memakai.</p></section>';
  }
  function cardStyle(i){
    const fills=['rgba(255,39,142,.48)','rgba(34,216,250,.46)','rgba(46,231,53,.42)','rgba(255,195,37,.44)','rgba(189,85,255,.46)'];
    const glows=['rgba(255,39,142,.72)','rgba(34,216,250,.70)','rgba(46,231,53,.65)','rgba(255,195,37,.68)','rgba(189,85,255,.70)'];
    return '--card-color:'+colors[i]+';--card-fill:'+fills[i]+';--card-glow:'+glows[i];
  }
  function modeCards(spec){
    let which=state.channel;
    return '<div class="mode-cards">'+['LED 1','LED 2','LED 3','LED 4','ALL'].map((label,i)=>{
      let mixed=i===4&&anyChannelsOn()&&!allChannelsOn(),on=i===4?allChannelsOn():state.channelEnabled[i],value=cardModeValue(i);
      return '<div class="mode-card '+(which===i?'active ':'')+(on?'channel-on ':'')+(!on&&!mixed?'channel-off ':'')+(mixed?'channel-mixed ':'')+'" data-mode-card-channel="'+i+'" style="'+cardStyle(i)+'"><button type="button" class="mode-card-select" data-mode-channel="'+i+'"><strong>'+label+'</strong><small>MODE</small><b>'+value+'</b></button><button type="button" class="channel-toggle '+(on?'on ':'')+(mixed?'mixed':'')+'" data-channel-toggle="'+i+'" aria-label="'+label+' '+(mixed?'campuran':(on?'ON':'OFF'))+'" aria-pressed="'+on+'"><span aria-hidden="true"></span><em>'+(mixed?'MIX':(on?'ON':'OFF'))+'</em></button></div>';
    }).join('')+'</div>';
  }
  function tickLabel(value){return value===0&&state.channel===4&&(page==='welcome'||page==='mode210')?'AUTO':String(value);}
  function curvedTicks(spec){
    const min=modeMin(page,state.channel),selected=clamp(selectedModeValue(page,state.channel),min,spec.max);
    let html='';
    for(let off=-4;off<=4;off++){
      const value=selected+off;if(value<min||value>spec.max)continue;
      let hue=((value-min)*31)%360;
      html+='<button type="button" class="orbit-tick off-'+(off<0?'m'+Math.abs(off):'p'+off)+(off===0?' selected':'')+'" data-mode-value="'+value+'" style="--tick-color:hsl('+hue+' 95% 62%)">'+tickLabel(value)+'</button>';
    }
    return html;
  }
  function refreshCurvedTicks(){const host=document.getElementById('orbit-ticks');if(host&&specs[page])host.innerHTML=curvedTicks(specs[page]);}
  function modeView(spec){
    let raw=selectedModeValue(page,state.channel);let value=clamp(raw,modeMin(page,state.channel),spec.max);state.modes[page]=value;if(state.channel<4)pageModeArray(page)[state.channel]=value;if(page==='mode210')state.channelMode210=pageModeArray('mode210').slice();
    let info=spec.local?'<div class="glass notice"><strong>Tampilan independen per LED.</strong> Nilai '+spec.title+' disimpan terpisah LED1–LED4 di aplikasi; firmware saat ini belum punya perintah BLE menu '+spec.title+'.</div>':(spec.firmwareGlobal?'<div class="glass notice">Kartu dan angka LED1–LED4 disimpan independen di aplikasi. Perintah '+spec.title+' tetap dikirim global mengikuti firmware saat ini.</div>':'<div class="glass notice">Pilih LED 1–4 atau ALL sebelum menggeser. Hanya kartu yang dipilih yang berubah; Mode 210 dikirim ke kanal itu.</div>');
    let pixel=spec.pixel?'<section class="glass panel"><p class="panel-title">SETTING PIXEL</p><div class="setting-input"><input type="text" id="pixel" inputmode="numeric" pattern="[0-9]*" maxlength="4" autocomplete="off" value="'+state.pixel+'" aria-label="Jumlah LED 1 sampai 1000"><button type="button" data-action="pixel">ATUR</button></div><p class="muted">Jumlah LED untuk modul, berlaku di semua halaman.</p></section>':'';
    let palette=spec.palette?'<section class="glass panel"><p class="section-label">WARNA CEPAT</p><div class="swatches">'+presets.map((c,i)=>'<button type="button" class="swatch" data-preset="'+i+'" style="--swatch:'+c+'" aria-label="Warna '+(i+1)+'"></button>').join('')+'</div><p class="tiny-hint">Warna RGB mengganti mode aktif pada kanal yang dipilih.</p></section>':'';
    let brightness=page==='rem'?state.remBrightness:state.brightness,speed=page==='rem'?state.remSpeed:state.speed;
    return heading(spec.title)+modeCards(spec)+'<section class="glass dial-panel neon-mode-panel"><p class="section-label">PILIH MODE</p><div class="holo-selector" id="dial" aria-label="Geser lingkaran untuk mengganti mode"><div class="holo-core"><output id="dial-number">'+value+'</output></div><div class="holo-ring back-ring"></div><div class="holo-ring front-ring"></div><div class="orbit-ticks" id="orbit-ticks">'+curvedTicks(spec)+'</div><div class="center-marker"></div></div><p class="dial-instruction">Geser ke kiri atau kanan untuk memilih mode</p></section>'+pixel+palette+
      '<div class="double-sliders"><section class="glass sliders">'+slider('brightness','KECERAHAN','☼',brightness,true)+'</section><section class="glass sliders">'+slider('speed','KECEPATAN','◉',speed)+'</section></div>'+info+'<button type="button" class="save-action" data-action="mode-save">▣ &nbsp;'+(spec.local?'SIMPAN DI PONSEL':'SIMPAN')+'</button>';
  }
  function autoView(){return heading('AUTO')+'<p class="page-intro">Mode otomatis firmware; pilihan jeda disimpan untuk tampilan aplikasi.</p><div class="mode-cards auto-cards">'+['LED 1','LED 2','LED 3','LED 4','ALL'].map((v,i)=>{let mixed=i===4&&anyChannelsOn()&&!allChannelsOn(),on=i===4?allChannelsOn():state.channelEnabled[i];return '<div class="mode-card '+(on?'channel-on ':'')+(!on&&!mixed?'channel-off ':'')+(mixed?'channel-mixed ':'')+'" data-mode-card-channel="'+i+'" style="'+cardStyle(i)+'"><div class="mode-card-select static"><strong>'+v+'</strong><small>MODE</small><b>AUTO</b></div><button type="button" class="channel-toggle '+(on?'on ':'')+(mixed?'mixed':'')+'" data-channel-toggle="'+i+'" aria-label="'+v+' '+(mixed?'campuran':(on?'ON':'OFF'))+'" aria-pressed="'+on+'"><span aria-hidden="true"></span><em>'+(mixed?'MIX':(on?'ON':'OFF'))+'</em></button></div>';}).join('')+'</div><section class="glass panel"><p class="panel-title">AUTO MODE CUSTOM</p><p class="muted">Perintah AUTO menjalankan urutan bawaan firmware (03 FF). Pengaturan waktu custom belum tersedia pada firmware ini.</p><div class="delay-list">'+[0,1,2,3,5].map(v=>'<button type="button" data-delay="'+v+'" class="'+(state.delay===v?'active':'')+'">'+v+' dtk</button>').join('')+'</div><p class="tiny-hint">Jeda di atas adalah catatan lokal; MCU tetap memakai jeda bawaan.</p></section><div class="double-sliders"><section class="glass sliders">'+slider('brightness','KECERAHAN','☼',state.brightness,true)+'</section><section class="glass sliders">'+slider('speed','KECEPATAN','◉',state.speed)+'</section></div><button class="save-action" data-action="auto-save" type="button">▣ &nbsp;AKTIFKAN AUTO</button>';
  }
  function menuIcon(kind){
    const paths={
      bluetooth:'<path d="M12 2v20l6-5-6-5 6-5-6-5ZM6 6l12 11M6 18 18 7"/>',
      welcome:'<path d="M8 14V6a2 2 0 0 1 4 0v5-7a2 2 0 0 1 4 0v7-5a2 2 0 0 1 4 0v7l.8-.8a2 2 0 0 1 3 2.5l-5.5 7a5 5 0 0 1-4 1.8h-3a5 5 0 0 1-3.9-2l-4.5-6a2 2 0 0 1 3-2.5L8 14Z" transform="translate(1 -1) scale(.8)"/>',
      standby:'<path d="M19.4 17.7A9 9 0 0 1 6.3 4.6 9 9 0 1 0 19.4 17.7Z"/><path d="m16 4 1 2 2 .3-1.6 1.4.4 2.1M20 2l.5 1 1.2.2-.9.9.2 1"/>',
      sein:'<path d="M3 12h18M3 12l5-5M3 12l5 5m13-5-5-5m5 5-5 5"/>',
      rem:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="6"/><path d="M12 7v6m0 3v.5"/>',
      mundur:'<path d="M6 18V6h4a3 3 0 0 1 0 6H6m4 0 3 6m5-9v9m-3-3 3 3 3-3"/>',
      auto:'<path d="M4 19 12 4l8 15M7 14h10"/>',
      about:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.5"/>',
      privacy:'<path d="M12 2 4 5v6c0 5 3.4 8.6 8 11 4.6-2.4 8-6 8-11V5l-8-3Z"/><path d="m9 12 2 2 4-4"/>',
      password:'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
      wallpaper:'<rect x="3" y="4" width="18" height="16" rx="1"/><circle cx="16" cy="8" r="1"/><path d="m4 17 5-5 4 4 2-2 5 4"/>',
      bahasa:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c-5 5-5 13 0 18m0-18c5 5 5 13 0 18M5 7h14M5 17h14"/>',
      subarea:'<rect x="3" y="3" width="8" height="8" rx="1"/><rect x="13" y="3" width="8" height="8" rx="1"/><rect x="3" y="13" width="8" height="8" rx="1"/><rect x="13" y="13" width="8" height="8" rx="1"/>',
      mode210:'<circle cx="12" cy="12" r="9"/><path d="M5 12h14M12 5v14"/>'
    };
    return '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'+paths[kind]+'</svg>';
  }
  function menuRow(target,title,description,icon,color,extra){return '<button class="menu-row" type="button" data-page="'+target+'"><span class="menu-icon '+color+'">'+menuIcon(icon)+'</span><span class="menu-copy"><strong>'+title+'</strong><small>'+description+'</small></span>'+(extra?'<span class="menu-extra">'+extra+'</span>':'')+'<span class="menu-arrow" aria-hidden="true">›</span></button>';}
  function settings(){const mode210Row=dmxConnected()?'':menuRow('mode210','210 MODE','Pilih mode firmware 1–210','mode210','blue');const extraTitle=ready&&deviceType==='ledcar'?'K1–K3':'SUB AREA / K1–K3';const extraDescription=ready&&deviceType==='ledcar'?'Kontrol K1, K2, dan K3':'Kontrol SUB AREA dan K1–K3';return '<div class="settings-screen"><section class="settings-device">'+menuRow('device','DEVICE & CONNECTION','Kelola perangkat dan koneksi','bluetooth','cyan','HS JAYA LIGHTING')+'</section><h2 class="settings-section-title">SETTINGS</h2><section class="menu-group">'+[
      ['welcome','MODE WELLCOME','Atur efek saat aplikasi pertama kali dibuka','welcome','violet'],
      ['standby','MODE STANDBY','Atur efek saat LED dalam keadaan on/standby','standby','green'],
      ['sein','MODE SEIN','Atur efek lampu sein kiri dan kanan','sein','yellow'],
      ['rem','MODE REM','Atur efek saat lampu rem aktif','rem','red'],
      ['mundur','MODE MUNDUR','Atur efek saat gigi mundur aktif','mundur','blue'],
      ['auto','AUTO MODE','Atur efek otomatis sesuai keinginan','auto','yellow']
    ].map(x=>menuRow(...x)).join('')+'</section><h2 class="settings-section-title">ABOUT</h2><section class="menu-group compact">'+menuRow('about','ABOUT RGB HYBRID','Informasi aplikasi','about','cyan')+menuRow('privacy','PRIVACY POLICY','Kebijakan privasi','privacy','violet')+'</section><h2 class="settings-section-title">OTHER</h2><section class="menu-group compact">'+menuRow('password','PASSWORD','Atur atau ubah password aplikasi','password','violet')+menuRow('wallpaper','WALLPAPER','Pilih wallpaper aplikasi','wallpaper','pink')+menuRow('bahasa','BAHASA','Pilih bahasa aplikasi','bahasa','cyan')+'</section><h2 class="settings-section-title">KONTROL TAMBAHAN</h2><section class="menu-group compact">'+menuRow('subarea',extraTitle,extraDescription,'subarea','cyan')+mode210Row+'</section><p class="settings-fineprint">RGB HYBRID · HS JAYA LIGHTING</p></div>';}
  function deviceView(){const shownType=ready?'PROFIL OTOMATIS':'DETEKSI OTOMATIS';return '<div class="device-screen"><h1 class="page-title">DEVICE & CONNECTION</h1><p class="eyebrow">HS JAYA LIGHTING</p><section class="glass device-card"><div class="device-head"><span class="menu-icon cyan">'+menuIcon('bluetooth')+'</span><div><strong>RGB HYBRID</strong><p>'+escapeHtml(shownType)+'</p></div><span data-ble-dot class="ble-dot '+(ready?'connected':'')+'"></span></div><p class="device-status" data-ble-status>'+escapeHtml(status)+'</p><p class="device-status">TERDETEKSI: <strong>'+detectedCount+'</strong> &nbsp;·&nbsp; TERHUBUNG: <strong>'+connectedCount+'</strong></p><button type="button" class="device-connect" data-action="connect" data-device-action>'+(ready?'SCAN ULANG':'CARI & HUBUNGKAN OTOMATIS')+'</button></section><section class="glass panel device-help"><h2>Cara menghubungkan</h2><p>Saat aplikasi dibuka, HS JAYA langsung scan otomatis. Setiap modul LEDCAR, LEDDMX, atau RGB HYBRID custom yang kompatibel dan ditemukan langsung dicoba hubungkan tanpa dipilih atau dicentang.</p><p>Jika ditemukan 2, 5, 10, atau lebih perangkat, semuanya masuk antrean koneksi otomatis. Jumlah koneksi yang benar-benar stabil mengikuti kemampuan Bluetooth Android/HP, bukan batas 2 dari aplikasi.</p><p>Tombol SCAN ULANG hanya mencari perangkat tambahan; koneksi yang sudah aktif tidak perlu diputus.</p><p>Semua perangkat ditampilkan sebagai RGB HYBRID; profil LEDCAR/LEDDMX/custom tetap dipisahkan secara internal agar packet masing-masing tetap benar.</p></section></div>';}
  function simplePage(title,body){return '<h1 class="page-title">'+title+'</h1><p class="eyebrow">RGB HYBRID · HS JAYA LIGHTING</p><section class="glass panel"><p class="muted">'+body+'</p></section>';}
  function wallpaperView(){
    const preview=state.wallpaper?' style="background-image:url('+state.wallpaper+')"':'';
    return '<div class="wallpaper-screen"><h1 class="page-title">WALLPAPER</h1><p class="eyebrow">RGB HYBRID · HS JAYA LIGHTING</p><section class="glass wallpaper-panel"><div class="wallpaper-preview '+(state.wallpaper?'has-image':'')+'"'+preview+'><span>'+(state.wallpaper?'WALLPAPER AKTIF':'BELUM ADA WALLPAPER')+'</span></div><input id="wallpaper-file" type="file" accept="image/*"><button type="button" class="wallpaper-choose" data-action="wallpaper-choose">PILIH DARI GALERI</button>'+(state.wallpaper?'<button type="button" class="wallpaper-remove" data-action="wallpaper-remove">HAPUS WALLPAPER</button>':'')+'<p class="muted">Galeri Android akan meminta Anda memilih foto. Hanya foto yang dipilih yang diberi akses dan disimpan lokal di aplikasi.</p></section></div>';
  }
  function password(){return '<h1 class="page-title">KUNCI MODUL</h1><p class="eyebrow">HS JAYA LIGHTING</p><section class="glass panel"><p class="panel-title">Kontrol penguncian MCU</p><p class="muted">Mengirim perintah kunci firmware. Ini bukan kata sandi untuk membuka aplikasi.</p><button class="pill danger" type="button" data-action="lock">Kunci modul</button><button class="pill" type="button" data-action="unlock">Buka kunci</button></section><div class="glass notice">Layar kata sandi dan timer otomatis pada gambar referensi belum didukung firmware yang dipakai. Tidak ada kata sandi yang disimpan di aplikasi.</div>';}
  function bahasa(){return '<h1 class="page-title">BAHASA</h1><p class="eyebrow">HS JAYA LIGHTING</p><section class="glass panel"><button class="language-choice selected" type="button">◉ &nbsp; Bahasa Indonesia</button><button class="language-choice disabled" type="button" disabled>◯ &nbsp; English · belum tersedia</button><button class="language-choice disabled" type="button" disabled>◯ &nbsp; 中文 · belum tersedia</button></section>';}
  function subareaView(){const dmxReady=ready&&deviceType==='dmx',knownReady=ready&&['dmx','ledcar'].includes(deviceType);const showSubarea=!ready||deviceType==='dmx';const subareaPanel=showSubarea?'<section class="glass panel subarea-panel"><p class="panel-title">SUB AREA</p><p class="muted">Panah kiri, kotak tengah, dan panah kanan mengikuti fungsi firmware SUB AREA.</p><div class="subarea-grid"><button type="button" class="subarea-button '+(state.subarea===1?'active':'')+'" data-area="1" aria-label="Panah kiri"><strong>←</strong></button><button type="button" class="subarea-button '+(state.subarea===0?'active':'')+'" data-area="0" aria-label="Kotak tengah"><strong>■</strong></button><button type="button" class="subarea-button '+(state.subarea===2?'active':'')+'" data-area="2" aria-label="Panah kanan"><strong>→</strong></button></div></section><div class="glass notice" id="subarea-status">'+(dmxReady?'RGB HYBRID terhubung · SUB AREA siap':'Sambungkan modul yang mendukung SUB AREA')+'</div>':'';const kControls='<section class="glass panel k-control-panel"><p class="panel-title">KONTROL K1–K3</p><p class="muted">Mengirim fungsi K1, K2, dan K3 asli dari firmware.</p><div class="k-control-grid"><button type="button" class="k-control-button k1" data-k-button="0"><strong>K1</strong><span>Pemetaan WELCOME ke Mode 210</span></button><button type="button" class="k-control-button k2" data-k-button="1"><strong>K2</strong><span>Playlist tiga WELCOME</span></button><button type="button" class="k-control-button k3" data-k-button="2"><strong>K3</strong><span>Edit warna CH1–CH4</span></button></div></section><div class="glass notice">'+(knownReady?'RGB HYBRID terhubung · K1–K3 siap':'Sambungkan RGB HYBRID untuk menggunakan K1–K3')+'</div>';return '<div class="settings-screen subarea-screen"><h1 class="page-title">'+(ready&&deviceType==='ledcar'?'K1–K3':'SUB AREA')+'</h1><p class="eyebrow">RGB HYBRID · '+(ready?'TERHUBUNG':'DETEKSI OTOMATIS')+'</p>'+subareaPanel+kControls+'</div>';}

  function refImg(name, extra=''){
    const ext=name==='mode210'?'png':'jpg';
    return '<div class="ref-screen ref-'+name+' '+extra+'" style="--ref:url(\'ref/'+name+'.'+ext+'\')"></div>';
  }
  function refHotspot(cls, attrs=''){return '<button type="button" class="ref-hotspot '+cls+'" '+attrs+' aria-label="kontrol"></button>';}
  function sevenSeg(value){
    const chars=String(value).split('');
    const map={0:'abcdef',1:'bc',2:'abdeg',3:'abcdg',4:'bcfg',5:'acdfg',6:'acdefg',7:'abc',8:'abcdefg',9:'abcdfg'};
    return '<span class="seven-wrap">'+chars.map(ch=>'<span class="seven-digit">'+['a','b','c','d','e','f','g'].map(s=>'<i class="seg '+s+' '+((map[ch]||'').includes(s)?'on':'')+'"></i>').join('')+'</span>').join('')+'</span>';
  }

  function sliderPct(v){
    const value=clamp(v,1,100);
    return 4+((value-1)/99)*92;
  }
  function refTickLabel(id,v){return v===0&&state.channel===4&&(id==='welcome'||id==='mode210')?'AUTO':String(v);}
  function refModeTicks(id,rawValue){
    const spec=specs[id],min=modeMin(id,state.channel),span=spec.max-min+1;
    const raw=Number.isFinite(rawValue)?clamp(rawValue,min,spec.max):clamp(selectedModeValue(id,state.channel),min,spec.max);
    const anchor=Math.round(raw);
    let html='';
    for(let slot=-4;slot<=4;slot++){
      const unwrapped=anchor+slot;
      const value=min+((((unwrapped-min)%span)+span)%span);
      const rel=unwrapped-raw;
      const theta=rel*19.2*Math.PI/180;
      const z=Math.cos(theta);
      const x=50+11.25*rel;
      const y=78-57*(1-z);
      const scale=.7+.3*z;
      const op=Math.max(0,Math.pow(z,3.15));
      const rotY=-theta*180/Math.PI*.72;
      const hue=((x+6)*3.05)%360;
      const color=Math.abs(rel)<.47?'#fff':'hsl('+hue+' 96% 61%)';
      html+='<span class="ref-wheel-tick '+(value===0?'auto ':'')+(Math.abs(rel)<.47?'sel':'')+'" data-mode-value="'+value+'" style="left:'+(x-6)+'%;top:'+(y-21)+'%;opacity:'+op+';--tick-color:'+color+';transform:perspective(260px) rotateY('+rotY+'deg) scale('+scale+')">'+refTickLabel(id,value)+'</span>';
    }
    return html;
  }
  function refSliderVisual(which,val){
    const pct=sliderPct(val);
    const grad=which==='brightness'?'linear-gradient(90deg,#ff198f,#ff18f2)':'linear-gradient(90deg,#151dff,#6124ff)';
    return '<span class="ref-slider-mask"></span><span class="ref-slider-fill" style="width:'+pct+'%;background:'+grad+'"></span><span class="ref-slider-knob" style="left:'+pct+'%"></span>';
  }
  function refModeOverlay(id){
    const arr=pageModeArray(id), sel=selectedModeValue(id,state.channel);
    const vals=[arr[0],arr[1],arr[2],arr[3],'ALL'];
    let html='<div class="ref-dynamic">';
    vals.forEach((v,i)=>{
      const mixed=i===4&&anyChannelsOn()&&!allChannelsOn(),on=i===4?allChannelsOn():state.channelEnabled[i];
      html+='<button class="ref-cardtap c'+i+' '+(state.channel===i?'active-ref ':'')+(!on&&!mixed?'ref-off ':'')+'" data-mode-channel="'+i+'" data-mode-card-channel="'+i+'" type="button" style="'+cardStyle(i)+'"></button>';
      html+='<button class="ref-toggle c'+i+' '+(on?'on ':'')+(mixed?'mixed ':'')+'" data-channel-toggle="'+i+'" type="button" aria-pressed="'+on+'" style="'+cardStyle(i)+'"><span></span></button>';
      html+='<span class="ref-cardval c'+i+'">'+v+'</span>';
    });
    html+='<div class="ref-center-number" id="dial-number">'+sevenSeg(sel)+'</div>';
    html+='<div class="ref-ring-touch" id="dial" aria-label="Geser kiri kanan untuk memilih mode"></div>';
    html+='<div class="ref-wheel-mask"></div><div class="ref-wheel-ticks" id="ref-wheel-ticks">'+refModeTicks(id)+'</div>';
    html+='</div>';
    return html;
  }
  function modeControls(id){
    const b=id==='rem'?state.remBrightness:state.brightness;
    const s=id==='rem'?state.remSpeed:state.speed;
    let html='<div class="ref-mode-bright ref-live-slider">'+refSliderVisual('brightness',b)+'<input type="range" min="1" max="100" value="'+b+'" data-slider="brightness"><output id="brightness-value">'+b+'</output></div>';
    html+='<div class="ref-mode-speed ref-live-slider">'+refSliderVisual('speed',s)+'<input type="range" min="1" max="100" value="'+s+'" data-slider="speed"><output id="speed-value">'+s+'</output></div>';
    if(specs[id]&&specs[id].pixel){
      html+='<div class="ref-pixel"><input id="pixel" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="4" autocomplete="off" value="'+state.pixel+'"><span id="pixel-live">'+state.pixel+'</span><button type="button" data-action="pixel">ATUR</button></div>';
    }
    if(specs[id]&&specs[id].palette){
      html+='<div class="ref-palette">'+presets.map((c,i)=>'<button type="button" class="rp p'+i+'" data-preset="'+i+'" style="--pc:'+c+'"></button>').join('')+'</div>';
    }
    html+='<button class="ref-mode-save" type="button" data-action="mode-save"></button>';
    return html;
  }

  function refPartPath(id,part){
    const base=id==='rem'?'sein':id;
    const ext=part==='mode'?'png':(base==='mode210'?'png':'jpg');
    return 'ref/parts/'+base+'_'+part+'.'+ext;
  }
  function refCardDisplay(id,value){
    if(value==='ALL'||value==='MIX')return value;
    const n=Number(value);
    return n===0&&state.channel===4&&(id==='welcome'||id==='mode210')?'AUTO':String(value);
  }
  function refCardsOverlayV7(id){
    const arr=pageModeArray(id);
    const vals=[arr[0],arr[1],arr[2],arr[3],'ALL'];
    let html='';
    vals.forEach((v,i)=>{
      const mixed=i===4&&anyChannelsOn()&&!allChannelsOn(),on=i===4?allChannelsOn():state.channelEnabled[i];
      const uiText=mixed?'MIX':(on?'ON':'OFF');
      html+='<button class="ref-cardtap c'+i+' '+(state.channel===i?'active-ref ':'')+'" data-mode-channel="'+i+'" data-mode-card-channel="'+i+'" type="button" style="'+cardStyle(i)+'"></button>';
      html+='<div class="v14-switch-ui c'+i+' '+(on?'on ':'off ')+(mixed?'mixed ':'')+'" style="'+cardStyle(i)+'"><b>'+uiText+'</b><i><span></span></i></div>';
      html+='<button class="ref-toggle c'+i+'" data-channel-toggle="'+i+'" type="button" aria-pressed="'+on+'" style="'+cardStyle(i)+'"></button>';
      html+='<span class="ref-cardval c'+i+'" style="'+cardStyle(i)+'">'+refCardDisplay(id,v)+'</span>';
    });
    return html;
  }
  function refRingOverlayV7(id){
    const v=clamp(selectedModeValue(id,state.channel),modeMin(id,state.channel),specs[id].max);
    return '<div class="ref-center-number" id="dial-number">'+sevenSeg(v)+'</div>'
      +'<div class="ref-wheel-ticks" id="ref-wheel-ticks">'+refModeTicks(id)+'</div>'
      +'<div class="ref-ring-touch" id="dial" tabindex="0" aria-label="Geser ring kiri kanan untuk memilih mode"></div>';
  }
  function refMiddleControlsV7(id){
    let html='';
    if(specs[id]&&specs[id].pixel){
      html+='<div class="ref-pixel"><input id="pixel" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="4" autocomplete="off" value="'+state.pixel+'"><span id="pixel-live">'+state.pixel+'</span><button type="button" data-action="pixel">ATUR</button></div>';
    }
    if(specs[id]&&specs[id].palette){
      html+='<div class="ref-palette">'+presets.map((c,i)=>'<button type="button" class="rp p'+i+'" data-preset="'+i+'" style="--pc:'+c+'"></button>').join('')+'</div>';
    }
    return html;
  }
  function refSlidersV7(id){
    const b=id==='rem'?state.remBrightness:state.brightness;
    const s=id==='rem'?state.remSpeed:state.speed;
    const sun='<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9 7 7M17 17l2.1 2.1M19.1 4.9 17 7M7 17l-2.1 2.1"></path></svg>';
    const slow='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 16h13a3 3 0 0 0 3-3v-1h-3l-2-3"></path><circle cx="10" cy="12" r="4"></circle><path d="M10 10.5a1.8 1.8 0 1 1-1.4 2.8"></path></svg>';
    const fast='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 15c0-4 2-7 6-7 3 0 5 2 5 5 0 4-3 6-7 6H6"></path><path d="M12 8 10 3M15 8l2-5M18 14h3M8 16l-3 3"></path><circle cx="13" cy="12" r=".8"></circle></svg>';
    const chrome='<span class="ref-slider-heading bright-heading">'+translatedText('KECERAHAN')+'</span><span class="ref-slider-heading speed-heading">'+translatedText('KECEPATAN')+'</span>'
      +'<span class="ref-slider-icon bright-low">'+sun+'</span><span class="ref-slider-icon bright-high">'+sun+'</span>'
      +'<span class="ref-slider-icon speed-low">'+slow+'</span><span class="ref-slider-icon speed-high">'+fast+'</span>';
    return chrome+'<div class="ref-mode-bright ref-live-slider">'+refSliderVisual('brightness',b)+'<input type="range" min="1" max="100" value="'+b+'" data-slider="brightness"><output id="brightness-value">'+b+'</output></div>'
      +'<div class="ref-mode-speed ref-live-slider">'+refSliderVisual('speed',s)+'<input type="range" min="1" max="100" value="'+s+'" data-slider="speed"><output id="speed-value">'+s+'</output></div>';
  }

  function refModeViewLegacy(id){
    const header=id==='mode210'?'ref/master/mode210-header-clean.png':refPartPath(id,'header'),
          cards=id==='mode210'?'ref/master/mode210-cards-single.png':refPartPath(id,'cards'),
          mode=id==='mode210'?'ref/clean/mode210-ring.png':refPartPath(id,'mode'),
          middle=id==='mode210'?'ref/master/standby-pixel.png':refPartPath(id,'middle'),
          sliders=id==='mode210'?'ref/clean/mode210-sliders.png':refPartPath(id,'sliders'),
          save=id==='mode210'?'ref/master/standby-save.png':refPartPath(id,'save');
    const titlePatch=id==='rem'?'<div class="ref-title-patch"><span class="rainbow">MODE</span> REM</div>':'';
    return '<div class="ref-page v7-layout v7-mode '+id+'">'
      +'<section class="v7-sec v7-header"><img class="ref-part-img" src="'+header+'" alt="">'+titlePatch+'<button type="button" class="ref-back" data-page="settings" aria-label="Kembali"></button></section>'
      +'<div class="v7-gap small"></div>'
      +'<section class="v7-sec v7-cards"><img class="ref-part-img" src="'+cards+'" alt="">'+refCardsOverlayV7(id)+'</section>'
      +'<div class="v7-gap"></div>'
      +'<section class="v7-sec v7-mode-sec"><img class="ref-part-img" src="'+mode+'" alt="">'+refRingOverlayV7(id)+(state.language==='id'?'':'<span class="i18n-v7-pick">'+translatedText('PILIH MODE')+'</span>')+'</section>'
      +'<div class="v7-gap"></div>'
      +'<section class="v7-sec v7-middle"><img class="ref-part-img" src="'+middle+'" alt="">'+refMiddleControlsV7(id)+(state.language==='id'?'':'<span class="i18n-v7-pixel">'+translatedText('SETTING PIXEL')+'</span>')+'</section>'
      +'<div class="v7-gap small"></div>'
      +'<section class="v7-sec v7-sliders"><img class="ref-part-img" src="'+sliders+'" alt="">'+refSlidersV7(id)+'</section>'
      +'<div class="v7-gap small"></div>'
      +'<section class="v7-sec v7-save"><img class="ref-part-img" src="'+save+'" alt=""><button class="ref-mode-save" type="button" data-action="mode-save"></button>'+(state.language==='id'?'':'<span class="i18n-v7-save">'+translatedText('SIMPAN')+'</span>')+'</section>'
      +'<div class="v7-bottom"></div></div>';
  }

  function refModeView(id){
    if(id==='mode210') return refModeViewLegacy(id);
    const originalBg={
      welcome:'ref/clean/welcome.png',
      standby:'ref/clean/standby.png',
      sein:'ref/clean/sein.png',
      mundur:'ref/clean/mundur.png',
      rem:'ref/clean/mundur.png'
    };
    const useOriginal=!!originalBg[id];
    const bg=originalBg[id]||('ref/v14/'+id+'.jpg');
    const titlePatch=id==='rem'?'<div class="v13-title-patch"><span class="rainbow">MODE</span> REM</div>':'';
    let middle='';
    if(id==='welcome'||id==='standby'){
      middle='<div class="v13-pixel"><input id="pixel" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="4" autocomplete="off" value="'+state.pixel+'" aria-label="Jumlah LED 1 sampai 1000"><button type="button" data-action="pixel" aria-label="Atur pixel"></button></div>';
    }
    if(id==='mundur'||id==='rem'){
      middle+='<div class="v13-palette">'+presets.map((c,i)=>'<button type="button" class="rp p'+i+'" data-preset="'+i+'" style="--pc:'+c+'"></button>').join('')+'</div>';
    }
    const ring=useOriginal
      ? '<div class="v13-ring">'+refRingOverlayV7(id)+'</div>'
      : '<div class="v13-ring"><div class="v20-mode-master-inner"><img class="v18-mode-master-img" src="ref/v14/mode210/mode.png" alt="">'+refRingOverlayV7(id)+'</div></div>';
    return '<div class="ref-page v13-mode '+id+' '+(useOriginal?'original-visual ':'')+'">'
      +'<img class="v13-bg" src="'+bg+'" alt="">'
      +titlePatch
      +'<button type="button" class="ref-back" data-page="settings" aria-label="Kembali"></button>'
      +'<div class="v13-cards">'+refCardsOverlayV7(id)+'</div>'
      +ring
      +middle
      +'<div class="v13-sliders">'+refSlidersV7(id)+'</div>'
      +'<button class="ref-mode-save" type="button" data-action="mode-save" aria-label="Simpan"></button>'
      +languageModeOverlay(id)
      +'</div>';
  }

  const autoProfileDefs=[
    {id:'led1',label:'LED 1',selection:0,color:'#ff2a8a'},
    {id:'led2',label:'LED 2',selection:1,color:'#1ea7ff'},
    {id:'all',label:'ALL',selection:4,color:'#d5efff'},
    {id:'led3',label:'LED 3',selection:2,color:'#2aff8a'},
    {id:'led4',label:'LED 4',selection:3,color:'#ffd400'}
  ];
  const autoCardColors=['#ff2a8a','#1ea7ff','#2aff8a','#ffd400','#b23bff','#22d3ee'];
  function autoProfile(){return autoProfileDefs.find(p=>p.id===state.autoProfile)||autoProfileDefs[0];}
  function autoRows(profile=state.autoProfile){return state.autoCollects[profile]||[];}
  function autoFind(id,profile=state.autoProfile){return autoRows(profile).find(row=>row.id===id);}
  function autoCollectIcon(index){
    if(index===1)return '<span class="ac-streak s1"></span><span class="ac-streak s2"></span><span class="ac-streak s3"></span>';
    if(index===2)return '<span class="ac-dots"></span>';
    if(index===3)return '<span class="ac-bars"></span>';
    if(index===4)return '<span class="ac-arrows">❯❯</span>';
    return '<span class="ac-ring r1"></span><span class="ac-ring r2"></span>';
  }
  function autoCard(row,index){
    const running=autoRunningProfile===state.autoProfile&&autoRunningId===row.id;
    const editing=autoEditingId===row.id,modeSelected=editing&&autoSelectedModeIndex!==null;
    const chips=row.modes.length?row.modes.map((mode,modeIndex)=>'<span class="ac-chip '+(running&&modeIndex===autoRunningIndex?'current ':'')+(editing&&autoSelectedModeIndex===modeIndex?'selected ':'')+'" '+(editing?'data-auto-mode-index="'+modeIndex+'"':'')+'>'+mode+'</span>').join(''):'<span class="ac-empty">'+autoText('empty')+'</span>';
    const color=autoCardColors[index%autoCardColors.length];
    return '<article class="ac-card '+(running?'running ':'')+(autoEditingId===row.id?'editing ':'')+'" style="--ac:'+color+'" data-auto-card="'+escapeHtml(row.id)+'">'
      +'<button type="button" class="ac-card-main" data-auto-run="'+escapeHtml(row.id)+'" aria-label="'+escapeHtml(autoText('running')+' '+row.name)+'"><span class="ac-visual v'+(row.visual%6)+'">'+autoCollectIcon(row.visual%6)+'</span><span class="ac-card-copy"><strong>'+escapeHtml(row.name)+'</strong><small>'+row.modes.length+' '+autoText('modes')+'</small><span class="ac-chips">'+chips+'</span></span></button>'
      +'<span class="ac-actions"><button type="button" class="ac-edit" data-auto-edit="'+escapeHtml(row.id)+'">✎ <span>'+(editing?autoText('editing'):autoText('edit'))+'</span></button><button type="button" class="ac-delete" '+(modeSelected?'data-auto-delete-mode="'+escapeHtml(row.id)+'"':'data-auto-delete="'+escapeHtml(row.id)+'"')+'>▣ <span>'+(modeSelected?autoText('removeMode'):autoText('remove'))+'</span></button></span></article>';
  }
  function refAutoView(){
    const profile=autoProfile(),rows=autoRows();
    const tabs=autoProfileDefs.map(item=>'<button type="button" class="ac-tab '+(item.id===profile.id?'active':'')+'" style="--ac:'+item.color+'" data-auto-profile="'+item.id+'"><i></i><span>'+item.label+'</span></button>').join('');
    const editedRow=autoEditingId?autoFind(autoEditingId):null;
    const addLabel=editedRow?autoText('add'):autoText('addCollect');
    const addHint=editedRow?autoText('addReady')+' '+editedRow.name:autoText('newCollectHint');
    const dialog=autoDeleteId?'<div class="ac-dialog"><section><strong>'+autoText('deleteTitle')+'</strong><p>'+autoText('deleteBody')+'</p><div><button type="button" data-auto-dialog="cancel">'+autoText('cancel')+'</button><button type="button" class="danger" data-auto-dialog="confirm">'+autoText('remove')+'</button></div></section></div>':'';
    return '<div class="collect-auto" lang="'+(state.language==='zh'?'zh-CN':state.language)+'">'
      +'<header class="ac-page-header"><button type="button" data-page="settings" aria-label="Kembali">←</button><h1><span>AUTO</span> MODE</h1><button type="button" data-auto-action="help" aria-label="Panduan">?</button></header>'
      +'<nav class="ac-tabs" aria-label="LED">'+tabs+'</nav>'
      +'<section class="ac-list-panel"><header><strong>'+autoText('list')+' — '+profile.label+'</strong><span>'+rows.length+' '+autoText('available')+'</span></header><div class="ac-list" id="auto-collect-list">'+rows.map(autoCard).join('')+'</div></section>'
      +'<button type="button" class="ac-add" data-auto-action="add"><b>＋</b><span><strong>'+addLabel+'</strong><small>'+escapeHtml(addHint)+'</small></span></button>'
      +'<section class="ac-settings"><header><span><strong>'+autoText('settings')+'</strong><small>'+autoText('settingsHint')+'</small></span><button type="button" data-auto-action="defaults">↻ '+autoText('defaults')+'</button></header><div class="ac-setting-grid">'
      +'<label class="ac-slider speed"><span>◴ '+autoText('speed')+' <output id="speed-value">'+state.speed+'</output></span><input type="range" min="1" max="100" value="'+state.speed+'" data-slider="speed"><small><i>'+autoText('slow')+'</i><i>'+autoText('fast')+'</i></small></label>'
      +'<label class="ac-slider bright"><span>☀ '+autoText('brightness')+' <output id="brightness-value">'+state.brightness+'</output></span><input type="range" min="1" max="100" value="'+state.brightness+'" data-slider="brightness"><small><i>'+autoText('dim')+'</i><i>'+autoText('bright')+'</i></small></label></div></section>'
      +'<div class="ac-wheel-position"><strong class="ac-wheel-label">'+autoText('wheel')+'</strong><section id="wp"><svg id="tk" viewBox="0 0 300 142" preserveAspectRatio="xMidYMid meet"></svg><div id="wheel"><div id="ws"></div></div></section></div>'
      +'<button type="button" class="ac-run-all '+(autoRunAll?'active':'')+'" data-auto-action="run-all">▶ '+(autoRunAll?autoText('stopAll'):autoText('runAll'))+'</button>'
      +'<footer class="ac-footer"><button type="button" class="ac-reset" data-auto-action="reset"><b>⟲</b> '+autoText('reset')+'</button><button type="button" class="ac-save" data-auto-action="save"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 3h13l3 3v15H4zM8 3v6h8V3M8 21v-7h8v7"/></svg><span>'+autoText('save')+'</span></button></footer>'+dialog+'</div>';
  }
  function autoTargetCode(profile){const def=autoProfileDefs.find(item=>item.id===profile)||autoProfileDefs[0];return channelCodes[def.selection];}
  function autoCycleBaseMs(mode){
    mode=clamp(Number(mode)||1,1,210);
    if(mode===185)return 12400;if(mode===186)return 13600;
    if(mode>=201)return 11600;
    if(mode===200)return 8000;
    if(mode>=181)return 8000;
    if(mode>=161)return mode>=171?9200:6000;
    if(mode>=141)return 7200;
    if(mode>=121)return 7400;
    if(mode>=101)return mode===119?7200:5800;
    if(mode>=71)return 7200;
    if(mode>=31)return 8000;
    return 6000;
  }
  function autoCycleMs(mode){const factor=.4+(clamp(state.speed,1,100)/100)*1.84;return Math.max(2500,Math.round(autoCycleBaseMs(mode)/factor));}
  function autoRequireConnection(){
    if(!ready){flash('Sambungkan modul LED melalui tombol koneksi dulu');return false;}
    return true;
  }
  function autoSendMode(mode,profile){
    if(!autoRequireConnection())return false;
    const value=clamp(Number(mode)||1,1,210),code=autoTargetCode(profile);
    return send('send',0x03,value,code);
  }
  function autoRefreshPlayback(){
    if(page!=='auto')return;
    content.querySelectorAll('[data-auto-card]').forEach(card=>{
      const active=autoRunningProfile===state.autoProfile&&card.dataset.autoCard===autoRunningId;
      card.classList.toggle('running',active);
      card.querySelectorAll('[data-auto-chip]').forEach(chip=>chip.classList.toggle('current',active&&Number(chip.dataset.autoChip)===autoRunningIndex));
    });
    const allButton=content.querySelector('[data-auto-action="run-all"]');
    if(allButton){allButton.classList.toggle('active',autoRunAll);allButton.textContent='▶ '+(autoRunAll?autoText('stopAll'):autoText('runAll'));}
  }
  function autoSchedule(){
    clearTimeout(autoTimer);
    if(!autoRunningId)return;
    const current=autoFind(autoRunningId,autoRunningProfile);
    if(!current||!current.modes.length){autoStop(false,false);return;}
    const wait=autoCycleMs(current.modes[clamp(autoRunningIndex,0,current.modes.length-1)]);
    autoTimer=setTimeout(()=>{
      let row=autoFind(autoRunningId,autoRunningProfile);
      if(!row||!row.modes.length){autoStop(false,false);return;}
      autoRunningIndex++;
      if(autoRunningIndex>=row.modes.length){
        if(autoRunAll){
          const playable=autoRows(autoRunningProfile).filter(item=>item.modes.length);
          if(!playable.length){autoStop(false,false);return;}
          autoRunAllIndex=(autoRunAllIndex+1)%playable.length;
          row=playable[autoRunAllIndex];
          autoRunningId=row.id;
        }
        autoRunningIndex=0;
      }
      // Collect is an application-side playlist. Each logical Mode command is
      // translated by the native router for every connected stock/custom module.
      const next=autoFind(autoRunningId,autoRunningProfile);
      if(!next||!next.modes.length||!autoSendMode(next.modes[autoRunningIndex],autoRunningProfile)){
        autoStop(false,false);return;
      }
      autoRefreshPlayback();
      autoSchedule();
    },wait);
  }
  function autoRun(id){
    const row=autoFind(id);if(!row||!row.modes.length){flash(autoText('collectEmpty'));return;}
    if(!autoSendMode(row.modes[0],state.autoProfile))return;
    autoRunAll=false;autoRunAllIndex=0;autoRunningProfile=state.autoProfile;autoRunningId=id;autoRunningIndex=0;
    state.autoLastRun={profile:state.autoProfile,id};persist();autoRefreshPlayback();autoSchedule();flash(autoText('running')+' '+row.name);
  }
  function autoStop(announce=true,transmit=true){
    clearTimeout(autoTimer);autoTimer=null;
    // No special Collect opcode is used. Stopping only stops future mode changes;
    // the currently displayed hardware mode remains active.
    autoRunningId=null;autoRunningProfile=null;autoRunningIndex=0;autoRunAll=false;autoRunAllIndex=0;autoRefreshPlayback();if(announce)flash(autoText('stopped'));
  }
  function autoRunEvery(){
    if(autoRunAll){autoStop(true);return;}
    const playable=autoRows().filter(item=>item.modes.length);if(!playable.length){flash(autoText('collectEmpty'));return;}
    if(!autoSendMode(playable[0].modes[0],state.autoProfile))return;
    autoRunAll=true;autoRunAllIndex=0;autoRunningProfile=state.autoProfile;autoRunningId=playable[0].id;autoRunningIndex=0;
    state.autoLastRun={profile:state.autoProfile,id:'*'};persist();autoRefreshPlayback();autoSchedule();flash(autoText('runningAll'));
  }
  function autoResetPlayback(){
    if(!autoRunningId){flash(autoText('noneRunning'));return;}
    autoRunningIndex=0;autoRunAllIndex=0;
    if(autoRunAll){
      const playable=autoRows(autoRunningProfile).filter(item=>item.modes.length);
      if(!playable.length){autoStop(false,false);return;}
      autoRunningId=playable[0].id;
    }
    const row=autoFind(autoRunningId,autoRunningProfile);
    if(!row||!row.modes.length||!autoSendMode(row.modes[0],autoRunningProfile))return;
    autoRefreshPlayback();autoSchedule();flash(autoText('resetDone'));
  }
  function scheduleAutoWheelPreview(){
    clearTimeout(autoPreviewTimer);
    autoPreviewTimer=setTimeout(()=>{
      if(page!=='auto'||!ready)return;
      // Scrolling pauses the current playlist preview but does not erase any saved Collect.
      if(autoRunningId)autoStop(false,false);
      const profile=autoProfile(),live=targetChannels(profile.selection).filter(i=>state.channelEnabled[i]);
      if(!live.length){flash('Channel yang dipilih sedang OFF');return;}
      autoSendMode(autoWheelValue,state.autoProfile);
    },240);
  }
  let ws=null,cur=1,ns=[];
  function wheel(){const c=ws.scrollTop/28;cur=Math.min(210,Math.max(1,Math.round(c)+1));
    const a=Math.max(0,cur-6),b=Math.min(209,cur+4);
    for(let i=a;i<=b;i++){const d=i-c,ad=Math.abs(d);const n=ns[i];
      n.style.transform=`rotateX(${-d*26}deg) scale(${Math.max(.5,1.15-ad*.28)})`;n.style.opacity=Math.max(.25,1-ad*.28);n.style.color=ad<.5?'#fff':'#9fd8ff';n.style.textShadow=ad<.5?'0 0 10px #22d3ee':'none'}
  }
  function initAutoView(){
    ws=document.getElementById('ws');if(!ws)return;
    const initialValue=autoWheelValue,currentWs=ws;
    let userMovedWheel=false;
    ws.innerHTML='<div class="sp"></div>'+Array.from({length:210},(_,i)=>`<div class="n">${i+1}</div>`).join('')+'<div class="sp"></div>';
    ns=[...ws.querySelectorAll('.n')];
    const markUserMove=()=>{userMovedWheel=true;};
    ws.addEventListener('pointerdown',markUserMove,{passive:true});
    ws.addEventListener('touchstart',markUserMove,{passive:true});
    ws.addEventListener('wheel',markUserMove,{passive:true});
    ws.addEventListener('keydown',markUserMove);
    ws.addEventListener('scroll',wheel,{passive:true});
    ws.addEventListener('scroll',()=>{autoWheelValue=cur;if(userMovedWheel)scheduleAutoWheelPreview();},{passive:true});
    ns.forEach((n,i)=>n.onclick=()=>{userMovedWheel=true;ws.scrollTo({top:i*28,behavior:'smooth'});if(i+1===autoWheelValue)scheduleAutoWheelPreview();});
    let h='';for(let a=-44;a<=44;a+=5){const r=a*Math.PI/180,ad=Math.abs(a);[1,-1].forEach(g=>{h+=`<line x1="${150+g*Math.cos(r)*88}" y1="${71+Math.sin(r)*88}" x2="${150+g*Math.cos(r)*98}" y2="${71+Math.sin(r)*98}" stroke="#2fe0ff" stroke-width="${ad<20?3:2}" stroke-linecap="round" opacity="${(1-ad/62).toFixed(2)}"/>`})}document.getElementById('tk').innerHTML=h;
  requestAnimationFrame(()=>{if(currentWs!==document.getElementById('ws'))return;currentWs.scrollTop=(initialValue-1)*28;wheel();autoWheelValue=cur;});
}
  function refHomeView(){
    const rgb=currentRgb();
    return '<div class="ref-page v7-layout v7-home home">'
      +'<section class="v7-sec v7-home-header"><img class="ref-part-img" src="ref/parts/home_header.jpg" alt=""><button type="button" class="ref-home-menu" data-page="settings" aria-label="Menu"></button><button type="button" class="ref-home-gear" data-page="mode210" aria-label="210 Mode"></button></section>'
      +'<div class="v7-gap small"></div>'
      +'<section class="v7-sec v7-home-wheel"><img class="ref-part-img" src="ref/parts/home_wheel.jpg" alt=""><div id="hue-wheel" class="ref-home-wheel" role="slider" tabindex="0"><i class="ref-hue-dot" id="ref-hue-dot"></i></div><button id="power" class="ref-power '+(state.power?'on':'')+'" type="button"></button><div class="ref-rgb-values"><span id="rgb-0">'+rgb[0]+'</span><span id="rgb-1">'+rgb[1]+'</span><span id="rgb-2">'+rgb[2]+'</span></div></section>'
      +'<div class="v7-gap"></div>'
      +'<section class="v7-sec v7-home-sliders"><img class="ref-part-img" src="ref/parts/home_sliders.jpg" alt=""><div class="ref-home-bright ref-live-slider">'+refSliderVisual('brightness',state.brightness)+'<input type="range" min="1" max="100" value="'+state.brightness+'" data-slider="brightness"><output id="brightness-value">'+state.brightness+'%</output></div><div class="ref-home-speed ref-live-slider">'+refSliderVisual('speed',state.speed)+'<input type="range" min="1" max="100" value="'+state.speed+'" data-slider="speed"><output id="speed-value">'+state.speed+'%</output></div></section>'
      +'<div class="v7-gap small"></div>'
      +'<section class="v7-sec v7-home-preset"><img class="ref-part-img" src="ref/parts/home_preset.jpg" alt="">'+presets.map((c,i)=>'<button type="button" class="ref-preset p'+i+'" data-preset="'+i+'"></button>').join('')+'</section>'
      +'<div class="v7-gap small"></div>'
      +'<section class="v7-sec v7-home-quick"><img class="ref-part-img" src="ref/parts/home_quick.jpg" alt="">'+state.quick.map((v,i)=>'<button type="button" class="ref-quick q'+i+' '+(v?'saved':'')+'" data-quick="'+i+'" style="'+(v?'--q:'+v:'')+'"></button>').join('')+'</section>'
      +'<section class="v7-sec v7-home-footer"><img class="ref-part-img" src="ref/parts/home_footer.jpg" alt=""></section><div class="v7-bottom"></div></div>';
  }

  function updateSliderVisual(root,val){
    if(!root)return;
    const pct=sliderPct(val),isModeBrightness=root.classList.contains('ref-mode-bright')&&!!root.closest('.v13-mode,.v7-mode.mode210');
    const visualPct=isModeBrightness?4+((clamp(val,1,100)-1)/99)*84:pct;
    const fill=root.querySelector('.ref-slider-fill'),knob=root.querySelector('.ref-slider-knob');
    if(fill)fill.style.width=visualPct+'%';
    if(knob)knob.style.left=visualPct+'%';
  }
  function refreshRefVisuals(){
    document.querySelectorAll('.ref-cardtap[data-mode-channel]').forEach(card=>{
      const i=Number(card.dataset.modeChannel),mixed=i===4&&anyChannelsOn()&&!allChannelsOn(),on=i===4?allChannelsOn():state.channelEnabled[i];
      card.classList.toggle('active-ref',state.channel===i);
      card.classList.toggle('ref-off',!on&&!mixed);
      const val=document.querySelector('.ref-cardval.c'+i);
      if(val)val.textContent=refCardDisplay(page,cardModeValue(i));
      const t=document.querySelector('.ref-toggle.c'+i);
      if(t){t.classList.toggle('on',on);t.classList.toggle('mixed',mixed);t.setAttribute('aria-pressed',String(on));}
      const ui=document.querySelector('.v14-switch-ui.c'+i);
      if(ui){
        ui.classList.toggle('on',on&&!mixed);
        ui.classList.toggle('off',!on&&!mixed);
        ui.classList.toggle('mixed',mixed);
        const label=ui.querySelector('b');if(label)label.textContent=mixed?'MIX':(on?'ON':'OFF');
      }
    });
    if(specs[page]){
      const v=selectedModeValue(page,state.channel);
      const center=document.getElementById('dial-number'); if(center)center.innerHTML=sevenSeg(v);
      const ticks=document.getElementById('ref-wheel-ticks'); if(ticks)ticks.innerHTML=refModeTicks(page);
    }
    const b=page==='rem'?state.remBrightness:state.brightness,s=page==='rem'?state.remSpeed:state.speed;
    updateSliderVisual(document.querySelector('.ref-mode-bright,.ref-home-bright,.ref-auto-bright'),b);
    updateSliderVisual(document.querySelector('.ref-mode-speed,.ref-home-speed,.ref-auto-speed'),s);
  }
  function refreshRefRingRaw(raw){
    if(!specs[page])return;
    const host=document.getElementById('ref-wheel-ticks');
    if(host)host.innerHTML=refModeTicks(page,raw);
    const center=document.getElementById('dial-number');
    if(center)center.innerHTML=sevenSeg(Math.round(clamp(raw,modeMin(page,state.channel),specs[page].max)));
  }

  function refSettingsView(){
    const setTargets=['welcome','standby','sein','rem','mundur','auto'];
    return '<div class="ref-page v7-layout v7-settings settings">'
      +'<section class="v7-sec v7-settings-header"><img class="ref-part-img" src="ref/parts/settings_header.jpg" alt=""><button type="button" class="ref-back" data-page="home" aria-label="Kembali"></button></section>'
      +'<div class="v7-gap small"></div>'
      +'<section class="v7-sec v7-settings-device"><img class="ref-part-img" src="ref/parts/settings_device.jpg" alt=""><button type="button" class="ref-settings-row r0" data-page="device"></button></section>'
      +'<div class="v7-gap small"></div>'
      +'<section class="v7-sec v7-settings-main"><img class="ref-part-img" src="ref/parts/settings_settings.jpg" alt="">'+setTargets.map((t,i)=>'<button type="button" class="ref-settings-row r'+(i+1)+'" data-page="'+t+'"></button>').join('')+'</section>'
      +'<div class="v7-gap small"></div>'
      +'<section class="v7-sec v7-settings-about"><img class="ref-part-img" src="ref/parts/settings_about.jpg" alt=""><button type="button" class="ref-settings-row r7" data-page="about"></button><button type="button" class="ref-settings-row r8" data-page="privacy"></button></section>'
      +'<div class="v7-gap small"></div>'
      +'<section class="v7-sec v7-settings-other"><img class="ref-part-img" src="ref/parts/settings_other.jpg" alt=""><button type="button" class="ref-settings-row r9" data-page="password"></button><button type="button" class="ref-settings-row r10" data-page="wallpaper"></button><button type="button" class="ref-settings-row r11" data-page="bahasa"></button><button type="button" class="v7-mode210-link" data-page="mode210" aria-label="210 Mode"></button></section>'
      +'<div class="v7-bottom"></div></div>';
  }
  function refBahasaView(){
    return '<div class="ref-page bahasa"><img class="ref-img" src="ref/bahasa.jpg" alt=""><button type="button" class="ref-back" data-page="settings" aria-label="Kembali"></button>'
      +'<button class="ref-lang l0 '+(state.language==='zh'?'selected':'')+'" data-lang="zh" type="button"></button>'
      +'<button class="ref-lang l1 '+(state.language==='en'?'selected':'')+'" data-lang="en" type="button"></button>'
      +'<button class="ref-lang l2 '+(state.language==='id'?'selected':'')+'" data-lang="id" type="button"></button></div>';
  }
  function refPasswordView(){
    return '<div class="ref-page password password-flow"><div class="password-master-top"><img class="ref-img" src="ref/password_top.jpg" alt=""><button type="button" class="ref-back" data-page="settings" aria-label="Kembali"></button>'
      +'<input class="ref-pass p1" id="pass1" type="password" placeholder="Masukkan password baru">'
      +'<input class="ref-pass p2" id="pass2" type="password" placeholder="Masukkan ulang password baru">'
      +'<button class="ref-reset-pass" type="button" data-action="password-reset"></button></div>'
      +'<section class="auto-lock-card"><span class="auto-lock-icon" aria-hidden="true"><svg viewBox="0 0 64 64"><rect x="13" y="25" width="33" height="27" rx="6"></rect><path d="M20 25v-7a10 10 0 0 1 20 0v7"></path><circle cx="45" cy="43" r="11"></circle><path d="M45 37v7l5 3"></path></svg></span><div class="auto-lock-copy"><strong>AUTO LOCK RGB HYBRID</strong><span>Kunci ON/OFF langsung mengikuti firmware</span></div><button class="auto-lock-switch '+(state.autoLock?'on':'off')+'" type="button" data-action="autolock" aria-pressed="'+state.autoLock+'" aria-label="AUTO LOCK '+(state.autoLock?'ON':'OFF')+'"><span><i></i></span><b>'+(state.autoLock?'ON':'OFF')+'</b></button></section>'
      +'<div class="password-save-master"><img src="ref/password_save.jpg" alt=""><button type="button" data-action="password-save" aria-label="Simpan password"></button></div></div>';
  }


  function render(){
    nav.textContent=page==='home'?'☰':'←';nav.setAttribute('aria-label',page==='home'?'Buka menu':'Kembali');
    document.body.classList.toggle('home-page',page==='home');
    document.body.classList.toggle('settings-page',page==='settings');document.body.classList.toggle('mode-page',!!specs[page]||page==='auto');
    if(specs[page]){brandEl.innerHTML='<span class="rainbow">MODE</span> '+specs[page].title;settingsShortcut.innerHTML='<span class="mode-h-mark">H</span>';settingsShortcut.setAttribute('aria-label','HS JAYA LIGHTING');}
    else if(page==='auto'){brandEl.innerHTML='<span class="rainbow">AUTO</span> MODE';settingsShortcut.innerHTML='<span class="mode-h-mark">H</span>';settingsShortcut.setAttribute('aria-label','HS JAYA LIGHTING');}
    else{brandEl.innerHTML='<span class="rainbow">RGB</span> <span>HYBRID</span>';settingsShortcut.innerHTML='<span class="overflow-glyph" aria-hidden="true"><i></i><i></i><i></i></span>';settingsShortcut.setAttribute('aria-label','Setelan');}
    settingsShortcut.style.visibility=['settings','device'].includes(page)?'hidden':'visible';
    content.innerHTML=page==='home'?home():specs[page]?refModeView(page):page==='auto'?refAutoView():page==='settings'?settings():page==='device'?deviceView():page==='subarea'?subareaView():page==='password'?refPasswordView():page==='bahasa'?refBahasaView():page==='about'?simplePage('ABOUT RGB HYBRID','Aplikasi HS JAYA untuk mengontrol modul RGB HYBRID melalui koneksi Bluetooth BLE. Versi 1.2.7.'):page==='privacy'?simplePage('PRIVACY POLICY','Aplikasi bekerja secara lokal lewat Bluetooth. Teks kebijakan privasi resmi belum tersedia.'):wallpaperView();
    applyWallpaper();
    renderLinks();updateConnection();
    if(page==='home')updateWheel();
    refreshRefVisuals();
    if(page==='auto')requestAnimationFrame(initAutoView);
  }
  function updateWheel(){
    const wheel=document.getElementById('hue-wheel');if(!wheel)return;
    wheel.setAttribute('aria-valuenow',String(state.hue));
    currentRgb().forEach((v,i)=>{let el=document.getElementById('rgb-'+i);if(el)el.textContent=String(v);});
    const handle=document.getElementById('hue-handle');
    if(handle){const a=-state.hue*Math.PI/180;handle.style.left=(50+49*Math.cos(a))+'%';handle.style.top=(50+49*Math.sin(a))+'%';}
    const dot=document.getElementById('ref-hue-dot');
    if(dot){const a=state.hue*Math.PI/180,r=.39;dot.style.left=(50+Math.cos(a)*r*100)+'%';dot.style.top=(50-Math.sin(a)*r*100)+'%';}
  }
  function chooseHue(h,transmit){state.hue=((Math.round(h)%360)+360)%360;state.rgb=rgbForHue(state.hue);const sel=page==='home'?4:state.channel;rememberRgb(state.rgb,sel);persist();updateWheel();if(transmit)sendRgbSelection(state.rgb,sel);}
  function choosePreset(index){const hex=presets[index];state.rgb=hex.match(/[0-9a-f]{2}/gi).map(x=>parseInt(x,16));const selection=page==='home'?4:state.channel;rememberRgb(state.rgb,selection);persist();if(page==='home')updateWheel();sendRgbSelection(state.rgb,selection);}
  function modeValue(v,transmit){let spec=specs[page];if(!spec)return;v=clamp(v,modeMin(page,state.channel),spec.max);
    const arr=pageModeArray(page),mixedAll=state.channel===4&&!arr.every(x=>x===arr[0]),old=selectedModeValue(page,state.channel);if(old===v&&!mixedAll)return;
    setSelectedModeValue(page,v,state.channel);
    if(page==='mode210')rememberMode210(v,state.channel);
    persist();let output=document.getElementById('dial-number');if(output)output.innerHTML=sevenSeg(v);
    refreshCurvedTicks();refreshRefVisuals();
    document.querySelectorAll('[data-mode-card-channel]').forEach(card=>{const i=Number(card.dataset.modeCardChannel),b=card.querySelector('b');if(b)b.textContent=cardModeValue(i);});
    if(transmit&&!spec.local)sendPageModeSelection(v,state.channel);
  }
  function scrollRuler(v,behavior){refreshCurvedTicks();}
  function sliderInput(el,final){let name=el.dataset.slider,val=clamp(el.value,1,100),rem=page==='rem';let key=rem?(name==='brightness'?'remBrightness':'remSpeed'):name;state[key]=val;persist();let output=document.getElementById(name+'-value');if(output)output.textContent=page==='home'?(val+'%'):String(val);updateSliderVisual(el.closest('.ref-live-slider'),val);if(specs[page]&&specs[page].local)return;
    if(page==='auto'&&autoRunningId&&name==='speed')autoSchedule();
    if(final||Date.now()-lastSliderAt>170){lastSliderAt=Date.now();if(rem)send('remSetting',name==='brightness'?1:2,val);else send('send',name==='brightness'?1:2,val,3);}
  }
  function sliderPointerValue(root,clientX){
    const box=root.getBoundingClientRect(),start=box.left+box.width*.04,usable=box.width*.92;
    const ratio=Math.min(1,Math.max(0,(clientX-start)/usable));
    return Math.round(1+ratio*99);
  }
  function updateSliderFromPointer(gesture,clientX,final){
    const value=sliderPointerValue(gesture.root,clientX);
    gesture.input.value=String(value);
    sliderInput(gesture.input,final);
  }
  function hsvToRgb(h,s,v){let c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c,r=0,g=0,b=0;if(h<60){r=c;g=x}else if(h<120){r=x;g=c}else if(h<180){g=c;b=x}else if(h<240){g=x;b=c}else if(h<300){r=x;b=c}else{r=c;b=x}return [r,g,b].map(n=>Math.round((n+m)*255));}
  function wheelPointer(ev,el){let box=(el||ev.currentTarget).getBoundingClientRect(),dx=ev.clientX-(box.left+box.width/2),dy=ev.clientY-(box.top+box.height/2),radius=Math.min(box.width,box.height)/2,dist=Math.min(radius,Math.hypot(dx,dy));return {h:(360-Math.atan2(dy,dx)*180/Math.PI)%360,s:Math.min(1,dist/(radius*.94))};}
  function chooseWheelPoint(point,transmit){state.hue=((Math.round(point.h)%360)+360)%360;state.rgb=hsvToRgb(state.hue,point.s,1);const sel=page==='home'?4:state.channel;rememberRgb(state.rgb,sel);persist();updateWheel();if(transmit)sendRgbSelection(state.rgb,sel);}
  function commitPendingQuick(){if(pendingQuickSlot===null)return;state.quick[pendingQuickSlot]=currentHex();let slot=pendingQuickSlot;pendingQuickSlot=null;persist();render();flash('Warna disimpan di Quick Save '+(slot+1));}
  function armQuickSlot(slot){
    pendingQuickSlot=slot;
    content.querySelectorAll('[data-quick]').forEach(el=>el.classList.toggle('quick-armed',Number(el.dataset.quick)===slot));
    flash('Sentuh warna di lingkaran, lalu lepas jari untuk menyimpan');
  }
  function commitPixelField(field,announce,transmit=true){
    if(!field)return true;
    const parsed=Number.parseInt(field.value,10);
    const val=clamp(Number.isFinite(parsed)?parsed:state.pixel,1,1000);
    field.value=String(val);state.pixel=val;persist();
    const pv=document.getElementById('pixel-live');if(pv)pv.textContent=String(val);
    let sent=true;
    if(ready&&transmit){sent=send('pixel',val);if(announce&&sent)flash('Jumlah LED '+val+' dikirim');}
    else if(announce)flash('Jumlah LED '+val+' disimpan');
    console.info('[PIXEL SAVE]',val,ready&&transmit?'HsNative.pixel':'local');
    return sent;
  }
  function saveWallpaperFile(file){
    if(!file||!/^image\//.test(file.type||'')){flash('Pilih file gambar dari galeri');return;}
    const reader=new FileReader();
    reader.onerror=()=>flash('Foto tidak dapat dibaca');
    reader.onload=()=>{
      const image=new Image();
      image.onerror=()=>flash('Format foto tidak didukung');
      image.onload=()=>{
        const maxW=1440,maxH=2560,scale=Math.min(1,maxW/image.width,maxH/image.height),canvas=document.createElement('canvas');
        canvas.width=Math.max(1,Math.round(image.width*scale));canvas.height=Math.max(1,Math.round(image.height*scale));
        const context=canvas.getContext('2d');context.fillStyle='#05050d';context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(image,0,0,canvas.width,canvas.height);
        state.wallpaper=canvas.toDataURL('image/jpeg',.82);persist();applyWallpaper();render();flash('Wallpaper dari galeri diterapkan');
      };
      image.src=String(reader.result||'');
    };
    reader.readAsDataURL(file);
  }

  content.addEventListener('pointerdown',ev=>{const slider=ev.target.closest('.ref-live-slider');if(slider){const input=slider.querySelector('[data-slider]');if(input){sliderGesture={root:slider,input,pointerId:ev.pointerId,startX:ev.clientX,startY:ev.clientY,active:false,cancelled:false};return;}}if(ev.target.closest('[data-channel-toggle],[data-mode-channel],[data-channel]')){ev.stopPropagation();}const wheel=ev.target.closest('#hue-wheel'),dial=ev.target.closest('#dial'),quick=ev.target.closest('[data-quick]');if(wheel){wheelStart=wheel;wheel.setPointerCapture(ev.pointerId);chooseWheelPoint(wheelPointer(ev,wheel),false);ev.preventDefault();}if(dial){dialStart={x:ev.clientX,v:selectedModeValue(page,state.channel)};dial.setPointerCapture(ev.pointerId);}if(quick){quick.dataset.held='0';quick._long=setTimeout(()=>{quick.dataset.held='1';armQuickSlot(Number(quick.dataset.quick));},650);}});
  content.addEventListener('pointermove',ev=>{if(sliderGesture&&sliderGesture.pointerId===ev.pointerId){const dx=ev.clientX-sliderGesture.startX,dy=ev.clientY-sliderGesture.startY;if(!sliderGesture.active&&!sliderGesture.cancelled&&Math.max(Math.abs(dx),Math.abs(dy))>=5){if(Math.abs(dy)>Math.abs(dx)){sliderGesture.cancelled=true;}else{sliderGesture.active=true;try{sliderGesture.root.setPointerCapture(ev.pointerId);}catch(_){/* pointer capture is optional */}}}if(sliderGesture.active){updateSliderFromPointer(sliderGesture,ev.clientX,false);ev.preventDefault();}return;}if(wheelStart){chooseWheelPoint(wheelPointer(ev,wheelStart),Date.now()-wheelLastAt>125);wheelLastAt=Date.now();}if(dialStart){let diff=dialStart.x-ev.clientX;if(Math.abs(diff)>3){let raw=clamp(dialStart.v+diff/24,modeMin(page,state.channel),specs[page].max),nv=Math.round(raw);modeValue(nv,false);refreshRefRingRaw(raw);}}});
  content.addEventListener('pointerup',ev=>{if(sliderGesture&&sliderGesture.pointerId===ev.pointerId){if(!sliderGesture.cancelled)updateSliderFromPointer(sliderGesture,ev.clientX,true);try{if(sliderGesture.root.hasPointerCapture(ev.pointerId))sliderGesture.root.releasePointerCapture(ev.pointerId);}catch(_){/* already released */}sliderGesture=null;return;}if(wheelStart){chooseWheelPoint(wheelPointer(ev,wheelStart),true);wheelStart=null;commitPendingQuick();}if(dialStart){let selected=selectedModeValue(page,state.channel);dialStart=null;refreshRefRingRaw(selected);scrollRuler(selected,'smooth');if(specs[page]&&!specs[page].local)sendPageModeSelection(selected,state.channel);}let quick=ev.target.closest('[data-quick]');if(quick)clearTimeout(quick._long);});
  content.addEventListener('pointercancel',ev=>{if(sliderGesture&&sliderGesture.pointerId===ev.pointerId)sliderGesture=null;wheelStart=null;dialStart=null;});
  content.addEventListener('scroll',ev=>{if(ev.target.id==='auto-wheel'&&page==='auto'){cancelAnimationFrame(autoWheelFrame);autoWheelFrame=requestAnimationFrame(autoRefreshWheel);return;}if(ev.target.id!=='mode-ruler'||!specs[page])return;const min=modeMin(page,state.channel);let selected=clamp(Math.round(ev.target.scrollLeft/58)+min,min,specs[page].max),current=selectedModeValue(page,state.channel);if(current===selected)return;modeValue(selected,false);clearTimeout(rulerTimer);rulerTimer=setTimeout(()=>{if(specs[page]&&!specs[page].local)sendPageModeSelection(selected,state.channel);},180);},true);
  content.addEventListener('focusin',ev=>{if(ev.target.id!=='pixel')return;ev.target.value='';const pv=document.getElementById('pixel-live');if(pv)pv.textContent='';});
  content.addEventListener('focusout',ev=>{if(ev.target.id==='pixel')commitPixelField(ev.target,false,false);});
  content.addEventListener('input',ev=>{if(ev.target.id==='pixel'){ev.target.value=ev.target.value.replace(/\D/g,'').slice(0,4);const pv=document.getElementById('pixel-live');if(pv)pv.textContent=ev.target.value;return;}if(ev.target.matches('[data-slider]'))sliderInput(ev.target,false);});
  content.addEventListener('change',ev=>{if(ev.target.id==='wallpaper-file'){saveWallpaperFile(ev.target.files&&ev.target.files[0]);return;}if(ev.target.matches('[data-slider]'))sliderInput(ev.target,true);});
  content.addEventListener('keydown',ev=>{if(ev.target.id==='pixel'){if(ev.key==='ArrowUp'||ev.key==='ArrowDown')ev.preventDefault();if(ev.key==='Enter'){ev.preventDefault();ev.target.blur();}return;}if(ev.target.id==='hue-wheel'){if(ev.key==='ArrowLeft'||ev.key==='ArrowRight'){chooseHue(state.hue+(ev.key==='ArrowRight'?3:-3),true);ev.preventDefault();}}});
  content.addEventListener('click',ev=>{
    const modeChip=ev.target.closest('[data-auto-mode-index]');
    if(modeChip){autoSelectedModeIndex=Number(modeChip.dataset.autoModeIndex);render();return;}
    const target=ev.target.closest('button');if(!target)return;
    if(target.dataset.page){navigate(target.dataset.page);return;}
    if(target.dataset.autoProfile!==undefined){state.autoProfile=target.dataset.autoProfile;autoEditingId=null;autoSelectedModeIndex=null;autoDeleteId=null;persist();render();return;}
    if(target.dataset.autoRun!==undefined){autoRun(target.dataset.autoRun);return;}
    if(target.dataset.autoEdit!==undefined){autoEditingId=autoEditingId===target.dataset.autoEdit?null:target.dataset.autoEdit;autoSelectedModeIndex=null;autoDeleteId=null;render();return;}
    if(target.dataset.autoDeleteMode!==undefined){const row=autoFind(target.dataset.autoDeleteMode);if(row&&autoSelectedModeIndex!==null&&row.modes[autoSelectedModeIndex]!==undefined){row.modes.splice(autoSelectedModeIndex,1);autoSelectedModeIndex=null;persist();render();flash(autoText('modeRemoved'));}return;}
    if(target.dataset.autoDelete!==undefined){autoDeleteId=target.dataset.autoDelete;render();return;}
    if(target.dataset.autoDialog!==undefined){if(target.dataset.autoDialog==='confirm'&&autoDeleteId){if(autoRunningProfile===state.autoProfile&&autoRunningId===autoDeleteId)autoStop(false);state.autoCollects[state.autoProfile]=autoRows().filter(row=>row.id!==autoDeleteId);state.autoCollects[state.autoProfile].forEach((row,index)=>row.name='Collect '+(index+1));if(autoEditingId===autoDeleteId){autoEditingId=null;autoSelectedModeIndex=null;}persist();autoDeleteId=null;render();flash(autoText('deleted'));}else{autoDeleteId=null;render();}return;}
    if(target.dataset.autoWheel!==undefined){autoWheelValue=clamp(Number(target.dataset.autoWheel),1,210);const wheel=document.getElementById('auto-wheel');if(wheel)wheel.scrollTo({top:(autoWheelValue-1)*30,behavior:'smooth'});return;}
    if(target.dataset.autoAction!==undefined){
      const action=target.dataset.autoAction;
      if(action==='add'){let row=autoEditingId?autoFind(autoEditingId):null;if(!row){const rows=autoRows();row={id:state.autoProfile+'-'+Date.now(),name:'Collect '+(rows.length+1),modes:[],visual:rows.length%6};rows.push(row);autoEditingId=row.id;autoSelectedModeIndex=null;persist();render();flash(autoText('created'));return;}row.modes.push(autoWheelValue);autoSelectedModeIndex=null;persist();render();flash('Mode '+autoWheelValue+' → '+row.name);return;}
      if(action==='defaults'){state.speed=70;state.brightness=100;persist();if(autoRunningId)autoSchedule();render();flash(autoText('defaults'));return;}
      if(action==='run-all'){autoRunEvery();return;}
      if(action==='reset'){autoResetPlayback();return;}
      if(action==='save'){persist();target.classList.add('saved');setTimeout(()=>target.classList.remove('saved'),1200);flash(autoText('saved'));return;}
      if(action==='help'){flash(autoText('addHint'));return;}
    }
    if(target.dataset.channelToggle!==undefined){ev.preventDefault();ev.stopPropagation();toggleSoftChannel(Number(target.dataset.channelToggle));return;}
    if(target.dataset.channel!==undefined){selectChannel(Number(target.dataset.channel));return;}
    if(target.dataset.modeChannel!==undefined){selectModeChannel(Number(target.dataset.modeChannel));return;}
    if(target.dataset.modeValue!==undefined){const v=Number(target.dataset.modeValue);modeValue(v,true);scrollRuler(v,'smooth');return;}
    if(target.dataset.preset!==undefined){if(page==='home'&&target.classList.contains('preset')){target.classList.remove('preset-pop');void target.offsetWidth;target.classList.add('preset-pop');target.querySelectorAll('.flame-shape-anim').forEach(anim=>{try{anim.beginElement();}catch(_){}});target.addEventListener('animationend',()=>target.classList.remove('preset-pop'),{once:true});}choosePreset(Number(target.dataset.preset));return;}
    if(target.dataset.quick!==undefined){if(target.dataset.held==='1'){target.dataset.held='0';return;}let i=Number(target.dataset.quick),v=state.quick[i];if(!v){armQuickSlot(i);}else{state.rgb=v.match(/[0-9a-f]{2}/gi).map(x=>parseInt(x,16));const sel=page==='home'?4:state.channel;rememberRgb(state.rgb,sel);persist();updateWheel();sendRgbSelection(state.rgb,sel);flash('Warna slot '+(i+1)+' digunakan');}return;}
    if(target.dataset.autoToggle!==undefined){let i=Number(target.dataset.autoToggle);state.autoModes[i]=!state.autoModes[i];persist();target.classList.toggle('on',state.autoModes[i]);target.classList.toggle('off',!state.autoModes[i]);return;}
    if(target.dataset.lang!==undefined){state.language=target.dataset.lang;persist();render();flash(state.language==='id'?'Bahasa Indonesia dipilih':state.language==='en'?'English selected':'已选择中文');return;}
    if(target.dataset.delay!==undefined){state.delay=Number(target.dataset.delay);persist();render();return;}
    if(target.dataset.kButton!==undefined){if(!ready||customConnectedCount===0){flash('K1–K3 memerlukan minimal satu RGB HYBRID custom');return;}const k=clamp(Number(target.dataset.kButton),0,2);if(send('send',0x11,k,3))flash('Perintah K'+(k+1)+' dikirim');return;}
    if(target.dataset.area!==undefined){if(!ready||deviceType!=='dmx'){flash('Perangkat terhubung tidak mendukung SUB AREA');return;}const area=clamp(Number(target.dataset.area),0,2);state.subarea=area;persist();document.querySelectorAll('[data-area]').forEach(el=>el.classList.toggle('active',Number(el.dataset.area)===area));if(area===0){if(send('send',0x14,0,3))flash('Kotak REM CH3/CH4 dikirim');}else if(send('subareaDouble',area))flash(area===1?'Panah kiri dikirim':'Panah kanan dikirim');return;}
    if(target.id==='power'){let next=!state.power;if(ready)send('send',4,next?1:0,3);state.power=next;state.channelEnabled=[next,next,next,next];persist();target.classList.toggle('on',state.power);target.setAttribute('aria-label','Lampu '+(state.power?'mati':'nyala'));refreshChannelVisuals();refreshRefVisuals();return;}
    switch(target.dataset.action){
      case 'connect': if(!window.HsNative){flash('Bluetooth tersedia di APK Android');break;}window.HsNative.connect();break;
      case 'pixel':{commitPixelField(document.getElementById('pixel'),true,true);break;}
      case 'mode-save':{const pixelOk=commitPixelField(document.getElementById('pixel'),false,true);if(!pixelOk)break;let spec=specs[page],v=selectedModeValue(page,state.channel);persist();if(spec.local){flash('Pixel dan Mode '+v+' disimpan di ponsel');break;}let ok=sendPageModeSelection(v,state.channel);if(ok)flash((document.getElementById('pixel')?'Pixel '+state.pixel+' + ':'')+'Mode '+v+' dikirim');break;}
      case 'auto-save':if(ready){if(send('send',3,255,3))flash('AUTO bawaan MCU diaktifkan');}else flash('Pengaturan AUTO disimpan di aplikasi');break;
      case 'password-reset':state.localPassword='';persist();flash('Password aplikasi direset');break;
      case 'autolock':state.autoLock=!state.autoLock;persist();if(ready)send('send',0x16,state.autoLock?1:0,3);render();flash(state.autoLock?'AUTO LOCK ON':'AUTO LOCK OFF');break;
      case 'wallpaper-choose':{const picker=document.getElementById('wallpaper-file');if(picker)picker.click();break;}
      case 'wallpaper-remove':state.wallpaper='';persist();applyWallpaper();render();flash('Wallpaper dihapus');break;
      case 'password-save':{const a=document.getElementById('pass1'),b=document.getElementById('pass2');const p1=a?a.value:'',p2=b?b.value:'';if(!p1||p1!==p2){flash('Password dan konfirmasi harus sama');break;}state.localPassword=p1;persist();flash('Password aplikasi disimpan');break;}
      case 'lock':if(send('send',22,1,3))flash('Kunci modul dikirim');break;
      case 'unlock':if(send('send',22,0,3))flash('Buka kunci modul dikirim');break;
      case 'ota':if(window.HsNative)window.HsNative.ota();else flash('Tautan OTA tersedia di APK');break;
    }
  });
  content.addEventListener('dblclick',ev=>{const target=ev.target.closest('[data-area="0"]');if(!target)return;ev.preventDefault();if(!ready||deviceType!=='dmx'){flash('Perangkat terhubung tidak mendukung SUB AREA');return;}state.subarea=0;persist();if(send('subareaDouble',0))flash('Semua SEN diaktifkan');});
  document.getElementById('drawer-links').addEventListener('click',ev=>{let link=ev.target.closest('[data-page]');if(link){ev.preventDefault();navigate(link.dataset.page);}});
  document.getElementById('drawer-close').addEventListener('click',()=>setDrawer(false));backdrop.addEventListener('click',()=>setDrawer(false));
  nav.addEventListener('click',()=>page==='home'?navigate('settings'):window.hsGoBack());settingsShortcut.addEventListener('click',()=>navigate('settings'));
  document.getElementById('connection').addEventListener('click',ev=>{if(!ev.target.closest('#connect'))return;if(!window.HsNative){flash('Bluetooth hanya tersedia dalam APK Android');return;}ready?window.HsNative.disconnect():window.HsNative.connect();});
  render();
})();
