/*
============================================================================
GLOBAL ENGINE WORK REV25.10 — MODE 1-200 GLOBAL 10MS
ESP32-C3 4-CHANNEL LED CONTROLLER (WS2812B)
// BUILD RANGE: MODE 1-200 — GLOBAL 4CH, FASTEST EFFECT FRAME 10ms
============================================================================
*/

// COMPILE FIX ONLY — Arduino .ino auto-prototype compatibility for Mode 73-80
struct M7380Color { float r, g, b; };
struct M7380Sample { float v; M7380Color c; };
struct M93100Color { float r, g, b; };
struct M93100Sample { float v; M93100Color c; };
struct M101120Color { float r, g, b; };
struct M101120Sample { float v; M101120Color c; };
struct M121140Color { float r, g, b; };
struct M121140Sample { float v; M121140Color c; };
struct M141160Color { float r, g, b; };
struct M141160Sample { float v; M141160Color c; };
struct M161180Color { float r, g, b; };
struct M161180Sample { float v; M161180Color c; };
struct M181200Color { float r, g, b; };
struct M181200Sample { float v; M181200Color c; };
struct M201210Color { float r, g, b; };
struct M201210Sample { float v; M201210Color c; };

// COMPILE FIX — Arduino 1.8.x auto-prototype compatibility for Welcome 38-39
struct GW38Shape { float head, headPing, back, backPing, broad, edgeK, freq, tailMix; };
struct GW39Shape { float head, headPing, back, backPing, broad, edgeK, freq, tailMix; };

// COMPILE FIX — Arduino 1.8.x auto-prototype compatibility for Welcome 6
struct GW6Shape { float head, headPing, back, backPing, broad, edgeK, freq, tailMix; };
struct GW6Eval { float brightness; float r, g, b; };

// COMPILE FIX11A — Arduino 1.8.x auto-prototype compatibility for shared Welcome 14..23
struct GW1423SharedConfig;

// COMPILE FIX — Arduino 1.8.x auto-prototype compatibility for Welcome 38-39

#include <Arduino.h>
// FIX13C: rebuilt from clean FIX11A; renderer/effect math unchanged.
// FIX11 SIZE SAFE STAGE1: Welcome 14..23 dikembalikan ke shared engine versi 1722 KB.
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <BLEAdvertising.h>
#include <esp_gap_ble_api.h>
#include <Update.h>
#include <FastLED.h>
#include <Preferences.h>
#include <cmath>
#include <nvs_flash.h>

// ============================================================================
// PENTING: FORMAT NVS (UBAH KE 1 UNTUK FORMAT, LALU KEMBALIKAN KE 0 & UPLOAD ULANG)
// ============================================================================
#define WIPE_NVS_ON_BOOT 0 

#ifndef PI
#define PI 3.14159265358979323846f
#endif

// ============================================================================
// HARDWARE MAPPING
// ============================================================================
#define LED_PIN_1 6   // CH1 -> Alis Kiri
#define LED_PIN_2 5   // CH2 -> Alis Kanan
#define LED_PIN_3 0   // CH3 -> Mirror Kiri
#define LED_PIN_4 1   // CH4 -> Mirror Kanan

#define PIN_SEN_KIRI  2
#define PIN_SEN_KANAN 3
#define PIN_REM       4
#define PIN_MUNDUR    10  // Input MUNDUR / reverse gear, aktif LOW
#define PIN_SENJA     7

#define STAGE0_LED_BUFFER 1000
CRGB leds1[STAGE0_LED_BUFFER];
CRGB leds2[STAGE0_LED_BUFFER];
CRGB leds3[STAGE0_LED_BUFFER];
CRGB leds4[STAGE0_LED_BUFFER];

CLEDController *ledController1 = nullptr;
CLEDController *ledController2 = nullptr;
CLEDController *ledController3 = nullptr;
CLEDController *ledController4 = nullptr;

// ============================================================================
// BLE PROFILE — LEDCAR-02-9931
// ============================================================================
#define BLE_NAME_CAR "LEDCAR-02-9931"
#define SERVICE_UUID        "0000ffe0-0000-1000-8000-00805f9b34fb"
#define CHARACTERISTIC_UUID "0000ffe1-0000-1000-8000-00805f9b34fb"


// ============================================================================
// OTA PROFILE — BLUETOOTH ONLY
// ============================================================================
#define BLE_OTA_SERVICE_UUID "7e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define BLE_OTA_DATA_UUID    "7e400002-b5a3-f393-e0a9-e50e24dcca9e"
#define BLE_OTA_CTRL_UUID    "7e400003-b5a3-f393-e0a9-e50e24dcca9e"
#define BLE_OTA_STATUS_UUID  "7e400004-b5a3-f393-e0a9-e50e24dcca9e"

volatile bool bleOtaActive = false;
volatile bool bleOtaRestartPending = false;
unsigned long bleOtaRestartRequestedAt = 0;
size_t bleOtaExpectedSize = 0;
size_t bleOtaReceivedSize = 0;
size_t bleOtaLastNotifyBytes = 0;
BLECharacteristic *bleOtaStatusCharacteristic = nullptr;

static void bleOtaStatus(const String &msg) {
  Serial.printf("[BLE OTA] %s\n", msg.c_str());

  // Status OTA dikirim melalui service OTA Bluetooth.
  if (bleOtaStatusCharacteristic) {
    bleOtaStatusCharacteristic->setValue(msg.c_str());
    bleOtaStatusCharacteristic->notify();
  }
}

volatile bool bleConnected = false;
volatile bool bleRestartRequested = false;
unsigned long bleDisconnectedAt = 0;
unsigned long bleLastValidPacketAt = 0;

static unsigned long k1MappingLastActivityAt = 0;
static constexpr unsigned long K1_MAPPING_TIMEOUT_MS = 25000UL;

static const uint8_t ledcarAdvData[] = {
  0x02, 0x01, 0x06,
  0x03, 0x03, 0xE0, 0xFF,
  0x0F, 0x09,
  'L','E','D','C','A','R','-','0','2','-','9','9','3','1'
};

// OTA FIX V2:
// OTA service UUID ikut diumumkan lewat scan-response.
// Advertisement utama LEDLAMP/LEDCAR tetap persis membawa FFE0 + nama perangkat,
// jadi kompatibilitas aplikasi lama tidak diubah.
static const uint8_t ledcarOtaScanData[] = {
  0x11, 0x07,                         // length=17, Complete List of 128-bit Service UUIDs
  0x9E, 0xCA, 0xDC, 0x24,
  0x0E, 0xE5, 0xA9, 0xE0,
  0x93, 0xF3, 0xA3, 0xB5,
  0x01, 0x00, 0x40, 0x7E              // 7e400001-b5a3-f393-e0a9-e50e24dcca9e (BLE little-endian)
};

// ============================================================================
// STATE VARIABLES
// ============================================================================
volatile uint8_t appBrightness = 100;
volatile uint8_t brightness255 = 255;
volatile uint8_t appSpeed = 75;
volatile float liveSpeedFactor = 1.78f;
volatile bool lampOn = true;
volatile bool lockedState = false;
volatile bool autoMode = false;
volatile uint16_t activeLedCount = 75;

volatile uint8_t selectedMode[4] = {1,1,1,1};
volatile uint8_t selectedWelcome = 0;
volatile uint8_t configuredWelcome = 0;

// Welcome CONTACT dan SENJA benar-benar independen.
// CONTACT = modul hidup / PIN7 LOW.
// SENJA   = PIN7 HIGH.
volatile uint8_t contactWelcomeMode = 0;
volatile uint8_t senjaWelcomeMode = 0;
volatile bool senjaPhysicalActive = false;
volatile uint8_t specialWelcomeContext = 0; // 0=normal, 1=CONTACT, 2=SENJA
volatile bool contactStandbyRedActive = false;

volatile uint8_t selectedSen = 0; // visible slot 1..10
volatile uint8_t senSlotVariant[11] = {0}; // index 1..10: 0=A, 1=B => total 20 mode
volatile bool senDirectionReverse = true;  // default arah KELUAR; toggle global semua SEN
volatile bool senMenuActive = false;       // true selama UI terakhir berada di menu SEN
static bool senDirectionTriggerLatched = false;
static unsigned long senDirectionBothOffSince = 0UL;
static unsigned long senLastAcceptedTapAt = 0UL;
static constexpr unsigned long SEN_TAP_DEBOUNCE_MS = 280UL;
static constexpr unsigned long SEN_DIRECTION_REARM_OFF_MS = 1500UL;
volatile uint8_t selectedRem = 0;
volatile uint8_t selectedMundur = 1; // 10 mode putih; default Mode 1
volatile uint8_t selectedKButton = 0xFF;
volatile uint8_t dmxSubarea = 0xFF;

bool brake34Enabled = false;
uint8_t turnPairSelection = 0; 
uint8_t dmxLastSubareaTap = 0xFF;
unsigned long dmxLastSubareaTapMs = 0;

static bool dmxBoxSinglePending = false;
static unsigned long dmxBoxFirstTapMs = 0;
static constexpr unsigned long DMX_BOX_DOUBLE_WINDOW_MS = 550UL;

volatile uint8_t rgbR[4] = {255,255,255,255};
volatile uint8_t rgbG[4] = {255,255,255,255};
volatile uint8_t rgbB[4] = {255,255,255,255};
volatile bool solidRgbActive = false;
volatile bool solidRgbForceRender = false;
static uint32_t solidRgbLastRenderAt = 0;

enum MainSource : uint8_t {
  MAIN_WELCOME = 0,
  MAIN_RGB     = 1,
  MAIN_MODE    = 2
};
volatile uint8_t mainSource = MAIN_WELCOME;
static bool modeRunning = false;
static bool modeForceRender = false;
static bool welcomeRunning = false;
static bool welcomeForceRender = false;

// Sumber utama per channel: tiap CH bisa independen RGB atau MODE.
// mainSource tetap dipakai sebagai konteks UI terakhir / status WELCOME sementara.
volatile uint8_t channelSource[4] = {MAIN_MODE, MAIN_MODE, MAIN_MODE, MAIN_MODE};

// ON/OFF keluaran aplikasi per channel. Efek/mode tetap disimpan dan terus
// dirender; channel OFF hanya dimask tepat sebelum output sehingga saat ON
// kembali efek melanjutkan tanpa diganti RGB hitam.
volatile bool channelOutputEnabled[4] = {true, true, true, true};

static inline bool isValidBaseSource(uint8_t src) { return src == MAIN_RGB || src == MAIN_MODE; }

static inline void refreshBaseSourceFlags() {
  bool anyRgb = false, anyMode = false;
  for (uint8_t ch = 0; ch < 4; ch++) {
    if (channelSource[ch] == MAIN_RGB) anyRgb = true;
    else if (channelSource[ch] == MAIN_MODE) anyMode = true;
  }
  solidRgbActive = anyRgb;
  modeRunning = anyMode;
}

static inline int8_t channelCodeToIndex(uint8_t code) {
  if (code == 0x01) return 0; // LED1 / CH1
  if (code == 0x02) return 1; // LED2 / CH2
  if (code == 0x04) return 2; // LED3 / CH3
  if (code == 0x05) return 3; // LED4 / CH4
  return -1;                 // 0x03 = ALL
}

static inline void setAllChannelSources(uint8_t src) {
  for (uint8_t ch = 0; ch < 4; ch++) channelSource[ch] = src;
  refreshBaseSourceFlags();
}

static bool contactOn = true;
static bool welcomePlaylistPlaying = false;
static uint8_t welcomeReturnSource = MAIN_MODE;

uint8_t mappedWelcome[256];
bool isMappingMode = false;
uint8_t mapTargetWelcome = 0xFF;
uint8_t mapTarget210 = 0xFF;
uint8_t k1PendingWelcome = 0xFF;

uint8_t welcomePlaylist[3] = {0x00, 0xFF, 0xFF};
uint8_t tempPlaylist[3] = {0xFF, 0xFF, 0xFF};
uint8_t playingPlaylistIndex = 0;
bool k2PlaylistConfigured = false;
int k2SetupState = 0;
bool isWaitingToLockSelection = false;
uint8_t pendingPlaylistSelection = 0xFF;
unsigned long lastWelcomeSelectionTime = 0;

struct ChannelColorOverrideV3 {
  uint8_t mask = 0;
  uint8_t r[4] = {255,255,255,255};
  uint8_t g[4] = {255,255,255,255};
  uint8_t b[4] = {255,255,255,255};
};
ChannelColorOverrideV3 effectColorOverrides[211];
ChannelColorOverrideV3 welcomeColorOverrides[51];
bool k3PauseActive = false;
unsigned long k3PauseStartedAt = 0;
const unsigned long K3_DOUBLE_TAP_WINDOW = 800;
uint8_t k3TapCount = 0;
unsigned long k3TapLastMs = 0;
bool k3ResetDecisionPending = false;
uint8_t k3EditContext = 0;
uint8_t k3EditStage = 0;
bool k3EditReceivedColor = false;
uint8_t k3EditModeByChannel[4] = {1,1,1,1};
uint8_t k3EditWelcomeByChannel[4] = {0,0,0,0};
unsigned long k3LastColorEditTime = 0;
unsigned long k3EditStageStartedAt = 0;
const unsigned long K3_NO_COLOR_TIMEOUT_MS = 5000;
const unsigned long K3_COLOR_SETTLE_MS = 3000;

// RAM OPT: buffer tambahan mengikuti activeLedCount, bukan selalu 1000.
// Buffer LED utama leds1..leds4 tetap 1000 agar batas maksimum tidak berubah.
static CRGB *runtimeCrgbAuxPool = nullptr;
static float *runtimeFloatAuxPool = nullptr;
static uint16_t runtimeAuxCount = 0;

CRGB *k3LastVisible1 = nullptr;
CRGB *k3LastVisible2 = nullptr;
CRGB *k3LastVisible3 = nullptr;
CRGB *k3LastVisible4 = nullptr;
CRGB *k3EditBase = nullptr;
CRGB *k3EditPreview = nullptr;
CRGB *k3ShowScratch1 = nullptr;
CRGB *k3ShowScratch2 = nullptr;
CRGB *k3ShowScratch3 = nullptr;
CRGB *k3ShowScratch4 = nullptr;
bool k3LastVisibleValid1 = false;
bool k3LastVisibleValid2 = false;
bool k3LastVisibleValid3 = false;
bool k3LastVisibleValid4 = false;

volatile int pendingBlinkCount = 0;
int currentBlinksDone = 0;
unsigned long lastBlinkToggle = 0;
bool isBlinkOn = false;
CRGB pendingBlinkColor = CRGB::Black;
uint8_t pendingBlinkTargetMask = 0x00;

volatile uint8_t senBrightness = 100;
volatile uint8_t remBrightness = 100;
volatile uint8_t senSpeed = 100;
volatile uint8_t remSpeed = 100;

volatile bool pendingChipUpdate = false;
volatile uint16_t pendingLedCount = 75;
volatile bool pendingClearOutput = false;
volatile bool pendingWelcomeRestart = false;

Preferences prefs;
Preferences k3Prefs;

static bool saveK3RecordVerified(uint8_t context, uint8_t id);
static void loadK3DirectRecords();
static void loadK3WelcomeDirectRecordsOnly();
bool persistK3ColorOverridesVerified();

static volatile bool pendingK1DirectSave = false;
static volatile uint8_t pendingK1DirectWelcome = 0xFF;
static volatile uint8_t pendingK1DirectMode = 0xFF;
static volatile bool pendingK1FactoryReset = false;
static volatile bool k1DoubleClickWindowActive = false;
static unsigned long k1FirstTapAt = 0;
static unsigned long k1LastAcceptedTapAt = 0;
static constexpr unsigned long K1_FACTORY_DOUBLE_CLICK_MS = 650UL;
static constexpr unsigned long K1_BUTTON_DEBOUNCE_MS = 180UL;

static bool loadK1DirectMapping(uint8_t welcomeId, uint8_t &modeOut) {
  char key[5];
  snprintf(key, sizeof(key), "w%02X", welcomeId);
  Preferences kp;
  if (!kp.begin("k1map", true)) return false;
  if (!kp.isKey(key)) { kp.end(); return false; }
  uint8_t m = kp.getUChar(key, 0xFF);
  kp.end();
  if (m < 1 || m > 210) return false;
  modeOut = m;
  return true;
}

static bool saveK1DirectMappingVerified(uint8_t welcomeId, uint8_t modeId) {
  if (modeId < 1 || modeId > 210) return false;
  char key[5];
  snprintf(key, sizeof(key), "w%02X", welcomeId);
  Preferences kp;
  if (!kp.begin("k1map", false)) return false;
  size_t wroteMap = kp.putUChar(key, modeId);
  kp.end();
  if (wroteMap != 1) return false;
  if (!prefs.begin("ledcar4ch", false)) return false;
  size_t wroteWel = prefs.putUChar("wel", welcomeId);
  prefs.end();
  if (wroteWel != 1) return false;
  uint8_t verifyMode = 0xFF;
  bool mapOk = loadK1DirectMapping(welcomeId, verifyMode);
  if (!prefs.begin("ledcar4ch", true)) return false;
  uint8_t verifyWel = prefs.getUChar("wel", 0xFF);
  prefs.end();
  return mapOk && verifyMode == modeId && verifyWel == welcomeId;
}

static bool resetK1MappingsFactoryVerified() {
  pendingK1DirectSave = false;
  pendingK1DirectWelcome = 0xFF;
  pendingK1DirectMode = 0xFF;
  k1DoubleClickWindowActive = false;
  k1FirstTapAt = 0;
  memset(mappedWelcome, 0xFF, sizeof(mappedWelcome));
  bool directOk = false;
  {
    Preferences kp;
    if (kp.begin("k1map", false)) {
      directOk = kp.clear();
      kp.end();
    }
  }
  bool legacyWriteOk = false;
  if (prefs.begin("ledcar4ch", false)) {
    size_t wrote = prefs.putBytes("welMap", mappedWelcome, sizeof(mappedWelcome));
    legacyWriteOk = (wrote == sizeof(mappedWelcome));
    prefs.end();
  }
  bool legacyVerifyOk = false;
  if (prefs.begin("ledcar4ch", true)) {
    uint8_t verifyMap[sizeof(mappedWelcome)];
    size_t len = prefs.getBytesLength("welMap");
    if (len == sizeof(verifyMap) && prefs.getBytes("welMap", verifyMap, sizeof(verifyMap)) == sizeof(verifyMap)) {
      legacyVerifyOk = true;
      for (size_t i = 0; i < sizeof(verifyMap); i++) {
        if (verifyMap[i] != 0xFF) { legacyVerifyOk = false; break; }
      }
    }
    prefs.end();
  }
  return directOk && legacyWriteOk && legacyVerifyOk;
}

static bool settingsDirty = false;
static bool settingsUrgentSave = false;
static uint32_t settingsLastChangedAt = 0;
static constexpr uint32_t AUTOSAVE_IDLE_MS = 800UL;
static constexpr uint32_t AUTOSAVE_URGENT_MS = 200UL;

static volatile bool pendingSaveWelcomeMap = false;
static volatile bool pendingSaveConfiguredWelcome = false;
static volatile bool pendingSaveWelcomePlaylist = false;
static volatile bool pendingPersistK3 = false;
static volatile bool pendingK3Show = false;
static uint8_t k1LastSavedWelcome = 0xFF;
static uint8_t k1LastSavedMode = 0xFF;

static inline void markSettingsDirty() {
  settingsDirty = true;
  settingsLastChangedAt = millis();
}
static inline void markSettingsUrgent() {
  settingsDirty = true;
  settingsUrgentSave = true;
  settingsLastChangedAt = millis();
}

static bool saveConfiguredWelcomeVerified(uint8_t welcomeId) {
  Preferences wp;
  if (!wp.begin("ledcar4ch", false)) return false;
  size_t wrote = wp.putUChar("wel", welcomeId);
  wp.end();
  if (wrote != sizeof(uint8_t)) return false;
  if (!wp.begin("ledcar4ch", true)) return false;
  uint8_t check = wp.getUChar("wel", 0xFF);
  wp.end();
  return check == welcomeId;
}

static inline float calculateLiveSpeedFactor(uint8_t v) {
  if (v < 1) v = 1;
  if (v > 100) v = 100;
  float delayMs = 50.0f - ((float)(v - 1) * 45.0f / 99.0f);
  if (delayMs < 5.0f) delayMs = 5.0f;
  if (delayMs > 50.0f) delayMs = 50.0f;
  return 25.0f / delayMs;
}

static inline uint8_t convertBrightness100To255(uint8_t v) {
  if (v < 1) v = 1;
  if (v > 100) v = 100;
  return (uint8_t)(1U + (((uint16_t)(v - 1U) * 254U + 49U) / 99U));
}

static inline uint16_t calculateAppStepMs(uint8_t v) {
  if (v < 1) v = 1;
  if (v > 100) v = 100;
  uint16_t d = (uint16_t)(50U - (((uint32_t)(v - 1U) * 45U + 49U) / 99U));
  if (d < 5U) d = 5U;
  if (d > 50U) d = 50U;
  return d;
}

static void saveSettingsNow() {
  prefs.begin("ledcar4ch", false);
  prefs.putUChar("bri", appBrightness);
  prefs.putUChar("spd", appSpeed);
  prefs.putUShort("ledcnt", activeLedCount);
  prefs.putBool("lamp", lampOn);
  prefs.putBool("rgbmode", solidRgbActive);

  uint8_t savedMainSource = mainSource;
  if (savedMainSource == MAIN_WELCOME) {
    savedMainSource = welcomeReturnSource;
    if (savedMainSource != MAIN_RGB && savedMainSource != MAIN_MODE) {
      savedMainSource = MAIN_MODE;
    }
  }
  prefs.putUChar("main", savedMainSource);
  prefs.putUChar("wel", configuredWelcome);
  prefs.putUChar("contactWel", contactWelcomeMode);
  prefs.putUChar("senjaWel", senjaWelcomeMode);
  prefs.putUChar("mode", selectedMode[0]);
  prefs.putBool("k2cfg", k2PlaylistConfigured);
  prefs.putBool("auto", autoMode);
  prefs.putBool("lock", lockedState);
  prefs.putUChar("sen", selectedSen);
  prefs.putBytes("senVar20", (const void*)senSlotVariant, sizeof(senSlotVariant));
  prefs.putBool("senRev", senDirectionReverse);
  prefs.putUChar("rem", selectedRem);
  prefs.putUChar("mundur", selectedMundur);
  prefs.putUChar("bBri", remBrightness);
  prefs.putUChar("bSpd", remSpeed);
  prefs.putBool("brk34", brake34Enabled);
  prefs.putUChar("turnpair", turnPairSelection);
  prefs.putBytes("welMap", mappedWelcome, sizeof(mappedWelcome));

  uint8_t modes[4] = { selectedMode[0], selectedMode[1], selectedMode[2], selectedMode[3] };
  uint8_t rgbs[12] = {
    rgbR[0], rgbG[0], rgbB[0],
    rgbR[1], rgbG[1], rgbB[1],
    rgbR[2], rgbG[2], rgbB[2],
    rgbR[3], rgbG[3], rgbB[3]
  };
  uint8_t srcs[4] = { channelSource[0], channelSource[1], channelSource[2], channelSource[3] };
  prefs.putBytes("modes", modes, sizeof(modes));
  prefs.putBytes("rgbs", rgbs, sizeof(rgbs));
  prefs.putBytes("srcs", srcs, sizeof(srcs));
  prefs.end();
  settingsDirty = false;
  settingsUrgentSave = false;
}

static void serviceDeferredAutoSave() {
  if (!settingsDirty) return;
  const uint32_t waitMs = settingsUrgentSave ? AUTOSAVE_URGENT_MS : AUTOSAVE_IDLE_MS;
  if ((uint32_t)(millis() - settingsLastChangedAt) < waitMs) return;
  saveSettingsNow();
}

static void loadSavedSettings() {
  prefs.begin("ledcar4ch", true);
  appBrightness = prefs.getUChar("bri", 100);
  if (appBrightness < 1) appBrightness = 1;
  if (appBrightness > 100) appBrightness = 100;
  appSpeed = prefs.getUChar("spd", 75);
  if (appSpeed < 1) appSpeed = 1;
  if (appSpeed > 100) appSpeed = 100;
  activeLedCount = prefs.getUShort("ledcnt", 75);

  memset(mappedWelcome, 0xFF, sizeof(mappedWelcome));
  size_t mapLen = prefs.getBytesLength("welMap");
  if (mapLen > 0) {
    size_t toRead = (mapLen <= sizeof(mappedWelcome)) ? mapLen : sizeof(mappedWelcome);
    prefs.getBytes("welMap", mappedWelcome, toRead);
  }

  if (prefs.getBytesLength("welPlay") != 3) {
    welcomePlaylist[0] = 0x00; welcomePlaylist[1] = 0xFF; welcomePlaylist[2] = 0xFF;
  } else {
    prefs.getBytes("welPlay", welcomePlaylist, 3);
  }
  k2PlaylistConfigured = prefs.getBool("k2cfg", false);

  memset(effectColorOverrides, 0, sizeof(effectColorOverrides));
  memset(welcomeColorOverrides, 0, sizeof(welcomeColorOverrides));
  bool loadedK3Main = false;
  if (prefs.getBytesLength("fxClrV3") == sizeof(effectColorOverrides)) {
    prefs.getBytes("fxClrV3", effectColorOverrides, sizeof(effectColorOverrides));
    loadedK3Main = true;
  }
  if (prefs.getBytesLength("welClrV3") == sizeof(welcomeColorOverrides)) {
    prefs.getBytes("welClrV3", welcomeColorOverrides, sizeof(welcomeColorOverrides));
    loadedK3Main = true;
  }

  if (!loadedK3Main) {
    k3Prefs.begin("k3color", true);
    if (k3Prefs.getBool("init", false)) {
      if (k3Prefs.getBytesLength("fx") == sizeof(effectColorOverrides)) {
        k3Prefs.getBytes("fx", effectColorOverrides, sizeof(effectColorOverrides));
      }
      if (k3Prefs.getBytesLength("wel") == sizeof(welcomeColorOverrides)) {
        k3Prefs.getBytes("wel", welcomeColorOverrides, sizeof(welcomeColorOverrides));
      }
    }
    k3Prefs.end();
  }
  
  loadK3DirectRecords();
  loadK3WelcomeDirectRecordsOnly();

  if (activeLedCount < 1) activeLedCount = 1;
  if (activeLedCount > STAGE0_LED_BUFFER) activeLedCount = STAGE0_LED_BUFFER;
  pendingLedCount = activeLedCount;

  lampOn = prefs.getBool("lamp", true);
  solidRgbActive = prefs.getBool("rgbmode", false);
  mainSource = prefs.getUChar("main", solidRgbActive ? MAIN_RGB : MAIN_MODE);
  if (mainSource != MAIN_RGB && mainSource != MAIN_MODE) mainSource = MAIN_MODE;
  welcomeReturnSource = mainSource;
  configuredWelcome = prefs.getUChar("wel", 0);
  if (configuredWelcome > 50U) configuredWelcome = 0U;
  selectedWelcome = configuredWelcome;

  // Migrasi aman: pertama kali CONTACT/SENJA memakai Welcome global terakhir,
  // setelah itu keduanya tersimpan independen.
  contactWelcomeMode = prefs.getUChar("contactWel", configuredWelcome);
  senjaWelcomeMode   = prefs.getUChar("senjaWel", configuredWelcome);
  if (contactWelcomeMode > 50U) contactWelcomeMode = configuredWelcome;
  if (senjaWelcomeMode > 50U) senjaWelcomeMode = configuredWelcome;

  uint8_t savedMode = prefs.getUChar("mode", 1);
  if (savedMode < 1 || savedMode > 210) savedMode = 1;
  for (uint8_t i = 0; i < 4; i++) selectedMode[i] = savedMode;

  autoMode = prefs.getBool("auto", false);
  lockedState = prefs.getBool("lock", false);
  
  selectedSen = prefs.getUChar("sen", 0);
  if (selectedSen > 10) selectedSen = 1;
  memset((void*)senSlotVariant, 0, sizeof(senSlotVariant));
  if (prefs.getBytesLength("senVar20") == sizeof(senSlotVariant)) {
    prefs.getBytes("senVar20", (void*)senSlotVariant, sizeof(senSlotVariant));
    for (uint8_t s = 1; s <= 10; s++) senSlotVariant[s] = senSlotVariant[s] ? 1U : 0U;
  }
  senDirectionReverse = prefs.getBool("senRev", true);
  senMenuActive = false;
  senDirectionTriggerLatched = false;
  senDirectionBothOffSince = 0UL;
  selectedRem = prefs.getUChar("rem", 0);
  if (selectedRem > 10) selectedRem = 1;
  selectedMundur = prefs.getUChar("mundur", 1);
  if (selectedMundur < 1 || selectedMundur > 10) selectedMundur = 1;
  // FIX10: REM fisik CH3+CH4 SELALU OFF setiap boot.
  // Harus di-enable manual dengan Kotak SUB AREA 1x pada sesi ini.
  // Nilai lama di NVS sengaja diabaikan agar trigger REM tidak bisa aktif sendiri setelah restart.
  brake34Enabled = false;
  turnPairSelection = 0;

  uint8_t modes[4] = {1,1,1,1};
  if (prefs.getBytesLength("modes") == sizeof(modes)) {
    prefs.getBytes("modes", modes, sizeof(modes));
    for (uint8_t i = 0; i < 4; i++) {
      if (modes[i] < 1 || modes[i] > 210) modes[i] = 1;
      selectedMode[i] = modes[i];
    }
  }
  uint8_t rgbs[12];
  if (prefs.getBytesLength("rgbs") == sizeof(rgbs)) {
    prefs.getBytes("rgbs", rgbs, sizeof(rgbs));
    for (uint8_t ch = 0; ch < 4; ch++) {
      rgbR[ch] = rgbs[ch*3 + 0]; rgbG[ch] = rgbs[ch*3 + 1]; rgbB[ch] = rgbs[ch*3 + 2];
    }
  }

  // Migrasi aman: firmware lama hanya punya satu mainSource.
  for (uint8_t ch = 0; ch < 4; ch++) channelSource[ch] = mainSource;
  uint8_t srcs[4];
  if (prefs.getBytesLength("srcs") == sizeof(srcs)) {
    prefs.getBytes("srcs", srcs, sizeof(srcs));
    for (uint8_t ch = 0; ch < 4; ch++) {
      if (isValidBaseSource(srcs[ch])) channelSource[ch] = srcs[ch];
    }
  }
  prefs.end();
  refreshBaseSourceFlags();

  brightness255 = convertBrightness100To255(appBrightness);
  liveSpeedFactor = calculateLiveSpeedFactor(appSpeed);
  senBrightness = appBrightness;
  senSpeed = appSpeed;

  // Restore nilai REM dedicated bila pernah disimpan; firmware lama kompatibel.
  {
    Preferences rp;
    if (rp.begin("ledcar4ch", true)) {
      remBrightness = rp.getUChar("bBri", appBrightness);
      remSpeed = rp.getUChar("bSpd", appSpeed);
      rp.end();
    } else {
      remBrightness = appBrightness;
      remSpeed = appSpeed;
    }
    if (remBrightness > 100U) remBrightness = appBrightness;
    if (remSpeed < 1U || remSpeed > 100U) remSpeed = appSpeed;
  }
}

void resetCustomSuites();
static void selectModeRealtime(uint8_t mode, uint8_t channelCode);

void triggerTargetBlink(CRGB color, int count, uint8_t mask) {
  pendingBlinkColor = color; pendingBlinkCount = count;
  pendingBlinkTargetMask = mask; currentBlinksDone = 0;
  isBlinkOn = false; lastBlinkToggle = millis() - 150;
}

void triggerBlink(CRGB color, int count) {
  triggerTargetBlink(color, count, 0x00);
}

static inline void signalK3EditStage(uint8_t stage) {
  if (stage < 1 || stage > 4) return;
  uint8_t mask = (uint8_t)(1U << (stage - 1U));
  triggerTargetBlink(CRGB::White, 3, mask);
}

static void cancelVisualFeedback() {
  pendingBlinkCount = 0; currentBlinksDone = 0; isBlinkOn = false; pendingBlinkTargetMask = 0x00;
}

void handleNonBlockingBlink() {
  if (pendingBlinkCount <= 0) return;
  unsigned long now = millis();
  if (now - lastBlinkToggle < 150UL) return;
  lastBlinkToggle = now;
  if (!isBlinkOn) {
    isBlinkOn = true;
  } else {
    isBlinkOn = false; currentBlinksDone++;
    if (currentBlinksDone >= pendingBlinkCount) {
      pendingBlinkCount = 0; currentBlinksDone = 0; pendingBlinkTargetMask = 0x00;
    }
  }
  welcomeForceRender = true; modeForceRender = true; solidRgbForceRender = true;
}

static inline bool isProtectedTurnAmber(const CRGB &c) {
  uint8_t r = c.r, g = c.g, b = c.b;
  if (r == 0) return false;
  uint16_t g100 = (uint16_t)g * 100U; uint16_t b100 = (uint16_t)b * 100U;
  if (g100 < (uint16_t)r * 12U) return false;
  if (g100 > (uint16_t)r * 55U) return false;
  if (b100 > (uint16_t)r * 12U) return false;
  return r >= g;
}

void applyModeColorOverrideToBuffer(CRGB *leds, uint16_t count, const CRGB &target) {
  for (uint16_t i = 0; i < count; i++) {
    const CRGB original = leds[i];
    uint8_t mx1 = (original.r > original.g) ? original.r : original.g;
    uint8_t level = (mx1 > original.b) ? mx1 : original.b;
    if (level == 0) continue;
    CRGB out = target; out.nscale8_video(level); leds[i] = out;
  }
}

void applyWelcomeColorOverrideToBuffer(CRGB *leds, uint16_t count, const CRGB &target) {
  for (uint16_t i = 0; i < count; i++) {
    const CRGB original = leds[i];
    uint8_t mx1 = (original.r > original.g) ? original.r : original.g;
    uint8_t level = (mx1 > original.b) ? mx1 : original.b;
    if (level == 0) continue;
    if (isProtectedTurnAmber(original)) continue;
    CRGB out = target; out.nscale8_video(level); leds[i] = out;
  }
}

void applyEffectColorOverride(uint8_t mode, uint8_t channelIndex, CRGB *leds, uint16_t count) {
  if (mode >= 211 || channelIndex > 3) return;
  ChannelColorOverrideV3 &ov = effectColorOverrides[mode];
  uint8_t bit = (uint8_t)(1U << channelIndex);
  if ((ov.mask & bit) == 0) return;
  CRGB target(ov.r[channelIndex], ov.g[channelIndex], ov.b[channelIndex]);
  applyModeColorOverrideToBuffer(leds, count, target);
}

void applyWelcomeColorOverride(uint8_t welcomeMode, uint8_t channelIndex, CRGB *leds, uint16_t count) {
  if (welcomeMode > 50 || channelIndex > 3) return;
  ChannelColorOverrideV3 &ov = welcomeColorOverrides[welcomeMode];
  uint8_t bit = (uint8_t)(1U << channelIndex);
  if ((ov.mask & bit) == 0) return;
  CRGB target(ov.r[channelIndex], ov.g[channelIndex], ov.b[channelIndex]);
  applyWelcomeColorOverrideToBuffer(leds, count, target);
}

void setEffectColorOverrideRAM(uint8_t mode, uint8_t channelNumber, uint8_t redVal, uint8_t greenVal, uint8_t blueVal) {
  if (mode >= 211 || channelNumber < 1 || channelNumber > 4) return;
  ChannelColorOverrideV3 &ov = effectColorOverrides[mode];
  uint8_t idx = channelNumber - 1;
  ov.mask |= (uint8_t)(1U << idx);
  ov.r[idx] = redVal; ov.g[idx] = greenVal; ov.b[idx] = blueVal;
}

void setWelcomeColorOverrideRAM(uint8_t welcomeMode, uint8_t channelNumber, uint8_t redVal, uint8_t greenVal, uint8_t blueVal) {
  if (welcomeMode > 50 || channelNumber < 1 || channelNumber > 4) return;
  ChannelColorOverrideV3 &ov = welcomeColorOverrides[welcomeMode];
  uint8_t idx = channelNumber - 1;
  ov.mask |= (uint8_t)(1U << idx);
  ov.r[idx] = redVal; ov.g[idx] = greenVal; ov.b[idx] = blueVal;
}

static bool saveK3RecordVerified(uint8_t context, uint8_t id) {
  if (context == 1) {
    if (id < 1 || id >= 211) return false;
    char key[8]; snprintf(key, sizeof(key), "m%03u", (unsigned)id);
    Preferences kp; if (!kp.begin("k3fx", false)) return false;
    size_t wrote = kp.putBytes(key, &effectColorOverrides[id], sizeof(ChannelColorOverrideV3));
    kp.end();
    if (wrote != sizeof(ChannelColorOverrideV3)) return false;
    ChannelColorOverrideV3 verify{};
    if (!kp.begin("k3fx", true)) return false;
    size_t len = kp.getBytesLength(key);
    size_t got = (len == sizeof(ChannelColorOverrideV3)) ? kp.getBytes(key, &verify, sizeof(ChannelColorOverrideV3)) : 0;
    kp.end();
    return got == sizeof(ChannelColorOverrideV3) && memcmp(&verify, &effectColorOverrides[id], sizeof(ChannelColorOverrideV3)) == 0;
  }
  if (context == 2) {
    if (id > 50) return false;
    char key[8]; snprintf(key, sizeof(key), "w%02u", (unsigned)id);
    Preferences kp; if (!kp.begin("k3wel", false)) return false;
    size_t wrote = kp.putBytes(key, &welcomeColorOverrides[id], sizeof(ChannelColorOverrideV3));
    kp.end();
    if (wrote != sizeof(ChannelColorOverrideV3)) return false;
    ChannelColorOverrideV3 verify{};
    if (!kp.begin("k3wel", true)) return false;
    size_t len = kp.getBytesLength(key);
    size_t got = (len == sizeof(ChannelColorOverrideV3)) ? kp.getBytes(key, &verify, sizeof(ChannelColorOverrideV3)) : 0;
    kp.end();
    return got == sizeof(ChannelColorOverrideV3) && memcmp(&verify, &welcomeColorOverrides[id], sizeof(ChannelColorOverrideV3)) == 0;
  }
  return false;
}

static void loadK3DirectRecords() {
  Preferences kp;
  if (kp.begin("k3fx", true)) {
    for (uint16_t m = 1; m < 211; m++) {
      char key[8]; snprintf(key, sizeof(key), "m%03u", (unsigned)m);
      if (kp.getBytesLength(key) == sizeof(ChannelColorOverrideV3)) {
        kp.getBytes(key, &effectColorOverrides[m], sizeof(ChannelColorOverrideV3));
      }
    }
    kp.end();
  }
  if (kp.begin("k3wel", true)) {
    for (uint8_t w = 0; w <= 50; w++) {
      char key[8]; snprintf(key, sizeof(key), "w%02u", (unsigned)w);
      if (kp.getBytesLength(key) == sizeof(ChannelColorOverrideV3)) {
        kp.getBytes(key, &welcomeColorOverrides[w], sizeof(ChannelColorOverrideV3));
      }
    }
    kp.end();
  }
}

static void loadK3WelcomeDirectRecordsOnly() {
  Preferences kp;
  if (!kp.begin("k3wel", true)) return;
  for (uint8_t w = 0; w <= 50; w++) {
    char key[8]; snprintf(key, sizeof(key), "w%02u", (unsigned)w);
    if (kp.getBytesLength(key) == sizeof(ChannelColorOverrideV3)) {
      kp.getBytes(key, &welcomeColorOverrides[w], sizeof(ChannelColorOverrideV3));
    }
  }
  kp.end();
}

bool persistK3ColorOverridesVerified() {
  Preferences kp;
  if (!kp.begin("ledcar4ch", false)) return false;
  size_t a = kp.putBytes("fxClrV3", effectColorOverrides, sizeof(effectColorOverrides));
  size_t b = kp.putBytes("welClrV3", welcomeColorOverrides, sizeof(welcomeColorOverrides));
  kp.end();
  if (a != sizeof(effectColorOverrides) || b != sizeof(welcomeColorOverrides)) return false;
  static ChannelColorOverrideV3 fxCheck[211];
  static ChannelColorOverrideV3 welCheck[51];
  if (!kp.begin("ledcar4ch", true)) return false;
  bool lenOk = (kp.getBytesLength("fxClrV3") == sizeof(effectColorOverrides)) && (kp.getBytesLength("welClrV3") == sizeof(welcomeColorOverrides));
  size_t ra = lenOk ? kp.getBytes("fxClrV3", fxCheck, sizeof(fxCheck)) : 0;
  size_t rb = lenOk ? kp.getBytes("welClrV3", welCheck, sizeof(welCheck)) : 0;
  kp.end();
  return ra == sizeof(fxCheck) && rb == sizeof(welCheck) && memcmp(fxCheck, effectColorOverrides, sizeof(fxCheck)) == 0 && memcmp(welCheck, welcomeColorOverrides, sizeof(welCheck)) == 0;
}

static bool k3BufferHasLight(const CRGB *buf, uint16_t count) {
  for (uint16_t i = 0; i < count; i++) { if (buf[i].r || buf[i].g || buf[i].b) return true; }
  return false;
}

static void k3RememberVisibleFrames(uint16_t count) {
  CRGB *bufs[4] = {leds1, leds2, leds3, leds4};
  CRGB *lasts[4] = {k3LastVisible1, k3LastVisible2, k3LastVisible3, k3LastVisible4};
  bool *valids[4] = {&k3LastVisibleValid1, &k3LastVisibleValid2, &k3LastVisibleValid3, &k3LastVisibleValid4};
  for (uint8_t ch = 1; ch <= 4; ch++) {
    if (k3PauseActive && k3EditStage == ch) continue;
    if (k3BufferHasLight(bufs[ch - 1], count)) {
      memcpy(lasts[ch - 1], bufs[ch - 1], sizeof(CRGB) * count);
      *valids[ch - 1] = true;
    }
  }
}

void k3CaptureEditFrame(uint8_t channel) {
  if (channel < 1 || channel > 4) return;
  uint16_t count = activeLedCount;
  if (count < 1) count = 1;
  if (count > STAGE0_LED_BUFFER) count = STAGE0_LED_BUFFER;
  CRGB *sourceBufs[4] = {leds1, leds2, leds3, leds4};
  CRGB *lastBufs[4] = {k3LastVisible1, k3LastVisible2, k3LastVisible3, k3LastVisible4};
  bool valids[4] = {k3LastVisibleValid1, k3LastVisibleValid2, k3LastVisibleValid3, k3LastVisibleValid4};
  uint8_t idx = (uint8_t)(channel - 1U);
  if (valids[idx] && k3BufferHasLight(lastBufs[idx], count)) {
    memcpy(k3EditBase, lastBufs[idx], sizeof(CRGB) * count);
  } else if (k3BufferHasLight(sourceBufs[idx], count)) {
    memcpy(k3EditBase, sourceBufs[idx], sizeof(CRGB) * count);
  } else {
    fill_solid(k3EditBase, count, CRGB::White);
  }
  memcpy(k3EditPreview, k3EditBase, sizeof(CRGB) * count);
}

void k3BuildPreviewFromBase(const CRGB &target) {
  uint16_t count = activeLedCount;
  for (uint16_t i = 0; i < count; i++) {
    const CRGB original = k3EditBase[i];
    uint8_t mx1 = (original.r > original.g) ? original.r : original.g;
    uint8_t level = (mx1 > original.b) ? mx1 : original.b;
    if (level == 0) { k3EditPreview[i] = CRGB::Black; continue; }
    if (k3EditContext == 2 && isProtectedTurnAmber(original)) { k3EditPreview[i] = original; continue; }
    CRGB out = target; out.nscale8_video(level); k3EditPreview[i] = out;
  }
}

void performCurrentColorResetFromK3() {
  if (k3EditContext == 1) {
    for (uint8_t ch = 0; ch < 4; ch++) {
      uint8_t m = k3EditModeByChannel[ch];
      if (m >= 1 && m < 211) {
        effectColorOverrides[m].mask &= (uint8_t)~(1U << ch);
        saveK3RecordVerified(1, m);
      }
    }
  } else if (k3EditContext == 2) {
    for (uint8_t ch = 0; ch < 4; ch++) {
      uint8_t wm = k3EditWelcomeByChannel[ch];
      if (wm <= 50) {
        welcomeColorOverrides[wm].mask &= (uint8_t)~(1U << ch);
        saveK3RecordVerified(2, wm);
      }
    }
  } else if (k3EditContext == 3) {
    for (uint8_t ch = 0; ch < 4; ch++) { rgbR[ch] = 255; rgbG[ch] = 255; rgbB[ch] = 255; }
    markSettingsUrgent();
  }
  if (k3EditContext == 1 || k3EditContext == 2) { persistK3ColorOverridesVerified(); }
  k3PauseActive = false; k3EditContext = 0; k3EditStage = 0; k3EditReceivedColor = false;
  modeForceRender = true; welcomeForceRender = true; solidRgbForceRender = true;
  triggerBlink(CRGB::Green, 2);
}

void performFactoryResetFromK3() {
  pendingPersistK3 = false; pendingK3Show = false;
  k3PauseActive = false; k3EditContext = 0; k3EditStage = 0; k3EditReceivedColor = false;
  
  memset(effectColorOverrides, 0, sizeof(effectColorOverrides));
  memset(welcomeColorOverrides, 0, sizeof(welcomeColorOverrides));
  
  persistK3ColorOverridesVerified();
  
  k3Prefs.begin("k3color", false); k3Prefs.clear(); k3Prefs.putBool("init", true); k3Prefs.end();
  { Preferences kp; if (kp.begin("k3fx", false)) { kp.clear(); kp.end(); } }
  { Preferences kp; if (kp.begin("k3wel", false)) { kp.clear(); kp.end(); } }
  
  for (uint8_t ch = 0; ch < 4; ch++) { rgbR[ch] = 255; rgbG[ch] = 255; rgbB[ch] = 255; }
  markSettingsUrgent();

  modeForceRender = true; welcomeForceRender = true; solidRgbForceRender = true;
  triggerBlink(CRGB::Green, 5);
}

struct TurnSignalEngine {
  bool active = false; bool isPhysical = false; uint8_t side = 2; uint8_t mode = 1;
  float virtualTime = 0.0f; unsigned long lastClock = 0; bool finishRequested = false; unsigned long finishRequestedAt = 0;
};
TurnSignalEngine turnEngine;

struct BrakeEngine {
  bool active = false; bool isPhysical = false; uint8_t mode = 1; unsigned long startTime = 0;
};
BrakeEngine brakeEngine;

// MUNDUR / reverse-gear overlay.
// Mapping aplikasi LEDLAMP bawaan sudah terverifikasi dari Serial:
//   7B 1D 01..0A FF FF FF FF FF BF
// GPIO10 tetap menjadi input MUNDUR fisik (aktif LOW).
struct MundurEngine {
  bool active = false;
  bool isPhysical = false;
  uint8_t mode = 1;
  unsigned long startTime = 0;
};
MundurEngine mundurEngine;
static constexpr uint8_t MUNDUR_CHANNEL_MASK = 0x0F; // CH1+CH2+CH3+CH4


// Welcome khusus CONTACT/SENJA tanpa menimpa configuredWelcome global,
// K1/K2/Mode/RGB yang sudah ada.
static void startContextWelcome(uint8_t context, uint8_t welcomeMode) {
  if (welcomeMode > 50U) welcomeMode = 0U;

  // Simpan sumber dasar terakhir agar SENJA selesai bisa kembali normal.
  if (mainSource == MAIN_RGB || mainSource == MAIN_MODE) {
    welcomeReturnSource = mainSource;
  }

  contactStandbyRedActive = false;
  specialWelcomeContext = context;
  welcomePlaylistPlaying = false;
  playingPlaylistIndex = 0;

  if (turnEngine.active && !turnEngine.isPhysical) {
    turnEngine.active = false;
    turnEngine.finishRequested = false;
  }
  if (brakeEngine.active && !brakeEngine.isPhysical) {
    brakeEngine.active = false;
  }

  mainSource = MAIN_WELCOME;
  solidRgbActive = false;
  modeRunning = false;
  selectedWelcome = welcomeMode;
  resetCustomSuites();
  startWelcome();
}

static uint8_t lastRemAppRaw = 0;
static unsigned long lastRemAppTapAt = 0;
static constexpr float SEN_SOURCE_DURATION_SEC = 2.4f;
static constexpr uint8_t SEN_SOURCE_REPEAT = 1U;

static inline uint8_t getSenInternalMode(uint8_t slot) {
  if (slot < 1U) slot = 1U;
  if (slot > 10U) slot = 10U;
  const uint8_t v = senSlotVariant[slot] ? 1U : 0U;
  return (uint8_t)(((slot - 1U) * 2U) + v + 1U);
}

static void registerSenAppSelection(uint8_t slot) {
  if (slot < 1U || slot > 10U) return;
  const unsigned long now = millis();

  // Scroll / pindah tombol: langsung jadi pilihan aktif + autosave.
  if (slot != selectedSen) {
    selectedSen = slot;
    senLastAcceptedTapAt = now;
    markSettingsUrgent();
    return;
  }

  // Paket BLE duplikat terlalu cepat diabaikan.
  if ((unsigned long)(now - senLastAcceptedTapAt) < SEN_TAP_DEBOUNCE_MS) return;

  // Klik ulang tombol SEN yang sama = toggle varian A/B + autosave.
  senSlotVariant[slot] ^= 1U;
  senLastAcceptedTapAt = now;
  markSettingsUrgent();
}

// COMPILEFIX4: helper SEN source diletakkan sebelum pemakaian agar Arduino 1.8.x tidak gagal auto-prototype.
static inline float senSrcFract(float x) { return x - floorf(x); }
static inline float senSrcEase(float x) { return -(cosf(PI * x) - 1.0f) / 2.0f; }
static inline float senSrcTri(float p) { return p < 0.5f ? p * 2.0f : 2.0f - p * 2.0f; }
static inline float senSrcGauss(float x, float c, float w) { float d = (x - c) / w; return expf(-0.5f * d * d); }
static inline float senSrcClamp01(float x) { return fmaxf(0.0f, fminf(1.0f, x)); }

static float senSourceEval(uint8_t effectModeZeroBased, float p, float progress) {
  float pass = senSrcFract(progress * 2.0f * (float)SEN_SOURCE_REPEAT);
  float grow = pass < 0.62f ? senSrcEase(pass / 0.62f) : 1.0f - senSrcEase((pass - 0.62f) / 0.38f);
  float v = 0.0f;
  if (effectModeZeroBased == 0U) {
    v = senSrcClamp01((1.0f / (1.0f + expf(-(grow - p) * 42.0f))) * 0.8f + senSrcGauss(p, grow, 0.025f) * 0.6f);
  } else if (effectModeZeroBased == 1U) {
    float q = 1.0f - p; v = senSrcClamp01((1.0f / (1.0f + expf(-(grow - q) * 42.0f))) * 0.8f + senSrcGauss(q, grow, 0.025f) * 0.6f);
  } else if (effectModeZeroBased == 2U) {
    float d = fabsf(p - 0.5f) * 2.0f; v = senSrcClamp01((1.0f / (1.0f + expf(-(grow - d) * 42.0f))) * 0.82f + senSrcGauss(d, grow, 0.035f) * 0.55f);
  } else if (effectModeZeroBased == 3U) {
    float d = (0.5f - fabsf(p - 0.5f)) * 2.0f; v = senSrcClamp01((1.0f / (1.0f + expf(-(grow - d) * 42.0f))) * 0.82f + senSrcGauss(d, grow, 0.035f) * 0.55f);
  } else if (effectModeZeroBased == 4U) {
    float a = grow * 0.5f; float b = 1.0f - grow * 0.5f; v = fmaxf(senSrcGauss(p, a, 0.055f), senSrcGauss(p, b, 0.055f));
  } else if (effectModeZeroBased == 5U) {
    float a = 0.5f - grow * 0.5f; float b = 0.5f + grow * 0.5f; v = fmaxf(senSrcGauss(p, a, 0.055f), senSrcGauss(p, b, 0.055f));
  } else if (effectModeZeroBased == 6U) {
    float ce = pass * 1.3f - 0.15f; float d = p - ce; v = senSrcGauss(p, ce, d > 0.0f ? 0.035f : 0.15f);
  } else if (effectModeZeroBased == 7U) {
    float ce = 1.0f - (pass * 1.3f - 0.15f); float d = (p - ce) * -1.0f; v = senSrcGauss(p, ce, d > 0.0f ? 0.035f : 0.15f);
  } else if (effectModeZeroBased == 8U) {
    float front = fminf(1.0f, floorf(grow * 8.0f) / 7.0f); v = senSrcClamp01((1.0f / (1.0f + expf(-(front - p) * 42.0f))) * 0.8f + senSrcGauss(p, front, 0.028f) * 0.55f);
  } else {
    float ce = senSrcEase(senSrcTri(pass)); bool right = pass < 0.5f; float d = right ? p - ce : ce - p; v = senSrcGauss(p, ce, d > 0.0f ? 0.03f : 0.14f);
  }
  if (progress > 0.9f) v *= 1.0f - senSrcEase((progress - 0.9f) / 0.1f);
  return senSrcClamp01(v);
}


static inline float sen20BarBrightness(float i, float pos, float width, float gain) {
  const float d = fabsf(i - pos);
  if (d <= width * 0.5f) return gain;
  if (d <= width * 0.5f + 3.0f) {
    return gain * (1.0f - (d - width * 0.5f) / 3.0f) * 0.45f;
  }
  return 0.0f;
}

static inline float sen20Cyc(float x) {
  x = fmodf(x, 1.0f);
  if (x < 0.0f) x += 1.0f;
  return x;
}

static inline float sen20Smooth(float x) {
  x = senSrcClamp01(x);
  return x * x * (3.0f - 2.0f * x);
}

static inline float sen20Tri(float x) {
  x = sen20Cyc(x);
  return (x < 0.5f) ? (x * 2.0f) : ((1.0f - x) * 2.0f);
}

// Port 20 mode dari HTML yang disetujui.
// Semua output hanya brightness 0..1; warna SEN tetap RGB(255,50,0).
static float sen20Eval(uint8_t mode, uint16_t idx, uint16_t count, float t) {
  if (count < 1U) return 0.0f;
  const float N = (float)count;
  const float maxp = N - 1.0f;
  const float i = (float)idx;
  float v = 0.0f;

  switch (mode) {
    case 1: {
      float u = sen20Cyc(t / 1.6f);
      float f = sen20Smooth(fminf(1.0f, u / 0.78f)) * N;
      v = (i <= f) ? 1.0f : 0.0f;
    } break;

    case 2: {
      float u = sen20Cyc(t / 1.25f);
      float p = u * (N + 12.0f) - 6.0f;
      v = sen20BarBrightness(i, p, 9.0f, 1.0f);
    } break;

    case 3: {
      float u = sen20Cyc(t / 1.5f);
      float p = u * (N + 20.0f) - 10.0f;
      v = fmaxf(sen20BarBrightness(i, p, 7.0f, 1.0f),
                sen20BarBrightness(i, p - 16.0f, 7.0f, 0.65f));
    } break;

    case 4: {
      int steps = (count / 10U);
      if (steps < 4) steps = 4;
      int on = (int)(sen20Cyc(t / 1.7f) * (float)(steps + 2));
      int seg = (int)((i * (float)steps) / N);
      v = (seg < on && seg < steps) ? 1.0f : 0.0f;
    } break;

    case 5: {
      float u = sen20Tri(t / 1.5f);
      float c = maxp * 0.5f;
      float d = u * c;
      v = fmaxf(sen20BarBrightness(i, c - d, 8.0f, 1.0f),
                sen20BarBrightness(i, c + d, 8.0f, 1.0f));
    } break;

    case 6: {
      float u = sen20Tri(t / 1.5f);
      float c = maxp * 0.5f;
      float d = (1.0f - u) * c;
      v = fmaxf(sen20BarBrightness(i, c - d, 8.0f, 1.0f),
                sen20BarBrightness(i, c + d, 8.0f, 1.0f));
    } break;

    case 7: {
      // FIX user: CH1/CH2 harus sejajar; renderer channel memakai nilai yang sama.
      float u = sen20Cyc(t / 1.35f);
      float p = u * (N + 30.0f) - 15.0f;
      v = fmaxf(sen20BarBrightness(i, p, 8.0f, 1.0f),
                sen20BarBrightness(i, p - 15.0f, 6.0f, 0.58f));
    } break;

    case 8: {
      float u = sen20Cyc(t / 1.2f);
      float p = u * (N + 28.0f) - 14.0f;
      for (uint8_t k = 0; k < 3U; k++) {
        float q = sen20BarBrightness(i, p - (float)k * 11.0f, 6.0f, 1.0f - (float)k * 0.22f);
        if (q > v) v = q;
      }
    } break;

    case 9: {
      // SEN visible tombol 5 varian A = C++ user:
      // EFFECT_MODE=1, DIR_MODE=0, DURATION=2.4, REPEAT=1.
      // Dikompensasi ke arah logis 0->N-1; reverse fisik global menentukan arah pemasangan.
      float progress = senSrcFract(t / 2.4f);
      float pLocal = (count <= 1U) ? 0.5f : i / (float)(count - 1U);
      float p = 1.0f - pLocal;
      v = senSourceEval(1U, p, progress);
    } break;

    case 10: {
      int segSize = (int)lroundf(N / 7.0f);
      if (segSize < 5) segSize = 5;
      int k = (int)(sen20Cyc(t / 1.5f) * 9.0f);
      int seg = (int)i / segSize;
      v = (seg < k && seg < 7) ? 1.0f : 0.0f;
    } break;

    case 11: {
      float u = sen20Cyc(t / 1.4f);
      float p = u * (N + 18.0f) - 9.0f;
      float breath = 0.45f + 0.55f * (0.5f + 0.5f * sinf(t * 10.0f));
      v = sen20BarBrightness(i, p, 14.0f, breath);
    } break;

    case 12: {
      float u = sen20Cyc(t / 1.8f);
      if (u < 0.68f) {
        float p = sen20Smooth(u / 0.68f) * (N + 10.0f) - 5.0f;
        v = sen20BarBrightness(i, p, 10.0f, 1.0f);
      } else if (u < 0.87f) {
        v = 1.0f;
      }
    } break;

    case 13: {
      const int block = 8;
      int total = ((int)count + block - 1) / block;
      if (total < 1) total = 1;
      float u = sen20Cyc(t / 2.0f);
      int k = (int)(u * (float)total);
      if (k >= total) k = total - 1;

      // blok yang sudah tertumpuk dari ujung
      int from = (int)count - k * block;
      if ((int)idx >= from) v = 0.70f;

      // blok berjalan menuju tumpukan
      float frac = u * (float)total - (float)k;
      float travel = (float)((int)count - k * block);
      float p = frac * travel;
      float q = sen20BarBrightness(i, p, (float)block, 1.0f);
      if (q > v) v = q;
    } break;

    case 14: {
      float u = sen20Cyc(t / 1.35f);
      float p = u * (N + 14.0f) - 7.0f;
      v = fmaxf(sen20BarBrightness(i, p - 6.0f, 4.0f, 1.0f),
                sen20BarBrightness(i, p + 6.0f, 4.0f, 0.70f));
    } break;

    case 15: {
      float u = sen20Tri(t / 1.55f);
      float c = maxp * 0.5f;
      float d = u * c;
      float w = 5.0f + u * 8.0f;
      v = fmaxf(sen20BarBrightness(i, c - d, w, 1.0f),
                sen20BarBrightness(i, c + d, w, 1.0f));
    } break;

    case 16: {
      float u = sen20Tri(t / 1.4f);
      float c = maxp * 0.5f;
      float d = u * c;
      v = (i >= c - d && i <= c + d) ? 0.85f : 0.0f;
    } break;

    case 17: {
      float p = sen20Tri(t / 1.35f) * maxp;
      v = sen20BarBrightness(i, p, 10.0f, 1.0f);
    } break;

    case 18: {
      const int block = 10;
      int total = ((int)count + block - 1) / block;
      if (total < 1) total = 1;
      int s = (int)(sen20Cyc(t / 1.25f) * (float)total);
      if (s >= total) s = total - 1;
      int a = s * block;
      int b = a + block - 1;
      if (b >= (int)count) b = (int)count - 1;
      v = ((int)idx >= a && (int)idx <= b) ? 1.0f : 0.0f;
    } break;

    case 19: {
      float u = sen20Cyc(t / 1.65f);
      if (u < 0.55f) {
        float f = sen20Smooth(u / 0.55f) * N;
        v = (i <= f) ? 1.0f : 0.0f;
      } else {
        float q = (u - 0.55f) / 0.45f;
        bool flash = (((int)(q * 6.0f)) % 2) == 0;
        v = flash ? 1.0f : 0.0f;
      }
    } break;

    case 20: {
      // FIX user: hanya SATU fase.
      float u = sen20Cyc(t / 1.45f);
      float p = u * (N + 16.0f) - 8.0f;
      v = sen20BarBrightness(i, p, 12.0f, 1.0f);
    } break;

    default:
      v = 0.0f;
      break;
  }

  return senSrcClamp01(v);
}

static inline float getTurnSignalProgress(float virtualTime) { return senSrcFract(virtualTime / SEN_SOURCE_DURATION_SEC); }

void startTurnSignal(uint8_t mode, uint8_t side, bool isPhys) {
  if (!isPhys && brakeEngine.active && !brakeEngine.isPhysical) brakeEngine.active = false;
  if (!isPhys) cancelVisualFeedback();
  turnEngine.active = true; turnEngine.isPhysical = isPhys; turnEngine.side = side;
  if (mode < 1) mode = 1; if (mode > 20) mode = 20;
  turnEngine.mode = mode; turnEngine.virtualTime = 0.0f; turnEngine.lastClock = millis(); turnEngine.finishRequested = false;
  modeForceRender = true; welcomeForceRender = true; solidRgbForceRender = true;
}

void finishTurnSignal() {
  turnEngine.active = false; turnEngine.finishRequested = false;
  modeForceRender = true; if (solidRgbActive) solidRgbForceRender = true;
}

void startBrake(uint8_t mode, bool isPhys) {
  if (!isPhys && turnEngine.active && !turnEngine.isPhysical) { turnEngine.active = false; turnEngine.finishRequested = false; }
  if (!isPhys) cancelVisualFeedback();
  brakeEngine.active = true; brakeEngine.isPhysical = isPhys;
  if (mode < 1) mode = 1; if (mode > 10) mode = 10;
  brakeEngine.mode = mode; brakeEngine.startTime = millis();
  modeForceRender = true; welcomeForceRender = true; solidRgbForceRender = true;
}

void finishBrake() {
  brakeEngine.active = false; modeForceRender = true; if (solidRgbActive) solidRgbForceRender = true;
}

static void startMundur(uint8_t mode, bool isPhys) {
  if (mode < 1U) mode = 1U;
  if (mode > 10U) mode = 10U;
  mundurEngine.active = true;
  mundurEngine.isPhysical = isPhys;
  mundurEngine.mode = mode;
  mundurEngine.startTime = millis();
  modeForceRender = true;
  welcomeForceRender = true;
  solidRgbForceRender = true;
}

static void finishMundur() {
  mundurEngine.active = false;
  modeForceRender = true;
  welcomeForceRender = true;
  if (solidRgbActive) solidRgbForceRender = true;
}

// Handler MUNDUR bawaan LEDLAMP (opcode 0x1D, mode 1..10).
static void handleMundurBleValue(uint8_t value) {
  if (value == 0x00U || value == 0xFFU) {
    // OFF dari aplikasi hanya menutup preview aplikasi. Jika GPIO10 masih LOW,
    // overlay fisik tetap dipertahankan.
    if (!mundurEngine.isPhysical) finishMundur();
    return;
  }
  if (value < 1U || value > 10U) return;

  selectedMundur = value;
  markSettingsUrgent();

  // Jika kendaraan memang sedang mundur (GPIO10 LOW), pilihan baru langsung
  // diterapkan sebagai overlay fisik. Jika tidak, tampilkan preview dari aplikasi.
  if (digitalRead(PIN_MUNDUR) == LOW) {
    startMundur(value, true);
  } else {
    startMundur(value, false);
  }
}

static void applyBoxSingleRemToggle() {
  brake34Enabled = !brake34Enabled;
  if (!brake34Enabled && brakeEngine.active && brakeEngine.isPhysical) { finishBrake(); }
  if (brake34Enabled && digitalRead(PIN_REM) == LOW && lampOn && contactOn && (!brakeEngine.active || !brakeEngine.isPhysical)) {
    startBrake(selectedRem ? selectedRem : 1, true);
  }
  cancelVisualFeedback(); modeForceRender = true; solidRgbForceRender = true; welcomeForceRender = true; markSettingsDirty();
}

static void serviceDmxBoxSingleTap() {
  if (!dmxBoxSinglePending) return;
  if ((uint32_t)(millis() - dmxBoxFirstTapMs) < DMX_BOX_DOUBLE_WINDOW_MS) return;
  dmxBoxSinglePending = false;
  applyBoxSingleRemToggle();
}

void handleDmxSubarea(uint8_t area) {
  dmxSubarea = area;
  unsigned long nowTap = millis();
  if (area == 0x00) {
    if (dmxBoxSinglePending && ((uint32_t)(nowTap - dmxBoxFirstTapMs) <= DMX_BOX_DOUBLE_WINDOW_MS)) {
      dmxBoxSinglePending = false; dmxBoxFirstTapMs = 0; turnPairSelection = 0; 
      cancelVisualFeedback(); triggerTargetBlink(CRGB(255, 50, 0), 2, 0x0F);
      modeForceRender = true; solidRgbForceRender = true; welcomeForceRender = true; markSettingsDirty();
      return;
    }
    dmxBoxSinglePending = true; dmxBoxFirstTapMs = nowTap; return;
  }
  bool isDouble = (dmxLastSubareaTap == area) && ((nowTap - dmxLastSubareaTapMs) <= 650UL);
  if (!isDouble) { dmxLastSubareaTap = area; dmxLastSubareaTapMs = nowTap; return; }
  dmxLastSubareaTap = 0xFF; dmxLastSubareaTapMs = 0;
  if (area == 0x02) { turnPairSelection = 1; } else if (area == 0x01) { turnPairSelection = 2; }
  cancelVisualFeedback(); markSettingsDirty();
}

static inline uint8_t calculateRemMode1KnightRiderScale(uint16_t i, uint16_t count, uint32_t elapsedMs) {
  if (count <= 1U) return 255U;
  uint16_t stepMs = calculateAppStepMs(remSpeed);
  if (stepMs < 5U) stepMs = 5U; if (stepMs > 50U) stepMs = 50U;
  const float maxPos = (float)(count - 1U); const float travel = maxPos * 2.0f;
  float phase = fmodf((float)elapsedMs / (float)stepMs, travel);
  float pos = (phase <= maxPos) ? phase : (travel - phase);
  float dist = fabsf((float)i - pos);
  uint8_t scale = 0U;
  if (dist < 1.0f) scale = 255U; else if (dist < 2.0f) scale = 230U;
  else if (dist < 3.0f) scale = 185U; else if (dist < 4.0f) scale = 130U;
  else if (dist < 5.0f) scale = 80U; else if (dist < 6.0f) scale = 35U;
  return scale;
}

static inline uint8_t calculateRemMode2Scale(uint16_t i, uint16_t count, uint32_t elapsedMs) {
  const uint8_t baseScale = 200;
  uint32_t fillMs = (uint32_t)calculateAppStepMs(remSpeed) * 10UL;
  if (fillMs < 120UL) fillMs = 120UL; if (fillMs > 500UL) fillMs = 500UL;
  if (elapsedMs >= fillMs || count <= 1U) return 255;
  float progress = (float)elapsedMs / (float)fillMs; progress = fmaxf(0.0f, fminf(1.0f, progress));
  float front = progress * (float)(count - 1U); float d = front - (float)i;
  float local = (d >= 0.0f) ? 1.0f : ((d > -4.0f) ? 1.0f - ((-d) / 4.0f) : 0.0f);
  uint16_t scaled = (uint16_t)baseScale + (uint16_t)((255U - baseScale) * local);
  return (scaled > 255U) ? 255U : (uint8_t)scaled;
}

// ============================================================================
// REM MODE 2..10 — RESTORE DARI FIRMWARE LAMA
// REM1 CURRENT Knight Rider tetap dipertahankan.
// Pola/gerak Mode 2..10 sama dengan source lama; timing memakai speed GLOBAL.
// Tanpa buffer LED tambahan.
// ============================================================================
static inline void calculateLegacyRemMode2to10Scales(
    uint8_t mode,
    float t,
    uint16_t i,
    uint16_t count,
    uint8_t &scaleLeft,
    uint8_t &scaleRight) {

  scaleLeft = 0U;
  scaleRight = 0U;
  const int N = (int)count;
  if (N <= 0) return;

  switch (mode) {
    case 2: {
      float scan = (sinf(t * 6.0f) * 0.5f + 0.5f) * (float)N;
      float d = fabsf((float)i - scan);
      uint8_t b = (d <= 3.0f)
        ? (uint8_t)(powf(1.0f - d / 3.0f, 2.0f) * 255.0f)
        : 0U;
      scaleLeft = b; scaleRight = b;
      break;
    }
    case 3: {
      float p = fmodf(t, 0.9f) / 0.9f;

      // CHIP SETTING FIX: blok tetap 10 LED seperti source lama,
      // tetapi jumlah slot mengikuti activeLedCount sampai ujung strip.
      const int blockLen = 10;
      int slotCount = (N + blockLen - 1) / blockLen;
      if (slotCount < 1) slotCount = 1;
      int activeSlot = (int)(p * (float)slotCount);
      if (activeSlot >= slotCount) activeSlot = slotCount - 1;

      bool subFlash = ((int)(p * (float)(slotCount * 6)) % 2 == 0);
      int curSlot = (int)i / blockLen;
      uint8_t b = (curSlot == activeSlot && subFlash) ? 255U : 0U;
      scaleLeft = b; scaleRight = b;
      break;
    }
    case 4: {
      float p = fmodf(t, 0.5f) / 0.5f;
      float head = p * ((float)N + 5.0f);
      float d = fabsf((float)i - head);
      uint8_t b = (d <= 3.0f)
        ? (uint8_t)(powf(1.0f - d / 3.0f, 1.5f) * 255.0f)
        : 0U;
      scaleLeft = b; scaleRight = b;
      break;
    }
    case 5: {
      float scanIn = (cosf(t * 7.0f) * 0.5f + 0.5f) * (float)N;
      float d = fabsf((float)i - scanIn);
      uint8_t b = (d <= 2.5f)
        ? (uint8_t)(powf(1.0f - d / 2.5f, 2.0f) * 255.0f)
        : 0U;
      scaleLeft = b; scaleRight = b;
      break;
    }
    case 6: {
      float p = fmodf(t, 0.6f) / 0.6f;

      // CHIP SETTING FIX: blok 5 LED tetap, jumlah blok dinamis.
      const int blockLen = 5;
      int blockCount = (N + blockLen - 1) / blockLen;
      if (blockCount < 1) blockCount = 1;
      int activeBlock = (int)(p * (float)blockCount);
      if (activeBlock >= blockCount) activeBlock = blockCount - 1;

      int curBlock = (int)i / blockLen;
      uint8_t b = (curBlock == activeBlock) ? 255U : 0U;
      scaleLeft = b; scaleRight = b;
      break;
    }
    case 7: {
      float p = fmodf(t, 0.48f) / 0.48f;
      int flashCycle = (int)(p * 12.0f);
      bool flash = (flashCycle % 2 == 0);
      bool leftActive = (flashCycle < 6);
      scaleLeft  = (leftActive && flash) ? 255U : 0U;
      scaleRight = (!leftActive && flash) ? 255U : 0U;
      break;
    }
    case 8: {
      float p = fmodf(t, 0.6f) / 0.6f;

      // CHIP SETTING FIX: sweep 0 -> ujung -> 0 memakai seluruh LED.
      float head = sinf(p * PI) * (float)(N - 1);
      float d = fabsf((float)i - head);
      uint8_t b = (d <= 3.0f)
        ? (uint8_t)(powf(1.0f - d / 3.0f, 1.8f) * 255.0f)
        : 0U;
      scaleLeft = b; scaleRight = b;
      break;
    }
    case 9: {
      float p = fmodf(t, 0.6f) / 0.6f;
      int step = (int)(p * 3.0f);
      if (step > 2) step = 2;
      bool flash = sinf(p * 30.0f) > 0.0f;

      // FULL LED FIX: tiga tahap membagi SELURUH activeLedCount.
      // Tidak ada LED yang selamanya tidak tersentuh.
      int segStart = (step * N) / 3;
      int segEnd   = ((step + 1) * N) / 3;
      if (step == 2) segEnd = N;
      bool inActiveSegment = ((int)i >= segStart && (int)i < segEnd);
      bool on = inActiveSegment && flash;

      scaleLeft = on ? 255U : 0U;
      scaleRight = scaleLeft;
      break;
    }
    case 10: {
      float p = fmodf(t, 0.9f) / 0.9f;

      // CHIP SETTING FIX: blok 10 LED tetap, slot berjalan sampai LED terakhir.
      const int blockLen = 10;
      int slotCount = (N + blockLen - 1) / blockLen;
      if (slotCount < 1) slotCount = 1;
      float slotPos = p * (float)slotCount;
      int activeSlot = (int)slotPos;
      if (activeSlot >= slotCount) activeSlot = slotCount - 1;
      float subP = slotPos - floorf(slotPos);
      int curSlot = (int)i / blockLen;

      uint8_t b = 0U;
      if (curSlot == activeSlot) {
        if (subP < 0.75f) b = (uint8_t)(50.0f + (subP / 0.75f) * 205.0f);
        else if (subP < 0.88f) b = 255U;
      }
      scaleLeft = b; scaleRight = b;
      break;
    }
    default:
      break;
  }
}


static inline void scaleBufferForMasterBypass(CRGB *buf, uint16_t count, uint8_t scale) {
  if (scale >= 255U) return;
  for (uint16_t i = 0; i < count; i++) buf[i].nscale8_video(scale);
}

// ============================================================================
// MUNDUR MODE 1..10 — SEMUA WARNA PUTIH
// GPIO10 aktif LOW. Mode 1 dibuat paling praktis: putih solid.
// Mode 2..10 dekoratif, tetap putih, tanpa buffer tambahan dan non-blocking.
// ============================================================================
static inline void calculateMundurModeScales(
    uint8_t mode,
    float t,
    uint16_t i,
    uint16_t count,
    uint8_t &scaleLeft,
    uint8_t &scaleRight) {

  // Semua mode MUNDUR hanya PUTIH. Yang dibedakan hanya pola nyala.
  // Dibuat sederhana/praktis: solid, kedip, multi-flash, dan wipe/fill.
  scaleLeft = 0U;
  scaleRight = 0U;
  const int N = (int)count;
  if (N <= 0) return;
  const float maxPos = (float)(N - 1);
  uint8_t b = 0U;

  switch (mode) {
    case 1: { // PUTIH SOLID
      b = 255U;
      break;
    }

    case 2: { // KEDIP LAMBAT
      float u = fmodf(t, 1.00f);
      if (u < 0.0f) u += 1.00f;
      b = (u < 0.50f) ? 255U : 0U;
      break;
    }

    case 3: { // KEDIP SEDANG
      float u = fmodf(t, 0.60f);
      if (u < 0.0f) u += 0.60f;
      b = (u < 0.30f) ? 255U : 0U;
      break;
    }

    case 4: { // KEDIP CEPAT
      float u = fmodf(t, 0.30f);
      if (u < 0.0f) u += 0.30f;
      b = (u < 0.15f) ? 255U : 0U;
      break;
    }

    case 5: { // DOUBLE FLASH + JEDA
      float u = fmodf(t, 0.90f);
      if (u < 0.0f) u += 0.90f;
      const bool on = (u < 0.12f) || (u >= 0.22f && u < 0.34f);
      b = on ? 255U : 0U;
      break;
    }

    case 6: { // TRIPLE FLASH + JEDA
      float u = fmodf(t, 1.05f);
      if (u < 0.0f) u += 1.05f;
      const bool on =
          (u < 0.10f) ||
          (u >= 0.20f && u < 0.30f) ||
          (u >= 0.40f && u < 0.50f);
      b = on ? 255U : 0U;
      break;
    }

    case 7: { // WIPE DEPAN -> BELAKANG / INDEX 0 -> AKHIR
      float u = fmodf(t / 1.20f, 1.0f);
      if (u < 0.0f) u += 1.0f;
      const float front = u * maxPos;
      b = ((float)i <= front) ? 255U : 0U;
      break;
    }

    case 8: { // WIPE BALIK / INDEX AKHIR -> 0
      float u = fmodf(t / 1.20f, 1.0f);
      if (u < 0.0f) u += 1.0f;
      const float front = maxPos - (u * maxPos);
      b = ((float)i >= front) ? 255U : 0U;
      break;
    }

    case 9: { // TENGAH -> LUAR
      float u = fmodf(t / 1.20f, 1.0f);
      if (u < 0.0f) u += 1.0f;
      const float center = maxPos * 0.5f;
      const float radius = u * (maxPos * 0.5f + 1.0f);
      b = (fabsf((float)i - center) <= radius) ? 255U : 0U;
      break;
    }

    case 10: { // UJUNG -> TENGAH
      float u = fmodf(t / 1.20f, 1.0f);
      if (u < 0.0f) u += 1.0f;
      const float edgeDist = fminf((float)i, maxPos - (float)i);
      const float front = u * (maxPos * 0.5f + 1.0f);
      b = (edgeDist <= front) ? 255U : 0U;
      break;
    }

    default:
      b = 255U;
      break;
  }

  // Kiri dan kanan selalu memakai warna/level putih yang sama.
  scaleLeft = b;
  scaleRight = b;
}

static void applyMundurOverlayToOutput(uint16_t count) {
  if (!lampOn || !contactOn || !mundurEngine.active) return;
  if (count < 1U) return;

  uint8_t mode = mundurEngine.mode;
  if (mode < 1U || mode > 10U) mode = 1U;
  const uint32_t elapsedMs = millis() - mundurEngine.startTime;
  const float t = ((float)elapsedMs * 0.001f) * calculateLiveSpeedFactor(appSpeed);

  for (uint16_t i = 0; i < count; i++) {
    uint8_t sl = 0U, sr = 0U;
    calculateMundurModeScales(mode, t, i, count, sl, sr);

    CRGB left(255,255,255), right(255,255,255);
    left.nscale8_video(sl); right.nscale8_video(sr);

    // Saat REM aktif, k3SafeShow memakai master-bypass. Kompensasi agar MUNDUR
    // tetap mengikuti brightness global pada pixel yang tidak ditimpa REM/SEN.
    if (brakeEngine.active && brightness255 < 255U) {
      left.nscale8_video(brightness255);
      right.nscale8_video(brightness255);
    }

    const bool physical = mundurEngine.isPhysical;
    if ((MUNDUR_CHANNEL_MASK & 0x01U) && (physical || channelOutputEnabled[0])) leds1[i] = left;
    if ((MUNDUR_CHANNEL_MASK & 0x02U) && (physical || channelOutputEnabled[1])) leds2[i] = right;
    if ((MUNDUR_CHANNEL_MASK & 0x04U) && (physical || channelOutputEnabled[2])) leds3[i] = left;
    if ((MUNDUR_CHANNEL_MASK & 0x08U) && (physical || channelOutputEnabled[3])) leds4[i] = right;
  }
}

static void applySenBrakeOverlayToOutput(uint16_t count) {
  if (!lampOn || !contactOn) return;
  const bool usePrimaryPair   = (turnPairSelection == 0 || turnPairSelection == 1);
  const bool useSecondaryPair = (turnPairSelection == 0 || turnPairSelection == 2);
  bool ov1 = turnEngine.active && usePrimaryPair && (turnEngine.side == 0 || turnEngine.side == 2);
  bool ov2 = turnEngine.active && usePrimaryPair && (turnEngine.side == 1 || turnEngine.side == 2);
  bool ov3 = turnEngine.active && useSecondaryPair && (turnEngine.side == 0 || turnEngine.side == 2);
  bool ov4 = turnEngine.active && useSecondaryPair && (turnEngine.side == 1 || turnEngine.side == 2);
  bool brk1 = brakeEngine.active && !brakeEngine.isPhysical;
  bool brk2 = brakeEngine.active && !brakeEngine.isPhysical;
  bool brk3 = brakeEngine.active && (!brakeEngine.isPhysical || brake34Enabled);
  bool brk4 = brakeEngine.active && (!brakeEngine.isPhysical || brake34Enabled);

  if (brakeEngine.active) {
    const uint32_t elapsedMs = millis() - brakeEngine.startTime;

    // FIX REM BRIGHTNESS:
    // overlay REM ditulis sesudah master-brightness, jadi brightness REM wajib
    // diterapkan langsung pada warna REM sebelum FastLED.show().
    uint8_t rb = remBrightness;
    if (rb > 100U) rb = 100U;
    const uint8_t remBri255 = (uint8_t)(((uint16_t)rb * 255U + 50U) / 100U);

    // Mode 2..10 mengikuti formula source lama; speed tetap GLOBAL.
    const float remT =
      ((float)elapsedMs * 0.001f) * calculateLiveSpeedFactor(remSpeed);

    for (uint16_t i = 0; i < count; i++) {
      uint8_t scaleLeft = 0U;
      uint8_t scaleRight = 0U;

      if (brakeEngine.mode == 1U) {
        // REM1 CURRENT tetap Knight Rider, tidak diubah.
        uint8_t s = calculateRemMode1KnightRiderScale(i, count, elapsedMs);
        scaleLeft = s;
        scaleRight = s;
      } else {
        calculateLegacyRemMode2to10Scales(
          brakeEngine.mode, remT, i, count, scaleLeft, scaleRight
        );
      }

      CRGB cLeft(255, 0, 0);
      CRGB cRight(255, 0, 0);
      cLeft.nscale8_video(scaleLeft);
      cRight.nscale8_video(scaleRight);
      cLeft.nscale8_video(remBri255);
      cRight.nscale8_video(remBri255);

      if (brk1 && !ov1) leds1[i] = cLeft;
      if (brk2 && !ov2) leds2[i] = cRight;
      if (brk3 && !ov3) leds3[i] = cLeft;
      if (brk4 && !ov4) leds4[i] = cRight;
    }
  }

  if (turnEngine.active) {
    for (uint16_t logical = 0; logical < count; logical++) {
      const float br = sen20Eval(turnEngine.mode, logical, count, turnEngine.virtualTime);
      CRGB c((uint8_t)(255.0f * br), (uint8_t)(50.0f * br), 0);
      if (brakeEngine.active && brightness255 < 255U) c.nscale8_video(brightness255);

      // Arah pemasangan GLOBAL SEN: semua 20 mode, kiri+kanan berubah bersama.
      const uint16_t physical = senDirectionReverse ? (uint16_t)(count - 1U - logical) : logical;

      if (ov1) leds1[physical] = (br > 0.001f) ? c : CRGB::Black;
      if (ov2) leds2[physical] = (br > 0.001f) ? c : CRGB::Black;
      if (ov3) leds3[physical] = (br > 0.001f) ? c : CRGB::Black;
      if (ov4) leds4[physical] = (br > 0.001f) ? c : CRGB::Black;
    }
  }
}

void k3SafeShow() {
  uint16_t count = activeLedCount;
  if (count < 1) count = 1; if (count > STAGE0_LED_BUFFER) count = STAGE0_LED_BUFFER;
  // PENTING: CH3/CH4 tidak lagi dicopy dari CH1/CH2. Semua channel independen.
  memcpy(k3ShowScratch1, leds1, sizeof(CRGB) * count); memcpy(k3ShowScratch2, leds2, sizeof(CRGB) * count);
  memcpy(k3ShowScratch3, leds3, sizeof(CRGB) * count); memcpy(k3ShowScratch4, leds4, sizeof(CRGB) * count);

  if (mainSource != MAIN_WELCOME) {
    uint8_t modes[4] = { selectedMode[0], selectedMode[1], selectedMode[2], selectedMode[3] };
    CRGB *outs[4] = {leds1, leds2, leds3, leds4};
    for (uint8_t ch = 0; ch < 4; ch++) {
      if (channelSource[ch] != MAIN_MODE) continue;
      uint8_t m = modes[ch]; if (m >= 1 && m < 211) applyEffectColorOverride(m, ch, outs[ch], count);
    }
  } else if (mainSource == MAIN_WELCOME) {
    uint8_t wm = selectedWelcome;
    if (wm <= 50) {
      applyWelcomeColorOverride(wm, 0, leds1, count); applyWelcomeColorOverride(wm, 1, leds2, count);
      applyWelcomeColorOverride(wm, 2, leds3, count); applyWelcomeColorOverride(wm, 3, leds4, count);
    }
  }

  k3RememberVisibleFrames(count);

  if (k3PauseActive && k3EditContext != 0 && k3EditStage >= 1 && k3EditStage <= 4) {
    CRGB *outs[4] = {leds1, leds2, leds3, leds4};
    memcpy(outs[k3EditStage - 1], k3EditPreview, sizeof(CRGB) * count);
  }

  // Mask hanya gambar dasar WELCOME/MODE/RGB. Overlay SEN/REM diterapkan
  // sesudahnya agar input kendaraan fisik tetap bekerja pada channel terkait.
  {
    CRGB *baseOuts[4] = {leds1, leds2, leds3, leds4};
    for (uint8_t ch = 0; ch < 4U; ch++) {
      if (!channelOutputEnabled[ch]) fill_solid(baseOuts[ch], count, CRGB::Black);
    }
  }

  if (pendingBlinkCount > 0) {
    uint8_t mask = pendingBlinkTargetMask ? pendingBlinkTargetMask : 0x0F;
    CRGB c = isBlinkOn ? pendingBlinkColor : CRGB::Black;
    if (mask & 0x01) fill_solid(leds1, count, c); if (mask & 0x02) fill_solid(leds2, count, c);
    if (mask & 0x04) fill_solid(leds3, count, c); if (mask & 0x08) fill_solid(leds4, count, c);
  }

  const bool remMasterBypass = brakeEngine.active;
  if (remMasterBypass) {
    scaleBufferForMasterBypass(leds1, count, brightness255); scaleBufferForMasterBypass(leds2, count, brightness255);
    scaleBufferForMasterBypass(leds3, count, brightness255); scaleBufferForMasterBypass(leds4, count, brightness255);
  }

  // Prioritas overlay: MUNDUR paling bawah, REM di atasnya, SEN paling atas.
  applyMundurOverlayToOutput(count);
  applySenBrakeOverlayToOutput(count);

  if (!lampOn || !contactOn) {
    fill_solid(leds1, count, CRGB::Black); fill_solid(leds2, count, CRGB::Black);
    fill_solid(leds3, count, CRGB::Black); fill_solid(leds4, count, CRGB::Black);
  }

  for (uint16_t i = count; i < STAGE0_LED_BUFFER; i++) {
    leds1[i] = CRGB::Black; leds2[i] = CRGB::Black; leds3[i] = CRGB::Black; leds4[i] = CRGB::Black;
  }

  if (remMasterBypass) FastLED.setBrightness(255);
  FastLED.show();
  if (remMasterBypass) FastLED.setBrightness(brightness255);

  memcpy(leds1, k3ShowScratch1, sizeof(CRGB) * count); memcpy(leds2, k3ShowScratch2, sizeof(CRGB) * count);
  memcpy(leds3, k3ShowScratch3, sizeof(CRGB) * count); memcpy(leds4, k3ShowScratch4, sizeof(CRGB) * count);
}

// CONTACT standby putih 4CH.
// Nama fungsi/flag lama dipertahankan agar patch sesempit mungkin dan tidak mengganggu fungsi lain.
// Tidak mengubah RGB/Mode tersimpan. SEN/REM fisik tetap di-overlay oleh k3SafeShow().
static void showContactStandbyRedNow() {
  uint16_t count = activeLedCount;
  if (count < 1U) count = 1U;
  if (count > STAGE0_LED_BUFFER) count = STAGE0_LED_BUFFER;

  // Setelah Welcome CONTACT selesai, tampil putih 4CH sesuai brightness global.
  const CRGB standbyRed = CRGB::White;
  fill_solid(leds1, count, standbyRed);
  fill_solid(leds2, count, standbyRed);
  fill_solid(leds3, count, standbyRed);
  fill_solid(leds4, count, standbyRed);

  // Supaya K3 override Mode/Welcome tidak mengubah putih CONTACT.
  const uint8_t savedMain = mainSource;
  const uint8_t savedWelcome = selectedWelcome;
  mainSource = MAIN_WELCOME;
  selectedWelcome = 0xFF;
  k3SafeShow();
  mainSource = savedMain;
  selectedWelcome = savedWelcome;
}

static void serviceContactStandbyRed() {
  static unsigned long lastShow = 0UL;
  if (!contactStandbyRedActive || senjaPhysicalActive || !lampOn || !contactOn) return;
  unsigned long now = millis();
  if ((unsigned long)(now - lastShow) < 15UL) return;
  lastShow = now;
  showContactStandbyRedNow();
}


static inline unsigned long getMode210StepDelay(unsigned long baseMs) {
  if (baseMs <= 1UL) return 1UL; float scaled = (float)baseMs / liveSpeedFactor;
  if (scaled < 2.0f) scaled = 2.0f; return (unsigned long)lroundf(scaled);
}

struct CustomModeConfig {
  uint8_t isCustom = 0; uint8_t r1 = 255, g1 = 255, b1 = 255; uint8_t r2 = 255, g2 = 255, b2 = 255; uint8_t tailUnified = 0;
};
CustomModeConfig modeOverrides[6];

struct Custom1SuiteState {
  uint8_t currentEffect = 1; uint8_t step = 0; uint8_t subStep = 0; uint8_t r = 0;
  uint16_t bKiri = 0; uint16_t bKanan = 0; unsigned long lastUpdate = 0; unsigned long nextDelay = 80; bool isPause = false;
};
Custom1SuiteState c1Suite;

void updateCustom1Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  CRGB warna = (modeOverrides[1].isCustom == 1) ? CRGB(modeOverrides[1].r1, modeOverrides[1].g1, modeOverrides[1].b1) : CRGB::White;
  int blocks = (count + 9) / 10; if (blocks < 1) blocks = 1;
  if (c1Suite.lastUpdate != 0 && (now - c1Suite.lastUpdate < getMode210StepDelay(c1Suite.nextDelay))) return;
  c1Suite.lastUpdate = now;
  if (c1Suite.isPause) {
    c1Suite.isPause = false; fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
    c1Suite.currentEffect = random(1, 9); c1Suite.step = 0; c1Suite.subStep = 0; c1Suite.r = 0; c1Suite.nextDelay = 80; return;
  }
  switch (c1Suite.currentEffect) {
    case 1: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c1Suite.subStep == 0) { c1Suite.bKiri = random(0, blocks) * 10; for (int j = c1Suite.bKiri; j < c1Suite.bKiri + 10 && j < count; j++) out1[j] = warna; c1Suite.nextDelay = 80; }
      else if (c1Suite.subStep == 1 || c1Suite.subStep == 3 || c1Suite.subStep == 5 || c1Suite.subStep == 7) { c1Suite.nextDelay = 80; }
      else if (c1Suite.subStep == 2) { for (int j = c1Suite.bKiri; j < c1Suite.bKiri + 10 && j < count; j++) out1[j] = warna; c1Suite.nextDelay = 80; }
      else if (c1Suite.subStep == 4) { c1Suite.bKanan = random(0, blocks) * 10; for (int j = c1Suite.bKanan; j < c1Suite.bKanan + 10 && j < count; j++) out2[j] = warna; c1Suite.nextDelay = 80; }
      else if (c1Suite.subStep == 6) { for (int j = c1Suite.bKanan; j < c1Suite.bKanan + 10 && j < count; j++) out2[j] = warna; c1Suite.nextDelay = 80; }
      c1Suite.subStep++; if (c1Suite.subStep >= 8) { c1Suite.subStep = 0; c1Suite.r++; if (c1Suite.r >= 4) { c1Suite.isPause = true; c1Suite.nextDelay = 500; } } break;
    }
    case 2: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c1Suite.subStep == 0) { c1Suite.bKiri = random(0, blocks) * 10; c1Suite.bKanan = random(0, blocks) * 10; }
      if (c1Suite.subStep % 2 == 0) {
        for (int j = 0; j < 10; j++) { int ik = c1Suite.bKiri + j; int in = c1Suite.bKanan + j; if (ik < count) out1[ik] = warna; if (in < count) out2[in] = warna; }
      }
      c1Suite.nextDelay = 70; c1Suite.subStep++;
      if (c1Suite.subStep >= 6) { c1Suite.subStep = 0; c1Suite.r++; if (c1Suite.r >= 3) { c1Suite.isPause = true; c1Suite.nextDelay = 500; } } break;
    }
    case 3: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      int b = c1Suite.subStep; for (int i = b * 10; i < (b * 10) + 10 && i < count; i++) { out1[i] = warna; out2[i] = warna; }
      c1Suite.nextDelay = 150; c1Suite.subStep++; if (c1Suite.subStep >= blocks) { c1Suite.subStep = 0; c1Suite.r++; if (c1Suite.r >= 3) { c1Suite.isPause = true; c1Suite.nextDelay = 500; } } break;
    }
    case 4: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      int b = random(0, blocks) * 10; int s = random(0, 2); for (int j = b; j < b + 10 && j < count; j++) { if (s == 0) out1[j] = warna; else out2[j] = warna; }
      c1Suite.nextDelay = 100; c1Suite.step++; if (c1Suite.step >= 20) { c1Suite.isPause = true; c1Suite.nextDelay = 500; } break;
    }
    case 5: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c1Suite.subStep == 0) fill_solid(out1, count, warna); else fill_solid(out2, count, warna);
      c1Suite.nextDelay = 150; c1Suite.subStep = 1 - c1Suite.subStep; if (c1Suite.subStep == 0) { c1Suite.step++; if (c1Suite.step >= 10) { c1Suite.isPause = true; c1Suite.nextDelay = 500; } } break;
    }
    case 6: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c1Suite.subStep == 0) { fill_solid(out1, count, warna); fill_solid(out2, count, warna); }
      c1Suite.nextDelay = 80; c1Suite.subStep = 1 - c1Suite.subStep; if (c1Suite.subStep == 0) { c1Suite.step++; if (c1Suite.step >= 15) { c1Suite.isPause = true; c1Suite.nextDelay = 500; } } break;
    }
    case 7: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c1Suite.subStep == 0) {
        c1Suite.bKiri = random(0, blocks) * 10; c1Suite.bKanan = random(0, blocks) * 10; int sel = random(0, 2);
        if (sel == 0) { for (int j = c1Suite.bKiri; j < c1Suite.bKiri + 10 && j < count; j++) out1[j] = warna; }
        else { for (int j = c1Suite.bKanan; j < c1Suite.bKanan + 10 && j < count; j++) out2[j] = warna; }
        c1Suite.nextDelay = 50;
      } else { c1Suite.nextDelay = 200; }
      c1Suite.subStep = 1 - c1Suite.subStep; if (c1Suite.subStep == 0) { c1Suite.step++; if (c1Suite.step >= 10) { c1Suite.isPause = true; c1Suite.nextDelay = 500; } } break;
    }
    case 8: {
      if (c1Suite.step % 5 == 0) { fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black); }
      out1[random(0, count)] = warna; out2[random(0, count)] = warna; c1Suite.nextDelay = 60; c1Suite.step++;
      if (c1Suite.step >= 50) { c1Suite.isPause = true; c1Suite.nextDelay = 500; } break;
    }
    default: c1Suite.isPause = true; c1Suite.nextDelay = 500; break;
  }
}

struct Custom2SuiteState {
  uint8_t currentEffect = 1; uint8_t step = 0; uint8_t subStep = 0; uint8_t r = 0;
  uint16_t bKiri = 0; uint16_t bKanan = 0; int8_t stepWarna = -1;
  unsigned long lastUpdate = 0; unsigned long nextDelay = 80; bool isPause = false;
};
Custom2SuiteState c2Suite;
const CRGB c2WarnaList[5] = { CRGB(255, 0, 0), CRGB(0, 0, 255), CRGB(0, 255, 0), CRGB(255, 255, 0), CRGB(180, 0, 255) };

void updateCustom2Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis(); CRGB warnaKiri, warnaKanan;
  if (c2Suite.stepWarna == -1) { warnaKiri = CRGB::White; warnaKanan = CRGB::White; }
  else { warnaKiri = c2WarnaList[c2Suite.stepWarna]; warnaKanan = c2WarnaList[(c2Suite.stepWarna + 2) % 5]; }
  if (modeOverrides[2].isCustom == 1) { warnaKiri = CRGB(modeOverrides[2].r1, modeOverrides[2].g1, modeOverrides[2].b1); warnaKanan = CRGB(modeOverrides[2].r2, modeOverrides[2].g2, modeOverrides[2].b2); }
  int blocks = (count + 9) / 10; if (blocks < 1) blocks = 1;
  if (c2Suite.lastUpdate != 0 && (now - c2Suite.lastUpdate < getMode210StepDelay(c2Suite.nextDelay))) return;
  c2Suite.lastUpdate = now;
  if (c2Suite.isPause) {
    c2Suite.isPause = false; fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
    c2Suite.stepWarna++; if (c2Suite.stepWarna > 4) c2Suite.stepWarna = -1;
    c2Suite.currentEffect = random(1, 9); c2Suite.step = 0; c2Suite.subStep = 0; c2Suite.r = 0; c2Suite.nextDelay = 80; return;
  }
  switch (c2Suite.currentEffect) {
    case 1: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c2Suite.subStep == 0 || c2Suite.subStep == 2) {
        if (c2Suite.subStep == 0) c2Suite.bKiri = random(0, blocks) * 10; for (int j = c2Suite.bKiri; j < c2Suite.bKiri + 10 && j < count; j++) out1[j] = warnaKiri;
      } else if (c2Suite.subStep == 4 || c2Suite.subStep == 6) {
        if (c2Suite.subStep == 4) c2Suite.bKanan = random(0, blocks) * 10; for (int j = c2Suite.bKanan; j < c2Suite.bKanan + 10 && j < count; j++) out2[j] = warnaKanan;
      }
      c2Suite.nextDelay = 150; c2Suite.subStep++; if (c2Suite.subStep >= 8) { c2Suite.subStep = 0; c2Suite.r++; if (c2Suite.r >= 4) { c2Suite.isPause = true; c2Suite.nextDelay = 500; } } break;
    }
    case 2: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c2Suite.subStep == 0) { c2Suite.bKiri = random(0, blocks) * 10; c2Suite.bKanan = random(0, blocks) * 10; }
      if (c2Suite.subStep % 2 == 0) { for (int j = 0; j < 10; j++) { int ik = c2Suite.bKiri + j; int in = c2Suite.bKanan + j; if (ik < count) out1[ik] = warnaKiri; if (in < count) out2[in] = warnaKanan; } }
      c2Suite.nextDelay = 100; c2Suite.subStep++; if (c2Suite.subStep >= 6) { c2Suite.subStep = 0; c2Suite.r++; if (c2Suite.r >= 3) { c2Suite.isPause = true; c2Suite.nextDelay = 500; } } break;
    }
    case 3: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      int b = c2Suite.subStep; for (int i = b * 10; i < (b * 10) + 10 && i < count; i++) { out1[i] = warnaKiri; out2[i] = warnaKanan; }
      c2Suite.nextDelay = 150; c2Suite.subStep++; if (c2Suite.subStep >= blocks) { c2Suite.subStep = 0; c2Suite.r++; if (c2Suite.r >= 3) { c2Suite.isPause = true; c2Suite.nextDelay = 500; } } break;
    }
    case 4: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      int b = random(0, blocks) * 10; int s = random(0, 2); for (int j = b; j < b + 10 && j < count; j++) { if (s == 0) out1[j] = warnaKiri; else out2[j] = warnaKanan; }
      c2Suite.nextDelay = 100; c2Suite.step++; if (c2Suite.step >= 10) { c2Suite.isPause = true; c2Suite.nextDelay = 500; } break;
    }
    case 5: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c2Suite.subStep == 0) fill_solid(out1, count, warnaKiri); else fill_solid(out2, count, warnaKanan);
      c2Suite.nextDelay = 150; c2Suite.subStep = 1 - c2Suite.subStep; if (c2Suite.subStep == 0) { c2Suite.step++; if (c2Suite.step >= 6) { c2Suite.isPause = true; c2Suite.nextDelay = 500; } } break;
    }
    case 6: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c2Suite.subStep == 0) { fill_solid(out1, count, warnaKiri); fill_solid(out2, count, warnaKanan); }
      c2Suite.nextDelay = 120; c2Suite.subStep = 1 - c2Suite.subStep; if (c2Suite.subStep == 0) { c2Suite.step++; if (c2Suite.step >= 8) { c2Suite.isPause = true; c2Suite.nextDelay = 500; } } break;
    }
    case 7: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c2Suite.subStep == 0) { c2Suite.bKiri = random(0, blocks) * 10; for (int j = c2Suite.bKiri; j < c2Suite.bKiri + 10 && j < count; j++) out1[j] = warnaKiri; c2Suite.nextDelay = 80; } else { c2Suite.nextDelay = 250; }
      c2Suite.subStep = 1 - c2Suite.subStep; if (c2Suite.subStep == 0) { c2Suite.step++; if (c2Suite.step >= 6) { c2Suite.isPause = true; c2Suite.nextDelay = 500; } } break;
    }
    case 8: {
      out1[random(0, count)] = warnaKiri; out2[random(0, count)] = warnaKanan;
      if (c2Suite.step % 3 == 0) { fadeToBlackBy(out1, count, 100); fadeToBlackBy(out2, count, 100); }
      c2Suite.nextDelay = 100; c2Suite.step++; if (c2Suite.step >= 30) { c2Suite.isPause = true; c2Suite.nextDelay = 500; } break;
    }
    default: c2Suite.isPause = true; c2Suite.nextDelay = 500; break;
  }
}

struct Custom3SuiteState {
  uint8_t currentEffect = 1; uint8_t step = 0; uint8_t subStep = 0; uint8_t r = 0;
  uint16_t bKiri = 0; uint16_t bKanan = 0; unsigned long lastUpdate = 0; unsigned long nextDelay = 200; bool isPause = false;
};
Custom3SuiteState c3Suite;

void updateCustom3Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  CRGB warna = (modeOverrides[3].isCustom == 1) ? CRGB(modeOverrides[3].r1, modeOverrides[3].g1, modeOverrides[3].b1) : CRGB::White;
  int blocks = (count + 9) / 10; if (blocks < 1) blocks = 1;
  if (c3Suite.lastUpdate != 0 && (now - c3Suite.lastUpdate < getMode210StepDelay(c3Suite.nextDelay))) return;
  c3Suite.lastUpdate = now;
  if (c3Suite.isPause) {
    c3Suite.isPause = false; fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
    c3Suite.currentEffect = random(1, 9); c3Suite.step = 0; c3Suite.subStep = 0; c3Suite.r = 0; c3Suite.nextDelay = 200; return;
  }
  switch (c3Suite.currentEffect) {
    case 1: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c3Suite.subStep == 0 || c3Suite.subStep == 2) {
        if (c3Suite.subStep == 0) c3Suite.bKiri = random(0, blocks) * 10; for (int j = c3Suite.bKiri; j < c3Suite.bKiri + 10 && j < count; j++) out1[j] = warna;
      } else if (c3Suite.subStep == 4 || c3Suite.subStep == 6) {
        if (c3Suite.subStep == 4) c3Suite.bKanan = random(0, blocks) * 10; for (int j = c3Suite.bKanan; j < c3Suite.bKanan + 10 && j < count; j++) out2[j] = warna;
      }
      c3Suite.nextDelay = 200; c3Suite.subStep++; if (c3Suite.subStep >= 8) { c3Suite.subStep = 0; c3Suite.r++; if (c3Suite.r >= 6) { c3Suite.isPause = true; c3Suite.nextDelay = 500; } } break;
    }
    case 2: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c3Suite.subStep == 0) { c3Suite.bKiri = random(0, blocks) * 10; c3Suite.bKanan = random(0, blocks) * 10; }
      if (c3Suite.subStep % 2 == 0) { for (int j = 0; j < 10; j++) { int ik = c3Suite.bKiri + j; int in = c3Suite.bKanan + j; if (ik < count) out1[ik] = warna; if (in < count) out2[in] = warna; } }
      c3Suite.nextDelay = 200; c3Suite.subStep++; if (c3Suite.subStep >= 6) { c3Suite.subStep = 0; c3Suite.r++; if (c3Suite.r >= 5) { c3Suite.isPause = true; c3Suite.nextDelay = 500; } } break;
    }
    case 3: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      int b = c3Suite.subStep; for (int i = b * 10; i < (b * 10) + 10 && i < count; i++) { out1[i] = warna; out2[i] = warna; }
      c3Suite.nextDelay = 200; c3Suite.subStep++; if (c3Suite.subStep >= blocks) { c3Suite.subStep = 0; c3Suite.r++; if (c3Suite.r >= 5) { c3Suite.isPause = true; c3Suite.nextDelay = 500; } } break;
    }
    case 4: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c3Suite.subStep == 0) { int b = random(0, blocks) * 10; int s = random(0, 2); for (int j = b; j < b + 10 && j < count; j++) { if (s == 0) out1[j] = warna; else out2[j] = warna; } }
      c3Suite.nextDelay = 200; c3Suite.subStep++; if (c3Suite.subStep >= 2) { c3Suite.subStep = 0; c3Suite.r++; if (c3Suite.r >= 15) { c3Suite.isPause = true; c3Suite.nextDelay = 500; } } break;
    }
    case 5: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c3Suite.subStep == 0) fill_solid(out1, count, warna); else fill_solid(out2, count, warna);
      c3Suite.nextDelay = 200; c3Suite.subStep++; if (c3Suite.subStep >= 2) { c3Suite.subStep = 0; c3Suite.r++; if (c3Suite.r >= 8) { c3Suite.isPause = true; c3Suite.nextDelay = 500; } } break;
    }
    case 6: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c3Suite.subStep == 0) { fill_solid(out1, count, warna); fill_solid(out2, count, warna); c3Suite.nextDelay = 200; } else { c3Suite.nextDelay = 400; }
      c3Suite.subStep++; if (c3Suite.subStep >= 2) { c3Suite.subStep = 0; c3Suite.r++; if (c3Suite.r >= 10) { c3Suite.isPause = true; c3Suite.nextDelay = 500; } } break;
    }
    case 7: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      if (c3Suite.subStep == 0) { int b = random(0, blocks) * 10; for (int j = b; j < b + 10 && j < count; j++) out1[j] = warna; c3Suite.nextDelay = 30; } else { c3Suite.nextDelay = 200; }
      c3Suite.subStep++; if (c3Suite.subStep >= 2) { c3Suite.subStep = 0; c3Suite.r++; if (c3Suite.r >= 8) { c3Suite.isPause = true; c3Suite.nextDelay = 500; } } break;
    }
    case 8: {
      if (c3Suite.r % 3 == 0) { fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black); }
      out1[random(0, count)] = warna; out2[random(0, count)] = warna; c3Suite.nextDelay = 200; c3Suite.r++;
      if (c3Suite.r >= 40) { c3Suite.isPause = true; c3Suite.nextDelay = 500; } break;
    }
  }
}

struct Custom4SuiteState {
  uint8_t colorIndex = 0; uint16_t changeTimer = 0; bool isOn = true;
  int bKiri = 0, bKanan = 0; unsigned long lastUpdate = 0; unsigned long nextDelay = 250;
};
Custom4SuiteState c4Suite;
const uint8_t c4Palette[10] = {213, 140, 192, 0, 64, 96, 32, 160, 110, 240};

void updateCustom4Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c4Suite.lastUpdate != 0 && (now - c4Suite.lastUpdate < getMode210StepDelay(c4Suite.nextDelay))) return;
  c4Suite.lastUpdate = now;
  int blocks = (count + 9) / 10; if (blocks < 1) blocks = 1;
  if (c4Suite.isOn) {
    fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
    CRGB warnaKanan = CHSV(c4Palette[c4Suite.colorIndex], 255, 255);
    CRGB warnaKiri = CHSV(c4Palette[(c4Suite.colorIndex + 1) % 10], 255, 255);
    if (modeOverrides[4].isCustom == 1) { warnaKiri = CRGB(modeOverrides[4].r1, modeOverrides[4].g1, modeOverrides[4].b1); warnaKanan = CRGB(modeOverrides[4].r2, modeOverrides[4].g2, modeOverrides[4].b2); }
    c4Suite.bKanan = random(0, blocks) * 10;
    for (int j = 0; j < 10 && c4Suite.bKanan + j < count; j++) out2[c4Suite.bKanan + j] = warnaKanan;
    c4Suite.bKiri = random(0, blocks) * 10;
    for (int j = 0; j < 10 && c4Suite.bKiri + j < count; j++) out1[c4Suite.bKiri + j] = warnaKiri;
    c4Suite.nextDelay = 250; c4Suite.isOn = false; c4Suite.changeTimer++;
    if (c4Suite.changeTimer > 30) { c4Suite.changeTimer = 0; c4Suite.colorIndex = (c4Suite.colorIndex + 1) % 10; }
  } else {
    fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black); c4Suite.nextDelay = 50; c4Suite.isOn = true;
  }
}

struct Custom5SuiteState {
  uint8_t gHue = 0; int meteorPos = 0; int meteorDir = 1; uint8_t meteorHue = 160; uint8_t fase = 0;
  unsigned long lastChangeTime = 0; unsigned long lastUpdate = 0; unsigned long nextDelay = 25;
};
Custom5SuiteState c5Suite;


// =========================================================================
// CUSTOM 6 SUITE — sumber: custom6.ino
// Kiri 3x tutup-buka, lalu kanan 3x tutup-buka. Non-blocking.
// =========================================================================
struct Custom6SuiteState {
  uint8_t side = 0;       // 0 = out1/kiri, 1 = out2/kanan
  uint8_t repeat = 0;     // 0..2 per sisi
  uint8_t phase = 0;      // 0 = menutup, 1 = membuka
  int pos = 0;
  uint8_t gHue = 0;
  bool clearBeforeNext = false;
  unsigned long lastUpdate = 0;
  unsigned long nextDelay = 20;
};
Custom6SuiteState c6Suite;

void updateCustom6Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  if (count == 0) return;
  unsigned long now = millis();
  if (c6Suite.lastUpdate != 0 && (now - c6Suite.lastUpdate < getMode210StepDelay(c6Suite.nextDelay))) return;
  c6Suite.lastUpdate = now;

  int center = (int)(count / 2U);
  if (center <= 0) {
    fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
    c6Suite.nextDelay = 20; return;
  }

  if (c6Suite.clearBeforeNext) {
    fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
    c6Suite.clearBeforeNext = false;
  }

  CRGB *target = (c6Suite.side == 0) ? out1 : out2;
  fadeToBlackBy(target, count, 120);

  int i = c6Suite.pos;
  if (i >= 0 && i < center) {
    target[i] = CHSV(c6Suite.gHue, 255, 255);
    int mirror = ((int)count - 1) - i;
    if (mirror >= 0 && mirror < (int)count) target[mirror] = CHSV(c6Suite.gHue, 255, 255);
  }
  c6Suite.gHue += 5;
  c6Suite.nextDelay = 20;

  if (c6Suite.phase == 0) {
    c6Suite.pos++;
    if (c6Suite.pos >= center) { c6Suite.phase = 1; c6Suite.pos = center - 1; }
  } else {
    c6Suite.pos--;
    if (c6Suite.pos < 0) {
      c6Suite.repeat++;
      if (c6Suite.repeat >= 3) { c6Suite.repeat = 0; c6Suite.side ^= 1U; }
      c6Suite.phase = 0;
      c6Suite.pos = 0;
      // FastLED.clear() asli dilakukan setelah repetisi tanpa show.
      // Buffer dibersihkan tepat sebelum frame berikutnya agar visual tetap identik.
      c6Suite.clearBeforeNext = true;
    }
  }
}

// =========================================================================
// CUSTOM 7 SUITE — sumber: custom7.ino
// Deep fade-in putih -> triple blitz -> blackout 1500 ms. Non-blocking.
// =========================================================================
struct Custom7SuiteState {
  uint8_t stage = 0;      // 0 fade, 1 tahan 100ms, 2 triple blitz, 3 blackout panjang
  uint8_t fadeValue = 0;
  uint8_t blitzCount = 0;
  bool blitzOn = true;
  unsigned long lastUpdate = 0;
  unsigned long nextDelay = 40;
};
Custom7SuiteState c7Suite;

void updateCustom7Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  if (count == 0) return;
  unsigned long now = millis();
  if (c7Suite.lastUpdate != 0 && (now - c7Suite.lastUpdate < getMode210StepDelay(c7Suite.nextDelay))) return;
  c7Suite.lastUpdate = now;

  switch (c7Suite.stage) {
    case 0: {
      uint8_t v = c7Suite.fadeValue;
      fill_solid(out1, count, CRGB(v, v, v));
      fill_solid(out2, count, CRGB(v, v, v));
      c7Suite.nextDelay = 40;
      c7Suite.fadeValue++;
      if (c7Suite.fadeValue >= 80) { c7Suite.fadeValue = 0; c7Suite.stage = 1; }
      break;
    }
    case 1: {
      // delay(100) asli: tidak mengubah frame terakhir fade.
      c7Suite.nextDelay = 100;
      c7Suite.blitzCount = 0; c7Suite.blitzOn = true; c7Suite.stage = 2;
      break;
    }
    case 2: {
      if (c7Suite.blitzOn) {
        fill_solid(out1, count, CRGB::White); fill_solid(out2, count, CRGB::White);
        c7Suite.nextDelay = 30; c7Suite.blitzOn = false;
      } else {
        fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
        c7Suite.nextDelay = 60; c7Suite.blitzOn = true; c7Suite.blitzCount++;
        if (c7Suite.blitzCount >= 3) c7Suite.stage = 3;
      }
      break;
    }
    default: {
      // Setelah OFF terakhir sudah ada delay 60 ms; ini menambahkan delay(1500) asli.
      c7Suite.nextDelay = 1500;
      c7Suite.stage = 0; c7Suite.fadeValue = 0; c7Suite.blitzCount = 0; c7Suite.blitzOn = true;
      break;
    }
  }
}

// =========================================================================
// CUSTOM 8 SUITE — sumber: custom_8_copy_20260520182929.ino
// 5 LED -> 10 -> ...; tiap tahap deep fade + double blitz. Non-blocking.
// =========================================================================
struct Custom8SuiteState {
  uint8_t stage = 0;      // 0 fade, 1 tahan100, 2 double blitz, 3 antar-limit400, 4 akhir1500
  uint16_t limit = 5;
  uint8_t fadeValue = 0;
  uint8_t blitzCount = 0;
  bool blitzOn = true;
  unsigned long lastUpdate = 0;
  unsigned long nextDelay = 40;
};
Custom8SuiteState c8Suite;

void updateCustom8Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  if (count == 0) return;
  unsigned long now = millis();
  if (c8Suite.lastUpdate != 0 && (now - c8Suite.lastUpdate < getMode210StepDelay(c8Suite.nextDelay))) return;
  c8Suite.lastUpdate = now;

  const uint16_t STEP = 5;
  if (c8Suite.limit < STEP) c8Suite.limit = STEP;
  if (c8Suite.limit > count && count >= STEP) c8Suite.limit = STEP;

  switch (c8Suite.stage) {
    case 0: {
      if (count < STEP) {
        fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
        c8Suite.nextDelay = 1500; return;
      }
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      uint8_t v = c8Suite.fadeValue;
      for (uint16_t j = 0; j < c8Suite.limit && j < count; j++) {
        out1[j] = CRGB(v, v, v);
        out2[(count - 1U) - j] = CRGB(v, v, v);
      }
      c8Suite.nextDelay = 40;
      c8Suite.fadeValue++;
      if (c8Suite.fadeValue >= 80) { c8Suite.fadeValue = 0; c8Suite.stage = 1; }
      break;
    }
    case 1: {
      // delay(100) asli: tahan frame fade terakhir.
      c8Suite.nextDelay = 100;
      c8Suite.blitzCount = 0; c8Suite.blitzOn = true; c8Suite.stage = 2;
      break;
    }
    case 2: {
      if (c8Suite.blitzOn) {
        fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
        for (uint16_t j = 0; j < c8Suite.limit && j < count; j++) {
          out1[j] = CRGB::White;
          out2[(count - 1U) - j] = CRGB::White;
        }
        c8Suite.nextDelay = 35; c8Suite.blitzOn = false;
      } else {
        fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
        c8Suite.nextDelay = 65; c8Suite.blitzOn = true; c8Suite.blitzCount++;
        if (c8Suite.blitzCount >= 2) c8Suite.stage = 3;
      }
      break;
    }
    case 3: {
      // delay(400) asli sesudah double blitz.
      c8Suite.nextDelay = 400;
      if ((uint32_t)c8Suite.limit + STEP <= count) {
        c8Suite.limit += STEP; c8Suite.stage = 0; c8Suite.fadeValue = 0;
      } else {
        c8Suite.stage = 4;
      }
      break;
    }
    default: {
      // delay(1500) asli setelah limit terakhir.
      c8Suite.nextDelay = 1500;
      c8Suite.limit = STEP; c8Suite.fadeValue = 0; c8Suite.blitzCount = 0; c8Suite.blitzOn = true; c8Suite.stage = 0;
      break;
    }
  }
}

// =========================================================================
// CUSTOM 9 SUITE — sumber: custom_9.ino
// Meteor rainbow 5 putaran -> strobe rainbow blok 10 LED. Non-blocking.
// out1 = kiri, out2 = kanan; path meteor asli: kanan maju -> kiri mundur.
// =========================================================================
struct Custom9SuiteState {
  uint8_t gHue = 0;
  int meteorPos = 0;
  uint8_t mode = 0;       // 0 meteor, 1 strobe
  uint8_t loopCount = 0;
  uint8_t strobeCount = 0;
  uint16_t blockIndex = 0;
  bool strobeOn = true;
  unsigned long lastUpdate = 0;
  unsigned long nextDelay = 25;
};
Custom9SuiteState c9Suite;

void updateCustom9Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  if (count == 0) return;
  unsigned long now = millis();
  if (c9Suite.lastUpdate != 0 && (now - c9Suite.lastUpdate < getMode210StepDelay(c9Suite.nextDelay))) return;
  c9Suite.lastUpdate = now;

  const int total = (int)count * 2;
  if (c9Suite.mode == 0) {
    for (uint16_t i = 0; i < count; i++) { out1[i].nscale8(200); out2[i].nscale8(200); }

    if (c9Suite.meteorPos < (int)count) {
      // Array gabungan asli bagian pertama adalah sisi kanan.
      out2[c9Suite.meteorPos] = CHSV(c9Suite.gHue, 255, 255);
    } else {
      int leftIndex = (total - 1) - c9Suite.meteorPos;
      if (leftIndex >= 0 && leftIndex < (int)count) out1[leftIndex] = CHSV(c9Suite.gHue, 255, 255);
    }

    c9Suite.gHue += 8;
    c9Suite.nextDelay = 25;
    c9Suite.meteorPos++;
    if (c9Suite.meteorPos >= total) {
      c9Suite.meteorPos = 0; c9Suite.loopCount++;
      if (c9Suite.loopCount >= 5) { c9Suite.loopCount = 0; c9Suite.mode = 1; c9Suite.strobeOn = true; }
    }
    return;
  }

  const uint16_t totalBlocks = (uint16_t)((total + 9) / 10);
  if (c9Suite.strobeOn) {
    fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
    int startPos = (int)c9Suite.blockIndex * 10;
    for (int i = 0; i < 10; i++) {
      int combined = startPos + i;
      if (combined >= total) break;
      if (combined < (int)count) out2[combined] = CHSV(c9Suite.gHue, 255, 255);
      else out1[combined - (int)count] = CHSV(c9Suite.gHue, 255, 255);
    }
    c9Suite.nextDelay = 200;
    c9Suite.strobeOn = false;
  } else {
    fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
    c9Suite.nextDelay = 80;
    c9Suite.strobeOn = true;
    c9Suite.gHue += 30;
    c9Suite.blockIndex++;
    if (c9Suite.blockIndex >= totalBlocks) c9Suite.blockIndex = 0;
    c9Suite.strobeCount++;
    if (c9Suite.strobeCount >= 30) {
      c9Suite.strobeCount = 0; c9Suite.mode = 0; c9Suite.meteorPos = 0;
    }
  }
}

// =========================================================================
// CUSTOM 10 SUITE — sumber: custom_10.ino
// Scan 3x/segmen -> collision -> putih 5x -> random jump 5x -> blackout 5s.
// =========================================================================
struct Custom10SuiteState {
  uint8_t stage = 0;
  int segIndex = 0;
  uint8_t scanFlash = 0;
  bool scanOn = true;
  int collisionI = 0;
  uint8_t explodeCount = 0;
  bool explodeOn = true;
  uint8_t jumpRep = 0;
  uint8_t jumpFlash = 0;
  bool jumpOn = true;
  uint8_t jumpStrip = 0;
  int jumpStart = 0;
  CRGB currentColor = CRGB::Black;
  unsigned long lastUpdate = 0;
  unsigned long nextDelay = 200;
};
Custom10SuiteState c10Suite;

void updateCustom10Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  if (count == 0) return;
  unsigned long now = millis();
  if (c10Suite.lastUpdate != 0 && (now - c10Suite.lastUpdate < getMode210StepDelay(c10Suite.nextDelay))) return;
  c10Suite.lastUpdate = now;

  const int segmentSize = 10;
  int segCount = (int)count / segmentSize;
  if (segCount < 1) segCount = 1;

  switch (c10Suite.stage) {
    case 0: {
      if (c10Suite.scanOn) {
        fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
        c10Suite.currentColor = CHSV(random8(), 255, 255);
        int start = c10Suite.segIndex * segmentSize;
        for (int k = 0; k < segmentSize && start + k < (int)count; k++) {
          out1[start + k] = c10Suite.currentColor; out2[start + k] = c10Suite.currentColor;
        }
        c10Suite.nextDelay = 200; c10Suite.scanOn = false;
      } else {
        fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
        c10Suite.nextDelay = 200; c10Suite.scanOn = true; c10Suite.scanFlash++;
        if (c10Suite.scanFlash >= 3) {
          c10Suite.scanFlash = 0; c10Suite.segIndex++;
          if (c10Suite.segIndex >= segCount) { c10Suite.segIndex = 0; c10Suite.stage = 1; c10Suite.collisionI = 0; }
        }
      }
      break;
    }

    case 1: {
      int maxI = ((int)count / 2) - 5;
      if (c10Suite.collisionI <= maxI) {
        fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
        c10Suite.currentColor = CHSV(random8(), 255, 255);
        int leftStart = c10Suite.collisionI;
        int rightStart = (int)count - c10Suite.collisionI - segmentSize;
        if (rightStart < 0) rightStart = 0;
        for (int k = 0; k < segmentSize; k++) {
          if (leftStart + k >= 0 && leftStart + k < (int)count) {
            out1[leftStart + k] = c10Suite.currentColor; out2[leftStart + k] = c10Suite.currentColor;
          }
          if (rightStart + k >= 0 && rightStart + k < (int)count) {
            out1[rightStart + k] = c10Suite.currentColor; out2[rightStart + k] = c10Suite.currentColor;
          }
        }
        c10Suite.nextDelay = 200;
        c10Suite.collisionI += 2;
        break;
      }
      c10Suite.stage = 2; c10Suite.explodeCount = 0; c10Suite.explodeOn = true;
      // Tidak ada delay tambahan antara collision terakhir dan strobo putih pertama.
    }
    // fall through
    case 2: {
      if (c10Suite.explodeOn) {
        fill_solid(out1, count, CRGB::White); fill_solid(out2, count, CRGB::White);
        c10Suite.nextDelay = 100; c10Suite.explodeOn = false;
      } else {
        fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
        c10Suite.nextDelay = 100; c10Suite.explodeOn = true; c10Suite.explodeCount++;
        if (c10Suite.explodeCount >= 5) {
          c10Suite.stage = 3; c10Suite.jumpRep = 0; c10Suite.jumpFlash = 0; c10Suite.jumpOn = true;
        }
      }
      break;
    }

    case 3: {
      if (c10Suite.jumpFlash == 0 && c10Suite.jumpOn) {
        c10Suite.jumpStrip = (uint8_t)random(0, 2);
        int maxStart = (int)count - segmentSize;
        if (maxStart < 0) maxStart = 0;
        c10Suite.jumpStart = random(0, maxStart + 1);
        c10Suite.currentColor = CHSV(random8(), 255, 255);
      }

      if (c10Suite.jumpOn) {
        fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
        CRGB *target = (c10Suite.jumpStrip == 0) ? out1 : out2;
        for (int k = 0; k < segmentSize && c10Suite.jumpStart + k < (int)count; k++) target[c10Suite.jumpStart + k] = c10Suite.currentColor;
        c10Suite.nextDelay = 200; c10Suite.jumpOn = false;
      } else {
        fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
        c10Suite.nextDelay = 200; c10Suite.jumpOn = true; c10Suite.jumpFlash++;
        if (c10Suite.jumpFlash >= 2) {
          c10Suite.jumpFlash = 0; c10Suite.jumpRep++;
          if (c10Suite.jumpRep >= 5) c10Suite.stage = 4;
        }
      }
      break;
    }

    default: {
      fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
      c10Suite.nextDelay = 5000;
      c10Suite.stage = 0; c10Suite.segIndex = 0; c10Suite.scanFlash = 0; c10Suite.scanOn = true;
      c10Suite.collisionI = 0; c10Suite.explodeCount = 0; c10Suite.explodeOn = true;
      c10Suite.jumpRep = 0; c10Suite.jumpFlash = 0; c10Suite.jumpOn = true;
      break;
    }
  }
}


// ============================================================================
// MODE 11-20 — SOURCE RECOVERY from Salinan(1).ino
// Gerakan/warna/fase/timing source dipertahankan; hanya adapter GLOBAL 4CH.
// ============================================================================
static uint8_t activeSuiteChannel = 0;
static CustomModeConfig legacyModeOverrides210[211];

#ifndef MAX_LEDS
#define MAX_LEDS STAGE0_LED_BUFFER
#endif
#define currentSpeed appSpeed
#define modeOverrides legacyModeOverrides210

static inline unsigned long getMode210Duration(unsigned long baseMs) {
  return getMode210StepDelay(baseMs);
}

static inline void clearUnusedChannel(CRGB *leds) {
  uint16_t count = activeLedCount;
  if (count > STAGE0_LED_BUFFER) count = STAGE0_LED_BUFFER;
  for (uint16_t i = count; i < STAGE0_LED_BUFFER; i++) leds[i] = CRGB::Black;
}

// =========================================================================
// CUSTOM 11 SUITE
// =========================================================================
struct Custom11SuiteState {
  uint8_t gHue = 0;
  uint8_t currentEffect = 1;
  unsigned long effectStart = 0;
  unsigned long lastHueUpdate = 0;
  uint8_t subStep = 0;
  int bKiri = 0, bKanan = 0;
  int pos = 0;
  unsigned long lastUpdate = 0;
  unsigned long nextDelay = 60;
};
Custom11SuiteState c11Suite;

void updateCustom11Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();

  if (now - c11Suite.lastHueUpdate >= getMode210StepDelay(20UL)) {
    c11Suite.gHue++;
    c11Suite.lastHueUpdate = now;
  }
  CRGB warna = CHSV(c11Suite.gHue, 255, 255);

  unsigned long durationScaled = getMode210Duration(2500UL);
  if (now - c11Suite.effectStart > durationScaled) {
    c11Suite.effectStart = now;
    c11Suite.currentEffect++;
    if (c11Suite.currentEffect > 8) c11Suite.currentEffect = 1;
    fill_solid(out1, count, CRGB::Black);
    fill_solid(out2, count, CRGB::Black);
    c11Suite.subStep = 0;
    c11Suite.nextDelay = 0;
  }

  if (c11Suite.lastUpdate != 0 && (now - c11Suite.lastUpdate < getMode210StepDelay(c11Suite.nextDelay))) {
    return;
  }
  c11Suite.lastUpdate = now;

  int blocks = (count + 9) / 10;
  if (blocks < 1) blocks = 1;

  switch (c11Suite.currentEffect) {
    case 1: {
      fill_solid(out1, count, CRGB::Black);
      if (c11Suite.subStep % 2 == 0) {
        if (c11Suite.subStep == 0) c11Suite.bKiri = random(0, blocks) * 10;
        for (int j = 0; j < 10 && c11Suite.bKiri + j < count; j++) out1[c11Suite.bKiri + j] = warna;
      }
      c11Suite.nextDelay = 60;
      c11Suite.subStep++;
      if (c11Suite.subStep >= 4) c11Suite.subStep = 0;
      break;
    }
    case 2: {
      fill_solid(out1, count, CRGB::Black);
      fill_solid(out2, count, CRGB::Black);
      if (c11Suite.subStep == 0) { c11Suite.bKiri = random(0, blocks) * 10; c11Suite.bKanan = random(0, blocks) * 10; }
      if (c11Suite.subStep % 2 == 0) {
        for (int j = 0; j < 10; j++) {
          if (c11Suite.bKiri + j < count) out1[c11Suite.bKiri + j] = warna;
          if (c11Suite.bKanan + j < count) out2[c11Suite.bKanan + j] = warna;
        }
      }
      c11Suite.nextDelay = 50;
      c11Suite.subStep++;
      if (c11Suite.subStep >= 6) c11Suite.subStep = 0;
      break;
    }
    case 3: {
      fill_solid(out1, count, CRGB::Black);
      fill_solid(out2, count, CRGB::Black);
      int b = c11Suite.subStep;
      for (int i = b * 10; i < (b * 10) + 10 && i < count; i++) { out1[i] = warna; out2[i] = warna; }
      c11Suite.nextDelay = 100;
      c11Suite.subStep++;
      if (c11Suite.subStep >= blocks) c11Suite.subStep = 0;
      break;
    }
    case 4: {
      fill_solid(out1, count, CRGB::Black);
      fill_solid(out2, count, CRGB::Black);
      int b = random(0, blocks) * 10;
      int s = random(0, 2);
      for (int j = 0; j < 10 && b + j < count; j++) { if (s == 0) out1[b + j] = warna; else out2[b + j] = warna; }
      c11Suite.nextDelay = 80;
      break;
    }
    case 5: {
      if (c11Suite.subStep == 0) { fill_solid(out1, count, warna); fill_solid(out2, count, CRGB::Black); }
      else { fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, warna); }
      c11Suite.nextDelay = 120;
      c11Suite.subStep = 1 - c11Suite.subStep;
      break;
    }
    case 6: {
      if (c11Suite.subStep == 0) { fill_solid(out1, count, warna); fill_solid(out2, count, warna); }
      else { fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black); }
      c11Suite.nextDelay = 60;
      c11Suite.subStep = 1 - c11Suite.subStep;
      break;
    }
    case 7: {
      if (c11Suite.subStep == 0) {
        fill_solid(out1, count, CRGB::Black);
        int b = random(0, blocks) * 10;
        for (int j = 0; j < 10 && b + j < count; j++) out1[b + j] = warna;
        c11Suite.nextDelay = 30;
      } else {
        fill_solid(out1, count, CRGB::Black);
        c11Suite.nextDelay = 150;
      }
      c11Suite.subStep = 1 - c11Suite.subStep;
      break;
    }
    case 8: {
      fill_rainbow(out1, count, c11Suite.gHue, 7);
      fill_rainbow(out2, count, c11Suite.gHue, 7);
      c11Suite.nextDelay = 20;
      break;
    }
  }
}

// =========================================================================
// CUSTOM 12 SUITE
// =========================================================================
struct Custom12SuiteState {
  uint8_t gHue = 0;
  unsigned long lastHueUpdate = 0;
  uint8_t currentEffect = 1;
  unsigned long effectStart = 0;
  unsigned long lastUpdate = 0;
  unsigned long nextDelay = 0;
  int posGeser = 0;
  int stepFill = 0; bool fillingFlag = true;
  int movePos = 0;
  int posBounce = 0, dirBounce = 1;
  int wipePos = 0;
  int qChase = 0;
  int pPong = 0, dPong = 1;
};
Custom12SuiteState c12Suite;
CRGB *c12TrailKByChannel[4] = {nullptr, nullptr, nullptr, nullptr};
CRGB *c12TrailNByChannel[4] = {nullptr, nullptr, nullptr, nullptr};

void updateCustom12Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  // MODE 12 BARU — BLUE ICE BLOK ADAPTIF PING-PONG
  // - CH kiri/kanan selalu sejajar.
  // - Lebar blok mengikuti jumlah LED: 30=5, 35=6, 40=7, ... 75=14.
  // - 5 kedipan per posisi.
  // - Setelah 5 kedipan: maju satu langkah blok.
  // - Sampai ujung lalu balik lagi sampai awal, lalu berulang.
  // - Timing tetap non-blocking dan mengikuti speed GLOBAL.
  if (out1 == nullptr || out2 == nullptr || count == 0U) return;

  unsigned long now = millis();
  if (c12Suite.lastUpdate != 0UL &&
      (unsigned long)(now - c12Suite.lastUpdate) <
        getMode210StepDelay(c12Suite.nextDelay)) {
    return;
  }
  c12Suite.lastUpdate = now;

  // LEBAR BLOK ADAPTIF:
  // 30 LED = 5 LED/blok, 35 = 6, 40 = 7, ... 75 = 14.
  // Rumus mengikuti patokan pengguna: setiap +5 LED, lebar blok +1 LED.
  uint16_t BLOCK_SIZE = 1U;
  if (count >= 10U) {
    BLOCK_SIZE = (uint16_t)(count / 5U);
    if (BLOCK_SIZE > 0U) BLOCK_SIZE -= 1U;
  }
  if (BLOCK_SIZE < 1U) BLOCK_SIZE = 1U;
  if (BLOCK_SIZE > count) BLOCK_SIZE = count;

  // Banyak posisi gerak dihitung dari lebar blok baru.
  // Posisi terakhir tetap dipaksa mencapai ujung dengan blok penuh.
  const uint16_t maxStart = (count > BLOCK_SIZE) ? (uint16_t)(count - BLOCK_SIZE) : 0U;
  const uint16_t blockCount = (uint16_t)(maxStart / BLOCK_SIZE + 1U +
    ((maxStart % BLOCK_SIZE) ? 1U : 0U));

  fill_solid(out1, count, CRGB::Black);
  fill_solid(out2, count, CRGB::Black);

  if (blockCount == 0U) {
    c12Suite.nextDelay = 90UL;
    return;
  }

  if (c12Suite.posGeser < 0) c12Suite.posGeser = 0;
  if (c12Suite.posGeser >= (int)blockCount)
    c12Suite.posGeser = (int)blockCount - 1;

  // qChase 0..9 = OFF/ON sebanyak 5 kedipan.
  // OFF 45 ms, ON 90 ms. Setelah itu jeda 85 ms sebelum pindah blok.
  if (c12Suite.qChase < 10) {
    bool on = ((c12Suite.qChase & 1) != 0);

    if (on) {
      const CRGB blueIce(105, 225, 255);
      uint32_t rawStart = (uint32_t)c12Suite.posGeser * (uint32_t)BLOCK_SIZE;
      uint16_t start = (rawStart > maxStart) ? maxStart : (uint16_t)rawStart;
      uint16_t end = start + BLOCK_SIZE;
      if (end > count) end = count;

      for (uint16_t i = start; i < end; i++) {
        out1[i] = blueIce;
        out2[i] = blueIce;
      }

      c12Suite.nextDelay = 90UL;
    } else {
      c12Suite.nextDelay = 45UL;
    }

    c12Suite.qChase++;
    return;
  }

  // Jeda pendek setelah kedipan ke-5, lalu pindah satu blok.
  c12Suite.qChase = 0;
  c12Suite.nextDelay = 85UL;

  if (blockCount <= 1U) return;

  if (c12Suite.dirBounce == 0) c12Suite.dirBounce = 1;

  if (c12Suite.posGeser >= (int)blockCount - 1) {
    c12Suite.dirBounce = -1;
  } else if (c12Suite.posGeser <= 0) {
    c12Suite.dirBounce = 1;
  }

  c12Suite.posGeser += c12Suite.dirBounce;

  if (c12Suite.posGeser < 0) c12Suite.posGeser = 0;
  if (c12Suite.posGeser >= (int)blockCount)
    c12Suite.posGeser = (int)blockCount - 1;
}

// =========================================================================
// CUSTOM 13 SUITE (SAMA SEPERTI MODE 8: FADE IN + DOUBLE BLITZ, SEGMEN MELEBAR
// BERTAHAP - TAPI WARNANYA RAINBOW BERGANTI-GANTI, BUKAN PUTIH)
// =========================================================================
struct Custom13SuiteState {
  uint8_t phase = 0; // 0 fade,1 blitzON1,2 blitzOFF1,3 blitzON2,4 blitzOFF2,5 jeda antar tahap,6 jeda akhir
  int fadeStep = 0;
  uint8_t limitIndex = 1; // 1..6
  uint8_t gHue = 0;
  unsigned long lastHueUpdate = 0;
  unsigned long lastUpdate = 0;
  unsigned long nextDelay = 40;
};
Custom13SuiteState c13Suite;

void updateCustom13Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();

  if (now - c13Suite.lastHueUpdate >= getMode210StepDelay(15UL)) {
    c13Suite.gHue++;
    c13Suite.lastHueUpdate = now;
  }

  if (now - c13Suite.lastUpdate < getMode210StepDelay(c13Suite.nextDelay)) {
    return;
  }
  c13Suite.lastUpdate = now;

  CRGB warna = CHSV(c13Suite.gHue, 255, 255);

  int limit = (count * c13Suite.limitIndex) / 6;
  if (limit < 1) limit = 1;
  if (limit > count) limit = count;

  switch (c13Suite.phase) {
    case 0: {
      fill_solid(out1, count, CRGB::Black);
      fill_solid(out2, count, CRGB::Black);
      CRGB c = warna;
      c.nscale8((uint8_t)((c13Suite.fadeStep * 255) / 79));
      for (int j = 0; j < limit; j++) {
        out1[j] = c;
        out2[count - 1 - j] = c;
      }
      c13Suite.nextDelay = 40;
      c13Suite.fadeStep++;
      if (c13Suite.fadeStep >= 80) { c13Suite.fadeStep = 0; c13Suite.phase = 1; c13Suite.nextDelay = 100; }
      break;
    }
    case 1: case 3: {
      fill_solid(out1, count, CRGB::Black);
      fill_solid(out2, count, CRGB::Black);
      for (int j = 0; j < limit; j++) { out1[j] = warna; out2[count - 1 - j] = warna; }
      c13Suite.nextDelay = 35;
      c13Suite.phase = (c13Suite.phase == 1) ? 2 : 4;
      break;
    }
    case 2: {
      fill_solid(out1, count, CRGB::Black);
      fill_solid(out2, count, CRGB::Black);
      c13Suite.nextDelay = 65;
      c13Suite.phase = 3;
      break;
    }
    case 4: {
      fill_solid(out1, count, CRGB::Black);
      fill_solid(out2, count, CRGB::Black);
      c13Suite.nextDelay = 65;
      c13Suite.phase = 5;
      break;
    }
    case 5: {
      c13Suite.nextDelay = 400;
      c13Suite.limitIndex++;
      c13Suite.fadeStep = 0;
      if (c13Suite.limitIndex > 6) { c13Suite.limitIndex = 1; c13Suite.phase = 6; }
      else c13Suite.phase = 0;
      break;
    }
    case 6: {
      fill_solid(out1, count, CRGB::Black);
      fill_solid(out2, count, CRGB::Black);
      c13Suite.nextDelay = 1500;
      c13Suite.phase = 0;
      c13Suite.limitIndex = 1;
      c13Suite.fadeStep = 0;
      break;
    }
  }
}

// =========================================================================
// CUSTOM 14 SUITE (SAMA SEPERTI MODE 13 TAPI PUTIH, MENGALIR ATAS-BAWAH
// BERGANTIAN TIAP SIKLUS, DUA CHANNEL BARENG SEARAH)
// =========================================================================
struct Custom14SuiteState {
  uint8_t phase = 0;
  int fadeStep = 0;
  uint8_t limitIndex = 1;
  bool fromBottom = false;
  unsigned long lastUpdate = 0;
  unsigned long nextDelay = 40;
};
Custom14SuiteState c14Suite;

void updateCustom14Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();

  if (now - c14Suite.lastUpdate < getMode210StepDelay(c14Suite.nextDelay)) {
    return;
  }
  c14Suite.lastUpdate = now;

  CRGB warna = CRGB::White;

  int limit = (count * c14Suite.limitIndex) / 6;
  if (limit < 1) limit = 1;
  if (limit > count) limit = count;

  switch (c14Suite.phase) {
    case 0: {
      fill_solid(out1, count, CRGB::Black);
      fill_solid(out2, count, CRGB::Black);
      CRGB c = warna;
      c.nscale8((uint8_t)((c14Suite.fadeStep * 255) / 79));
      for (int j = 0; j < limit; j++) {
        int idx = c14Suite.fromBottom ? (count - 1 - j) : j;
        out1[idx] = c;
        out2[idx] = c;
      }
      c14Suite.nextDelay = 40;
      c14Suite.fadeStep++;
      if (c14Suite.fadeStep >= 80) { c14Suite.fadeStep = 0; c14Suite.phase = 1; c14Suite.nextDelay = 100; }
      break;
    }
    case 1: case 3: {
      fill_solid(out1, count, CRGB::Black);
      fill_solid(out2, count, CRGB::Black);
      for (int j = 0; j < limit; j++) {
        int idx = c14Suite.fromBottom ? (count - 1 - j) : j;
        out1[idx] = warna; out2[idx] = warna;
      }
      c14Suite.nextDelay = 35;
      c14Suite.phase = (c14Suite.phase == 1) ? 2 : 4;
      break;
    }
    case 2: {
      fill_solid(out1, count, CRGB::Black);
      fill_solid(out2, count, CRGB::Black);
      c14Suite.nextDelay = 65;
      c14Suite.phase = 3;
      break;
    }
    case 4: {
      fill_solid(out1, count, CRGB::Black);
      fill_solid(out2, count, CRGB::Black);
      c14Suite.nextDelay = 65;
      c14Suite.phase = 5;
      break;
    }
    case 5: {
      c14Suite.nextDelay = 400;
      c14Suite.limitIndex++;
      c14Suite.fadeStep = 0;
      if (c14Suite.limitIndex > 6) { c14Suite.limitIndex = 1; c14Suite.phase = 6; }
      else c14Suite.phase = 0;
      break;
    }
    case 6: {
      fill_solid(out1, count, CRGB::Black);
      fill_solid(out2, count, CRGB::Black);
      c14Suite.nextDelay = 1500;
      c14Suite.phase = 0;
      c14Suite.limitIndex = 1;
      c14Suite.fadeStep = 0;
      c14Suite.fromBottom = !c14Suite.fromBottom;
      break;
    }
  }
}

void resetCustom13And14Suites() {
  c13Suite.phase = 0;
  c13Suite.fadeStep = 0;
  c13Suite.limitIndex = 1;
  c13Suite.gHue = 0;
  c13Suite.lastHueUpdate = 0;
  c13Suite.lastUpdate = 0;
  c13Suite.nextDelay = 40;

  c14Suite.phase = 0;
  c14Suite.fadeStep = 0;
  c14Suite.limitIndex = 1;
  c14Suite.fromBottom = false;
  c14Suite.lastUpdate = 0;
  c14Suite.nextDelay = 40;
}

float blockDistanceIntensity(float d, float W) {
  float halfW = W * 0.5f;
  if (d <= halfW) return 1.0f;
  const float TAIL_LEN = 3.5f;
  if (d <= halfW + TAIL_LEN) {
    float tailDist = d - halfW;
    float fade = 1.0f - (tailDist / TAIL_LEN);
    return 0.60f * (fade * fade);
  }
  return 0.0f;
}

CRGB apply_hardware_color(float val, CRGB baseColor, CRGB tailColor) {
  if (val <= 0.001f) return CRGB(0, 0, 0);
  if (val >= 0.70f) {
    return baseColor;
  } else {
    float tFade = val / 0.70f;
    CRGB c = tailColor;
    c.nscale8_video((uint8_t)constrain(tFade * 255.0f, 0.0f, 255.0f));
    return c;
  }
}

// =========================================================================
// CUSTOM 15 SUITE (GRAVITY BOUNCE BALL - PELANGI)
// =========================================================================
void updateCustom15Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  float speedFactor = map(currentSpeed, 0, 100, 2, 35) * 0.1f;
  float t = millis() * 0.001f * speedFactor;
  const float W = 10.0f;

  float cycle = fmodf(t * 2.0f, 2.0f);
  float h = fabsf(sinf(cycle * 3.14159f * 0.5f)) * (count - 1);

  for (uint16_t i = 0; i < count; i++) {
    float val = blockDistanceIntensity(fabsf((float)i - h), W);
    if (val <= 0.001f) {
      out1[i] = CRGB::Black;
      out2[i] = CRGB::Black;
    } else {
      uint8_t hue = (uint8_t)(((float)i / (float)count * 255.0f) + (t * 50.0f));
      CRGB c = CHSV(hue, 255, 255);
      c.nscale8_video((uint8_t)constrain(val * 255.0f, 0.0f, 255.0f));
      out1[i] = c;
      out2[i] = c;
    }
  }
}

// =========================================================================
// CUSTOM 16 SUITE (GRAVITY BOUNCE BALL - PUTIH SOLID)
// =========================================================================
void updateCustom16Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  float speedFactor = map(currentSpeed, 0, 100, 2, 35) * 0.1f;
  float t = millis() * 0.001f * speedFactor;
  const float W = 10.0f;

  float cycle = fmodf(t * 2.0f, 2.0f);
  float h = fabsf(sinf(cycle * 3.14159f * 0.5f)) * (count - 1);

  for (uint16_t i = 0; i < count; i++) {
    float val = blockDistanceIntensity(fabsf((float)i - h), W);
    CRGB c = CRGB::White;
    c.nscale8_video((uint8_t)constrain(val * 255.0f, 0.0f, 255.0f));
    out1[i] = c;
    out2[i] = c;
  }
}

// =========================================================================
// CUSTOM 17 SUITE (GRAVITY BOUNCE BALL - CH1 & CH2 DISAMBUNG JADI SATU STRIP)
// =========================================================================
void updateCustom17Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  float speedFactor = map(currentSpeed, 0, 100, 2, 35) * 0.1f;
  float t = millis() * 0.001f * speedFactor;
  const float W = 10.0f;

  int N_eval = count * 2;
  float cycle = fmodf(t * 2.0f, 2.0f);
  float h = fabsf(sinf(cycle * 3.14159f * 0.5f)) * (N_eval - 1);

  CRGB baseColorCh1 = CRGB(0, 85, 255);
  CRGB tailColorCh1 = CRGB(255, 255, 255);

  for (uint16_t i = 0; i < count; i++) {
    float virtCh1 = (float)(count + i);
    float virtCh2 = (float)i;

    float val1 = blockDistanceIntensity(fabsf(virtCh1 - h), W);
    float val2 = blockDistanceIntensity(fabsf(virtCh2 - h), W);

    out1[i] = apply_hardware_color(val1, baseColorCh1, tailColorCh1);

    if (val2 <= 0.001f) {
      out2[i] = CRGB::Black;
    } else {
      uint8_t hue = (uint8_t)(((float)i / (float)count * 255.0f) + (t * 50.0f));
      CRGB c = CHSV(hue, 255, 255);
      c.nscale8_video((uint8_t)constrain(val2 * 255.0f, 0.0f, 255.0f));
      out2[i] = c;
    }
  }
}

// =========================================================================
// CUSTOM 18 SUITE (ELASTIC SPRING CHASER - CH1 PELANGI FULL-LED, CH2 PUTIH SOLID)
// Konfigurasi Efek #19 (Elastic Spring Chaser) Sesuai Kode yang Anda Berikan:
// BLOCK_LEN = 7, WHITE_RATIO = 0.50f, TAIL_LEN = 3
// CH1: Pelangi Penuh Spektrum (Badan, Kepala & Ekor Otomatis Jadi Pelangi)
// CH2: Putih Solid dengan Kepala & Ekor (atau warna custom K3 jika disimpan)
// =========================================================================
void updateCustom18Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  float speedFactor = map(currentSpeed, 0, 100, 2, 35) * 0.1f;
  float t = millis() * 0.001f * speedFactor;
  const int BLOCK_LEN = 7;
  const int TAIL_LEN = 3;

  float mid = ((float)count - 1.0f) * 0.5f;
  float p = mid + expf(-fmodf(t * 2.0f, 3.0f)) * cosf(t * 14.0f) * (mid * 0.95f);

  CRGB color_ch2 = CRGB(255, 255, 255);
  CRGB color_core_ch2 = CRGB(255, 255, 255);
  CRGB color_tail2 = CRGB(255, 255, 255);

  if (modeOverrides[18].isCustom == 1) {
    color_ch2 = CRGB(modeOverrides[18].r2, modeOverrides[18].g2, modeOverrides[18].b2);
    color_core_ch2 = color_ch2;
    color_tail2 = (modeOverrides[18].tailUnified == 1) ? color_ch2 : CRGB(0, 120, 255);
  }

  for (uint16_t i = 0; i < count; i++) {
    float d = fabsf((float)i - p);
    float val = blockDistanceIntensity(d, (float)BLOCK_LEN);

    // CH1: PELANGI PENUH (Badan, Kepala & Ekor Jadi Spektrum Pelangi):
    CHSV rainbow1 = CHSV((uint8_t)(t * 40.0f + (float)i * 4.0f), 255, 255);
    CRGB ch1_col = (CRGB)rainbow1;
    ch1_col.nscale8_video((uint8_t)(val >= 1.0f ? 255 : (val <= 0.0f ? 0 : (uint8_t)(val * 255.0f))));
    out1[i] = ch1_col;

    // CH2: PUTIH SOLID DENGAN KEPALA & EKOR:
    out2[i] = apply_hardware_color(val, color_ch2, color_tail2);
  }
}

// =========================================================================
// CUSTOM 19 SUITE (CH1 EFEK #210 + PELANGI / CH2 EFEK #1)
// Ditambahkan setelah Mode 18. Mode 18 TIDAK DIUBAH.
// Formula mengikuti kode hardware yang diberikan untuk Mode 19.
// =========================================================================
inline float jsMod19(float a, float b) {
  if (b == 0.0f) return 0.0f;
  float r = fmodf(a, b);
  return r < 0.0f ? r + b : r;
}

inline float blockDistanceIntensity19(float d, float W, int tail = 0) {
  float halfW = W * 0.5f;
  if (d <= halfW * 0.7f) return 1.0f;
  if (d <= halfW) return 1.0f - (d - halfW * 0.7f) / (halfW * 0.3f) * 0.35f;
  if (tail > 0 && d <= halfW + tail) return 0.65f * (1.0f - (d - halfW) / (float)tail);
  return 0.0f;
}

inline CRGB applyHardwareColor19(float val, CRGB baseColor, CRGB coreColor, CRGB tailColor) {
  if (val <= 0.001f) return CRGB(0, 0, 0);
  const float WHITE_RATIO = 1.00f;
  float whiteThreshold = 1.0f - WHITE_RATIO * 0.5f;

  if (val >= whiteThreshold && WHITE_RATIO > 0.01f) {
    float wBlend = (val - whiteThreshold) / (1.0f - whiteThreshold);
    return blend(baseColor, coreColor, (uint8_t)(wBlend * 255.0f));
  } else {
    float fade = val / whiteThreshold;
    CRGB blendedRGB = blend(tailColor, baseColor,
                            (uint8_t)(powf(fade, 0.7f) * 255.0f));
    blendedRGB.nscale8_video((uint8_t)(fade >= 1.0f ? 255 :
                              (fade <= 0.0f ? 0 : (uint8_t)(fade * 255.0f))));
    return blendedRGB;
  }
}

inline float calculateEffect210ForMode19(float t, int i, int ch, int N, int W, int TAIL_LEN) {
  float norm = (N > 1) ? ((float)i / (float)(N - 1)) : 0.0f;
  float centerNorm = fabsf(norm - 0.5f) * 2.0f;
  (void)centerNorm;
  float p1 = jsMod19(t * 22.0f, (float)N);
  float p2 = (float)(N - 1) - jsMod19(t * 22.0f, (float)N);
  float v = sinf(norm * 3.14159265f * 3.0f - t * 4.0f) * 0.4f + 0.3f
          + fmaxf(blockDistanceIntensity19(fabsf(i - p1), 14.0f),
                  blockDistanceIntensity19(fabsf(i - p2), 14.0f)) * 0.6f
          + ((jsMod19(floorf(t * 8.0f), 8.0f) == 0.0f) ? 0.4f : 0.0f);
  return fminf(1.0f, v);
}

inline float calculateEffect1ForMode19(float t, int i, int ch, int N, int W, int TAIL_LEN) {
  float norm = (N > 1) ? ((float)i / (float)(N - 1)) : 0.0f;
  float centerNorm = fabsf(norm - 0.5f) * 2.0f;
  (void)norm; (void)centerNorm; (void)ch; (void)TAIL_LEN;
  float p = jsMod19(t * 22.0f, (float)(N + W)) - W * 0.5f;
  return blockDistanceIntensity19(fabsf(i - p), (float)W, 0);
}

void updateCustom19Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  if (count == 0) return;

  float t = millis() * 0.001f * 1.20f;
  const int BLOCK_LEN = 7;
  const int TAIL_LEN = 3;

  const CRGB color_ch2 = CRGB(255, 255, 255);
  const CRGB color_core_ch2 = CRGB(255, 0, 0);
  const CRGB color_tail = CRGB(255, 255, 255);

  for (uint16_t i = 0; i < count; i++) {
    float val1 = calculateEffect210ForMode19(t, i, 0, count, BLOCK_LEN, TAIL_LEN);
    float val2 = calculateEffect1ForMode19(t, i, 1, count, BLOCK_LEN, TAIL_LEN);

    CHSV rainbow1 = CHSV((uint8_t)(t * 40.0f + (float)i * 4.0f), 255, 255);
    CRGB ch1_col = (CRGB)rainbow1;
    ch1_col.nscale8_video((uint8_t)(val1 >= 1.0f ? 255 :
                           (val1 <= 0.0f ? 0 : (uint8_t)(val1 * 255.0f))));
    out1[i] = ch1_col;

    out2[i] = applyHardwareColor19(val2, color_ch2, color_core_ch2, color_tail);
  }

  clearUnusedChannel(out1);
  clearUnusedChannel(out2);
}

// =========================================================================
// CUSTOM 20 SUITE (COMET WITH EXPONENTIAL DECAY)
// Sesuai konfigurasi:
// BLOCK_LEN = 14, WHITE_RATIO = 1.00f, TAIL_LEN = 0
// CH1: Base CRGB(0, 242, 254), Core CRGB(255, 187, 0), Tail CRGB(0, 0, 255)
// CH2: Base CRGB(255, 0, 128), Core CRGB(255, 0, 0), Tail CRGB(0, 0, 255)
// =========================================================================
inline float jsMod20(float a, float b) {
  if (b == 0.0f) return 0.0f;
  float r = fmodf(a, b);
  return r < 0.0f ? r + b : r;
}

inline CRGB applyHardwareColor20(float val, CRGB baseColor, CRGB coreColor, CRGB tailColor) {
  if (val <= 0.001f) return CRGB(0, 0, 0);

  const float WHITE_RATIO = 1.00f;
  float whiteThreshold = 1.0f - WHITE_RATIO * 0.5f;

  if (val >= whiteThreshold && WHITE_RATIO > 0.01f) {
    float wBlend = (val - whiteThreshold) / (1.0f - whiteThreshold);
    return blend(baseColor, coreColor, (uint8_t)(wBlend * 255.0f));
  } else {
    float fade = val / whiteThreshold;
    CRGB blendedRGB = blend(tailColor, baseColor,
                            (uint8_t)(powf(fade, 0.7f) * 255.0f));
    blendedRGB.nscale8_video(
      (uint8_t)(fade >= 1.0f ? 255 :
                (fade <= 0.0f ? 0 : (uint8_t)(fade * 255.0f)))
    );
    return blendedRGB;
  }
}

inline float calculateEffect10ForMode20(float t, int i, int N, int W) {
  float head = jsMod20(t * 26.0f, (float)(N + 35)) - 10.0f;
  float d = head - (float)i;
  if (d >= -2.0f && d <= (float)W) return 1.0f;
  if (d > (float)W && d < (float)W + 25.0f) return expf(-(d - (float)W) / 8.0f);
  return 0.0f;
}

void updateCustom20Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  if (count == 0) return;

  float speedFactor = map(currentSpeed, 0, 100, 2, 35) * 0.1f;
  float t = millis() * 0.001f * speedFactor;

  const int BLOCK_LEN = 14;

  CRGB color_ch1      = CRGB(0, 242, 254);   // Dasar Kiri
  CRGB color_core_ch1 = CRGB(255, 187, 0);   // Kepala Kiri
  CRGB color_ch2      = CRGB(255, 0, 128);   // Dasar Kanan
  CRGB color_core_ch2 = CRGB(255, 0, 0);     // Kepala Kanan
  CRGB color_tail     = CRGB(0, 0, 255);     // Ekor (Global)

  if (modeOverrides[20].isCustom == 1) {
    color_ch1 = CRGB(modeOverrides[20].r1, modeOverrides[20].g1, modeOverrides[20].b1);
    color_ch2 = CRGB(modeOverrides[20].r2, modeOverrides[20].g2, modeOverrides[20].b2);
  }

  // SAMBUNG BERUNTUN CH1 ➔ CH2 (Total 2x count LED estafet mengalir bersambung):
  int totalN = count * 2;
  for (uint16_t i = 0; i < count; i++) {
    float val1 = calculateEffect10ForMode20(t, i, totalN, BLOCK_LEN);
    float val2 = calculateEffect10ForMode20(t, i + count, totalN, BLOCK_LEN);

    out1[i] = applyHardwareColor20(val1, color_ch1, color_core_ch1, color_tail);
    out2[i] = applyHardwareColor20(val2, color_ch2, color_core_ch2, color_tail);
  }

  clearUnusedChannel(out1);
  clearUnusedChannel(out2);
}
#undef modeOverrides
#undef currentSpeed
#undef MAX_LEDS
// ============================================================================
// END MODE 11-20 SOURCE RECOVERY
// ============================================================================



// ============================================================================
// MODE 21-30 — SOURCE: Salinan(1).ino / preview yang sudah disetujui
// Adaptasi GLOBAL sempit:
// - Semua state mutable berada di CustomNSuiteState.
// - updateCustomNSuite(out1,out2,count), non-blocking.
// - Tidak ada setup()/loop()/delay()/FastLED.show()/clear()/setBrightness().
// - Speed GLOBAL berlaku melalui getMode210StepDelay() untuk 21-27.
// - Mode 28-30 mempertahankan kurva speed live sumber; timer gate tetap non-blocking.
// - K3 warna tetap lewat applyEffectColorOverride() milik GLOBAL (tidak diduplikasi di sini).
// ============================================================================

static inline float m2130Mod(float a, float b) {
  if (b == 0.0f) return 0.0f;
  float r = fmodf(a, b);
  return r < 0.0f ? r + b : r;
}

static inline float m2130Block(float d, float W, int tail = 0) {
  float halfW = W * 0.5f;
  if (d <= halfW * 0.7f) return 1.0f;
  if (d <= halfW) return 1.0f - (d - halfW * 0.7f) / (halfW * 0.3f) * 0.35f;
  if (tail > 0 && d <= halfW + tail) return 0.65f * (1.0f - (d - halfW) / (float)tail);
  return 0.0f;
}

static inline CRGB m2130Color(float val, CRGB baseColor, CRGB coreColor, CRGB tailColor, float whiteRatio = 1.0f) {
  if (val <= 0.001f) return CRGB::Black;
  float whiteThreshold = 1.0f - whiteRatio * 0.5f;
  if (val >= whiteThreshold && whiteRatio > 0.01f) {
    float wBlend = (val - whiteThreshold) / (1.0f - whiteThreshold);
    return blend(baseColor, coreColor, (uint8_t)(wBlend * 255.0f));
  }
  float fade = val / whiteThreshold;
  CRGB c = blend(tailColor, baseColor, (uint8_t)(powf(fade, 0.7f) * 255.0f));
  c.nscale8_video((uint8_t)(fade >= 1.0f ? 255 : (fade <= 0.0f ? 0 : (uint8_t)(fade * 255.0f))));
  return c;
}

struct Custom21SuiteState { unsigned long lastUpdate = 0; unsigned long nextDelay = 15; float virtualMs = 0.0f; };
Custom21SuiteState c21Suite;

void updateCustom21Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c21Suite.lastUpdate != 0 && (now - c21Suite.lastUpdate < getMode210StepDelay(c21Suite.nextDelay))) return;
  c21Suite.lastUpdate = now;
  c21Suite.virtualMs += (float)c21Suite.nextDelay;
  if (c21Suite.virtualMs > 3600000.0f) c21Suite.virtualMs = fmodf(c21Suite.virtualMs, 3600000.0f);
  c21Suite.nextDelay = 15;
  if (count == 0) return;

  const int W = 8, TAIL_LEN = 3;
  const int totalN = count * 2;
  const float t = c21Suite.virtualMs * 0.001f * 1.20f;
  const CRGB color2(8,158,181), core2(15,189,189), tail(9,170,108);
  const float sweep = m2130Mod(t * 20.0f, (float)totalN);

  for (uint16_t i=0; i<count; i++) {
    float val1 = m2130Block(fabsf((float)i - sweep), 20.0f);
    float val2base = m2130Block(fabsf((float)(i + count) - sweep), 20.0f);
    float val2 = 1.0f - val2base;
    (void)W; (void)TAIL_LEN;
    CRGB rainbow = CRGB(CHSV((uint8_t)(t * 40.0f + (float)i * 4.0f),255,255));
    rainbow.nscale8_video((uint8_t)(val1 >= 1.0f ? 255 : (val1 <= 0.0f ? 0 : (uint8_t)(val1 * 255.0f))));
    out1[i] = rainbow;
    out2[i] = m2130Color(val2, color2, core2, tail, 1.0f);
  }
}

struct Custom22SuiteState { unsigned long lastUpdate = 0; unsigned long nextDelay = 15; float virtualMs = 0.0f; };
Custom22SuiteState c22Suite;

void updateCustom22Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c22Suite.lastUpdate != 0 && (now - c22Suite.lastUpdate < getMode210StepDelay(c22Suite.nextDelay))) return;
  c22Suite.lastUpdate = now;
  c22Suite.virtualMs += (float)c22Suite.nextDelay;
  if (c22Suite.virtualMs > 3600000.0f) c22Suite.virtualMs = fmodf(c22Suite.virtualMs, 3600000.0f);
  c22Suite.nextDelay = 15;
  if (count == 0) return;

  const int W=8, TAIL_LEN=3;
  const float t = c22Suite.virtualMs * 0.001f * 1.20f;
  const CRGB color2(143,75,175), core2(173,118,219), tail(178,108,198);
  const float mid = ((float)count - 1.0f) * 0.5f;

  for (uint16_t i=0; i<count; i++) {
    float p = mid + expf(-m2130Mod(t*2.0f,3.0f)) * cosf(t*14.0f) * (mid*0.95f);
    float val1 = m2130Block(fabsf((float)i-p),(float)W,TAIL_LEN);
    float h1 = m2130Mod(t*22.0f,(float)(count+30))-10.0f;
    float h2 = (float)(count-1) - (m2130Mod(t*22.0f,(float)(count+30))-10.0f);
    float val2 = fminf(1.0f, m2130Block(fabsf((float)i-h1),(float)W) + m2130Block(fabsf((float)i-h2),(float)W));
    CRGB rainbow = CRGB(CHSV((uint8_t)(t*40.0f + (float)i*4.0f),255,255));
    rainbow.nscale8_video((uint8_t)(val1 >= 1.0f ? 255 : (val1 <= 0.0f ? 0 : (uint8_t)(val1*255.0f))));
    out1[i]=rainbow;
    out2[i]=m2130Color(val2,color2,core2,tail,1.0f);
  }
}

struct Custom23SuiteState { unsigned long lastUpdate = 0; unsigned long nextDelay = 15; float virtualMs = 0.0f; };
Custom23SuiteState c23Suite;

void updateCustom23Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now=millis();
  if (c23Suite.lastUpdate != 0 && (now-c23Suite.lastUpdate < getMode210StepDelay(c23Suite.nextDelay))) return;
  c23Suite.lastUpdate=now; c23Suite.virtualMs += (float)c23Suite.nextDelay; c23Suite.nextDelay=15;
  if (c23Suite.virtualMs > 3600000.0f) c23Suite.virtualMs=fmodf(c23Suite.virtualMs,3600000.0f);
  if (count==0) return;
  const float t=c23Suite.virtualMs*0.001f*1.20f; const int totalN=count*2;
  const CRGB b1(31,101,65), core1(255,255,255), b2(0,120,255), core2(255,255,255), tail(220,9,9);
  for (uint16_t i=0;i<count;i++) {
    float n1=(float)i/(float)(totalN-1); float n2=(float)(i+count)/(float)(totalN-1);
    float v1=sinf(n1*2.0f-t*2.0f)*0.5f+0.5f; float v2=sinf(n2*2.0f-t*2.0f)*0.5f+0.5f;
    out1[i]=m2130Color(v1,b1,core1,tail,1.0f); out2[i]=m2130Color(v2,b2,core2,tail,1.0f);
  }
}

struct Custom24SuiteState { unsigned long lastUpdate = 0; unsigned long nextDelay = 15; float virtualMs = 0.0f; };
Custom24SuiteState c24Suite;

void updateCustom24Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now=millis();
  if (c24Suite.lastUpdate != 0 && (now-c24Suite.lastUpdate < getMode210StepDelay(c24Suite.nextDelay))) return;
  c24Suite.lastUpdate=now; c24Suite.virtualMs += (float)c24Suite.nextDelay; c24Suite.nextDelay=15;
  if (c24Suite.virtualMs > 3600000.0f) c24Suite.virtualMs=fmodf(c24Suite.virtualMs,3600000.0f);
  if (count==0) return;
  const float t=c24Suite.virtualMs*0.001f*3.00f; const int totalN=count*2, W=8;
  const CRGB b1(227,116,13), core1(216,0,245), b2(0,120,255), core2(117,138,40), tail(220,9,9);
  for (uint16_t i=0;i<count;i++) {
    int vi1=i, vi2=i+count;
    float p1=m2130Mod(t*22.0f,(float)(totalN+W))-W/2.0f;
    float v1=m2130Block(fabsf((float)vi1-p1),(float)W);
    float p2=m2130Mod(t*20.0f,(float)(totalN+30))-15.0f; float d=fabsf((float)vi2-p2);
    float v2=d<14.0f?1.0f:(d<22.0f?cosf(((d-14.0f)/8.0f)*(3.14159265f/2.0f)):0.0f);
    out1[i]=m2130Color(v1,b1,core1,tail,1.0f); out2[i]=m2130Color(v2,b2,core2,tail,1.0f);
  }
}

struct Custom25SuiteState { unsigned long lastUpdate = 0; unsigned long nextDelay = 15; float virtualMs = 0.0f; };
Custom25SuiteState c25Suite;

void updateCustom25Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now=millis();
  if (c25Suite.lastUpdate != 0 && (now-c25Suite.lastUpdate < getMode210StepDelay(c25Suite.nextDelay))) return;
  c25Suite.lastUpdate=now; c25Suite.virtualMs += (float)c25Suite.nextDelay; c25Suite.nextDelay=15;
  if (c25Suite.virtualMs > 3600000.0f) c25Suite.virtualMs=fmodf(c25Suite.virtualMs,3600000.0f);
  if (count==0) return;
  const float t=c25Suite.virtualMs*0.001f*3.00f; const int totalN=count*2, W=8;
  const CRGB b1(227,116,13), core1(216,0,245), b2(0,120,255), core2(117,138,40), tail(220,9,9);
  const float oneRoundT=(float)(totalN+30)/20.0f; uint32_t roundNo=(uint32_t)floorf(t/oneRoundT); bool swapped=(roundNo&1U)!=0U; float localT=fmodf(t,oneRoundT);
  for (uint16_t i=0;i<count;i++) {
    int vi[2]={(int)i,(int)i+(int)count};
    for (uint8_t ch=0;ch<2;ch++) {
      bool use3=(!swapped&&ch==0)||(swapped&&ch==1); float val; CRGB b,core;
      if (use3) { float p=m2130Mod(localT*22.0f,(float)(totalN+W))-W/2.0f; val=m2130Block(fabsf((float)vi[ch]-p),(float)W); b=b1; core=core1; }
      else { float p=m2130Mod(localT*20.0f,(float)(totalN+30))-15.0f; float d=fabsf((float)vi[ch]-p); val=d<14.0f?1.0f:(d<22.0f?cosf(((d-14.0f)/8.0f)*(3.14159265f/2.0f)):0.0f); b=b2; core=core2; }
      (ch==0?out1[i]:out2[i])=m2130Color(val,b,core,tail,1.0f);
    }
  }
}

struct Custom26SuiteState { unsigned long lastUpdate = 0; unsigned long nextDelay = 15; float virtualMs = 0.0f; };
Custom26SuiteState c26Suite;

void updateCustom26Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now=millis();
  if (c26Suite.lastUpdate != 0 && (now-c26Suite.lastUpdate < getMode210StepDelay(c26Suite.nextDelay))) return;
  c26Suite.lastUpdate=now; c26Suite.virtualMs += (float)c26Suite.nextDelay; c26Suite.nextDelay=15;
  if (c26Suite.virtualMs > 3600000.0f) c26Suite.virtualMs=fmodf(c26Suite.virtualMs,3600000.0f);
  if (count==0) return;
  const float t=c26Suite.virtualMs*0.001f*1.20f; const int W=7;
  const CRGB b1(96,18,161), core1(90,21,193), b2(21,193,87), core2(21,193,87), tail(21,193,87);
  for (uint16_t i=0;i<count;i++) {
    float p1=(sinf(t*3.2f)*0.5f+0.5f)*(count-1); float p2=(sinf(t*2.4f)*0.5f+0.5f)*(count-1);
    float v1=m2130Block(fabsf((float)i-p1),(float)W); float v2=m2130Block(fabsf((float)i-p2),(float)W);
    out1[i]=m2130Color(v1,b1,core1,tail,0.50f); out2[i]=m2130Color(v2,b2,core2,tail,0.50f);
  }
}

#define MODE27_GLOBAL_MAX_ROWS ((STAGE0_LED_BUFFER + 4) / 5)
enum Custom27Phase : uint8_t { C27_ON=0, C27_OFF, C27_BLOCK_GAP, C27_MODE_GAP };
struct Custom27SuiteState {
  unsigned long lastUpdate=0; unsigned long nextDelay=10; uint16_t phaseElapsed=0;
  uint16_t rowOrder1[MODE27_GLOBAL_MAX_ROWS]; uint16_t rowOrder2[MODE27_GLOBAL_MAX_ROWS];
  uint8_t modeIndex=0; uint16_t rowCount=0, index1=0, index2=0; bool nextIs1=true;
  Custom27Phase phase=C27_ON; uint8_t flashIndex=0, currentChannel=0; uint16_t currentRow=0;
  bool rainbowBlock=false; CRGB solidColor=CRGB::White; uint8_t rainbowHue=0; uint16_t preparedCount=0; bool initialized=false;
};
Custom27SuiteState c27Suite;
static const uint8_t C27_BLOCK_SIZES[4]={5,8,10,12};

static inline CRGB c27RandomBright(){ return CHSV(random8(),random8(220,255),255); }
static void c27Shuffle(uint16_t *arr,uint16_t n){ if(n<=1)return; for(int i=(int)n-1;i>0;i--){int j=random(i+1);uint16_t t=arr[i];arr[i]=arr[j];arr[j]=t;} }
static bool c27Finished(){ return c27Suite.index1>=c27Suite.rowCount && c27Suite.index2>=c27Suite.rowCount; }
static void c27StartBlock(){
  bool use1=true;
  if(c27Suite.index1>=c27Suite.rowCount) use1=false; else if(c27Suite.index2>=c27Suite.rowCount) use1=true; else use1=c27Suite.nextIs1;
  if(use1){ c27Suite.currentChannel=0; c27Suite.currentRow=c27Suite.rowOrder1[c27Suite.index1++]; c27Suite.nextIs1=false; }
  else { c27Suite.currentChannel=1; c27Suite.currentRow=c27Suite.rowOrder2[c27Suite.index2++]; c27Suite.nextIs1=true; }
  c27Suite.rainbowBlock=(random(100)<25); c27Suite.solidColor=c27RandomBright(); c27Suite.rainbowHue=random8(); c27Suite.flashIndex=0; c27Suite.phase=C27_ON; c27Suite.phaseElapsed=0;
}
static void c27Prepare(uint16_t count){
  uint8_t bs=C27_BLOCK_SIZES[c27Suite.modeIndex]; c27Suite.rowCount=(count+bs-1)/bs; if(c27Suite.rowCount<1)c27Suite.rowCount=1; if(c27Suite.rowCount>MODE27_GLOBAL_MAX_ROWS)c27Suite.rowCount=MODE27_GLOBAL_MAX_ROWS;
  for(uint16_t i=0;i<c27Suite.rowCount;i++){c27Suite.rowOrder1[i]=i;c27Suite.rowOrder2[i]=i;} c27Shuffle(c27Suite.rowOrder1,c27Suite.rowCount);c27Shuffle(c27Suite.rowOrder2,c27Suite.rowCount);
  c27Suite.index1=0;c27Suite.index2=0;c27Suite.nextIs1=random(2);c27Suite.preparedCount=count;c27Suite.initialized=true;c27StartBlock();
}
static void c27Draw(CRGB *dst,uint16_t count,uint16_t row,uint8_t bs,bool rainbow,CRGB solid,uint8_t hue){
  uint32_t start=(uint32_t)row*bs,end=start+bs;if(end>count)end=count;if(start>=count||end<=start)return;uint16_t sz=(uint16_t)(end-start);
  if(!rainbow){for(uint32_t i=start;i<end;i++)dst[i]=solid;return;} uint8_t hs=(uint8_t)(255/(sz?sz:1));for(uint16_t i=0;i<sz;i++)dst[start+i]=CHSV(hue+i*hs,255,255);
}
void updateCustom27Suite(CRGB *out1,CRGB *out2,uint16_t count){
  unsigned long now=millis();
  if(c27Suite.lastUpdate!=0 && (now-c27Suite.lastUpdate<getMode210StepDelay(c27Suite.nextDelay)))return;
  c27Suite.lastUpdate=now;c27Suite.nextDelay=10;if(count==0)return;
  if(!c27Suite.initialized||c27Suite.preparedCount!=count){c27Suite.modeIndex=0;c27Prepare(count);}
  else {
    c27Suite.phaseElapsed += 10;
    for(uint8_t guard=0;guard<12;guard++){
      uint16_t need=(c27Suite.phase==C27_ON)?50:(c27Suite.phase==C27_OFF)?50:(c27Suite.phase==C27_BLOCK_GAP)?100:150;
      if(c27Suite.phaseElapsed<need)break;c27Suite.phaseElapsed-=need;
      if(c27Suite.phase==C27_ON)c27Suite.phase=C27_OFF;
      else if(c27Suite.phase==C27_OFF){if(c27Suite.flashIndex<2){c27Suite.flashIndex++;c27Suite.phase=C27_ON;}else c27Suite.phase=C27_BLOCK_GAP;}
      else if(c27Suite.phase==C27_BLOCK_GAP){
        if(c27Finished()) c27Suite.phase=C27_MODE_GAP;
        else { uint16_t remain=c27Suite.phaseElapsed; c27StartBlock(); c27Suite.phaseElapsed=remain; }
      }
      else { uint16_t remain=c27Suite.phaseElapsed; c27Suite.modeIndex=(c27Suite.modeIndex+1)&3U; c27Prepare(count); c27Suite.phaseElapsed=remain; }
    }
  }
  fill_solid(out1,count,CRGB::Black);fill_solid(out2,count,CRGB::Black);
  if(c27Suite.phase==C27_ON){uint8_t bs=C27_BLOCK_SIZES[c27Suite.modeIndex];c27Draw(c27Suite.currentChannel==0?out1:out2,count,c27Suite.currentRow,bs,c27Suite.rainbowBlock,c27Suite.solidColor,c27Suite.rainbowHue);}
}

struct Custom28SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=1; float progress1=0.0f,progress2=0.0f; };
Custom28SuiteState c28Suite;
static void c28RenderOne(CRGB *out,uint16_t count,float progress,uint8_t ch){
  int cycle=(int)floorf(progress);float local=progress-(float)cycle;bool reverse=(((cycle/3)&1)!=0);float phase=local;if(ch){phase+=0.5f;if(phase>=1.0f)phase-=1.0f;}float p=reverse?(1.0f-phase):phase;
  const CRGB c1[3]={CRGB(255,40,145),CRGB(0,210,255),CRGB(255,180,0)};const CRGB c2[3]={CRGB(255,255,255),CRGB(70,120,255),CRGB(80,255,80)};CRGB base=(ch?c2:c1)[cycle%3];
  float visualT=progress/0.22f;bool gateOn=(((unsigned long)floorf(visualT*10.0f))%4UL)<2UL;float gate=gateOn?1.0f:0.10f;
  for(uint16_t i=0;i<count;i++){float x=count>1?(float)i/(float)(count-1):0.0f;float d=fabsf(x-p);if(d>0.5f)d=1.0f-d;float scan=d<0.10f?1.0f-d/0.10f:0.0f;int block=(int)floorf(x*10.0f);if(block>9)block=9;int active=(int)floorf(p*10.0f);if(active>9)active=9;float blk=block==active?gate:0.0f;float val=fmaxf(scan*0.80f,blk);if(val<=0.001f)out[i]=CRGB::Black;else{CRGB c=base;c.nscale8_video((uint8_t)constrain(val*255.0f,0.0f,255.0f));out[i]=c;}}
}
void updateCustom28Suite(CRGB *out1,CRGB *out2,uint16_t count){
  unsigned long now=millis();if(c28Suite.lastUpdate!=0 && (now-c28Suite.lastUpdate<getMode210StepDelay(c28Suite.nextDelay)))return;unsigned long dt=c28Suite.lastUpdate?now-c28Suite.lastUpdate:0;c28Suite.lastUpdate=now;c28Suite.nextDelay=1;if(dt>200)dt=200;
  float rate=0.0484f+(float)appSpeed*0.00396f;c28Suite.progress1+=(float)dt*0.001f*rate;c28Suite.progress2+=(float)dt*0.001f*rate;while(c28Suite.progress1>=66.0f)c28Suite.progress1-=66.0f;while(c28Suite.progress2>=66.0f)c28Suite.progress2-=66.0f;c28RenderOne(out1,count,c28Suite.progress1,0);c28RenderOne(out2,count,c28Suite.progress2,1);
}

static inline float c2930Clamp(float v){return v<0?0:(v>1?1:v);} static inline float c2930Wrap(float v){v=fmodf(v,1.0f);if(v<0)v+=1.0f;return v;} static inline CRGB c2930HSV(float h){return CRGB(CHSV((uint8_t)(c2930Wrap(h)*255.0f),255,255));}
struct Custom29SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=1; float t1=0.0f,t2=0.0f; };
Custom29SuiteState c29Suite;
void updateCustom29Suite(CRGB *out1,CRGB *out2,uint16_t count){
  unsigned long now=millis();if(c29Suite.lastUpdate!=0 && (now-c29Suite.lastUpdate<getMode210StepDelay(c29Suite.nextDelay)))return;unsigned long dt=c29Suite.lastUpdate?now-c29Suite.lastUpdate:0;c29Suite.lastUpdate=now;c29Suite.nextDelay=1;if(dt>200)dt=200;float rate=0.22f+(float)appSpeed*0.018f;c29Suite.t1+=(float)dt*0.001f*rate;c29Suite.t2+=(float)dt*0.001f*rate;if(c29Suite.t1>3600)c29Suite.t1=fmodf(c29Suite.t1,3600);if(c29Suite.t2>3600)c29Suite.t2=fmodf(c29Suite.t2,3600);
  float ts[2]={c29Suite.t1,c29Suite.t2};CRGB* outs[2]={out1,out2};for(uint8_t ch=0;ch<2;ch++){float t=ts[ch],center=sinf(t*1.5f+(ch?3.14159265f:0.0f))*0.5f+0.5f,width=0.08f+0.22f*(sinf(t*0.7f)*0.5f+0.5f),blitz=((int)floorf(m2130Mod(t,1.8f)*12.0f)<3)?1.0f:0.35f;for(uint16_t i=0;i<count;i++){float x=count>1?(float)i/(float)(count-1):0.0f;float body=c2930Clamp(1.0f-fabsf(x-center)/width),val=body*blitz;CRGB c=c2930HSV(x*0.9f+t*0.08f+(ch?0.16f:0.0f));c.nscale8_video((uint8_t)constrain(val*255.0f,0.0f,255.0f));outs[ch][i]=val<=0.001f?CRGB::Black:c;}}
}

struct Custom30SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=1; float t1=0.0f,t2=0.0f; };
Custom30SuiteState c30Suite;
void updateCustom30Suite(CRGB *out1,CRGB *out2,uint16_t count){
  unsigned long now=millis();if(c30Suite.lastUpdate!=0 && (now-c30Suite.lastUpdate<getMode210StepDelay(c30Suite.nextDelay)))return;unsigned long dt=c30Suite.lastUpdate?now-c30Suite.lastUpdate:0;c30Suite.lastUpdate=now;c30Suite.nextDelay=1;if(dt>200)dt=200;float rate=0.22f+(float)appSpeed*0.018f;c30Suite.t1+=(float)dt*0.001f*rate;c30Suite.t2+=(float)dt*0.001f*rate;if(c30Suite.t1>3600)c30Suite.t1=fmodf(c30Suite.t1,3600);if(c30Suite.t2>3600)c30Suite.t2=fmodf(c30Suite.t2,3600);
  float ts[2]={c30Suite.t1,c30Suite.t2};CRGB* outs[2]={out1,out2};for(uint8_t ch=0;ch<2;ch++){float t=ts[ch],p=sinf(t*1.6f+(ch?0.8f:0.0f))*0.5f+0.5f;for(uint16_t i=0;i<count;i++){float x=count>1?(float)i/(float)(count-1):0.0f,d=fabsf(x-p),core=expf(-d*45.0f);CRGB c=ch?CRGB(255,0,120):c2930HSV(x+t*0.08f);c.nscale8_video((uint8_t)constrain(core*255.0f,0.0f,255.0f));outs[ch][i]=core<=0.001f?CRGB::Black:c;}}
}

// ============================================================================
// END MODE 21-30
// ============================================================================


// ============================================================================
// MODE 31-40 — SOURCE: HTML preview 31-40 yang disetujui
// Mapping output ditangani GLOBAL: Mode 31-40 memakai dua output langsung pada CH1 dan CH3.
// Adaptasi GLOBAL:
// - Semua state mutable efek ada di CustomNSuiteState.
// - updateCustomNSuite(out1,out2,count), non-blocking.
// - Tidak ada setup()/loop()/delay()/FastLED.show()/FastLED.clear()/FastLED.setBrightness().
// - Speed GLOBAL berlaku lewat getMode210StepDelay(cNSuite.nextDelay).
// - K3 warna tetap diterapkan oleh k3SafeShow()/applyEffectColorOverride() GLOBAL.
// ============================================================================
static inline float m3140Clamp(float v, float a=0.0f, float b=1.0f) {
  if (v < a) return a; if (v > b) return b; return v;
}
static inline float m3140Wrap01(float v) {
  v = fmodf(v, 1.0f); if (v < 0.0f) v += 1.0f; return v;
}
static inline float m3140Wrap(float v, float n) {
  if (n <= 0.0f) return 0.0f; v = fmodf(v, n); if (v < 0.0f) v += n; return v;
}
static inline float m3140CyclicDist(float a, float b) {
  float d = fabsf(a-b); d = fmodf(d,1.0f); if (d > 0.5f) d = 1.0f-d; return d;
}
static inline float m3140Gauss(float d, float w) {
  if (w <= 0.000001f) return 0.0f; return expf(-(d*d)/(2.0f*w*w));
}
static inline float m3140Block(float d, float w) {
  if (w <= 0.000001f) return 0.0f; return m3140Clamp(1.0f-d/w);
}
static inline CRGB m3140Scale(CRGB c, float k) {
  k=m3140Clamp(k); if (k <= 0.001f) return CRGB::Black;
  c.nscale8_video((uint8_t)(k*255.0f)); return c;
}
static inline CRGB m3140Add(CRGB a, CRGB b) {
  uint16_t r=(uint16_t)a.r+b.r, g=(uint16_t)a.g+b.g, bl=(uint16_t)a.b+b.b;
  return CRGB((uint8_t)(r>255?255:r),(uint8_t)(g>255?255:g),(uint8_t)(bl>255?255:bl));
}
static inline CRGB m3140HSV01(float h) {
  h=m3140Wrap01(h); return CRGB(CHSV((uint8_t)(h*255.0f),255,255));
}
static inline CRGB m3140HSVDeg(float deg) {
  deg=fmodf(deg,360.0f); if(deg<0.0f) deg+=360.0f;
  return CRGB(CHSV((uint8_t)(deg*(255.0f/360.0f)),242,255));
}

// MODE 31 — ALIS VARIO & RING PROJIE / Rainbow Shift
// Sumber user diadaptasi SESMPIT mungkin ke GLOBAL firmware:
// - jalur kiri  virtual: CH1 -> CH3
// - jalur kanan virtual: CH2 -> CH4
// - 8 fase, start fase 4, AUTO_NEXT_TICK = 160 seperti source
// - frame source 5 ms tetap memakai speed GLOBAL via getMode210StepDelay(5)
// - brightness tetap brightness GLOBAL; tidak ada FastLED.setBrightness/show/delay di sini
struct Custom31SuiteState {
  unsigned long lastUpdate = 0;
  unsigned long nextDelay = 5;
  uint8_t phase = 4;
  int pos = 0;
  int8_t dir = 1;
  uint32_t globalStep = 0;
  uint32_t phaseTick = 0;
};
Custom31SuiteState c31Suite;

static inline CRGB m31DynamicColor(int i, int totalPerSide, uint32_t step) {
  if (totalPerSide <= 0) return CRGB::Black;
  const uint32_t timeShift = step * 3UL;
  const uint16_t posFactor = (uint16_t)(((uint32_t)i * 255UL) / (uint32_t)totalPerSide);
  const uint8_t hue = (uint8_t)((posFactor * 2U + timeShift) & 0xFFU);
  CRGB rgb;
  hsv2rgb_rainbow(CHSV(hue, 255, 128), rgb);
  return rgb;
}

static inline CRGB* m31VirtualPixel(CRGB *first, CRGB *second, uint16_t count, int idx) {
  if (idx < 0 || idx >= (int)count * 2) return nullptr;
  if (idx < (int)count) return first ? &first[idx] : nullptr;
  return second ? &second[idx - (int)count] : nullptr;
}

static inline void m31SetVirtual(CRGB *first, CRGB *second, uint16_t count, int idx, const CRGB &c) {
  CRGB *p = m31VirtualPixel(first, second, count, idx);
  if (p) *p = c;
}

static inline void m31OrVirtual(CRGB *first, CRGB *second, uint16_t count, int idx, const CRGB &c) {
  CRGB *p = m31VirtualPixel(first, second, count, idx);
  if (p) *p |= c;
}

static bool m31BeginFrame() {
  const unsigned long now = millis();
  if (c31Suite.lastUpdate != 0 &&
      (unsigned long)(now - c31Suite.lastUpdate) < getMode210StepDelay(c31Suite.nextDelay)) return false;
  c31Suite.lastUpdate = now;
  c31Suite.nextDelay = 5; // frameDelay source, tetap diskalakan speed GLOBAL

  c31Suite.phaseTick++;
  if (c31Suite.phaseTick > 160UL) {
    c31Suite.phase = (uint8_t)((c31Suite.phase % 8U) + 1U);
    c31Suite.pos = 0;
    c31Suite.dir = 1;
    c31Suite.globalStep = 0;
    c31Suite.phaseTick = 0;
  }
  return true;
}

static void m31RenderFrame(CRGB *ch1, CRGB *ch2, CRGB *ch3, CRGB *ch4, uint16_t count) {
  if (count == 0) return;
  const int total = (int)count * 2;
  if (total <= 0) return;

  // bufL/bufR source selalu dibersihkan setiap frame.
  if (ch1) fill_solid(ch1, count, CRGB::Black);
  if (ch2) fill_solid(ch2, count, CRGB::Black);
  if (ch3) fill_solid(ch3, count, CRGB::Black);
  if (ch4) fill_solid(ch4, count, CRGB::Black);

  switch (c31Suite.phase) {
    case 1: {
      const int size = 40;
      for (int j = 0; j < size; j++) {
        const int idx = (c31Suite.pos - j + total) % total;
        const fract8 fade = (fract8)(255 - (j * 255 / size));
        CRGB cL = m31DynamicColor(idx, total, c31Suite.globalStep);
        CRGB cR = m31DynamicColor(idx, total, c31Suite.globalStep + 15UL);
        cL.nscale8(fade); cR.nscale8(fade);
        m31SetVirtual(ch1, ch3, count, idx, cL);
        m31SetVirtual(ch2, ch4, count, idx, cR);
      }
      c31Suite.pos = (c31Suite.pos + 1) % total;
      break;
    }

    case 2: {
      const int trail = 50;
      for (int k = 0; k < 2; k++) {
        const int headPos = (c31Suite.pos + k * (total / 2)) % total;
        for (int j = 0; j < trail; j++) {
          const int idx = (headPos - j + total) % total;
          const fract8 dim = (fract8)(255 - (j * 255 / trail));
          CRGB cL = m31DynamicColor(idx, total, c31Suite.globalStep);
          CRGB cR = m31DynamicColor(idx, total, c31Suite.globalStep + 15UL);
          cL.nscale8(dim); cR.nscale8(dim);
          m31OrVirtual(ch1, ch3, count, idx, cL);
          m31OrVirtual(ch2, ch4, count, idx, cR);
        }
      }
      c31Suite.pos = (c31Suite.pos + 1) % total;
      break;
    }

    case 3: {
      const int width = 35;
      for (int j = 0; j < width; j++) {
        const int idx = (c31Suite.pos + (c31Suite.dir == 1 ? -j : j) + total) % total;
        const fract8 fade = sin8((uint8_t)((j * 255) / width));
        CRGB cL = m31DynamicColor(idx, total, c31Suite.globalStep);
        CRGB cR = m31DynamicColor(idx, total, c31Suite.globalStep + 15UL);
        cL.nscale8(fade); cR.nscale8(fade);
        m31SetVirtual(ch1, ch3, count, idx, cL);
        m31SetVirtual(ch2, ch4, count, idx, cR);
      }
      c31Suite.pos += c31Suite.dir * 2;
      if (c31Suite.pos >= total) { c31Suite.pos = total - 1; c31Suite.dir = -1; }
      else if (c31Suite.pos < 0) { c31Suite.pos = 0; c31Suite.dir = 1; }
      break;
    }

    case 4: {
      const int sweepLen = 50;
      const int head = c31Suite.pos % (total + sweepLen);
      for (int j = 0; j < sweepLen; j++) {
        const int idx = head - j;
        if (idx >= 0 && idx < total) {
          const fract8 fade = sin8((uint8_t)((j * 255) / sweepLen));
          CRGB cL = m31DynamicColor(idx, total, c31Suite.globalStep);
          CRGB cR = m31DynamicColor(idx, total, c31Suite.globalStep + 15UL);
          cL.nscale8(fade); cR.nscale8(fade);
          m31SetVirtual(ch1, ch3, count, idx, cL);
          m31SetVirtual(ch2, ch4, count, idx, cR);
        }
      }
      c31Suite.pos++;
      if (c31Suite.pos > total + sweepLen) c31Suite.pos = 0;
      break;
    }

    case 5: {
      for (int i = 0; i < total; i++) {
        const uint8_t wave = (uint8_t)((sin8((uint8_t)(c31Suite.globalStep * 6UL + (uint32_t)i * 4UL)) + 1U) / 2U);
        CRGB cL = m31DynamicColor(i, total, c31Suite.globalStep);
        CRGB cR = m31DynamicColor(i, total, c31Suite.globalStep + 15UL);
        cL.nscale8(wave); cR.nscale8(wave);
        m31SetVirtual(ch1, ch3, count, i, cL);
        m31SetVirtual(ch2, ch4, count, i, cR);
      }
      c31Suite.pos++;
      break;
    }

    case 6: {
      const int center = total / 2;
      const int half = total / 2;
      const int span = (half > 0) ? (c31Suite.pos % half) : 0;
      const int idx1 = (center + span + total) % total;
      const int idx2 = (center - span + total) % total;
      for (int j = 0; j < 20; j++) {
        const fract8 fade = (fract8)(255 - (j * 255 / 20));
        const int i1 = (idx1 - j + total) % total;
        const int i2 = (idx2 + j + total) % total;
        CRGB cL1 = m31DynamicColor(i1, total, c31Suite.globalStep);
        CRGB cL2 = m31DynamicColor(i2, total, c31Suite.globalStep);
        cL1.nscale8(fade); cL2.nscale8(fade);
        m31SetVirtual(ch1, ch3, count, i1, cL1);
        m31SetVirtual(ch1, ch3, count, i2, cL2);
        // Source asli fase 6 memakai warna kiri juga untuk sisi kanan.
        m31SetVirtual(ch2, ch4, count, i1, cL1);
        m31SetVirtual(ch2, ch4, count, i2, cL2);
      }
      c31Suite.pos++;
      if (c31Suite.pos > half) c31Suite.pos = 0;
      break;
    }

    case 7: {
      const int p1 = c31Suite.pos % total;
      const int p2 = (c31Suite.pos * 2) % total;
      for (int j = 0; j < 25; j++) {
        const fract8 fade = sin8((uint8_t)((j * 255) / 25));
        const int i1 = (p1 - j + total) % total;
        const int i2 = (p2 - j + total) % total;
        CRGB cL1 = m31DynamicColor(i1, total, c31Suite.globalStep);
        CRGB cL2 = m31DynamicColor(i2, total, c31Suite.globalStep + 30UL);
        cL1.nscale8(fade); cL2.nscale8(fade);
        m31SetVirtual(ch1, ch3, count, i1, cL1);
        m31SetVirtual(ch2, ch4, count, i2, cL2);
      }
      c31Suite.pos++;
      break;
    }

    case 8:
    default: {
      const uint8_t breath = (uint8_t)((sin8((uint8_t)(c31Suite.globalStep * 4UL)) + 1U) / 2U);
      const uint8_t scale = (uint8_t)(scale8(breath, 210) + 45U);
      for (int i = 0; i < total; i++) {
        CRGB cL = m31DynamicColor(i, total, c31Suite.globalStep);
        CRGB cR = m31DynamicColor(i, total, c31Suite.globalStep + 15UL);
        cL.nscale8(scale); cR.nscale8(scale);
        m31SetVirtual(ch1, ch3, count, i, cL);
        m31SetVirtual(ch2, ch4, count, i, cR);
      }
      break;
    }
  }

  c31Suite.globalStep++;
}

// Renderer 4CH persis layout source: CH1->CH3 dan CH2->CH4.
static void updateCustom31Suite4(CRGB *ch1, CRGB *ch2, CRGB *ch3, CRGB *ch4, uint16_t count) {
  if (!m31BeginFrame()) return;
  m31RenderFrame(ch1, ch2, ch3, ch4, count);
}

// Fallback untuk jalur GLOBAL independen/pair. Tidak mengubah arsitektur mode lain.
// Saat keempat channel sama-sama Mode 31, GLOBAL memakai updateCustom31Suite4 di bawah.
void updateCustom31Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  if (!m31BeginFrame()) return;
  m31RenderFrame(out1, out2, nullptr, nullptr, count);
}

struct Custom32SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom32SuiteState c32Suite;
void updateCustom32Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c32Suite.lastUpdate != 0 && (now - c32Suite.lastUpdate < getMode210StepDelay(c32Suite.nextDelay))) return;
  c32Suite.lastUpdate = now;
  c32Suite.nextDelay = 25; c32Suite.t += 0.025f; if(c32Suite.t>3600.0f)c32Suite.t=fmodf(c32Suite.t,3600.0f);
  float t=c32Suite.t;
  for(uint8_t ch=0;ch<2;ch++){
    float A=m3140Wrap01(t*0.52f+(ch?0.25f:0.0f)), B=4.0f*A*(1.0f-A), C=ch?(1.0f-B):B;
    CRGB *out=ch?out2:out1;
    for(uint16_t i=0;i<count;i++){
      float x=count>1?(float)i/(float)(count-1):0.0f;
      float ball=expf(-fabsf(x-C)*35.0f), ghost=expf(-fabsf(x-(1.0f-C))*30.0f)*0.30f;
      CRGB p=m3140HSV01(t*0.12f+x*0.5f+(ch?0.20f:0.0f));
      out[i]=m3140Add(m3140Scale(p,ball),m3140Scale(CRGB::White,ghost));
    }
  }
}

struct Custom33SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom33SuiteState c33Suite;
void updateCustom33Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c33Suite.lastUpdate != 0 && (now - c33Suite.lastUpdate < getMode210StepDelay(c33Suite.nextDelay))) return;
  c33Suite.lastUpdate = now;
  c33Suite.nextDelay = 25; c33Suite.t += 0.025f; if(c33Suite.t>3600.0f)c33Suite.t=fmodf(c33Suite.t,3600.0f);
  float t=c33Suite.t; static const float widths[4]={0.05f,0.08f,0.10f,0.12f};
  for(uint8_t ch=0;ch<2;ch++){
    bool swap=(((int)floorf(t/2.2f)&1)!=0), reverse=((ch!=0)!=swap); float dir=reverse?-1.0f:1.0f;
    float A=m3140Wrap01(t*0.32f*dir), B=widths[((int)floorf(t/1.2f))&3];
    float C=m3140Wrap01(floorf(t*2.4f)*0.173f+(ch?0.41f:0.0f)); bool flag=((int)floorf(t*12.0f)%6)<3;
    CRGB *out=ch?out2:out1; CRGB base=ch?CRGB(255,80,20):CRGB(40,180,255);
    for(uint16_t i=0;i<count;i++){
      float x=count>1?(float)i/(float)(count-1):0.0f;
      float run=expf(-m3140CyclicDist(x,A)*32.0f), blk=(m3140CyclicDist(x,C)<B*0.5f&&flag)?1.0f:0.0f;
      out[i]=m3140Scale(base,fmaxf(run,blk));
    }
  }
}

struct Custom34SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom34SuiteState c34Suite;
void updateCustom34Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c34Suite.lastUpdate != 0 && (now - c34Suite.lastUpdate < getMode210StepDelay(c34Suite.nextDelay))) return;
  c34Suite.lastUpdate = now;
  c34Suite.nextDelay = 25; c34Suite.t += 0.025f; if(c34Suite.t>3600.0f)c34Suite.t=fmodf(c34Suite.t,3600.0f);
  float t=c34Suite.t, dir=(((int)floorf(t/2.4f)&1)!=0)?1.0f:-1.0f, A=m3140Wrap01(t*0.28f*dir); bool flag=((int)floorf(t*8.0f)%8)<2;
  for(uint16_t i=0;i<count;i++){
    float x=count>1?(float)i/(float)(count-1):0.0f, flow=expf(-m3140CyclicDist(x,A)*20.0f), burst=(flag&&fabsf(x-0.5f)<0.20f)?1.0f:0.0f;
    CRGB c=m3140Scale(CRGB::White,fmaxf(flow*0.80f,burst)); out1[i]=c; out2[i]=c;
  }
}

struct Custom35SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom35SuiteState c35Suite;
void updateCustom35Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c35Suite.lastUpdate != 0 && (now - c35Suite.lastUpdate < getMode210StepDelay(c35Suite.nextDelay))) return;
  c35Suite.lastUpdate = now;
  c35Suite.nextDelay = 25; c35Suite.t += 0.025f; if(c35Suite.t>3600.0f)c35Suite.t=fmodf(c35Suite.t,3600.0f);
  float t=c35Suite.t, A=sinf(t*1.25f)*0.38f+0.5f, B=1.0f-A;
  for(uint8_t ch=0;ch<2;ch++){
    float ta=ch?B:A,tb=ch?A:B; CRGB *out=ch?out2:out1;
    for(uint16_t i=0;i<count;i++){
      float x=count>1?(float)i/(float)(count-1):0.0f, a=expf(-fabsf(x-ta)*20.0f), b=expf(-fabsf(x-tb)*20.0f)*0.55f;
      CRGB c1=m3140HSV01(x+t*0.10f+(ch?0.18f:0.0f)), c2=m3140HSV01(1.0f-x+t*0.07f+0.5f);
      out[i]=m3140Add(m3140Scale(c1,a),m3140Scale(c2,b));
    }
  }
}

struct Custom36SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom36SuiteState c36Suite;
void updateCustom36Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c36Suite.lastUpdate != 0 && (now - c36Suite.lastUpdate < getMode210StepDelay(c36Suite.nextDelay))) return;
  c36Suite.lastUpdate = now;
  c36Suite.nextDelay = 25; c36Suite.t += 0.025f; if(c36Suite.t>3600.0f)c36Suite.t=fmodf(c36Suite.t,3600.0f);
  float t=c36Suite.t, A=m3140Wrap01(t*0.25f), B=A<0.5f?A*2.0f:2.0f-A*2.0f;
  for(uint8_t ch=0;ch<2;ch++){
    CRGB *out=ch?out2:out1;
    for(uint16_t i=0;i<count;i++){
      float x=count>1?(float)i/(float)(count-1):0.0f, u=((ch?1.0f:0.0f)+x)*0.5f, d=fabsf(u-B);
      float core=expf(-d*60.0f), tail=expf(-fmaxf(0.0f,u-B)*18.0f)*0.50f;
      CRGB p=m3140HSV01(u+t*0.08f);
      out[i]=m3140Add(m3140Scale(p,core),m3140Scale(CRGB(255,150,20),tail));
    }
  }
}

struct Custom37SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom37SuiteState c37Suite;
void updateCustom37Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c37Suite.lastUpdate != 0 && (now - c37Suite.lastUpdate < getMode210StepDelay(c37Suite.nextDelay))) return;
  c37Suite.lastUpdate = now;
  c37Suite.nextDelay = 25; c37Suite.t += 0.025f; if(c37Suite.t>3600.0f)c37Suite.t=fmodf(c37Suite.t,3600.0f);
  float t=c37Suite.t, N=(float)count, W=fmaxf(4.0f,N/10.0f);
  for(uint8_t ch=0;ch<2;ch++){
    CRGB *out=ch?out2:out1; int kk=(int)floorf(t*3.0f)%6; float p=m3140Wrap((float)kk*W*1.35f+(ch?W*0.6f:0.0f),N);
    bool flash=((int)floorf(t*12.0f)%6)<3 && m3140Wrap(t*6.0f,1.0f)>0.68f; float breath=0.35f+0.65f*(sinf(t*2.4f)*0.5f+0.5f);
    for(uint16_t i=0;i<count;i++){
      float vv=m3140Block(fabsf((float)i-p),W*0.7f), v=m3140Clamp(fmaxf(vv,flash?0.9f:0.0f)*breath), h=45.0f+(float)i*3.0f+t*20.0f;
      out[i]=m3140Scale(m3140HSVDeg(h),v);
    }
  }
}

struct Custom38SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom38SuiteState c38Suite;
void updateCustom38Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c38Suite.lastUpdate != 0 && (now - c38Suite.lastUpdate < getMode210StepDelay(c38Suite.nextDelay))) return;
  c38Suite.lastUpdate = now;
  c38Suite.nextDelay = 25; c38Suite.t += 0.025f; if(c38Suite.t>3600.0f)c38Suite.t=fmodf(c38Suite.t,3600.0f);
  float t=c38Suite.t,N=(float)count,C=(N-1.0f)*0.5f,W=fmaxf(4.0f,N/10.0f),p=m3140Wrap(t*18.0f,N+W)-W*0.5f,q=N-1.0f-p,ss=fmaxf(0.0f,sinf(t*3.5f));
  for(uint8_t ch=0;ch<2;ch++){CRGB *out=ch?out2:out1;for(uint16_t i=0;i<count;i++){
    float meteor=fmaxf(m3140Gauss((float)i-p,W*0.55f),m3140Gauss((float)i-q,W*0.55f));
    float collision=m3140Gauss((float)i-C,W*1.2f)*powf(ss,8.0f),v=m3140Clamp(meteor+collision),h=(float)i*5.0f+t*80.0f+(ch?90.0f:0.0f);
    out[i]=m3140Scale(m3140HSVDeg(h),v);
  }}
}

struct Custom39SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom39SuiteState c39Suite;
void updateCustom39Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c39Suite.lastUpdate != 0 && (now - c39Suite.lastUpdate < getMode210StepDelay(c39Suite.nextDelay))) return;
  c39Suite.lastUpdate = now;
  c39Suite.nextDelay = 25; c39Suite.t += 0.025f; if(c39Suite.t>3600.0f)c39Suite.t=fmodf(c39Suite.t,3600.0f);
  float t=c39Suite.t,N=(float)count,C=(N-1.0f)*0.5f,W=fmaxf(4.0f,N/10.0f),r=(sinf(t*2.2f)*0.5f+0.5f)*C; bool flash=((int)floorf(t*8.0f)%8)<2;
  for(uint8_t ch=0;ch<2;ch++){CRGB *out=ch?out2:out1;for(uint16_t i=0;i<count;i++){
    float ring=m3140Block(fabsf(fabsf((float)i-C)-r),W*0.45f),v=fmaxf(ring,flash?0.8f:0.0f),h=35.0f+(ch?190.0f:0.0f)+t*30.0f;
    out[i]=m3140Scale(m3140HSVDeg(h),v);
  }}
}

struct Custom40SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom40SuiteState c40Suite;
void updateCustom40Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c40Suite.lastUpdate != 0 && (now - c40Suite.lastUpdate < getMode210StepDelay(c40Suite.nextDelay))) return;
  c40Suite.lastUpdate = now;
  c40Suite.nextDelay = 25; c40Suite.t += 0.025f; if(c40Suite.t>3600.0f)c40Suite.t=fmodf(c40Suite.t,3600.0f);
  float t=c40Suite.t,N=(float)count,W=fmaxf(4.0f,N/10.0f); bool pulse=((int)floorf(t*10.0f)%20)==0;
  for(uint8_t ch=0;ch<2;ch++){CRGB *out=ch?out2:out1;for(uint16_t i=0;i<count;i++){
    float vv=0.0f; for(int kk=0;kk<4;kk++){float p=m3140Wrap(t*20.0f-(float)kk*N/4.0f+(ch?(float)kk*4.0f:0.0f)+N*8.0f,N);vv=fmaxf(vv,m3140Gauss((float)i-p,W*0.42f));}
    if(pulse)vv+=0.8f; float v=m3140Clamp(vv),h=t*70.0f+(float)i*2.0f+(ch?120.0f:0.0f); out[i]=m3140Scale(m3140HSVDeg(h),v);
  }}
}
// ============================================================================
// END MODE 31-40
// ============================================================================


// ============================================================================
// MODE 41-50 — FROM APPROVED HTML PREVIEW
// Mapping GLOBAL saat semua 4CH memakai mode yang sama: CH1=CH3, CH2=CH4.
// Timing semua mode mengikuti speed GLOBAL melalui getMode210StepDelay().
// ============================================================================
static inline uint8_t m4150Hash8(uint32_t frame, uint16_t i, uint8_t ch, uint8_t salt) {
  uint32_t x = frame;
  x ^= (uint32_t)i * 0x045d9f3bUL;
  x ^= (uint32_t)(ch + 1U) * 0x27d4eb2dUL;
  x ^= (uint32_t)(salt + 11U) * 0x165667b1UL;
  x ^= x >> 16;
  x *= 0x7feb352dUL;
  x ^= x >> 15;
  x *= 0x846ca68bUL;
  x ^= x >> 16;
  return (uint8_t)(x & 0xFFU);
}

struct Custom41SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom41SuiteState c41Suite;
void updateCustom41Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c41Suite.lastUpdate != 0 && (now - c41Suite.lastUpdate < getMode210StepDelay(c41Suite.nextDelay))) return;
  c41Suite.lastUpdate = now;
  c41Suite.nextDelay = 25; c41Suite.t += 0.025f; if (c41Suite.t > 3600.0f) c41Suite.t = fmodf(c41Suite.t, 3600.0f);
  if (count == 0) return;
  float t=c41Suite.t, N=(float)count, W=fmaxf(4.0f,N/10.0f); bool pulse=((int)floorf(t*10.0f)%20)==0;
  for(uint8_t ch=0; ch<2; ch++) { CRGB *out=ch?out2:out1; for(uint16_t i=0;i<count;i++) {
    float vv=0.0f;
    for(int k=0;k<4;k++) { float p=m3140Wrap(t*20.0f-(float)k*N/4.0f+(ch?(float)k*4.0f:0.0f)+N*8.0f,N); vv=fmaxf(vv,m3140Gauss((float)i-p,W*0.42f)); }
    if(pulse) vv += 0.8f;
    float v=m3140Clamp(vv), h=t*70.0f+(float)i*2.0f+(ch?120.0f:0.0f);
    out[i]=m3140Scale(m3140HSVDeg(h),v);
  }}
}

struct Custom42SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom42SuiteState c42Suite;
void updateCustom42Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c42Suite.lastUpdate != 0 && (now - c42Suite.lastUpdate < getMode210StepDelay(c42Suite.nextDelay))) return;
  c42Suite.lastUpdate = now;
  c42Suite.nextDelay = 25; c42Suite.t += 0.025f; if (c42Suite.t > 3600.0f) c42Suite.t = fmodf(c42Suite.t, 3600.0f);
  if (count == 0) return;
  float t=c42Suite.t, N=(float)count, C=(N-1.0f)*0.5f, W=fmaxf(4.0f,N/10.0f);
  float p=C+sinf(t*2.5f)*cosf(t*0.72f)*C*0.95f;
  float ph=m3140Wrap(t*1.5f,4.0f);
  float e=C+expf(-ph)*cosf(t*13.0f)*C*0.8f;
  for(uint8_t ch=0; ch<2; ch++) { CRGB *out=ch?out2:out1; for(uint16_t i=0;i<count;i++) {
    float v=fmaxf(m3140Block(fabsf((float)i-p),W),m3140Block(fabsf((float)i-e),W*0.7f));
    float h=195.0f+sinf(t)*90.0f+(ch?60.0f:0.0f);
    out[i]=m3140Scale(m3140HSVDeg(h),v);
  }}
}

struct Custom43SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom43SuiteState c43Suite;
void updateCustom43Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c43Suite.lastUpdate != 0 && (now - c43Suite.lastUpdate < getMode210StepDelay(c43Suite.nextDelay))) return;
  c43Suite.lastUpdate = now;
  c43Suite.nextDelay = 25; c43Suite.t += 0.025f; if (c43Suite.t > 3600.0f) c43Suite.t = fmodf(c43Suite.t, 3600.0f);
  if (count == 0) return;
  float t=c43Suite.t, N=(float)count, C=(N-1.0f)*0.5f, W=fmaxf(4.0f,N/10.0f);
  float r=m3140Wrap(t*16.0f,C+W);
  if (((int)floorf(t*0.65f)&1)!=0) r=C-m3140Wrap(r,fmaxf(C,1.0f));
  float head=m3140Wrap(t*22.0f,N);
  uint32_t frame=(uint32_t)floorf(t*60.0f);
  for(uint8_t ch=0; ch<2; ch++) { CRGB *out=ch?out2:out1; for(uint16_t i=0;i<count;i++) {
    float ring=m3140Block(fabsf(fabsf((float)i-C)-r),W*0.6f);
    float sp=(fabsf((float)i-head)<W*2.0f && m4150Hash8(frame,i,ch,43)>224U)?0.9f:0.0f;
    float v=fmaxf(ring,sp), h=20.0f+(float)i*4.0f+t*55.0f;
    out[i]=m3140Scale(m3140HSVDeg(h),v);
  }}
}

struct Custom44SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom44SuiteState c44Suite;
void updateCustom44Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c44Suite.lastUpdate != 0 && (now - c44Suite.lastUpdate < getMode210StepDelay(c44Suite.nextDelay))) return;
  c44Suite.lastUpdate = now;
  c44Suite.nextDelay = 25; c44Suite.t += 0.025f; if (c44Suite.t > 3600.0f) c44Suite.t = fmodf(c44Suite.t, 3600.0f);
  if (count == 0) return;
  float t=c44Suite.t, N=(float)count, C=(N-1.0f)*0.5f, W=fmaxf(4.0f,N/10.0f);
  float size=W+(sinf(t*2.6f)*0.5f+0.5f)*(C-W), sw=C+sinf(t*3.1f)*C*0.9f;
  for(uint8_t ch=0; ch<2; ch++) { CRGB *out=ch?out2:out1; for(uint16_t i=0;i<count;i++) {
    float ed=fabsf((float)i-C);
    float ap=ed<size?1.0f:m3140Gauss(ed-size,W*0.6f);
    float v=m3140Clamp(ap*0.6f+m3140Block(fabsf((float)i-sw),W*1.1f)*0.6f);
    float h=275.0f+sinf(t*1.5f)*80.0f+(ch?55.0f:0.0f);
    out[i]=m3140Scale(m3140HSVDeg(h),v);
  }}
}

struct Custom45SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom45SuiteState c45Suite;
void updateCustom45Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c45Suite.lastUpdate != 0 && (now - c45Suite.lastUpdate < getMode210StepDelay(c45Suite.nextDelay))) return;
  c45Suite.lastUpdate = now;
  c45Suite.nextDelay = 25; c45Suite.t += 0.025f; if (c45Suite.t > 3600.0f) c45Suite.t = fmodf(c45Suite.t, 3600.0f);
  if (count == 0) return;
  float t=c45Suite.t, N=(float)count, W=fmaxf(4.0f,N/10.0f);
  for(uint8_t ch=0; ch<2; ch++) {
    float p,q;
    if(ch==0){p=(sinf(t*3.2f)*0.5f+0.5f)*(N-1.0f);q=m3140Wrap(t*13.0f,N);}
    else {p=(sinf(t*2.35f+1.2f)*0.5f+0.5f)*(N-1.0f);q=(N-1.0f)-m3140Wrap(t*17.0f,N);}
    CRGB *out=ch?out2:out1;
    for(uint16_t i=0;i<count;i++) {
      float v=fmaxf(m3140Block(fabsf((float)i-p),W*0.7f),m3140Gauss((float)i-q,W*0.55f));
      float h=ch?130.0f:275.0f;
      out[i]=m3140Scale(m3140HSVDeg(h),v);
    }
  }
}

struct Custom46SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom46SuiteState c46Suite;
void updateCustom46Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c46Suite.lastUpdate != 0 && (now - c46Suite.lastUpdate < getMode210StepDelay(c46Suite.nextDelay))) return;
  c46Suite.lastUpdate = now;
  c46Suite.nextDelay = 25; c46Suite.t += 0.025f; if (c46Suite.t > 3600.0f) c46Suite.t = fmodf(c46Suite.t, 3600.0f);
  if (count == 0) return;
  static const uint8_t segList[4]={5,8,10,12};
  float t=c46Suite.t; uint8_t seg=segList[((int)floorf(t*0.8f))&3]; int32_t ep=(int32_t)floorf(t*4.0f); bool st=((int)floorf(t*12.0f)%3)<2;
  for(uint8_t ch=0; ch<2; ch++) {
    int32_t start=(int32_t)(((uint32_t)ep*37UL+(uint32_t)ch*71UL)%count); start-=start%seg;
    float h=(float)floorf(t*4.0f)*47.0f+(ch?90.0f:0.0f); CRGB *out=ch?out2:out1;
    for(uint16_t i=0;i<count;i++) { bool inb=((int32_t)i>=start && (int32_t)i<(int32_t)fminf((float)count,(float)(start+seg))); out[i]=m3140Scale(m3140HSVDeg(h),(inb&&st)?1.0f:0.0f); }
  }
}

struct Custom47SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom47SuiteState c47Suite;
void updateCustom47Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c47Suite.lastUpdate != 0 && (now - c47Suite.lastUpdate < getMode210StepDelay(c47Suite.nextDelay))) return;
  c47Suite.lastUpdate = now;
  c47Suite.nextDelay = 25; c47Suite.t += 0.025f; if (c47Suite.t > 3600.0f) c47Suite.t = fmodf(c47Suite.t, 3600.0f);
  if (count == 0) return;
  static const uint8_t segList[4]={5,8,10,12};
  float t=c47Suite.t, N=(float)count, C=(N-1.0f)*0.5f, W=fmaxf(4.0f,N/10.0f); int stage=(int)floorf(t/2.8f)%4; uint32_t frame=(uint32_t)floorf(t*60.0f);
  for(uint8_t ch=0; ch<2; ch++) { CRGB *out=ch?out2:out1; for(uint16_t i=0;i<count;i++) {
    float v=0.0f;
    if(stage==0){float p=m3140Wrap(t*22.0f,N);v=fmaxf(m3140Gauss((float)i-p,W*0.5f),m3140Gauss((float)i-(N-1.0f-p),W*0.5f));}
    else if(stage==1){float p=m3140Wrap(t*18.0f,N+W)-W*0.5f,q=N-1.0f-p;v=m3140Clamp(fmaxf(m3140Block(fabsf((float)i-p),W),m3140Block(fabsf((float)i-q),W))+m3140Gauss((float)i-C,W)*0.5f);}
    else if(stage==2){float p=m3140Wrap(t*20.0f,N);float sp=(fabsf((float)i-p)<W*2.0f&&m4150Hash8(frame,i,ch,47)>214U)?0.8f:0.0f;v=m3140Clamp(m3140Block(fabsf((float)i-p),W*0.8f)+sp);}
    else {uint8_t seg=segList[((int)floorf(t*1.2f))&3];int32_t ep=(int32_t)floorf(t*5.0f);int32_t start=(int32_t)(((uint32_t)ep*29UL+(uint32_t)ch*41UL)%count);start-=start%seg;v=((int32_t)i>=start&&(int32_t)i<start+seg&&((int)floorf(t*14.0f)%3)<2)?1.0f:0.0f;}
    float h=t*90.0f+(float)i*3.0f+(ch?80.0f:0.0f); out[i]=m3140Scale(m3140HSVDeg(h),v);
  }}
}

struct Custom48SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom48SuiteState c48Suite;
void updateCustom48Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c48Suite.lastUpdate != 0 && (now - c48Suite.lastUpdate < getMode210StepDelay(c48Suite.nextDelay))) return;
  c48Suite.lastUpdate = now;
  c48Suite.nextDelay = 25; c48Suite.t += 0.025f; if (c48Suite.t > 3600.0f) c48Suite.t = fmodf(c48Suite.t, 3600.0f);
  if (count == 0) return;
  float t=c48Suite.t, C=((float)count-1.0f)*0.5f; int ph=(int)floorf(t*2.4f)%4; bool flash=(ph==1||ph==3)&&(((int)floorf(t*12.0f)%2)==0);
  for(uint8_t ch=0; ch<2; ch++) { CRGB *out=ch?out2:out1; for(uint16_t i=0;i<count;i++) {
    bool left=(float)i<C, red=ph<2?left:!left; CRGB c=red?CRGB(255,0,0):CRGB(0,70,255); out[i]=m3140Scale(c,flash?1.0f:0.85f);
  }}
}

struct Custom49SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom49SuiteState c49Suite;
void updateCustom49Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c49Suite.lastUpdate != 0 && (now - c49Suite.lastUpdate < getMode210StepDelay(c49Suite.nextDelay))) return;
  c49Suite.lastUpdate = now;
  c49Suite.nextDelay = 25; c49Suite.t += 0.025f; if (c49Suite.t > 3600.0f) c49Suite.t = fmodf(c49Suite.t, 3600.0f);
  if (count == 0) return;
  float t=c49Suite.t, N=(float)count, W=fmaxf(4.0f,N/10.0f); int32_t step=(int32_t)floorf(t*13.0f), cy=step%18, grp=step/18; float base=(float)grp*W*2.0f, off=cy<12?(float)cy:(float)(24-cy), p=m3140Wrap(base+off*W/3.0f,N);
  for(uint8_t ch=0; ch<2; ch++) { CRGB *out=ch?out2:out1; for(uint16_t i=0;i<count;i++) out[i]=m3140Scale(CRGB::White,m3140Block(fabsf((float)i-p),W*0.7f)); }
}

struct Custom50SuiteState { unsigned long lastUpdate=0; unsigned long nextDelay=25; float t=0.0f; };
Custom50SuiteState c50Suite;
void updateCustom50Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c50Suite.lastUpdate != 0 && (now - c50Suite.lastUpdate < getMode210StepDelay(c50Suite.nextDelay))) return;
  c50Suite.lastUpdate = now;
  c50Suite.nextDelay = 25; c50Suite.t += 0.025f; if (c50Suite.t > 3600.0f) c50Suite.t = fmodf(c50Suite.t, 3600.0f);
  if (count == 0) return;
  float t=c50Suite.t, N=(float)count, W=fmaxf(4.0f,N/10.0f); int st=(int)floorf(t/1.8f)%4;
  for(uint8_t ch=0; ch<2; ch++) { CRGB *out=ch?out2:out1; for(uint16_t i=0;i<count;i++) {
    float v=0.0f; CRGB c=CRGB::Black;
    if(st==0){v=((int)floorf(t*12.0f)%2)==0?1.0f:0.0f;c=CRGB(255,0,0);}
    else if(st==1){v=((int)floorf(t*12.0f)%2)==0?1.0f:0.0f;c=CRGB(0,70,255);}
    else if(st==2){float p=m3140Wrap(t*20.0f,N);v=m3140Block(fabsf((float)i-p),W*0.8f);c=CRGB::White;}
    out[i]=m3140Scale(c,v);
  }}
}
// ============================================================================
// END MODE 41-50
// ============================================================================


// ============================================================================
// MODE 51-60 — SOURCE: "10 Efek Revisi Variatif"
// Mapping GLOBAL umum Mode 52-60: CH1=CH3 (virtual A), CH2=CH4 (virtual B).
// KHUSUS MODE 51: jalur 4CH menyambung CH1 -> CH3 -> CH4 -> CH2,
// lalu arah balik CH2 -> CH4 -> CH3 -> CH1; 1 fase x 5 pengulangan / 5 warna.
// Speed GLOBAL tetap melalui getMode210StepDelay(); khusus Mode 51-60
// frame delay tercepat dibatasi 10 ms agar tidak membebani BLE/4CH.
// ============================================================================
static inline float m5160Clamp(float v, float a=0.0f, float b=1.0f) {
  if (v < a) return a; if (v > b) return b; return v;
}
static inline float m5160Gauss(float d, float w) {
  if (w <= 0.0001f) return 0.0f;
  return expf(-(d*d)/(2.0f*w*w));
}
static inline CRGB m5160Scale(CRGB c, float v) {
  v = m5160Clamp(v);
  if (v <= 0.001f) return CRGB::Black;
  c.nscale8_video((uint8_t)(v*255.0f));
  return c;
}
static inline CRGB m5160Color3(int n) {
  int k=n%3; if(k<0)k+=3;
  if(k==0)return CRGB(255,255,255);
  if(k==1)return CRGB(255,0,0);
  return CRGB(0,80,255);
}
static inline unsigned long m5160GlobalStep10(unsigned long baseMs) {
  unsigned long d = getMode210StepDelay(baseMs);
  return (d < 10UL) ? 10UL : d;
}

// MODE 51 approved HTML: satu fase yang sama diulang 5x.
// Urutan maju  : CH1 -> CH3 -> CH4 -> CH2.
// Urutan balik : CH2 -> CH4 -> CH3 -> CH1.
// Setiap pengulangan memakai warna berikutnya (total 5 warna).
static const CRGB m51RepeatColors[5] = {
  CRGB(255,40,40), CRGB(0,170,255), CRGB(0,255,110),
  CRGB(185,60,255), CRGB(255,150,0)
};

static inline void m51MaxBlend(CRGB &dst, CRGB src) {
  if (src.r > dst.r) dst.r = src.r;
  if (src.g > dst.g) dst.g = src.g;
  if (src.b > dst.b) dst.b = src.b;
}

static void renderCustom51All4Frame(CRGB *ch1, CRGB *ch2, CRGB *ch3, CRGB *ch4, uint16_t count, float t) {
  if (!ch1 || !ch2 || !ch3 || !ch4 || count == 0) return;
  fill_solid(ch1, count, CRGB::Black);
  fill_solid(ch2, count, CRGB::Black);
  fill_solid(ch3, count, CRGB::Black);
  fill_solid(ch4, count, CRGB::Black);

  const float repeatLen = 2.6f;
  int repeat = ((int)floorf(t / repeatLen)) % 5;
  if (repeat < 0) repeat += 5;
  float local = fmodf(t, repeatLen); if (local < 0.0f) local += repeatLen;
  const float u = local / repeatLen;
  const bool forward = ((repeat & 1) == 0);
  const int total = (int)count * 4;
  const float headF = forward ? (u * (float)(total - 1)) : ((1.0f - u) * (float)(total - 1));
  const int head = (int)lroundf(headF);
  int block = (int)lroundf((float)count * 0.085f); if (block < 5) block = 5;
  int tail = (int)lroundf((float)count * 0.06f); if (tail < 4) tail = 4;
  const int dir = forward ? 1 : -1;
  CRGB *order[4] = { ch1, ch3, ch4, ch2 };
  const CRGB color = m51RepeatColors[repeat];

  for (int j = 0; j < block + tail; ++j) {
    const int vp = head - dir * j;
    if (vp < 0 || vp >= total) continue;
    const int seg = vp / (int)count;
    const int idx = vp % (int)count;
    float intensity = 1.0f;
    if (j >= block) intensity = 1.0f - ((float)(j - block + 1) / (float)(tail + 1));
    m51MaxBlend(order[seg][idx], m5160Scale(color, intensity));
  }
}

static void renderCustom51to60Core(uint8_t mode, CRGB *out1, CRGB *out2, uint16_t count, float t) {
  if (!out1 || !out2 || count==0 || mode<51 || mode>60) return;
  const float N=(float)count;
  const float W=fmaxf(4.0f,N/12.0f);
  const float C=(N-1.0f)*0.5f;
  const float PI_F=3.14159265358979323846f;
  static const CRGB progressivePalette[10]={
    CRGB(255,0,0),CRGB(0,90,255),CRGB(255,255,255),CRGB(170,0,255),CRGB(0,255,120),
    CRGB(255,40,140),CRGB(0,220,255),CRGB(255,220,0),CRGB(120,255,0),CRGB(255,100,40)
  };
  static const CRGB swapPairs[3][2]={
    {CRGB(255,255,255),CRGB(255,0,0)},
    {CRGB(0,90,255),CRGB(255,255,255)},
    {CRGB(255,0,0),CRGB(0,90,255)}
  };

  for(uint8_t ch=0;ch<2;ch++) {
    CRGB *out = ch ? out2 : out1;
    for(uint16_t i=0;i<count;i++) {
      float v=0.0f; CRGB color=CRGB::Black;

      if(mode==51) { // Fallback 2-output untuk Mode 51 approved (jalur ALL4 ditangani service khusus)
        const float repeatLen=2.6f; int repeat=((int)floorf(t/repeatLen))%5; if(repeat<0)repeat+=5;
        float local=fmodf(t,repeatLen);if(local<0)local+=repeatLen;float u=local/repeatLen;bool forward=((repeat&1)==0);
        int total=(int)count*2;float head=forward?(u*(float)(total-1)):((1.0f-u)*(float)(total-1));int block=(int)lroundf(N*0.085f);if(block<5)block=5;int tail=(int)lroundf(N*0.06f);if(tail<4)tail=4;
        int virt=(ch==0)?(int)i:((int)count+(int)i);int dir=forward?1:-1;v=0.0f;
        for(int j=0;j<block+tail;j++){int vp=(int)lroundf(head)-dir*j;if(vp!=virt)continue;float q=(j<block)?1.0f:(1.0f-((float)(j-block+1)/(float)(tail+1)));if(q>v)v=q;}
        color=m51RepeatColors[repeat];
      }
      else if(mode==52) { // Orbit Gates 3-Color
        const float cycleLen=4.0f; int cyc=(int)floorf(t/cycleLen); float u=fmodf(t,cycleLen)/cycleLen;
        float spread=(0.12f+0.25f*(0.5f-0.5f*cosf(u*PI_F*2.0f)))*N;
        float drift=sinf(u*PI_F*2.0f)*N*0.11f;
        float centers[4]={C-spread+drift*0.65f,C-spread*0.35f-drift*0.65f,C+spread*0.35f+drift*0.65f,C+spread-drift*0.65f};
        for(int k=0;k<4;k++){float ring=fabsf((float)i-centers[k]);float gate=1.0f-fabsf(ring-W*0.75f)/(W*0.28f);if(gate<0)gate=0;if(gate>v)v=gate;}
        float pulse=0.72f+0.28f*sinf(u*PI_F*4.0f); v=m5160Clamp(v*pulse); color=m5160Color3(cyc);
      }
      else if(mode==53) { // APPROVED HTML: 8 fase efek baru
        const float phaseLen=1.55f;
        int p=((int)floorf(t/phaseLen))%8;if(p<0)p+=8;
        float local=fmodf(t,phaseLen);if(local<0)local+=phaseLen;float u=local/phaseLen;
        CRGB baseA=(ch==0)?CRGB(0,190,255):CRGB(255,45,120);
        CRGB baseB=(ch==0)?CRGB(255,220,0):CRGB(80,255,120);
        if(p==0){ // center -> edges widening bar
          float half=u*N*0.5f,d=fabsf((float)i-C);v=(d<=half)?1.0f:m5160Gauss(d-half,W*0.22f);color=baseA;
        } else if(p==1){ // edges -> center collapse
          float edge=fminf((float)i,(N-1.0f)-(float)i),lim=u*N*0.5f;v=(edge>=lim)?1.0f:m5160Gauss(edge-lim,W*0.20f);color=baseB;
        } else if(p==2){ // alternating 5-block pulse
          int seg=(int)lroundf(N/10.0f);if(seg<4)seg=4;int idx=(int)i/seg;int pulse=((int)floorf(u*8.0f))%2;v=(((idx+pulse)&1)==0)?1.0f:0.08f;color=(ch==0)?CRGB(255,255,255):CRGB(0,100,255);
        } else if(p==3){ // opposing snakes
          float a=u*(N-1.0f),b=(1.0f-u)*(N-1.0f);v=fmaxf(m5160Gauss((float)i-a,W*0.34f),m5160Gauss((float)i-b,W*0.34f));color=(ch==0)?CRGB(180,50,255):CRGB(255,130,0);
        } else if(p==4){ // double end fill
          float reach=u*N*0.5f;v=(((float)i<reach)||((float)i>(N-1.0f-reach)))?1.0f:0.0f;color=(ch==0)?CRGB(0,255,130):CRGB(255,40,40);
        } else if(p==5){ // moving dark hole through lit strip
          float h=u*(N-1.0f),hole=m5160Gauss((float)i-h,W*0.55f);v=1.0f-hole;color=(ch==0)?CRGB(255,255,255):CRGB(255,0,160);
        } else if(p==6){ // collision flash
          float a=u*C,b=(N-1.0f)-u*C,va=m5160Gauss((float)i-a,W*0.36f),vb=m5160Gauss((float)i-b,W*0.36f);v=fmaxf(va,vb);if(u>0.82f)v=fmaxf(v,m5160Gauss((float)i-C,W*(0.25f+(u-0.82f)*4.0f)));color=(ch==0)?CRGB(0,170,255):CRGB(255,210,0);
        } else { // 3-pulse full finale
          int pulse=(int)floorf(u*6.0f);v=((pulse&1)==0)?1.0f:0.0f;int pi=((int)floorf(u*3.0f)+(int)ch*2)%10;color=progressivePalette[pi];
        }
      }
      else if(mode==54) { // Segment Domino Collapse
        int seg=(int)roundf(N/12.0f);if(seg<4)seg=4;int segCount=(int)ceilf(N/(float)seg);if(segCount<1)segCount=1;
        float cyc=fmodf(t,5.2f);int idx=(int)i/seg;
        if(cyc<2.6f){int onCount=(int)floorf((cyc/2.6f)*((float)segCount+1.0f));v=(idx<onCount)?1.0f:0.0f;}
        else {float q=(cyc-2.6f)/2.6f;float denom=(float)segCount*0.5f;if(denom<0.5f)denom=0.5f;float dist=fabsf(((float)idx+0.5f)-(float)segCount*0.5f)/denom;v=(dist>q)?1.0f:0.0f;}
        float edge=(((int)i%seg)<2)?0.35f:1.0f;v*=edge;color=CRGB(235,245,255);
      }
      else if(mode==55) { // Staircase 3-Color Cycle
        int seg=(int)roundf(N/8.0f);if(seg<5)seg=5;int segCount=(int)ceilf(N/(float)seg);if(segCount<1)segCount=1;
        const float fullLen=5.0f;int cyc=(int)floorf(t/fullLen);float localTime=fmodf(t,fullLen)/fullLen;int phase=(int)floorf(localTime*(float)segCount*2.0f);int idx=(int)i/seg;
        if(phase<segCount)v=(idx<=phase)?1.0f:0.0f;else v=(idx<=(segCount*2-1-phase))?1.0f:0.0f;color=m5160Color3(cyc);
      }
      else if(mode==56) { // Twin Portal Warp
        float cycle=fmodf(t,5.0f),u=cycle/5.0f;float p1=N*(0.22f+0.18f*sinf(t*0.8f));float p2=N*(0.78f+0.14f*cosf(t*0.7f));
        float rad=(0.5f-0.5f*cosf(u*PI_F*2.0f))*N*0.18f;float r1=fabsf(fabsf((float)i-p1)-rad),r2=fabsf(fabsf((float)i-p2)-rad*0.8f);
        v=fmaxf(m5160Gauss(r1,W*0.22f),m5160Gauss(r2,W*0.22f));float flick=0.72f+0.28f*sinf(t*9.0f+(float)i*0.05f);v=m5160Clamp(v*flick);
        color=(ch==0)?CRGB(180,235,255):CRGB(255,255,255);
      }
      else if(mode==57) { // Comet Pair Offset
        float rate=11.0f+5.0f*sinf(t*0.8f);float p=fmodf(t*rate,N);if(p<0)p+=N;float q=fmodf(p+N*0.32f,N);if(q<0)q+=N;
        v=fmaxf(m5160Gauss((float)i-p,W*0.5f),m5160Gauss((float)i-q,W*0.5f));color=CRGB(255,255,255);
      }
      else if(mode==58) { // Broken Rail Runner
        int seg=(int)roundf(N/16.0f);if(seg<4)seg=4;int idx=(int)i/seg;int shift=(int)floorf(t*5.0f);int local=(int)i%seg;int pattern=(idx+shift)%6;if(pattern<0)pattern+=6;
        bool on=(pattern==0||pattern==1||pattern==4);float pulse=0.55f+0.45f*(sinf(t*5.0f+(float)idx*0.8f)*0.5f+0.5f);float edge=(local==0||local==seg-1)?0.35f:1.0f;
        v=on?pulse*edge:0.0f;color=CRGB(245,245,255);
      }
      else if(mode==59) { // Swap Islands
        const float cycleLen=4.0f;int cyc=(int)floorf(t/cycleLen);int pairIdx=cyc%3;if(pairIdx<0)pairIdx+=3;int swap=cyc%2;if(swap<0)swap+=2;int colorSide=(ch+swap)%2;color=swapPairs[pairIdx][colorSide];
        float centers[4]={N*0.16f,N*0.38f,N*0.62f,N*0.84f};float localTime=fmodf(t,cycleLen)/cycleLen;
        for(int k=0;k<4;k++){float pulse=0.15f+0.85f*(sinf(localTime*PI_F*2.0f+(float)k*1.35f+(float)ch*0.8f)*0.5f+0.5f);float island=m5160Gauss((float)i-centers[k],W*0.72f)*pulse;if(island>v)v=island;}
      }
      else { // Mode 60 Magnetic Cluster
        float u=sinf(t*1.25f)*0.5f+0.5f;float center=N*(0.25f+0.5f*(sinf(t*0.37f)*0.5f+0.5f));float starts[5]={N*0.08f,N*0.27f,N*0.48f,N*0.69f,N*0.91f};
        for(int k=0;k<5;k++){float repel=((float)k-2.0f)*N*0.045f*sinf(t*2.1f);float p=starts[k]*(1.0f-u)+center*u+repel;float cluster=m5160Gauss((float)i-p,W*0.42f);if(cluster>v)v=cluster;}
        color=(ch==0)?CRGB(255,255,255):CRGB(120,190,255);
      }
      out[i]=m5160Scale(color,v);
    }
  }
}
// ============================================================================
// FIX13C SAFE SIZE STAGE2 — SHARED MODE CLOCK/SCHEDULER 51..140
// Hanya scheduler identik yang disatukan. Semua renderer/rumus efek tetap dari FIX11A.
// ============================================================================
__attribute__((noinline))
static bool sharedModeClockTick(
  float &t,
  unsigned long &lastUpdate,
  unsigned long &lastCall,
  unsigned long &nextDelay,
  unsigned long &dtMs,
  bool *freshOut
) {
  unsigned long now = millis();
  bool fresh = false;
  if (lastCall == 0 || (unsigned long)(now - lastCall) > 250UL) {
    t = 0.0f;
    lastUpdate = 0;
    fresh = true;
  }
  lastCall = now;
  unsigned long stepDelay = m5160GlobalStep10(nextDelay);
  if (lastUpdate != 0 && (unsigned long)(now - lastUpdate) < stepDelay) {
    if (freshOut) *freshOut = fresh;
    return false;
  }
  dtMs = (lastUpdate == 0) ? 0UL : (unsigned long)(now - lastUpdate);
  lastUpdate = now;
  nextDelay = 25;
  if (dtMs > 200UL) dtMs = 200UL;
  t += ((float)dtMs * 0.001f) * liveSpeedFactor;
  if (t > 7200.0f) t = fmodf(t, 7200.0f);
  if (freshOut) *freshOut = fresh;
  return true;
}

struct Custom51SuiteState { unsigned long lastUpdate=0; unsigned long lastCall=0; unsigned long nextDelay=25; float t=0.0f; };
Custom51SuiteState c51Suite;
void updateCustom51Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c51Suite.t, c51Suite.lastUpdate, c51Suite.lastCall, c51Suite.nextDelay, dtMs, nullptr)) return;
  renderCustom51to60Core(51, out1, out2, count, c51Suite.t);
}

static void updateCustom51SuiteAll4(CRGB *ch1, CRGB *ch2, CRGB *ch3, CRGB *ch4, uint16_t count) {
  unsigned long now = millis();
  if (c51Suite.lastCall == 0 || (unsigned long)(now - c51Suite.lastCall) > 250UL) { c51Suite.t = 0.0f; c51Suite.lastUpdate = 0; }
  c51Suite.lastCall = now;
  unsigned long stepDelay = m5160GlobalStep10(c51Suite.nextDelay);
  if (c51Suite.lastUpdate != 0 && (now - c51Suite.lastUpdate < stepDelay)) return;
  unsigned long dtMs = (c51Suite.lastUpdate == 0) ? 0UL : (unsigned long)(now - c51Suite.lastUpdate);
  c51Suite.lastUpdate = now;
  c51Suite.nextDelay = 25;
  if (dtMs > 200UL) dtMs = 200UL;
  c51Suite.t += ((float)dtMs * 0.001f) * liveSpeedFactor;
  if (c51Suite.t > 7200.0f) c51Suite.t = fmodf(c51Suite.t, 7200.0f);
  renderCustom51All4Frame(ch1, ch2, ch3, ch4, count, c51Suite.t);
}

struct Custom52SuiteState { unsigned long lastUpdate=0; unsigned long lastCall=0; unsigned long nextDelay=25; float t=0.0f; };
Custom52SuiteState c52Suite;
void updateCustom52Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c52Suite.t, c52Suite.lastUpdate, c52Suite.lastCall, c52Suite.nextDelay, dtMs, nullptr)) return;
  renderCustom51to60Core(52, out1, out2, count, c52Suite.t);
}

struct Custom53SuiteState { unsigned long lastUpdate=0; unsigned long lastCall=0; unsigned long nextDelay=25; float t=0.0f; };
Custom53SuiteState c53Suite;
void updateCustom53Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c53Suite.t, c53Suite.lastUpdate, c53Suite.lastCall, c53Suite.nextDelay, dtMs, nullptr)) return;
  renderCustom51to60Core(53, out1, out2, count, c53Suite.t);
}

struct Custom54SuiteState { unsigned long lastUpdate=0; unsigned long lastCall=0; unsigned long nextDelay=25; float t=0.0f; };
Custom54SuiteState c54Suite;
void updateCustom54Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c54Suite.t, c54Suite.lastUpdate, c54Suite.lastCall, c54Suite.nextDelay, dtMs, nullptr)) return;
  renderCustom51to60Core(54, out1, out2, count, c54Suite.t);
}

struct Custom55SuiteState { unsigned long lastUpdate=0; unsigned long lastCall=0; unsigned long nextDelay=25; float t=0.0f; };
Custom55SuiteState c55Suite;
void updateCustom55Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c55Suite.t, c55Suite.lastUpdate, c55Suite.lastCall, c55Suite.nextDelay, dtMs, nullptr)) return;
  renderCustom51to60Core(55, out1, out2, count, c55Suite.t);
}

struct Custom56SuiteState { unsigned long lastUpdate=0; unsigned long lastCall=0; unsigned long nextDelay=25; float t=0.0f; };
Custom56SuiteState c56Suite;
void updateCustom56Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c56Suite.t, c56Suite.lastUpdate, c56Suite.lastCall, c56Suite.nextDelay, dtMs, nullptr)) return;
  renderCustom51to60Core(56, out1, out2, count, c56Suite.t);
}

struct Custom57SuiteState { unsigned long lastUpdate=0; unsigned long lastCall=0; unsigned long nextDelay=25; float t=0.0f; };
Custom57SuiteState c57Suite;
void updateCustom57Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c57Suite.t, c57Suite.lastUpdate, c57Suite.lastCall, c57Suite.nextDelay, dtMs, nullptr)) return;
  renderCustom51to60Core(57, out1, out2, count, c57Suite.t);
}

struct Custom58SuiteState { unsigned long lastUpdate=0; unsigned long lastCall=0; unsigned long nextDelay=25; float t=0.0f; };
Custom58SuiteState c58Suite;
void updateCustom58Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c58Suite.t, c58Suite.lastUpdate, c58Suite.lastCall, c58Suite.nextDelay, dtMs, nullptr)) return;
  renderCustom51to60Core(58, out1, out2, count, c58Suite.t);
}

struct Custom59SuiteState { unsigned long lastUpdate=0; unsigned long lastCall=0; unsigned long nextDelay=25; float t=0.0f; };
Custom59SuiteState c59Suite;
void updateCustom59Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c59Suite.t, c59Suite.lastUpdate, c59Suite.lastCall, c59Suite.nextDelay, dtMs, nullptr)) return;
  renderCustom51to60Core(59, out1, out2, count, c59Suite.t);
}

struct Custom60SuiteState { unsigned long lastUpdate=0; unsigned long lastCall=0; unsigned long nextDelay=25; float t=0.0f; };
Custom60SuiteState c60Suite;
void updateCustom60Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c60Suite.t, c60Suite.lastUpdate, c60Suite.lastCall, c60Suite.nextDelay, dtMs, nullptr)) return;
  renderCustom51to60Core(60, out1, out2, count, c60Suite.t);
}
// ============================================================================
// END MODE 51-60
// ============================================================================


// ============================================================================
// MODE 61-70 — SOURCE: preview_mode_61_70_revisi4 / Salinan(1).ino
// 61 Gate Split Rebound
// 62 Patrol Morph X
// 63 Block Compression Shift
// 64 Twin Spear Crossback
// 65 Ladder Breakout
// 66 Zone Relay Pulse
// 67 Shutter Flip Sequence
// 68 Crossfire Burst
// 69 Pulse Knot Release
// 70 Avalanche Reset
//
// Adaptasi GLOBAL sempit:
// - tidak ada setup()/loop()/delay()/FastLED.show()/FastLED.clear()/setBrightness().
// - tiap Mode punya CustomNSuiteState + updateCustomNSuite(out1,out2,count).
// - speed GLOBAL melalui getMode210StepDelay(), tercepat 10 ms untuk Mode 61-70.
// - rumus gerakan/fase/warna sumber dipertahankan.
// - K3 tetap diterapkan oleh k3SafeShow()/applyEffectColorOverride() GLOBAL.
// ============================================================================
static float m6170Clamp(float v, float a = 0.0f, float b = 1.0f) {
  if (v < a) return a;
  if (v > b) return b;
  return v;
}

static float m6170Gauss(float d, float w) {
  if (w <= 0.0001f) return 0.0f;
  return expf(-(d * d) / (2.0f * w * w));
}

static float m6170Block(float d, float w) {
  if (w <= 0.0001f) return 0.0f;
  return m6170Clamp(1.0f - d / w);
}

static float m6170Wrap(float x, float m) {
  if (m <= 0.0001f) return 0.0f;
  x = fmodf(x, m);
  if (x < 0.0f) x += m;
  return x;
}

static CRGB m6170Scale(CRGB c, float v) {
  v = m6170Clamp(v);
  if (v <= 0.001f) return CRGB::Black;
  c.nscale8_video((uint8_t)(v * 255.0f));
  return c;
}

static CRGB m6170FiveColor(int n) {
  int k = n % 5;
  if (k < 0) k += 5;

  switch (k) {
    case 0: return CRGB(255,255,255); // putih
    case 1: return CRGB(255,0,0);     // merah
    case 2: return CRGB(0,90,255);    // biru
    case 3: return CRGB(0,255,90);    // hijau
    default:return CRGB(255,0,170);   // magenta
  }
}

static CRGB m6170HSV(float h, float s = 1.0f, float v = 1.0f) {
  h = fmodf(h, 360.0f);
  if (h < 0.0f) h += 360.0f;
  s = m6170Clamp(s);
  v = m6170Clamp(v);

  float c = v * s;
  float hp = h / 60.0f;
  float x = c * (1.0f - fabsf(fmodf(hp, 2.0f) - 1.0f));
  float m = v - c;

  float r = 0.0f, g = 0.0f, b = 0.0f;
  if (h < 60.0f)       { r = c; g = x; }
  else if (h < 120.0f) { r = x; g = c; }
  else if (h < 180.0f) { g = c; b = x; }
  else if (h < 240.0f) { g = x; b = c; }
  else if (h < 300.0f) { r = x; b = c; }
  else                  { r = c; b = x; }

  return CRGB(
    (uint8_t)((r + m) * 255.0f),
    (uint8_t)((g + m) * 255.0f),
    (uint8_t)((b + m) * 255.0f)
  );
}

static CRGB m6170Rainbow(float t, uint16_t i, uint16_t count, float offset = 0.0f) {
  float denom = (count > 1) ? (float)(count - 1) : 1.0f;
  float h = t * 85.0f + ((float)i / denom) * 360.0f + offset;
  return m6170HSV(h, 1.0f, 1.0f);
}


static inline unsigned long m6170GlobalStep10(unsigned long baseMs) {
  unsigned long d = getMode210StepDelay(baseMs);
  return (d < 10UL) ? 10UL : d;
}

static void m6170RenderChannel(uint8_t mode, CRGB *out, int ch, uint16_t count, float t) {
  if (out == nullptr || count == 0 || mode < 61 || mode > 70) return;
  if (count > STAGE0_LED_BUFFER) count = STAGE0_LED_BUFFER;

  const float N = (float)count;
  const float W = fmaxf(3.0f, N / 14.0f);
  const float C = (N - 1.0f) * 0.5f;
  const float PI_F = 3.14159265358979323846f;

  for (uint16_t i = 0; i < count; i++) {
    float v = 0.0f;
    CRGB color = CRGB::Black;

    // ==========================================================
    // MODE 61 — Gate Split Rebound
    // center -> split -> edge hold -> rebound -> center flash
    // ==========================================================
    if (mode == 61) {
      const float L = 5.2f;
      float u = m6170Wrap(t, L) / L;

      if (u < 0.22f) {
        float q = u / 0.22f;
        v = m6170Gauss((float)i - C, W * (0.45f + q * 0.25f));
      }
      else if (u < 0.52f) {
        float q = (u - 0.22f) / 0.30f;
        float p = q * C;
        v = fmaxf(
          m6170Gauss((float)i - (C - p), W * 0.48f),
          m6170Gauss((float)i - (C + p), W * 0.48f)
        );
      }
      else if (u < 0.68f) {
        v = fmaxf(
          m6170Gauss((float)i - 1.0f, W * 0.65f),
          m6170Gauss((float)i - (N - 2.0f), W * 0.65f)
        );
      }
      else if (u < 0.94f) {
        float q = (u - 0.68f) / 0.26f;
        float p = (1.0f - q) * C;
        v = fmaxf(
          m6170Gauss((float)i - (C - p), W * 0.52f),
          m6170Gauss((float)i - (C + p), W * 0.52f)
        );
      }
      else {
        bool flash = (((int)floorf(t * 18.0f)) % 2) == 0;
        v = flash ? m6170Gauss((float)i - C, W * 1.25f) : 0.0f;
      }

      color = CRGB(255,255,255);
    }

    // ==========================================================
    // MODE 62 — Patrol Morph X
    // split red-blue -> swap -> collision -> white flash -> split
    // ==========================================================
    else if (mode == 62) {
      const float L = 6.0f;
      float u = m6170Wrap(t, L) / L;
      CRGB red(255,0,0);
      CRGB blue(0,70,255);

      if (u < 0.25f) {
        int swapSide = ((int)floorf(t / L)) % 2;
        bool left = ((float)i < C);
        bool isRed = swapSide ? !left : left;
        v = 0.90f;
        color = isRed ? red : blue;
      }
      else if (u < 0.48f) {
        float q = (u - 0.25f) / 0.23f;
        float p = q * C;
        float vl = m6170Gauss((float)i - p, W * 0.55f);
        float vr = m6170Gauss((float)i - (N - 1.0f - p), W * 0.55f);
        v = fmaxf(vl, vr);
        color = (vl > vr) ? red : blue;
      }
      else if (u < 0.58f) {
        bool flash = (((int)floorf(t * 20.0f)) % 2) == 0;
        v = m6170Gauss((float)i - C, W * 1.30f) * (flash ? 1.0f : 0.10f);
        color = CRGB(255,255,255);
      }
      else {
        float q = (u - 0.58f) / 0.42f;
        float p = q * C;
        float vl = m6170Gauss((float)i - (C - p), W * 0.50f);
        float vr = m6170Gauss((float)i - (C + p), W * 0.50f);
        v = fmaxf(vl, vr);
        color = (vl > vr) ? blue : red;
      }
    }

    // ==========================================================
    // MODE 63 — Block Compression Shift
    // 6 blocks -> compress -> half-zone shift -> expand -> pulse
    // ==========================================================
    else if (mode == 63) {
      const float L = 5.6f;
      float u = m6170Wrap(t, L) / L;
      const int blocks = 6;
      float seg = N / (float)blocks;
      float shift = (u < 0.5f) ? 0.0f : seg * 0.5f;

      float local = m6170Wrap((float)i - shift, N);
      int idx = (int)floorf(local / seg);
      if (idx < 0) idx = 0;
      if (idx >= blocks) idx = blocks - 1;

      float pos = local - (float)idx * seg;
      float width;

      if (u < 0.25f) {
        width = 0.42f;
      } else if (u < 0.50f) {
        width = 0.42f - ((u - 0.25f) / 0.25f) * 0.25f;
      } else if (u < 0.75f) {
        width = 0.17f + ((u - 0.50f) / 0.25f) * 0.25f;
      } else {
        width = 0.42f;
      }

      float center = seg * 0.50f;
      float d = fabsf(pos - center);
      v = m6170Block(d, seg * width);

      if (u > 0.75f) {
        v *= 0.55f + 0.45f *
          (sinf(t * 8.0f + (float)idx) * 0.5f + 0.5f);
      }

      color = ((idx % 2) == 0)
        ? CRGB(255,255,255)
        : CRGB(0,150,255);
    }

    // ==========================================================
    // MODE 64 — Twin Spear Crossback
    // inward -> cross -> pass -> reverse with longer tails
    // ==========================================================
    else if (mode == 64) {
      const float L = 6.4f;
      float u = m6170Wrap(t, L) / L;

      float p1, p2;
      float tail = 0.55f;

      if (u < 0.36f) {
        float q = u / 0.36f;
        p1 = q * (N - 1.0f);
        p2 = (N - 1.0f) - q * (N - 1.0f);
      }
      else if (u < 0.58f) {
        float q = (u - 0.36f) / 0.22f;
        p1 = C + q * C;
        p2 = C - q * C;
      }
      else {
        float q = (u - 0.58f) / 0.42f;
        p1 = (N - 1.0f) - q * (N - 1.0f);
        p2 = q * (N - 1.0f);
        tail = 0.95f;
      }

      float v1 =
        m6170Gauss((float)i - p1, W * 0.38f) +
        m6170Gauss((float)i - (p1 - tail * W * 2.0f), W * 0.80f) * 0.45f;

      float v2 =
        m6170Gauss((float)i - p2, W * 0.38f) +
        m6170Gauss((float)i - (p2 + tail * W * 2.0f), W * 0.80f) * 0.45f;

      v = m6170Clamp(fmaxf(v1, v2));
      color = (v1 > v2)
        ? CRGB(255,255,255)
        : CRGB(0,100,255);
    }

    // ==========================================================
    // MODE 65 — Ladder Breakout
    // build -> odd/even break -> center collapse -> rebuild reverse
    // ==========================================================
    else if (mode == 65) {
      const float L = 6.2f;
      float u = m6170Wrap(t, L) / L;

      const int zones = 8;
      float seg = N / (float)zones;
      int idx = (int)floorf((float)i / seg);
      if (idx < 0) idx = 0;
      if (idx >= zones) idx = zones - 1;

      if (u < 0.28f) {
        int k = (int)floorf((u / 0.28f) * (zones + 1));
        v = (idx < k) ? 1.0f : 0.0f;
      }
      else if (u < 0.48f) {
        v = ((idx % 2) == (((int)floorf(t * 6.0f)) % 2))
          ? 1.0f : 0.12f;
      }
      else if (u < 0.70f) {
        float q = (u - 0.48f) / 0.22f;
        float dist =
          fabsf(((float)idx + 0.5f) - zones * 0.5f) / (zones * 0.5f);
        v = (dist > q) ? 1.0f : 0.0f;
      }
      else {
        int k = (int)floorf(((u - 0.70f) / 0.30f) * (zones + 1));
        v = (idx >= zones - k) ? 1.0f : 0.0f;
      }

      color = CRGB(255,255,255);
    }

    // ==========================================================
    // MODE 66 — Zone Relay Pulse
    // forward relay -> reverse relay -> paired zones -> dim reset
    // ==========================================================
    else if (mode == 66) {
      const float L = 6.8f;
      float u = m6170Wrap(t, L) / L;

      const int zones = 5;
      float seg = N / (float)zones;
      int idx = (int)floorf((float)i / seg);
      if (idx < 0) idx = 0;
      if (idx >= zones) idx = zones - 1;

      float local = ((float)i - (float)idx * seg) / seg;
      float shape = sinf(PI_F * local);

      int active = 0;
      v = 0.05f;

      if (u < 0.30f) {
        active = ((int)floorf((u / 0.30f) * zones)) % zones;
        v = (idx == active) ? shape : 0.0f;
      }
      else if (u < 0.60f) {
        active = zones - 1 -
          (((int)floorf(((u - 0.30f) / 0.30f) * zones)) % zones);
        v = (idx == active) ? shape : 0.0f;
      }
      else if (u < 0.86f) {
        int k =
          ((int)floorf(((u - 0.60f) / 0.26f) * zones)) % zones;
        v = (idx == k || idx == (zones - 1 - k)) ? shape : 0.0f;
      }
      else {
        v = 0.18f * shape;
      }

      color = (ch == 0)
        ? CRGB(255,255,255)
        : CRGB(0,140,255);
    }

    // ==========================================================
    // MODE 67 — Shutter Flip Sequence
    // open -> close -> even -> odd -> thin sweep
    // 5 solid colors + rainbow side, alternating each cycle
    // ==========================================================
    else if (mode == 67) {
      const float L = 6.0f;
      float u = m6170Wrap(t, L) / L;
      int cyc = (int)floorf(t / L);

      const int zones = 10;
      float seg = N / (float)zones;
      int idx = (int)floorf((float)i / seg);
      if (idx < 0) idx = 0;
      if (idx >= zones) idx = zones - 1;

      float d = fabsf((float)i - C);

      if (u < 0.22f) {
        float q = u / 0.22f;
        v = (d < C * q) ? 1.0f : 0.0f;
      }
      else if (u < 0.42f) {
        float q = (u - 0.22f) / 0.20f;
        v = (d < C * (1.0f - q)) ? 1.0f : 0.0f;
      }
      else if (u < 0.60f) {
        v = ((idx % 2) == 0) ? 1.0f : 0.05f;
      }
      else if (u < 0.78f) {
        v = ((idx % 2) == 1) ? 1.0f : 0.05f;
      }
      else {
        float q = (u - 0.78f) / 0.22f;
        float p = q * (N - 1.0f);
        v = m6170Gauss((float)i - p, W * 0.42f);
      }

      int rainbowSide = cyc % 2;
      color = (ch == rainbowSide)
        ? m6170Rainbow(t, i, count, (float)cyc * 37.0f)
        : m6170FiveColor(cyc);
    }

    // ==========================================================
    // MODE 68 — Crossfire Burst
    // opposite travel -> collision burst -> separate -> direction swap
    // ==========================================================
    else if (mode == 68) {
      const float L = 6.4f;
      float u = m6170Wrap(t, L) / L;
      int flip = ((int)floorf(t / L)) % 2;

      int dir1 = flip ? 1 : -1;
      int dir2 = -dir1;
      float p1 = C, p2 = C;
      float v1 = 0.0f, v2 = 0.0f;

      if (u < 0.42f) {
        float q = u / 0.42f;
        p1 = (dir1 < 0)
          ? (N - 1.0f) * (1.0f - q)
          : (N - 1.0f) * q;
        p2 = (dir2 < 0)
          ? (N - 1.0f) * (1.0f - q)
          : (N - 1.0f) * q;

        v1 = m6170Gauss((float)i - p1, W * 0.48f);
        v2 = m6170Gauss((float)i - p2, W * 0.48f);
      }
      else if (u < 0.56f) {
        // Blitz putih dibuat tegas agar tidak terasa "ngangkut":
        // 3 hentakan cepat, OFF benar-benar padam, tanpa sisa 10%.
        float blitzPhase = (u - 0.42f) / 0.14f; // 0..1
        int blitzStep = (int)floorf(blitzPhase * 6.0f);
        bool flash = ((blitzStep % 2) == 0);

        v = flash
          ? m6170Gauss((float)i - C, W * 0.95f)
          : 0.0f;

        // Putih murni dan tidak boleh ditimpa K3.
        color = CRGB(255,255,255);

        out[i] = m6170Scale(color, v);
        continue;
      }
      else {
        float q = (u - 0.56f) / 0.44f;
        p1 = C + ((dir1 < 0) ? -1.0f : 1.0f) * q * C;
        p2 = C + ((dir2 < 0) ? -1.0f : 1.0f) * q * C;

        v1 = m6170Gauss((float)i - p1, W * 0.50f);
        v2 = m6170Gauss((float)i - p2, W * 0.50f);
      }

      float own = (ch == 0) ? v1 : v2;
      float other = (ch == 0) ? v2 : v1;

      v = m6170Clamp(fmaxf(own, other * 0.35f));
      color = (ch == 0)
        ? CRGB(255,30,120)
        : CRGB(0,140,255);
    }

    // ==========================================================
    // MODE 69 — Pulse Knot Release
    // 3 heads converge -> knot -> release 3 ways -> fade/reposition
    // ==========================================================
    else if (mode == 69) {
      const float L = 7.0f;
      float u = m6170Wrap(t, L) / L;

      float starts[3] = { N * 0.12f, N * 0.50f, N * 0.88f };
      float targets[3] = { N * 0.36f, N * 0.50f, N * 0.64f };
      float dest[3] = { N * 0.10f, N * 0.50f, N * 0.90f };

      int best = 0;
      v = 0.0f;

      for (int k = 0; k < 3; k++) {
        float p;

        if (u < 0.34f) {
          float q = u / 0.34f;
          p = starts[k] * (1.0f - q) + C * q;
        }
        else if (u < 0.48f) {
          p = C;
        }
        else if (u < 0.78f) {
          float q = (u - 0.48f) / 0.30f;
          p = C * (1.0f - q) + dest[k] * q;
        }
        else {
          float q = (u - 0.78f) / 0.22f;
          p = dest[k];
          if (q > 0.65f) p = targets[k];
        }

        float qv = m6170Gauss(
          (float)i - p,
          W * ((k == 1) ? 0.55f : 0.45f)
        );

        if (qv > v) {
          v = qv;
          best = k;
        }
      }

      float fade = (u > 0.78f)
        ? 1.0f - ((u - 0.78f) / 0.22f) * 0.55f
        : 1.0f;

      v = m6170Clamp(v * fade);

      if (best == 0)      color = CRGB(255,255,255);
      else if (best == 1) color = CRGB(0,150,255);
      else                color = CRGB(255,40,130);
    }

    // ==========================================================
    // MODE 70 — Avalanche Reset
    // fill both edges -> collapse center -> 3 big blocks -> reverse
    // 5 solid colors + rainbow side, alternating each cycle
    // ==========================================================
    else {
      const float L = 7.2f;
      float u = m6170Wrap(t, L) / L;
      int cyc = (int)floorf(t / L);

      const int zones = 12;
      float seg = N / (float)zones;
      int idx = (int)floorf((float)i / seg);
      if (idx < 0) idx = 0;
      if (idx >= zones) idx = zones - 1;

      int reverse = cyc % 2;

      if (u < 0.32f) {
        int k = (int)floorf((u / 0.32f) * (zones * 0.5f + 1.0f));
        bool on = (idx < k || idx >= zones - k);
        v = on ? 1.0f : 0.0f;
      }
      else if (u < 0.54f) {
        float q = (u - 0.32f) / 0.22f;
        float dist =
          fabsf(((float)idx + 0.5f) - zones * 0.5f) / (zones * 0.5f);
        v = (dist < 1.0f - q) ? 1.0f : 0.0f;
      }
      else if (u < 0.80f) {
        int blockIdx =
          ((int)floorf(((u - 0.54f) / 0.26f) * 3.0f)) % 3;
        int third = (idx * 3) / zones;
        if (third > 2) third = 2;
        v = (third == blockIdx) ? 1.0f : 0.08f;
      }
      else {
        float q = (u - 0.80f) / 0.20f;
        int k = (int)floorf(q * (zones + 1));

        v = reverse
          ? ((idx >= zones - k) ? 1.0f : 0.0f)
          : ((idx < k) ? 1.0f : 0.0f);
      }

      int rainbowSide = (cyc + 1) % 2;
      color = (ch == rainbowSide)
        ? m6170Rainbow(t * 1.15f, i, count, (float)cyc * 53.0f)
        : m6170FiveColor(cyc + 2);
    }

    out[i] = m6170Scale(color, v);
  }

  clearUnusedChannel(out);
}

struct Custom61SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom61SuiteState c61Suite;

void updateCustom61Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c61Suite.t, c61Suite.lastUpdate, c61Suite.lastCall, c61Suite.nextDelay, dtMs, nullptr)) return;

  m6170RenderChannel(61, out1, 0, count, c61Suite.t);
  m6170RenderChannel(61, out2, 1, count, c61Suite.t);
}

struct Custom62SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom62SuiteState c62Suite;

void updateCustom62Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c62Suite.t, c62Suite.lastUpdate, c62Suite.lastCall, c62Suite.nextDelay, dtMs, nullptr)) return;

  m6170RenderChannel(62, out1, 0, count, c62Suite.t);
  m6170RenderChannel(62, out2, 1, count, c62Suite.t);
}

struct Custom63SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom63SuiteState c63Suite;

void updateCustom63Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c63Suite.t, c63Suite.lastUpdate, c63Suite.lastCall, c63Suite.nextDelay, dtMs, nullptr)) return;

  m6170RenderChannel(63, out1, 0, count, c63Suite.t);
  m6170RenderChannel(63, out2, 1, count, c63Suite.t);
}

struct Custom64SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom64SuiteState c64Suite;

void updateCustom64Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c64Suite.t, c64Suite.lastUpdate, c64Suite.lastCall, c64Suite.nextDelay, dtMs, nullptr)) return;

  m6170RenderChannel(64, out1, 0, count, c64Suite.t);
  m6170RenderChannel(64, out2, 1, count, c64Suite.t);
}

struct Custom65SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom65SuiteState c65Suite;

void updateCustom65Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c65Suite.t, c65Suite.lastUpdate, c65Suite.lastCall, c65Suite.nextDelay, dtMs, nullptr)) return;

  m6170RenderChannel(65, out1, 0, count, c65Suite.t);
  m6170RenderChannel(65, out2, 1, count, c65Suite.t);
}

struct Custom66SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom66SuiteState c66Suite;

void updateCustom66Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c66Suite.t, c66Suite.lastUpdate, c66Suite.lastCall, c66Suite.nextDelay, dtMs, nullptr)) return;

  m6170RenderChannel(66, out1, 0, count, c66Suite.t);
  m6170RenderChannel(66, out2, 1, count, c66Suite.t);
}

struct Custom67SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom67SuiteState c67Suite;

void updateCustom67Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c67Suite.t, c67Suite.lastUpdate, c67Suite.lastCall, c67Suite.nextDelay, dtMs, nullptr)) return;

  m6170RenderChannel(67, out1, 0, count, c67Suite.t);
  m6170RenderChannel(67, out2, 1, count, c67Suite.t);
}

struct Custom68SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom68SuiteState c68Suite;

void updateCustom68Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c68Suite.t, c68Suite.lastUpdate, c68Suite.lastCall, c68Suite.nextDelay, dtMs, nullptr)) return;

  m6170RenderChannel(68, out1, 0, count, c68Suite.t);
  m6170RenderChannel(68, out2, 1, count, c68Suite.t);
}

struct Custom69SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom69SuiteState c69Suite;

void updateCustom69Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c69Suite.t, c69Suite.lastUpdate, c69Suite.lastCall, c69Suite.nextDelay, dtMs, nullptr)) return;

  m6170RenderChannel(69, out1, 0, count, c69Suite.t);
  m6170RenderChannel(69, out2, 1, count, c69Suite.t);
}

struct Custom70SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom70SuiteState c70Suite;

void updateCustom70Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c70Suite.t, c70Suite.lastUpdate, c70Suite.lastCall, c70Suite.nextDelay, dtMs, nullptr)) return;

  m6170RenderChannel(70, out1, 0, count, c70Suite.t);
  m6170RenderChannel(70, out2, 1, count, c70Suite.t);
}

// ============================================================================
// END MODE 61-70
// ============================================================================


// ============================================================================
// MODE 71-90 — SOURCE HTML / GLOBAL ADAPTER, 10ms MIN FRAME
// 71 Accordion Route
// 72 Mega Connected Finale
// 73 Bridge Runner
// 74 Portal Transfer
// 75 Snake Relay
// 76 Jumping Comet
// 77 Wave Handoff
// 78 Block Morph
// 79 Twin Runner Merge
// 80 Pulse Tunnel
// 81 Color Baton
// 82 Cascade Flip
// 83 Broken Meteor
// 84 Cross Channel Bounce
// 85 Spiral March
// 86 Rocket Split Merge
// 87 Segment Teleport
// 88 Reverse Handoff
// 89 Color Ladder Flow
// 90 Cluster Train
// Jalur virtual sumber: out1 = CH1, out2 = CH2.
// Mapping fisik 4CH dilakukan oleh GLOBAL: CH1=CH3, CH2=CH4.
// ============================================================================

static inline unsigned long m7180GlobalStep10(unsigned long baseMs) {
  unsigned long d = getMode210StepDelay(baseMs);
  return (d < 10UL) ? 10UL : d;
}

static float m7180Clamp(float v, float a = 0.0f, float b = 1.0f) {
  if (v < a) return a;
  if (v > b) return b;
  return v;
}

static float m7180Smoothstep(float a, float b, float x) {
  if (fabsf(b - a) < 0.000001f) return (x >= b) ? 1.0f : 0.0f;
  float q = m7180Clamp((x - a) / (b - a));
  return q * q * (3.0f - 2.0f * q);
}

static float m7180SoftBar(float g, float p, float w) {
  if (w <= 0.000001f) return 0.0f;
  float d = fabsf(g - p);
  return m7180Clamp(1.0f - m7180Smoothstep(w * 0.68f, w, d));
}

static float m7180Hash(float n) {
  float x = sinf(n * 12.9898f + 78.233f) * 43758.5453f;
  return x - floorf(x);
}

static CRGB m7180HSV(float h, float s, float v) {
  h = fmodf(h, 360.0f); if (h < 0.0f) h += 360.0f;
  s = m7180Clamp(s); v = m7180Clamp(v);
  float c = v * s;
  float hp = h / 60.0f;
  float x = c * (1.0f - fabsf(fmodf(hp, 2.0f) - 1.0f));
  float m = v - c;
  float r = 0.0f, g = 0.0f, b = 0.0f;
  if (h < 60.0f) { r = c; g = x; }
  else if (h < 120.0f) { r = x; g = c; }
  else if (h < 180.0f) { g = c; b = x; }
  else if (h < 240.0f) { g = x; b = c; }
  else if (h < 300.0f) { r = x; b = c; }
  else { r = c; b = x; }
  return CRGB((uint8_t)((r+m)*255.0f), (uint8_t)((g+m)*255.0f), (uint8_t)((b+m)*255.0f));
}

static CRGB m7180RandomColor(int previewId, int cycle, int phase) {
  float h = m7180Hash((float)previewId * 101.0f + (float)cycle * 47.0f + (float)phase * 29.0f) * 360.0f;
  float s = 0.78f + m7180Hash((float)previewId * 19.0f + (float)cycle * 83.0f + (float)phase * 11.0f) * 0.22f;
  return m7180HSV(h, s, 1.0f);
}

static CRGB m7180Scale(CRGB c, float v) {
  v = m7180Clamp(v);
  if (v <= 0.001f) return CRGB::Black;
  c.nscale8_video((uint8_t)(v * 255.0f));
  return c;
}

static void m7172RenderPair(uint8_t mode, CRGB *out1, CRGB *out2, uint16_t count, float t) {
  if (!out1 || !out2 || count == 0 || mode < 71 || mode > 72) return;
  const float N = (float)count;
  const float M = N * 2.0f;
  const float W = fmaxf(9.0f, M / 13.0f);
  const float PI_F = 3.14159265358979323846f;

  for (uint8_t ch = 0; ch < 2; ch++) {
    CRGB *out = (ch == 0) ? out1 : out2;
    const float Gbase = (ch == 0) ? 0.0f : N;
    for (uint16_t i = 0; i < count; i++) {
      const float G = Gbase + (float)i;
      float v = 0.0f;
      CRGB color = CRGB::Black;

      if (mode == 71) {
        const float L = 8.6f;
        float u = fmodf(t, L) / L;
        int cyc = (int)floorf(t / L);
        float q = (u < 0.5f) ? u * 2.0f : 2.0f - u * 2.0f;
        int dir = (u < 0.5f) ? 1 : -1;
        float p = q * (M - 1.0f);
        float pulse = 0.5f + 0.5f * sinf(q * PI_F * 6.0f);
        if (dir < 0) pulse = 1.0f - pulse;
        float w = W * (0.7f + 1.65f * pulse);
        v = m7180SoftBar(G, p, w);
        int colorPhase = (int)floorf(q * 3.0f) + ((dir < 0) ? 3 : 0);
        color = m7180RandomColor(15, cyc, colorPhase);
      } else {
        const float L = 11.0f;
        float u = fmodf(t, L) / L;
        int cyc = (int)floorf(t / L);
        if (u < 0.20f) {
          float p = (u / 0.20f) * (M - 1.0f);
          v = m7180SoftBar(G, p, W);
          color = m7180RandomColor(19, cyc, 0);
        } else if (u < 0.36f) {
          float q = (u - 0.20f) / 0.16f;
          float p = M - 1.0f;
          v = m7180SoftBar(G, p, W * (1.0f + 3.0f * q));
          color = m7180RandomColor(19, cyc, 1);
        } else if (u < 0.52f) {
          float q = (u - 0.36f) / 0.16f;
          float sep = q * W * 2.4f;
          float p = M - 1.0f;
          v = fmaxf(m7180SoftBar(G, p - sep, W * 0.85f), m7180SoftBar(G, p + sep, W * 0.85f));
          color = m7180RandomColor(19, cyc, 2);
        } else if (u < 0.60f) {
          int step = (int)floorf(((u - 0.52f) / 0.08f) * 6.0f);
          v = ((step % 2) == 0) ? 1.0f : 0.0f;
          color = CRGB(255,255,255);
        } else {
          float q = (u - 0.60f) / 0.40f;
          float p = (1.0f - q) * (M - 1.0f);
          float w = W * (1.3f + 0.9f * sinf(q * PI_F));
          v = m7180SoftBar(G, p, w);
          color = m7180RandomColor(19, cyc, 3);
        }
      }
      out[i] = m7180Scale(color, v);
    }
    clearUnusedChannel(out);
  }
}

// Manual prototypes are intentional: Arduino's .ino preprocessor can emit
// auto-prototypes before these custom structs and then fail with
// "M7380Color does not name a type".
static M7380Color m7380RC(float c, float s = 0.0f);
static M7380Color m7380Mix(M7380Color a, M7380Color b, float k);
static M7380Sample m7380Sample(uint8_t id, float t, float g, float N);

static float m7380Clamp(float v, float a=0.0f, float b=1.0f) { if(v<a)return a; if(v>b)return b; return v; }
static float m7380Gauss(float d,float w) { if(w<=0.0000001f)return 0.0f; return expf(-(d*d)/(2.0f*w*w)); }
static float m7380Block(float d,float w) { if(w<=0.0000001f)return 0.0f; return m7380Clamp(1.0f-d/w); }
static float m7380Hash(float n) { float x=sinf(n*12.9898f+78.233f)*43758.5453f; return x-floorf(x); }
static const M7380Color m7380Pal[10] = {
  {255,255,255},{255,0,0},{0,90,255},{180,0,255},{0,220,120},
  {255,40,150},{0,220,255},{255,220,0},{120,255,0},{255,90,40}
};
static M7380Color m7380RC(float c,float s) { float hv=m7380Hash(c*7.17f+s); int idx=((int)floorf(hv*10.0f))%10; if(idx<0)idx+=10; return m7380Pal[idx]; }
static M7380Color m7380Mix(M7380Color a,M7380Color b,float k) { return {a.r*(1.0f-k)+b.r*k,a.g*(1.0f-k)+b.g*k,a.b*(1.0f-k)+b.b*k}; }
static float m7380Ping(float u,float L) { float q=fmodf(u,2.0f*L); if(q<0.0f)q+=2.0f*L; return (q<L)?q:(2.0f*L-q); }

static M7380Sample m7380Sample(uint8_t id,float t,float g,float N) {
  const float PI_D=3.14159265358979323846f;
  const float L=N*2.0f;
  const float W=fmaxf(4.0f,N/10.0f);
  const int cyc=(int)floorf(t/6.0f);
  M7380Color col=m7380RC((float)cyc,(float)id*3.1f);
  M7380Color col2=m7380RC((float)(cyc+1),(float)id*5.7f);
  const float u=fmodf(t,6.0f)/6.0f;
  float v=0.0f,p=0.0f; M7380Color c=col;
  switch(id) {
    case 0: // 73 Bridge Runner
      p=u*L;
      if(u<0.28f) v=m7380Block(fabsf(g-p),W*0.55f);
      else if(u<0.52f) v=m7380Block(fabsf(g-p),W*(0.55f+(u-0.28f)*4.0f));
      else if(u<0.78f) { for(int k=-1;k<=1;k++) v=fmaxf(v,m7380Gauss(g-(p+(float)k*W*1.8f),W*0.35f)); }
      else { p=L-(u-0.78f)/0.22f*L; v=m7380Gauss(g-p,W*0.28f); }
      break;
    case 1: // 74 Portal Transfer
      p=u*L;
      v=m7380Gauss(fabsf(fabsf(g-p)-W*(0.3f+2.0f*sinf(u*PI_D))),W*0.22f);
      if(u>0.65f&&u<0.82f) v=fmaxf(v,m7380Gauss(g-L*0.82f,W*1.2f));
      if(u>0.82f) v=m7380Gauss(g-L*0.82f,W*(1.2f-(u-0.82f)*5.0f));
      c=m7380Mix(col,col2,u);
      break;
    case 2: // 75 Snake Relay
      p=u*L;
      if(u<0.42f) v=m7380Gauss(g-p,W*0.55f);
      else if(u<0.70f) v=fmaxf(m7380Gauss(g-p,W*0.25f),m7380Gauss(g-(p-W*1.5f),W*0.25f));
      else { p=L-(u-0.70f)/0.30f*L; v=m7380Gauss(g-p,W*0.65f); }
      c=(u<0.42f)?col:col2;
      break;
    case 3: // 76 Jumping Comet
      if(u<0.35f) p=u/0.35f*L*0.45f;
      else if(u<0.55f) p=L*(0.45f+floorf((u-0.35f)*10.0f)*0.08f);
      else if(u<0.70f) p=L*0.78f;
      else p=L*0.78f+(u-0.70f)/0.30f*L*0.22f;
      v=m7380Gauss(g-p,W*0.38f);
      break;
    case 4: // 77 Wave Handoff
      if(u<0.62f) p=u/0.62f*L; else p=L-(u-0.62f)/0.38f*L;
      v=(0.5f+0.5f*sinf((g-p)*0.22f))*m7380Gauss(g-p,W*2.4f);
      c=(u<0.62f)?col:col2;
      break;
    case 5: { // 78 Block Morph
      int cnt=(u<0.33f)?5:((u<0.66f)?8:3);
      float seg=L/(float)cnt;
      float x=fmodf(g-fmodf(t*18.0f,L)+L,L);
      int idx=(int)floorf(x/seg);
      float local=x-(float)idx*seg;
      v=(local>seg*0.15f&&local<seg*0.85f)?1.0f:0.08f;
      c=m7380RC((float)(cyc+idx),(float)id);
      break;
    }
    case 6: { // 79 Twin Runner Merge
      float p1=u*L,p2=L-u*L;
      if(u<0.42f) v=fmaxf(m7380Gauss(g-p1,W*0.4f),m7380Gauss(g-p2,W*0.4f));
      else if(u<0.58f) v=m7380Gauss(g-L/2.0f,W*(0.4f+(u-0.42f)*5.0f));
      else { float q=(u-0.58f)/0.42f*L*0.5f; v=fmaxf(m7380Gauss(g-(L/2.0f-q),W*0.35f),m7380Gauss(g-(L/2.0f+q),W*0.35f)); }
      break;
    }
    case 7: // 80 Pulse Tunnel
      p=u*L;
      v=m7380Gauss(g-p,W*(0.25f+1.6f*(0.5f-0.5f*cosf(u*PI_D*4.0f)))) * m7380Clamp(0.55f+0.45f*cosf((g-p)*0.35f));
      break;
    case 8: // 81 Color Baton
      p=u*L;
      c=m7380RC((float)(cyc+(int)floorf(p/(L/4.0f))),(float)id);
      v=fmaxf(m7380Gauss(g-p,W*0.38f),m7380Gauss(g-(p-W*1.4f),W*0.25f)*0.65f);
      break;
    case 9: // 82 Cascade Flip
      if(u<0.35f) {
        for(int k=0;k<5;k++) v=fmaxf(v,m7380Gauss(g-((u/0.35f)*L-(float)k*W*1.2f),W*0.2f));
      } else if(u<0.65f) {
        for(int k=0;k<5;k++) v=fmaxf(v,m7380Gauss(g-(L-(u-0.35f)/0.30f*L-(float)k*W*0.9f),W*0.2f));
      } else {
        for(int k=0;k<6;k++) v=fmaxf(v,m7380Gauss(g-((u-0.65f)/0.35f*L-(float)k*W*0.6f),W*0.18f));
      }
      break;
    case 10: // 83 Broken Meteor
      p=u*L;
      v=m7380Gauss(g-p,W*0.7f);
      if(u>0.45f&&u<0.72f) {
        v=0.0f;
        for(int k=-2;k<=2;k++) v=fmaxf(v,m7380Gauss(g-(p+(float)k*W*0.9f),W*0.22f));
      }
      if(u>0.72f) v=m7380Gauss(g-p,W*(0.2f+(u-0.72f)*2.2f));
      break;
    case 11: { // 84 Cross Channel Bounce
      p=m7380Ping(t*22.0f,L);
      int st=((int)floorf(t/1.4f))%4;
      const float widths[4]={0.35f,0.75f,0.22f,1.1f};
      float w=widths[st]*W;
      v=m7380Gauss(g-p,w);
      c=m7380RC((float)(cyc+st),(float)id);
      break;
    }
    case 12: // 85 Spiral March
      for(int k=0;k<4;k++) {
        float sp=W*(1.1f+0.8f*sinf(u*PI_D*2.0f+(float)k));
        float pp=fmodf(u*L+(float)k*sp,L);
        v=fmaxf(v,m7380Gauss(g-pp,W*0.28f));
      }
      if(u>0.72f) v=fmaxf(v,m7380Gauss(g-L*0.78f,W*1.5f));
      break;
    case 13: { // 86 Rocket Split Merge
      if(u<0.38f) {
        float q=u/0.38f;
        p=(q*q)*L*0.52f;
        v=m7380Gauss(g-p,W*0.42f);
      } else if(u<0.58f) {
        float q=(u-0.38f)/0.20f;
        p=L*(0.52f+q*0.10f);
        v=m7380Gauss(g-p,W*(0.42f+0.28f*sinf(q*PI_D)));
      } else if(u<0.82f) {
        float q=(u-0.58f)/0.24f;
        float center=L*(0.62f+q*0.25f);
        float sep=W*(0.35f+q*1.7f);
        v=fmaxf(m7380Gauss(g-(center-sep),W*0.34f),m7380Gauss(g-(center+sep),W*0.34f));
      } else {
        float q=(u-0.82f)/0.18f;
        float center=L*(0.87f+q*0.11f);
        float sep=W*2.05f*(1.0f-q);
        v=fmaxf(fmaxf(m7380Gauss(g-(center-sep),W*0.34f),m7380Gauss(g-(center+sep),W*0.34f)),m7380Gauss(g-center,W*0.42f)*q);
      }
      c=m7380RC((float)cyc,(float)(id+13));
      break;
    }
    case 14: { // 87 Segment Teleport
      const float jumps[7]={0.05f,0.24f,0.47f,0.36f,0.72f,0.58f,0.92f};
      int n=(int)floorf(u*7.0f); if(n>6)n=6;
      float f=u*7.0f-(float)n;
      int n2=n+1; if(n2>6)n2=6;
      p=(jumps[n]*(1.0f-f)+jumps[n2]*f)*L;
      v=m7380Gauss(g-p,W*0.42f);
      break;
    }
    case 15: // 88 Reverse Handoff
      if(u<0.5f) p=u/0.5f*L; else p=L-(u-0.5f)/0.5f*L;
      v=m7380Gauss(g-p,(u<0.5f)?W*0.5f:W*(0.25f+0.65f*sinf((u-0.5f)*PI_D)));
      c=(u<0.5f)?col:col2;
      break;
    case 16: { // 89 Color Ladder Flow
      float seg=L/8.0f;
      int idx=(int)floorf(g/seg);
      int step=(int)floorf(u*10.0f);
      v=(idx<=(step%9))?1.0f:0.05f;
      if(u>0.55f) {
        p=(u-0.55f)/0.45f*L;
        v=fmaxf(v*0.25f,m7380Gauss(g-p,W*0.2f));
        c=col2;
      }
      break;
    }
    case 17: { // 90 Cluster Train
      const float speeds[3]={10.0f,15.0f,21.0f};
      for(int k=0;k<3;k++) {
        float pp=fmodf(t*speeds[k]+(float)k*L/3.0f,L);
        v=fmaxf(v,m7380Gauss(g-pp,W*(0.28f+0.08f*(float)k)));
      }
      if(u>0.70f) v=fmaxf(v,m7380Gauss(g-L*0.68f,W*1.3f));
      c=m7380RC((float)(cyc+(int)floorf(u*4.0f)),(float)id);
      break;
    }
    case 18: // 91 Rolling Gate Transfer
      p=u*L;
      v=m7380Gauss(
        fabsf(fabsf(g-p)-W*(0.3f+1.7f*fabsf(sinf(u*PI_D*3.0f)))),
        W*0.18f
      );
      if(u>0.72f) {
        float local=fmodf(g-p+L,L);
        if(((int)floorf(local/(W*0.7f))%2)==0) {
          v=fmaxf(v,m7380Gauss(g-p,W*1.7f));
        }
      }
      break;
    case 19: { // 92 Finale Sequence
      float uu=fmodf(t,7.2f)/7.2f;
      int st=(int)floorf(uu*6.0f);
      float lo=fmodf(uu*6.0f,1.0f);
      c=m7380RC((float)(cyc+st),(float)id);
      if(st==0) {
        p=lo*L;
        v=m7380Gauss(g-p,W*0.42f);
      } else if(st==1) {
        p=lo*L;
        v=fmaxf(
          fmaxf(m7380Gauss(g-p,W*0.3f),m7380Gauss(g-(p-W*1.4f),W*0.3f)),
          m7380Gauss(g-(p+W*1.4f),W*0.3f)
        );
      } else if(st==2) {
        p=lo*L;
        v=m7380Gauss(g-p,W*(0.25f+1.1f*sinf(lo*PI_D)));
      } else if(st==3) {
        p=lo*L;
        float local=g-p+L;
        v=(((int)floorf(local/(W*0.7f))%3)==0) ? m7380Gauss(g-p,W*2.2f) : 0.0f;
      } else if(st==4) {
        p=L-lo*L;
        v=m7380Gauss(g-p,W*0.5f);
      } else {
        v=0.0f;
      }
      break;
    }
  }
  return {m7380Clamp(v),c};
}

static uint8_t m7380Byte(float x) { int v=(int)floorf(x+0.5f); if(v<0)v=0; if(v>255)v=255; return (uint8_t)v; }

static void m7380RenderPair(uint8_t mode, CRGB *out1, CRGB *out2, uint16_t count, float tf) {
  if (!out1 || !out2 || count == 0 || mode < 73 || mode > 92) return;
  const uint8_t id=(uint8_t)(mode-73);
  const float t=(float)tf;
  const float N=(float)count;
  for(uint8_t ch=0;ch<2;ch++) {
    CRGB *out=(ch==0)?out1:out2;
    for(uint16_t i=0;i<count;i++) {
      float g=(ch==0)?(float)i:(N+(float)i);
      M7380Sample s=m7380Sample(id,t,g,N);
      out[i]=CRGB(m7380Byte(s.c.r*s.v),m7380Byte(s.c.g*s.v),m7380Byte(s.c.b*s.v));
    }
    clearUnusedChannel(out);
  }
}

struct Custom71SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom71SuiteState c71Suite;

void updateCustom71Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c71Suite.t, c71Suite.lastUpdate, c71Suite.lastCall, c71Suite.nextDelay, dtMs, nullptr)) return;
  m7172RenderPair(71, out1, out2, count, c71Suite.t);
}

struct Custom72SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom72SuiteState c72Suite;

void updateCustom72Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c72Suite.t, c72Suite.lastUpdate, c72Suite.lastCall, c72Suite.nextDelay, dtMs, nullptr)) return;
  m7172RenderPair(72, out1, out2, count, c72Suite.t);
}

struct Custom73SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom73SuiteState c73Suite;

void updateCustom73Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c73Suite.t, c73Suite.lastUpdate, c73Suite.lastCall, c73Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(73, out1, out2, count, c73Suite.t);
}

struct Custom74SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom74SuiteState c74Suite;

void updateCustom74Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c74Suite.t, c74Suite.lastUpdate, c74Suite.lastCall, c74Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(74, out1, out2, count, c74Suite.t);
}

struct Custom75SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom75SuiteState c75Suite;

void updateCustom75Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c75Suite.t, c75Suite.lastUpdate, c75Suite.lastCall, c75Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(75, out1, out2, count, c75Suite.t);
}

struct Custom76SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom76SuiteState c76Suite;

void updateCustom76Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c76Suite.t, c76Suite.lastUpdate, c76Suite.lastCall, c76Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(76, out1, out2, count, c76Suite.t);
}

struct Custom77SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom77SuiteState c77Suite;

void updateCustom77Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c77Suite.t, c77Suite.lastUpdate, c77Suite.lastCall, c77Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(77, out1, out2, count, c77Suite.t);
}

struct Custom78SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom78SuiteState c78Suite;

void updateCustom78Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c78Suite.t, c78Suite.lastUpdate, c78Suite.lastCall, c78Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(78, out1, out2, count, c78Suite.t);
}

struct Custom79SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom79SuiteState c79Suite;

void updateCustom79Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c79Suite.t, c79Suite.lastUpdate, c79Suite.lastCall, c79Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(79, out1, out2, count, c79Suite.t);
}

struct Custom80SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom80SuiteState c80Suite;

void updateCustom80Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c80Suite.t, c80Suite.lastUpdate, c80Suite.lastCall, c80Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(80, out1, out2, count, c80Suite.t);
}

// ============================================================================
// END MODE 71-80
// ============================================================================



struct Custom81SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom81SuiteState c81Suite;

void updateCustom81Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c81Suite.t, c81Suite.lastUpdate, c81Suite.lastCall, c81Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(81, out1, out2, count, c81Suite.t);
}


struct Custom82SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom82SuiteState c82Suite;

void updateCustom82Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c82Suite.t, c82Suite.lastUpdate, c82Suite.lastCall, c82Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(82, out1, out2, count, c82Suite.t);
}


struct Custom83SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom83SuiteState c83Suite;

void updateCustom83Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c83Suite.t, c83Suite.lastUpdate, c83Suite.lastCall, c83Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(83, out1, out2, count, c83Suite.t);
}


struct Custom84SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom84SuiteState c84Suite;

void updateCustom84Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c84Suite.t, c84Suite.lastUpdate, c84Suite.lastCall, c84Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(84, out1, out2, count, c84Suite.t);
}


struct Custom85SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom85SuiteState c85Suite;

void updateCustom85Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c85Suite.t, c85Suite.lastUpdate, c85Suite.lastCall, c85Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(85, out1, out2, count, c85Suite.t);
}


struct Custom86SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom86SuiteState c86Suite;

void updateCustom86Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c86Suite.t, c86Suite.lastUpdate, c86Suite.lastCall, c86Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(86, out1, out2, count, c86Suite.t);
}


struct Custom87SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom87SuiteState c87Suite;

void updateCustom87Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c87Suite.t, c87Suite.lastUpdate, c87Suite.lastCall, c87Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(87, out1, out2, count, c87Suite.t);
}


struct Custom88SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom88SuiteState c88Suite;

void updateCustom88Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c88Suite.t, c88Suite.lastUpdate, c88Suite.lastCall, c88Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(88, out1, out2, count, c88Suite.t);
}


struct Custom89SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom89SuiteState c89Suite;

void updateCustom89Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c89Suite.t, c89Suite.lastUpdate, c89Suite.lastCall, c89Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(89, out1, out2, count, c89Suite.t);
}


struct Custom90SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom90SuiteState c90Suite;

void updateCustom90Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c90Suite.t, c90Suite.lastUpdate, c90Suite.lastCall, c90Suite.nextDelay, dtMs, nullptr)) return;
  m7380RenderPair(90, out1, out2, count, c90Suite.t);
}



// ============================================================================
// MODE 93-100 — EXACT HTML "8 Efek Baru Non-Monoton", GLOBAL 4CH ADAPTATION
// 93 Prism Surge | 94 Scatter Magnet | 95 Ribbon Fold | 96 Pulse Ladder Burst
// 97 Orbit Split Transfer | 98 Cluster Snapback | 99 Color Tunnel Break
// 100 Chaos Relay Finale
//
// PATOKAN:
// - Gerakan/fase/palette/random color mengikuti HTML sumber.
// - Jalur virtual tetap CH1 -> CH2.
// - Ekor sumber dipertahankan: saat level turun, trail *= 0.58 per frame 60 FPS.
// - Adaptasi GLOBAL hanya timer non-blocking + frame tercepat 10 ms.
// - GLOBAL 4CH tetap CH1=CH3 dan CH2=CH4 saat semua channel memakai mode sama.
// - Tidak ada FastLED.show(), delay(), setup(), loop(), atau setBrightness() di engine ini.
// ============================================================================
static float m93100Clamp(float v, float a = 0.0f, float b = 1.0f) {
  if (v < a) return a;
  if (v > b) return b;
  return v;
}
static float m93100Gauss(float d, float w) {
  if (w <= 0.0000001f) return 0.0f;
  return expf(-(d*d)/(2.0f*w*w));
}
static float m93100Hash(float n) {
  float x = sinf(n*12.9898f + 78.233f) * 43758.5453f;
  return x - floorf(x);
}
static const M93100Color m93100Pal[10] = {
  {255.0f,255.0f,255.0f},
  {255.0f,0.0f,0.0f},
  {0.0f,90.0f,255.0f},
  {190.0f,0.0f,255.0f},
  {0.0f,220.0f,130.0f},
  {255.0f,30.0f,150.0f},
  {0.0f,220.0f,255.0f},
  {255.0f,220.0f,0.0f},
  {120.0f,255.0f,0.0f},
  {255.0f,80.0f,40.0f}
};

static M93100Color m93100RC(float seed) {
  float hv = m93100Hash(seed);
  int idx = ((int)floorf(hv * 10.0f)) % 10;
  if (idx < 0) idx += 10;
  return m93100Pal[idx];
}

static M93100Sample m93100Sample(
  uint8_t id,
  float t,
  float g,
  float N
) {
  const float PI_D = 3.14159265358979323846f;
  const float L = N * 2.0f;
  const float W = fmaxf(4.0f, N / 10.0f);
  const float u = fmodf(t, 6.0f) / 6.0f;
  const int cyc = (int)floorf(t / 6.0f);

  float v = 0.0f;
  M93100Color c =
    m93100RC((float)cyc + (float)id * 7.0f);

  switch (id) {

    case 0: { // 93 Prism Surge
      if (u < 0.22f) {
        float p = u / 0.22f * L * 0.38f;
        v = m93100Gauss(g - p, W * 0.3f);
        c = m93100RC((float)cyc);
      }
      else if (u < 0.42f) {
        float q = (u - 0.22f) / 0.20f;
        float p = L * (0.38f + q * 0.16f);
        v = m93100Gauss(g - p, W * (0.3f + q * 0.9f));
        c = m93100RC((float)cyc + 1.0f);
      }
      else if (u < 0.68f) {
        float q = (u - 0.42f) / 0.26f;
        float p = L * (0.54f + q * 0.28f);
        for (int k = -2; k <= 1; k++) {
          v = fmaxf(
            v,
            m93100Gauss(
              g - (p + (float)k * W * 0.9f),
              W * 0.24f
            )
          );
        }
        c = m93100RC((float)cyc + 2.0f);
      }
      else if (u < 0.86f) {
        float q = (u - 0.68f) / 0.18f;
        float p = L * (0.82f + q * 0.12f);
        v = fmaxf(
          m93100Gauss(g - p, W * 0.3f),
          m93100Gauss(g - (p - W), W * 0.2f)
        );
        c = m93100RC((float)cyc + 3.0f);
      }
      else {
        float q = (u - 0.86f) / 0.14f;
        float p = L * (0.94f + q * 0.05f);
        v = m93100Gauss(g - p, W * (0.8f - 0.45f * q));
        c = m93100RC((float)cyc + 4.0f);
      }
      break;
    }

    case 1: { // 94 Scatter Magnet
      const float pts[6] = {
        0.08f, 0.22f, 0.39f, 0.57f, 0.74f, 0.91f
      };

      if (u < 0.30f) {
        for (int k = 0; k < 6; k++) {
          v = fmaxf(
            v,
            m93100Gauss(g - L * pts[k], W * 0.2f)
          );
        }
        c = m93100RC((float)cyc);
      }
      else if (u < 0.56f) {
        float q = (u - 0.30f) / 0.26f;
        float center =
          L * (0.48f + 0.12f * sinf(t));

        for (int k = 0; k < 6; k++) {
          float p =
            L * pts[k] * (1.0f - q) +
            center * q;

          v = fmaxf(
            v,
            m93100Gauss(g - p, W * 0.25f)
          );
        }
        c = m93100RC((float)cyc + 1.0f);
      }
      else if (u < 0.78f) {
        float q = (u - 0.56f) / 0.22f;
        float center = L * 0.55f;

        for (int k = 0; k < 6; k++) {
          float p =
            center +
            (pts[k] - 0.5f) * L * q * 1.3f;

          v = fmaxf(
            v,
            m93100Gauss(g - p, W * 0.22f)
          );
        }
        c = m93100RC((float)cyc + 2.0f);
      }
      else {
        float q = (u - 0.78f) / 0.22f;
        float p = q * L;
        v = m93100Gauss(g - p, W * 0.45f);
        c = m93100RC((float)cyc + 3.0f);
      }
      break;
    }

    case 2: { // 95 Ribbon Fold
      if (u < 0.32f) {
        float p = u / 0.32f * L * 0.52f;
        v =
          m93100Gauss(g - p, W * 0.85f) *
          (0.55f + 0.45f * sinf((g - p) * 0.25f));
        c = m93100RC((float)cyc);
      }
      else if (u < 0.58f) {
        float q = (u - 0.32f) / 0.26f;
        float center = L * 0.56f;
        float sep = W * (0.4f + q * 2.3f);

        v = fmaxf(
          m93100Gauss(g - (center - sep), W * 0.45f),
          m93100Gauss(g - (center + sep), W * 0.45f)
        );
        c = m93100RC((float)cyc + 1.0f);
      }
      else if (u < 0.80f) {
        float q = (u - 0.58f) / 0.22f;
        float p = L * (0.56f - q * 0.28f);
        v = m93100Gauss(g - p, W * 0.5f);
        c = m93100RC((float)cyc + 2.0f);
      }
      else {
        float q = (u - 0.80f) / 0.20f;
        float p = L * (0.28f + q * 0.68f);
        v = m93100Gauss(g - p, W * 0.72f);
        c = m93100RC((float)cyc + 3.0f);
      }
      break;
    }

    case 3: { // 96 Pulse Ladder Burst
      float seg = L / 10.0f;
      int idx = (int)floorf(g / seg);

      if (u < 0.30f) {
        int step = (int)floorf((u / 0.30f) * 11.0f);
        v = (idx <= step) ? 1.0f : 0.03f;
        c = m93100RC((float)cyc);
      }
      else if (u < 0.55f) {
        float q = (u - 0.30f) / 0.25f;
        int parity = ((int)floorf(q * 8.0f)) % 2;
        v = ((idx % 2) == parity) ? 1.0f : 0.08f;
        c = m93100RC((float)cyc + 1.0f);
      }
      else if (u < 0.78f) {
        float p = (u - 0.55f) / 0.23f * L;
        v = fmaxf(
          m93100Gauss(g - p, W * 0.25f),
          fmaxf(
            m93100Gauss(g - (p - W), W * 0.2f),
            m93100Gauss(g - (p + W), W * 0.2f)
          )
        );
        c = m93100RC((float)cyc + 2.0f);
      }
      else {
        int blink = ((int)floorf((u - 0.78f) * 30.0f)) % 2;
        v = blink ? 1.0f : 0.0f;
        c = m93100RC((float)cyc + 3.0f);
      }
      break;
    }

    case 4: { // 97 Orbit Split Transfer
      if (u < 0.34f) {
        float p1 = u / 0.34f * L * 0.45f;
        float p2 = L * 0.18f + u / 0.34f * L * 0.30f;

        v = fmaxf(
          m93100Gauss(g - p1, W * 0.32f),
          m93100Gauss(g - p2, W * 0.32f)
        );
        c = m93100RC((float)cyc);
      }
      else if (u < 0.62f) {
        float q = (u - 0.34f) / 0.28f;
        float center = L * (0.5f + q * 0.25f);
        float sep = W * (0.4f + q * 2.0f);

        for (int k = -1; k <= 1; k++) {
          v = fmaxf(
            v,
            m93100Gauss(
              g - (center + (float)k * sep),
              W * 0.25f
            )
          );
        }
        c = m93100RC((float)cyc + 1.0f);
      }
      else if (u < 0.82f) {
        float q = (u - 0.62f) / 0.20f;
        float p = L * (0.75f + q * 0.18f);

        v = fmaxf(
          m93100Gauss(g - p, W * 0.35f),
          m93100Gauss(g - (p - W * 0.9f), W * 0.28f)
        );
        c = m93100RC((float)cyc + 2.0f);
      }
      else {
        float q = (u - 0.82f) / 0.18f;
        float p = L * (0.93f + q * 0.05f);
        v = m93100Gauss(g - p, W * (0.9f - 0.5f * q));
        c = m93100RC((float)cyc + 3.0f);
      }
      break;
    }

    case 5: { // 98 Cluster Snapback
      if (u < 0.28f) {
        float p = u / 0.28f * L * 0.42f;

        for (int k = 0; k < 3; k++) {
          v = fmaxf(
            v,
            m93100Gauss(
              g - (p - (float)k * W * 0.8f),
              W * 0.28f
            )
          );
        }
        c = m93100RC((float)cyc);
      }
      else if (u < 0.44f) {
        float p = L * 0.42f;
        v = m93100Gauss(g - p, W * 0.6f);
        c = m93100RC((float)cyc + 1.0f);
      }
      else if (u < 0.62f) {
        float q = (u - 0.44f) / 0.18f;
        float p = L * (0.42f - q * 0.14f);
        v = m93100Gauss(g - p, W * 0.35f);
        c = m93100RC((float)cyc + 2.0f);
      }
      else if (u < 0.84f) {
        float q = (u - 0.62f) / 0.22f;
        float p = L * (0.28f + q * 0.57f);
        v = m93100Gauss(g - p, W * 0.28f);
        c = m93100RC((float)cyc + 3.0f);
      }
      else {
        float q = (u - 0.84f) / 0.16f;
        float p = L * (0.85f + q * 0.12f);

        v = fmaxf(
          m93100Gauss(g - p, W * 0.25f),
          m93100Gauss(g - (p - W * 0.7f), W * 0.18f)
        );
        c = m93100RC((float)cyc + 4.0f);
      }
      break;
    }

    case 6: { // 99 Color Tunnel Break
      if (u < 0.28f) {
        float p = u / 0.28f * L * 0.45f;
        float rad = W * (0.4f + u / 0.28f * 1.8f);

        v = m93100Gauss(
          fabsf(fabsf(g - p) - rad),
          W * 0.2f
        );
        c = m93100RC((float)cyc);
      }
      else if (u < 0.56f) {
        float q = (u - 0.28f) / 0.28f;
        float p = L * (0.45f + q * 0.25f);
        float seg = W * 0.7f;
        int idx =
          (int)floorf((g - p + L) / seg);

        v = ((idx % 3) == 0)
          ? m93100Gauss(g - p, W * 2.5f)
          : 0.0f;

        c = m93100RC((float)(cyc + idx));
      }
      else if (u < 0.82f) {
        float q = (u - 0.56f) / 0.26f;
        float p = L * (0.70f + q * 0.23f);

        for (int k = 0; k < 5; k++) {
          v = fmaxf(
            v,
            m93100Gauss(
              g - (p - (float)k * W * 0.7f),
              W * 0.18f
            )
          );
        }
        c = m93100RC((float)cyc + 2.0f);
      }
      else {
        float q = (u - 0.82f) / 0.18f;
        float p = L * (0.93f + q * 0.05f);
        v = m93100Gauss(g - p, W * 0.4f);
        c = m93100RC((float)cyc + 3.0f);
      }
      break;
    }

    case 7: { // 100 Chaos Relay Finale
      int stage = (int)floorf(u * 6.0f);
      float q = fmodf(u * 6.0f, 1.0f);

      if (stage == 0) {
        float p = q * L * 0.4f;
        v = m93100Gauss(g - p, W * 0.3f);
        c = m93100RC((float)cyc);
      }
      else if (stage == 1) {
        float p = L * 0.4f;
        v = (q < 0.6f)
          ? m93100Gauss(g - p, W * 0.45f)
          : 0.0f;
        c = m93100RC((float)cyc + 1.0f);
      }
      else if (stage == 2) {
        float center = L * (0.4f + q * 0.2f);
        float sep = W * (0.3f + q * 1.8f);

        v = fmaxf(
          m93100Gauss(g - (center - sep), W * 0.25f),
          m93100Gauss(g - (center + sep), W * 0.25f)
        );
        c = m93100RC((float)cyc + 2.0f);
      }
      else if (stage == 3) {
        float p = L * (0.6f - q * 0.18f);
        v = m93100Gauss(g - p, W * 0.3f);
        c = m93100RC((float)cyc + 3.0f);
      }
      else if (stage == 4) {
        float p = L * (0.42f + q * 0.5f);
        v = m93100Gauss(g - p, W * (0.5f - 0.2f * q));
        c = m93100RC((float)cyc + 4.0f);
      }
      else {
        int blink = ((int)floorf(q * 8.0f)) % 2;
        v = blink ? 1.0f : 0.0f;
        c = m93100RC((float)cyc + 5.0f);
      }
      break;
    }
  }

  M93100Sample out;
  out.v = m93100Clamp(v);
  out.c = c;
  return out;
}

static uint8_t m93100Byte(float x) {
  int v = (int)floorf(x + 0.5f);
  if (v < 0) v = 0;
  if (v > 255) v = 255;
  return (uint8_t)v;
}


static float *m93100TrailV4[4] = {nullptr, nullptr, nullptr, nullptr};
static CRGB *m93100TrailColor4[4] = {nullptr, nullptr, nullptr, nullptr};
static uint8_t m93100TrailMode4[4] = {0,0,0,0};
static uint16_t m93100TrailCount4[4] = {0,0,0,0};

static inline int8_t m93100PhysicalSlot(CRGB *out) {
  if (out == leds1) return 0;
  if (out == leds2) return 1;
  if (out == leds3) return 2;
  if (out == leds4) return 3;
  return -1; // dummy / offscreen buffer
}

static void m93100ClearPhysicalTrail(uint8_t slot, uint16_t count) {
  if (slot > 3) return;
  if (count > STAGE0_LED_BUFFER) count = STAGE0_LED_BUFFER;
  for (uint16_t i=0; i<count; i++) {
    m93100TrailV4[slot][i] = 0.0f;
    m93100TrailColor4[slot][i] = CRGB::Black;
  }
  m93100TrailCount4[slot] = count;
  m93100TrailMode4[slot] = 0;
}

static void m93100ResetOutputTrail(uint8_t mode, CRGB *out, uint16_t count) {
  int8_t slot = m93100PhysicalSlot(out);
  if (slot < 0) return;
  m93100ClearPhysicalTrail((uint8_t)slot, count);
  m93100TrailMode4[(uint8_t)slot] = mode;
}

static void m93100RenderOutput(
  uint8_t mode,
  CRGB *out,
  uint8_t virtualCh,
  uint16_t count,
  float tf,
  unsigned long dtMs
) {
  if (!out || count == 0 || mode < 93 || mode > 100) return;
  if (count > STAGE0_LED_BUFFER) count = STAGE0_LED_BUFFER;

  const uint8_t id = (uint8_t)(mode - 93);
  const float t = (float)tf;
  const float N = (float)count;
  const int8_t slot = m93100PhysicalSlot(out);

  // HTML decay 0.58 per requestAnimationFrame (~16.667ms).
  // Karena GLOBAL boleh update 10..N ms, decay dinormalisasi terhadap waktu nyata
  // agar bentuk/ekor tidak berubah hanya karena interval scheduler.
  float decay = 0.58f;
  if (dtMs > 0UL) {
    decay = powf(0.58f, (float)dtMs / 16.667f);
    if (decay < 0.0f) decay = 0.0f;
    if (decay > 1.0f) decay = 1.0f;
  }

  if (slot >= 0) {
    uint8_t s = (uint8_t)slot;
    if (m93100TrailMode4[s] != mode || m93100TrailCount4[s] != count) {
      m93100ClearPhysicalTrail(s, count);
      m93100TrailMode4[s] = mode;
    }

    for (uint16_t i=0; i<count; i++) {
      const float g = (virtualCh == 0) ? (float)i : (N + (float)i);
      M93100Sample cur = m93100Sample(id, t, g, N);

      if ((float)cur.v >= m93100TrailV4[s][i]) {
        m93100TrailV4[s][i] = (float)cur.v;
        m93100TrailColor4[s][i] = CRGB(
          m93100Byte(cur.c.r),
          m93100Byte(cur.c.g),
          m93100Byte(cur.c.b)
        );
      } else {
        m93100TrailV4[s][i] = (float)((float)m93100TrailV4[s][i] * decay);
      }

      const float v = (float)m93100TrailV4[s][i];
      const CRGB c = m93100TrailColor4[s][i];
      out[i] = CRGB(
        m93100Byte((float)c.r * v),
        m93100Byte((float)c.g * v),
        m93100Byte((float)c.b * v)
      );
    }
  } else {
    // Dummy buffer hanya untuk menjaga renderer pair; tidak terlihat secara fisik.
    for (uint16_t i=0; i<count; i++) {
      const float g = (virtualCh == 0) ? (float)i : (N + (float)i);
      M93100Sample cur = m93100Sample(id, t, g, N);
      out[i] = CRGB(
        m93100Byte(cur.c.r * cur.v),
        m93100Byte(cur.c.g * cur.v),
        m93100Byte(cur.c.b * cur.v)
      );
    }
  }

  clearUnusedChannel(out);
}

static void m93100RenderPair(
  uint8_t mode,
  CRGB *out1,
  CRGB *out2,
  uint16_t count,
  float tf,
  unsigned long dtMs
) {
  m93100RenderOutput(mode, out1, 0, count, tf, dtMs);
  m93100RenderOutput(mode, out2, 1, count, tf, dtMs);
}


struct Custom91SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom91SuiteState c91Suite;

void updateCustom91Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  bool fresh = false;
  if (!sharedModeClockTick(c91Suite.t, c91Suite.lastUpdate, c91Suite.lastCall, c91Suite.nextDelay, dtMs, &fresh)) return;
  m7380RenderPair(91, out1, out2, count, c91Suite.t);
}

struct Custom92SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom92SuiteState c92Suite;

void updateCustom92Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  bool fresh = false;
  if (!sharedModeClockTick(c92Suite.t, c92Suite.lastUpdate, c92Suite.lastCall, c92Suite.nextDelay, dtMs, &fresh)) return;
  m7380RenderPair(92, out1, out2, count, c92Suite.t);
}

struct Custom93SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom93SuiteState c93Suite;

void updateCustom93Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  bool fresh = false;
  if (!sharedModeClockTick(c93Suite.t, c93Suite.lastUpdate, c93Suite.lastCall, c93Suite.nextDelay, dtMs, &fresh)) return;
  if (fresh) {
    m93100ResetOutputTrail(93, out1, count);
    m93100ResetOutputTrail(93, out2, count);
  }
  m93100RenderPair(93, out1, out2, count, c93Suite.t, dtMs);
}

struct Custom94SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom94SuiteState c94Suite;

void updateCustom94Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  bool fresh = false;
  if (!sharedModeClockTick(c94Suite.t, c94Suite.lastUpdate, c94Suite.lastCall, c94Suite.nextDelay, dtMs, &fresh)) return;
  if (fresh) {
    m93100ResetOutputTrail(94, out1, count);
    m93100ResetOutputTrail(94, out2, count);
  }
  m93100RenderPair(94, out1, out2, count, c94Suite.t, dtMs);
}

struct Custom95SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom95SuiteState c95Suite;

void updateCustom95Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  bool fresh = false;
  if (!sharedModeClockTick(c95Suite.t, c95Suite.lastUpdate, c95Suite.lastCall, c95Suite.nextDelay, dtMs, &fresh)) return;
  if (fresh) {
    m93100ResetOutputTrail(95, out1, count);
    m93100ResetOutputTrail(95, out2, count);
  }
  m93100RenderPair(95, out1, out2, count, c95Suite.t, dtMs);
}

struct Custom96SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom96SuiteState c96Suite;

void updateCustom96Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  bool fresh = false;
  if (!sharedModeClockTick(c96Suite.t, c96Suite.lastUpdate, c96Suite.lastCall, c96Suite.nextDelay, dtMs, &fresh)) return;
  if (fresh) {
    m93100ResetOutputTrail(96, out1, count);
    m93100ResetOutputTrail(96, out2, count);
  }
  m93100RenderPair(96, out1, out2, count, c96Suite.t, dtMs);
}

struct Custom97SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom97SuiteState c97Suite;

void updateCustom97Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  bool fresh = false;
  if (!sharedModeClockTick(c97Suite.t, c97Suite.lastUpdate, c97Suite.lastCall, c97Suite.nextDelay, dtMs, &fresh)) return;
  if (fresh) {
    m93100ResetOutputTrail(97, out1, count);
    m93100ResetOutputTrail(97, out2, count);
  }
  m93100RenderPair(97, out1, out2, count, c97Suite.t, dtMs);
}

struct Custom98SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom98SuiteState c98Suite;

void updateCustom98Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  bool fresh = false;
  if (!sharedModeClockTick(c98Suite.t, c98Suite.lastUpdate, c98Suite.lastCall, c98Suite.nextDelay, dtMs, &fresh)) return;
  if (fresh) {
    m93100ResetOutputTrail(98, out1, count);
    m93100ResetOutputTrail(98, out2, count);
  }
  m93100RenderPair(98, out1, out2, count, c98Suite.t, dtMs);
}

struct Custom99SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom99SuiteState c99Suite;

void updateCustom99Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  bool fresh = false;
  if (!sharedModeClockTick(c99Suite.t, c99Suite.lastUpdate, c99Suite.lastCall, c99Suite.nextDelay, dtMs, &fresh)) return;
  if (fresh) {
    m93100ResetOutputTrail(99, out1, count);
    m93100ResetOutputTrail(99, out2, count);
  }
  m93100RenderPair(99, out1, out2, count, c99Suite.t, dtMs);
}

struct Custom100SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom100SuiteState c100Suite;

void updateCustom100Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  bool fresh = false;
  if (!sharedModeClockTick(c100Suite.t, c100Suite.lastUpdate, c100Suite.lastCall, c100Suite.nextDelay, dtMs, &fresh)) return;
  if (fresh) {
    m93100ResetOutputTrail(100, out1, count);
    m93100ResetOutputTrail(100, out2, count);
  }
  m93100RenderPair(100, out1, out2, count, c100Suite.t, dtMs);
}


// =========================================================================
// MODE 101-120 — EXACT SOURCE FAMILY "20 Efek Baru Set 2"
// 101 Triple Block Launch
// 102 Split Rail
// 103 Pulse Stair
// 104 Diamond Runner
// 105 Flash Corridor
// 106 Triple Sling
// 107 Segment Fold
// 108 Wave Cutter
// 109 Twin Color Chase
// 110 Center Gate
// 111 Step Comet
// 112 Block Domino
// 113 Double Helix
// 114 Pulse Bridge
// 115 Scatter Line
// 116 Snap Runner
// 117 Color Blocks Relay
// 118 Breathing Train
// 119 Mirror Break
// 120 Grand Relay
//
// SOURCE behavior: virtual CH1 -> CH2 route, no artificial trail.
// GLOBAL physical mapping for this batch:
//   virtual A -> CH1 + CH4
//   virtual B -> CH2 + CH3
// Fastest scheduler frame remains 10 ms.
// K3 color override is not applied.
// =========================================================================

static const float M101120_PI = 3.14159265358979323846f;

static float m101120Clamp(float x) {
  return x < 0.0f ? 0.0f : (x > 1.0f ? 1.0f : x);
}

static float m101120Gauss(float d, float w) {
  return expf(-(d*d)/(2.0f*w*w));
}

static float m101120Block(float d, float w) {
  return m101120Clamp(1.0f-d/w);
}

static float m101120Hash(float n) {
  float x = sinf(n*12.9898f+78.233f)*43758.5453f;
  return x-floorf(x);
}

static float m101120Ping(float u, float L) {
  float q = fmodf(u,2.0f*L);
  if (q < 0.0f) q += 2.0f*L;
  return q < L ? q : 2.0f*L-q;
}

static int m101120MinInt(int a, int b) {
  return a < b ? a : b;
}

static int m101120ConstrainInt(int x, int a, int b) {
  return x < a ? a : (x > b ? b : x);
}

static const M101120Color m101120Palette[8] = {
  {255.0f,255.0f,255.0f},
  {255.0f,0.0f,0.0f},
  {0.0f,90.0f,255.0f},
  {180.0f,0.0f,255.0f},
  {0.0f,220.0f,120.0f},
  {255.0f,40.0f,150.0f},
  {0.0f,220.0f,255.0f},
  {120.0f,255.0f,0.0f}
};

static M101120Color m101120RC(int n, float s) {
  int i = (int)floorf(m101120Hash((float)n*7.17f+s)*8.0f);
  if (i < 0) i = 0;
  if (i > 7) i = 7;
  return m101120Palette[i];
}

static M101120Sample m101120Sample(uint8_t id,float t,float g,float N){
 const float L=N*2.0f,W=fmaxf(4.0f,N/10.0f);
 int cyc=floorf(t/5.6f); M101120Color col=m101120RC(cyc,id*2.71f),col2=m101120RC(cyc+1,id*4.13f),col3=m101120RC(cyc+2,id*5.91f);
 float u=fmodf(t,5.6f)/5.6f,v=0,p=0; M101120Color c=col;
 switch(id){
 case 0:{float ph;if(u<.22f){ph=u/.22f;for(int k=0;k<3;k++){float pp=L*(.08f+k*.11f),on=m101120Clamp(ph*3-k);v=fmaxf(v,m101120Block(fabsf(g-pp),W*.48f)*on);}c=col;}else if(u<.46f){ph=(u-.22f)/.24f;float p1=L*.08f+(L*.30f-L*.08f)*ph,p2=L*.19f+(L*.30f-L*.19f)*ph,p3=L*.30f;v=fmaxf(m101120Block(fabsf(g-p1),W*.48f),fmaxf(m101120Block(fabsf(g-p2),W*.48f),m101120Block(fabsf(g-p3),W*.48f)));c=col2;}else if(u<.68f){ph=(u-.46f)/.22f;p=L*.30f+ph*L*.25f;v=m101120Block(fabsf(g-p),W*(.75f+ph*.9f));c=col2;}else{ph=(u-.68f)/.32f;p=L*.55f+ph*L*.45f;for(int k=-1;k<=1;k++){float pp=p+k*W*(1.2f+ph*.8f);v=fmaxf(v,m101120Gauss(g-pp,W*.26f));}c=col3;}}break;
 case 1:{float q=u*L;if(u<.25f)v=m101120Gauss(g-q,W*.4f);else if(u<.72f){float sp=(u-.25f)/.47f*W*2.4f;v=fmaxf(m101120Gauss(g-(q-sp),W*.24f),m101120Gauss(g-(q+sp),W*.24f));}else{float m=L-(u-.72f)/.28f*L*.22f;v=m101120Gauss(g-m,W*(.7f-(u-.72f)*1.4f));}c=u<.5f?col:col2;}break;
 case 2:{float seg=L/9;int step=floorf(u*11),idx=floorf(g/seg);if(u<.42f)v=idx<=step?1:.04f;else if(u<.68f){p=(u-.42f)/.26f*L;v=fmaxf(.12f,m101120Gauss(g-p,W*.7f));}else{float cut=(u-.68f)/.32f*L;v=g>cut?.8f:.03f;}c=u<.42f?col:u<.68f?col2:col3;}break;
 case 3:p=u*L;if(u<.35f)v=fmaxf(m101120Gauss(g-(p-W*.7f),W*.18f),fmaxf(m101120Gauss(g-p,W*.45f),m101120Gauss(g-(p+W*.7f),W*.18f)));else if(u<.65f)v=m101120Gauss(g-p,W*(.8f-(u-.35f)*1.5f));else{float d=(u-.65f)/.35f*W*2.2f;v=fmaxf(m101120Gauss(g-(p-d),W*.23f),m101120Gauss(g-(p+d),W*.23f));}break;
 case 4:{float center=u*L,rad;if(u<.38f)rad=(u/.38f)*W*2.6f;else if(u<.72f)rad=W*2.6f;else rad=W*2.6f*(1-(u-.72f)/.28f);v=m101120Gauss(fabsf(g-center)-rad,W*.18f);if(u>.55f&&u<.72f)v=fmaxf(v,m101120Gauss(g-center,W*.55f));c=u<.5f?col:col2;}break;
 case 5:{float base=m101120Ping(t*24,L);for(int k=0;k<3;k++){float off=(k-1)*W*(1.2f+.7f*sinf(u*M101120_PI*2+k));v=fmaxf(v,m101120Gauss(g-(base+off),W*.24f));}if(u>.7f)v=fmaxf(v,m101120Gauss(g-m101120Ping(t*34,L),W*.18f));c=m101120RC(cyc+floorf(u*3),id);}break;
 case 6:p=u*L;if(u<.36f)v=m101120Block(fabsf(g-p),W*1.15f);else if(u<.63f){float d=(u-.36f)/.27f*W*2.2f;v=fmaxf(m101120Block(fabsf(g-(p-d)),W*.55f),m101120Block(fabsf(g-(p+d)),W*.55f));}else if(u<.78f){p=L-(u-.63f)/.15f*L*.3f;v=m101120Block(fabsf(g-p),W*.7f);}else{p=L*.7f+(u-.78f)/.22f*L*.3f;v=m101120Gauss(g-p,W*.3f);}c=u<.5f?col:col2;break;
 case 7:p=u*L;if(u<.35f)v=(.5f+.5f*sinf((g-p)*.18f))*m101120Gauss(g-p,W*2.8f);else if(u<.68f){int cell=floorf((g-p+L)/(W*.75f));v=(cell%2==0)?m101120Gauss(g-p,W*2.5f):0;}else v=(.5f+.5f*sinf((g-p)*.28f))*m101120Gauss(g-p,W*1.7f);c=u<.35f?col:u<.68f?col2:col3;break;
 case 8:{float p1=u*L,p2=fmaxf(0.0f,p1-W*2);if(u<.48f){v=fmaxf(m101120Gauss(g-p1,W*.28f),m101120Gauss(g-p2,W*.28f));c=fabsf(g-p1)<fabsf(g-p2)?col:col2;}else if(u<.72f){v=fmaxf(m101120Gauss(g-p1,W*.3f),m101120Gauss(g-p2,W*.3f));c=fabsf(g-p1)<fabsf(g-p2)?col2:col;}else{v=m101120Gauss(g-p1,W*.5f);c=col3;}}break;
 case 9:{float center=L*.5f,rad;if(u<.4f)rad=(u/.4f)*L*.42f;else if(u<.7f)rad=L*.42f;else rad=L*.42f-(u-.7f)/.3f*L*.25f;v=fmaxf(m101120Gauss(g-(center-rad),W*.23f),m101120Gauss(g-(center+rad),W*.23f));if(u>.7f)v=fmaxf(v,m101120Gauss(g-(L*.5f+(u-.7f)/.3f*L*.5f),W*.35f));c=u<.55f?col:col2;}break;
 case 10:{const float stp[]={.05f,.13f,.23f,.35f,.49f,.62f,.74f,.88f,.98f};if(u<.6f){int n=m101120MinInt(8,(int)floorf(u/.6f*9));p=stp[n]*L;}else if(u<.72f){p=L*.75f;v=fmaxf(v,m101120Gauss(g-p,W*1.3f));}else p=L*.75f+(u-.72f)/.28f*L*.25f;v=fmaxf(v,m101120Gauss(g-p,W*.32f));c=u<.6f?col:u<.72f?col2:col3;}break;
 case 11:{float seg=L/10;int head=floorf(u*13);if(u<.68f){int idx=floorf(g/seg);float f=head-idx;v=(f>=0&&f<3)?(1-f*.28f):.03f;}else{float p2=L-(u-.68f)/.32f*L;v=m101120Gauss(g-p2,W*.33f);}c=u<.68f?col:col2;}break;
 case 12:{float d=W*(.7f+1.4f*fabsf(sinf(u*M101120_PI*2)));p=u*L;v=fmaxf(m101120Gauss(g-(p-d),W*.24f),m101120Gauss(g-(p+d),W*.24f));if(u>.55f&&u<.72f)v=fmaxf(v,m101120Gauss(g-p,W*.45f));c=u<.5f?col:col2;}break;
 case 13:{float left=L*.15f,right=L*.85f;if(u<.35f){float e=u/.35f;v=fmaxf(m101120Block(fabsf(g-(left+e*L*.2f)),W*.55f),m101120Block(fabsf(g-(right-e*L*.2f)),W*.55f));}else if(u<.72f){p=(u-.35f)/.37f*L;v=fmaxf(.08f,m101120Gauss(g-p,W*.34f));}else{float cut=(u-.72f)/.28f*L;v=g>cut?m101120Gauss(g-L*.8f,W*2.4f):.02f;}c=u<.5f?col:col2;}break;
 case 14:{int seed=floorf(g/(W*.75f));float appear=m101120Hash(seed*3.1f+cyc);if(u<.33f)v=(appear<u/.33f)?(.35f+.65f*m101120Hash(seed+8)):0;else if(u<.66f){float center=L*.5f,pp=center+(g-center)*(1-(u-.33f)/.33f);v=m101120Gauss(g-pp,W*.22f);}else{p=(u-.66f)/.34f*L;v=fmaxf(m101120Gauss(g-p,W*.28f),m101120Gauss(g-(p-W*1.1f),W*.18f));}c=m101120RC(cyc+seed,id);}break;
 case 15:{const float j[]={.04f,.18f,.31f,.55f,.46f,.70f,.84f,.96f};if(u<.58f){float pos=u/.58f*7;int n=floorf(pos);float f=pos-n;n=m101120MinInt(n,7);p=(j[n]*(1-f)+j[m101120MinInt(n+1,7)]*f)*L;}else p=L*.58f+(u-.58f)/.42f*L*.42f;v=m101120Gauss(g-p,u<.58f?W*.28f:W*.4f);c=u<.58f?col:col2;}break;
 case 16:{float seg=L/6,shift=u*L;M101120Color cc[3]={col,col2,col3};for(int k=0;k<3;k++){float pp=fmodf(shift+k*seg*2,L),vv=m101120Block(fabsf(g-pp),W*.65f);if(vv>v){v=vv;c=cc[k];}}if(u>.72f){p=L-(u-.72f)/.28f*L*.3f;float vv=m101120Gauss(g-p,W*.32f);if(vv>v){v=vv;c=col2;}}}break;
 case 17:{float breath=.35f+.65f*(.5f-.5f*cosf(u*M101120_PI*6));for(int k=0;k<4;k++){float pp=fmodf(u*L-k*W*1.45f+L,L);v=fmaxf(v,m101120Gauss(g-pp,W*(.22f+.35f*breath)));}if(u>.62f&&u<.8f)v=fmaxf(v,m101120Gauss(g-L*.72f,W*1.3f));if(u>.8f){float d=(u-.8f)/.2f*W*2;v=fmaxf(m101120Gauss(g-(L*.72f-d),W*.28f),m101120Gauss(g-(L*.72f+d),W*.28f));}c=u<.5f?col:col2;}break;
 case 18:{float p1=u*L,p2=L-u*L;if(u<.48f)v=fmaxf(m101120Gauss(g-p1,W*.3f),m101120Gauss(g-p2,W*.3f));else if(u<.7f)v=fmaxf(m101120Gauss(g-(p1+W*1.3f),W*.23f),m101120Gauss(g-(p2-W*.4f),W*.42f));else{p=L*.55f+(u-.7f)/.3f*L*.45f;v=m101120Gauss(g-p,W*.36f);}c=u<.48f?col:u<.7f?col2:col3;}break;
 case 19:{float uu=fmodf(t,7.2f)/7.2f,lo=fmodf(uu*6,1.0f);int st=floorf(uu*6);M101120Color cc[6]={col,col2,col3,col,col2,col3};c=cc[m101120ConstrainInt(st,0,5)];if(st==0){p=lo*L;v=m101120Gauss(g-p,W*.36f);}else if(st==1){p=lo*L;v=fmaxf(m101120Gauss(g-(p-W),W*.24f),m101120Gauss(g-(p+W),W*.24f));}else if(st==2){float seg=L/8;int idx=floorf(g/seg);v=idx<=floorf(lo*9)?1:.04f;}else if(st==3){float center=L*.5f,rad=lo*L*.45f;v=fmaxf(m101120Gauss(g-(center-rad),W*.22f),m101120Gauss(g-(center+rad),W*.22f));}else if(st==4){p=L-lo*L;v=m101120Gauss(g-p,W*.4f);}else v=0;}break;
 }
 M101120Sample out; out.v=m101120Clamp(v); out.c=c; return out;
}

static uint8_t m101120Byte(float x) {
  int v = (int)floorf(x + 0.5f);
  if (v < 0) v = 0;
  if (v > 255) v = 255;
  return (uint8_t)v;
}

static void m101120RenderPair(
  uint8_t mode,
  CRGB *out1,
  CRGB *out2,
  uint16_t count,
  float tf
) {
  if (out1 == nullptr || out2 == nullptr || count == 0 || mode < 101 || mode > 120) return;
  const uint8_t id = (uint8_t)(mode - 101);
  const float t = (float)tf;
  const float N = (float)count;

  for (uint16_t i=0; i<count; i++) {
    M101120Sample a = m101120Sample(id, t, (float)i, N);
    M101120Sample b = m101120Sample(id, t, N + (float)i, N);
    out1[i] = CRGB(
      m101120Byte(a.c.r*a.v),
      m101120Byte(a.c.g*a.v),
      m101120Byte(a.c.b*a.v)
    );
    out2[i] = CRGB(
      m101120Byte(b.c.r*b.v),
      m101120Byte(b.c.g*b.v),
      m101120Byte(b.c.b*b.v)
    );
  }
  clearUnusedChannel(out1);
  clearUnusedChannel(out2);
}


struct Custom101SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom101SuiteState c101Suite;

void updateCustom101Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c101Suite.t, c101Suite.lastUpdate, c101Suite.lastCall, c101Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(101, out1, out2, count, c101Suite.t);
}

struct Custom102SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom102SuiteState c102Suite;

void updateCustom102Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c102Suite.t, c102Suite.lastUpdate, c102Suite.lastCall, c102Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(102, out1, out2, count, c102Suite.t);
}

struct Custom103SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom103SuiteState c103Suite;

void updateCustom103Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c103Suite.t, c103Suite.lastUpdate, c103Suite.lastCall, c103Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(103, out1, out2, count, c103Suite.t);
}

struct Custom104SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom104SuiteState c104Suite;

void updateCustom104Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c104Suite.t, c104Suite.lastUpdate, c104Suite.lastCall, c104Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(104, out1, out2, count, c104Suite.t);
}

struct Custom105SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom105SuiteState c105Suite;

void updateCustom105Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c105Suite.t, c105Suite.lastUpdate, c105Suite.lastCall, c105Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(105, out1, out2, count, c105Suite.t);
}

struct Custom106SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom106SuiteState c106Suite;

void updateCustom106Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c106Suite.t, c106Suite.lastUpdate, c106Suite.lastCall, c106Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(106, out1, out2, count, c106Suite.t);
}

struct Custom107SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom107SuiteState c107Suite;

void updateCustom107Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c107Suite.t, c107Suite.lastUpdate, c107Suite.lastCall, c107Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(107, out1, out2, count, c107Suite.t);
}

struct Custom108SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom108SuiteState c108Suite;

void updateCustom108Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c108Suite.t, c108Suite.lastUpdate, c108Suite.lastCall, c108Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(108, out1, out2, count, c108Suite.t);
}

struct Custom109SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom109SuiteState c109Suite;

void updateCustom109Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c109Suite.t, c109Suite.lastUpdate, c109Suite.lastCall, c109Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(109, out1, out2, count, c109Suite.t);
}

struct Custom110SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom110SuiteState c110Suite;

void updateCustom110Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c110Suite.t, c110Suite.lastUpdate, c110Suite.lastCall, c110Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(110, out1, out2, count, c110Suite.t);
}

struct Custom111SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom111SuiteState c111Suite;

void updateCustom111Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c111Suite.t, c111Suite.lastUpdate, c111Suite.lastCall, c111Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(111, out1, out2, count, c111Suite.t);
}

struct Custom112SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom112SuiteState c112Suite;

void updateCustom112Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c112Suite.t, c112Suite.lastUpdate, c112Suite.lastCall, c112Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(112, out1, out2, count, c112Suite.t);
}

struct Custom113SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom113SuiteState c113Suite;

void updateCustom113Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c113Suite.t, c113Suite.lastUpdate, c113Suite.lastCall, c113Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(113, out1, out2, count, c113Suite.t);
}

struct Custom114SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom114SuiteState c114Suite;

void updateCustom114Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c114Suite.t, c114Suite.lastUpdate, c114Suite.lastCall, c114Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(114, out1, out2, count, c114Suite.t);
}

struct Custom115SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom115SuiteState c115Suite;

void updateCustom115Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c115Suite.t, c115Suite.lastUpdate, c115Suite.lastCall, c115Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(115, out1, out2, count, c115Suite.t);
}

struct Custom116SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom116SuiteState c116Suite;

void updateCustom116Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c116Suite.t, c116Suite.lastUpdate, c116Suite.lastCall, c116Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(116, out1, out2, count, c116Suite.t);
}

struct Custom117SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom117SuiteState c117Suite;

void updateCustom117Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c117Suite.t, c117Suite.lastUpdate, c117Suite.lastCall, c117Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(117, out1, out2, count, c117Suite.t);
}

struct Custom118SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom118SuiteState c118Suite;

void updateCustom118Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c118Suite.t, c118Suite.lastUpdate, c118Suite.lastCall, c118Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(118, out1, out2, count, c118Suite.t);
}

struct Custom119SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom119SuiteState c119Suite;

void updateCustom119Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c119Suite.t, c119Suite.lastUpdate, c119Suite.lastCall, c119Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(119, out1, out2, count, c119Suite.t);
}

struct Custom120SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom120SuiteState c120Suite;

void updateCustom120Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c120Suite.t, c120Suite.lastUpdate, c120Suite.lastCall, c120Suite.nextDelay, dtMs, nullptr)) return;
  m101120RenderPair(120, out1, out2, count, c120Suite.t);
}


// =========================================================================
// MODE 121-140 — EXACT HTML "20 Efek Independen CH1 & CH2"
// 121 Opposite Blaster
// 122 Dual Scanner Morph
// 123 Block Race
// 124 Mirror Breaker
// 125 Pulse Clash
// 126 Triple Wave Split
// 127 Segment Shuffle
// 128 Comet vs Blocks
// 129 Center Explosion
// 130 Alternating Chase
// 131 Color Ladder Duo
// 132 Random Burst Grid
// 133 Twin Orbit
// 134 Domino Reverse
// 135 Breath Runner
// 136 Split Merge Duo
// 137 Step Flash
// 138 Cluster Dance
// 139 Gate Pulse
// 140 Independent Finale
//
// Sumber: HTML user. CH1 dan CH2 independen, tanpa ekor.
// GLOBAL fisik batch ini: CH1=CH3 dan CH2=CH4.
// =========================================================================
static const float M121140_PI = 3.14159265358979323846f;

static float m121140Clamp(float v, float a=0.0f, float b=1.0f) {
  if (v < a) return a;
  if (v > b) return b;
  return v;
}
static float m121140Gauss(float d, float w) {
  return expf(-(d*d)/(2.0f*w*w));
}
static float m121140Block(float d, float w) {
  return m121140Clamp(1.0f-d/w);
}
static float m121140Ping(float u, float L) {
  float q = fmodf(u,2.0f*L);
  if (q < 0.0f) q += 2.0f*L;
  return q < L ? q : 2.0f*L-q;
}
static float m121140Hash(float n) {
  float x = sinf(n*12.9898f+78.233f)*43758.5453f;
  return x-floorf(x);
}
static const M121140Color m121140Pal[8] = {
  {255.0f,255.0f,255.0f}, {255.0f,0.0f,0.0f}, {0.0f,90.0f,255.0f}, {180.0f,0.0f,255.0f},
  {0.0f,220.0f,120.0f}, {255.0f,40.0f,150.0f}, {0.0f,220.0f,255.0f}, {120.0f,255.0f,0.0f}
};
static M121140Color m121140RC(float c, float seed=0.0f) {
  int idx = (int)floorf(m121140Hash(c*7.17f+seed)*8.0f);
  if (idx < 0) idx = 0;
  if (idx > 7) idx = 7;
  return m121140Pal[idx];
}

static M121140Sample m121140Sample(uint8_t id, float t, float i, float N, int ch) {
  const float W=fmaxf(4.0f,N/10.0f);
  const int cyc=(int)floorf(t/5.8f);
  float u=fmodf(t,5.8f)/5.8f;
  if (u < 0.0f) u += 1.0f;
  M121140Color col=m121140RC((float)cyc,(float)id*2.3f+(float)ch*4.7f);
  M121140Color col2=m121140RC((float)(cyc+1),(float)id*4.1f+(float)ch*6.3f);
  M121140Color col3=m121140RC((float)(cyc+2),(float)id*5.9f+(float)ch*3.2f);
  float v=0.0f,p=0.0f; M121140Color c=col;
  switch(id) {
    case 0:
      if(u<.25f){p=ch==0?u/.25f*N:N-u/.25f*N;v=m121140Gauss(i-p,W*.35f);}
      else if(u<.5f){p=ch==0?N-(u-.25f)/.25f*N:(u-.25f)/.25f*N;v=m121140Gauss(i-p,W*.8f);c=col2;}
      else if(u<.75f){p=m121140Ping((u-.5f)*N*8.0f+(ch?N*.4f:0.0f),N);v=fmaxf(m121140Gauss(i-p,W*.22f),m121140Gauss(i-(p-W),W*.18f));c=col2;}
      else{float q=(u-.75f)/.25f;v=(((int)floorf(i/(W*.8f)+q*8.0f+(float)ch))%3==0)?1.0f:.08f;c=col3;}
    break;
    case 1:
      p=m121140Ping(t*(ch?18.0f:24.0f),N);
      if(u<.33f)v=m121140Gauss(i-p,W*(ch?1.0f:.35f));
      else if(u<.66f){v=m121140Gauss(i-p,W*(ch?.35f:1.0f));c=col2;}
      else{p=m121140Ping(t*(ch?25.0f:16.0f),N);v=fmaxf(m121140Gauss(i-p,W*.22f),m121140Gauss(i-(N-p),W*.22f));c=col3;}
    break;
    case 2:{
      int cnt=u<.33f?(ch?2:3):u<.66f?(ch?5:4):(ch?3:6); float seg=N/(float)cnt;
      float shift=fmodf(t*(ch?13.0f:18.0f),N); float x=fmodf(i-shift+N,N); int idx=(int)floorf(x/seg); float local=x-(float)idx*seg;
      v=(local>seg*.15f&&local<seg*.82f)?1.0f:.08f; c=m121140RC((float)(cyc+idx+ch*2),(float)id);
    }break;
    case 3:
      if(u<.3f){p=ch==0?u/.3f*N:N-u/.3f*N;v=m121140Gauss(i-p,W*.4f);}
      else if(u<.62f){if(ch==0){for(int k=0;k<4;k++){float pp=fmodf(u*N*2.0f+(float)k*N/4.0f,N);v=fmaxf(v,m121140Gauss(i-pp,W*.18f));}}else{p=N*.5f;v=m121140Block(fabsf(i-p),W*(.5f+(u-.3f)*4.0f));}c=col2;}
      else{p=ch==0?N-(u-.62f)/.38f*N:(u-.62f)/.38f*N;v=m121140Gauss(i-p,W*.3f);c=col3;}
    break;
    case 4:
      p=m121140Ping(t*(ch?20.0f:28.0f),N);
      if(u<.42f)v=m121140Gauss(i-p,W*(.25f+1.0f*fabsf(sinf(u*M121140_PI*4.0f+(float)ch))));
      else if(u<.72f){v=m121140Gauss(i-p,W*(1.2f-(u-.42f)*2.5f));c=col2;}
      else{v=(((int)floorf(u*40.0f+i/(W*.6f)+(float)ch))%4==0)?1.0f:0.0f;c=col3;}
    break;
    case 5:
      p=ch==0?u*N:N-u*N;
      if(u<.4f){int heads=ch?2:3;for(int k=0;k<heads;k++)v=fmaxf(v,m121140Gauss(i-(p+(float)k*W*(ch?-1.0f:1.0f)),W*.25f));}
      else if(u<.7f){v=(.5f+.5f*sinf((i-p)*.35f))*m121140Gauss(i-p,W*2.0f);c=col2;}
      else{p=ch==0?N-u*N:u*N;v=m121140Gauss(i-p,W*.4f);c=col3;}
    break;
    case 6:{
      float seg=W*.85f; float shift=floorf(u*9.0f+(float)ch*2.0f)*seg; int idx=(int)floorf(fmodf(i+shift,N)/seg);
      v=(idx%3==0)?1.0f:.08f; if(u>.5f&&u<.72f)v=(idx%2==ch)?1.0f:.08f;
      if(u>.72f){p=m121140Ping(t*(ch?19.0f:27.0f),N);v=fmaxf(v*.2f,m121140Gauss(i-p,W*.25f));}
      c=m121140RC((float)(cyc+idx+(int)floorf(u*3.0f)),(float)(id+ch));
    }break;
    case 7:
      if((u<.5f&&ch==0)||(u>=.5f&&ch==1)){p=ch==0?u*2.0f*N:(u-.5f)*2.0f*N;v=m121140Gauss(i-p,W*.55f);}
      else{float q=(u<.5f?u*2.0f:(u-.5f)*2.0f),seg=N/6.0f,x=fmodf(i-q*N+N,N);int idx=(int)floorf(x/seg);float local=x-(float)idx*seg;v=(local<seg*.58f)?1.0f:.08f;}
      c=u<.5f?col:col2;
    break;
    case 8:{
      float center=N*.5f,rad;if(u<.35f)rad=(u/.35f)*N*.48f;else if(u<.62f)rad=N*.48f*(1.0f-(u-.35f)/.27f);else rad=(u-.62f)/.38f*N*.48f;
      if(ch==1)rad=N*.48f-rad;v=fmaxf(m121140Gauss(i-(center-rad),W*.25f),m121140Gauss(i-(center+rad),W*.25f));c=u<.35f?col:(u<.62f?col2:col3);
    }break;
    case 9:
      if(u<.38f){p=ch==0?u/.38f*N:N-u/.38f*N;v=m121140Gauss(i-p,W*.3f);}
      else if(u<.55f){p=m121140Ping(t*(ch?20.0f:26.0f),N);v=m121140Gauss(i-p,W*.24f);c=col2;}
      else{for(int k=0;k<3;k++){float pp=m121140Ping((u-.55f)*N*7.0f+(float)k*N/3.0f+(ch?N*.2f:0.0f),N);v=fmaxf(v,m121140Gauss(i-pp,W*.2f));}c=col2;}
    break;
    case 10:{
      float seg=N/8.0f; int idx=(int)floorf(i/seg),step=(int)floorf(u*10.0f);
      v=(ch==0 ? idx<=step%9 : idx>=7-step%9) ? 1.0f : .08f;
      if(u>.62f){p=ch==0?(u-.62f)/.38f*N:N-(u-.62f)/.38f*N;v=fmaxf(v*.2f,m121140Gauss(i-p,W*.22f));c=col2;}
    }break;
    case 11:{
      int cell=(int)floorf(i/(W*.7f)),phase=(int)floorf(u*12.0f);
      bool on=m121140Hash((float)cell*2.7f+(float)phase+(float)ch*8.0f)<.28f;
      v=on?1.0f:.08f;
      if(u>.6f){int order=(cell+phase+ch)%5;v=order==0?1.0f:.08f;c=col2;}
    }break;
    case 12:{
      float d=W*(1.0f+1.2f*sinf(u*M121140_PI*2.0f+(float)ch*M121140_PI/2.0f));
      p=m121140Ping(t*(ch?22.0f:29.0f),N);
      v=fmaxf(m121140Gauss(i-(p-d),W*.23f),m121140Gauss(i-(p+d),W*.23f));
      if(u>.55f){c=col2;if(u>.78f)v=fmaxf(v,m121140Gauss(i-p,W*.4f));}
    }break;
    case 13:{
      float seg=N/10.0f; int idx=(int)floorf(i/seg),step=(int)floorf(u*13.0f);
      if(u<.55f)v=(ch==0?idx<=step:idx>=9-step)?1.0f:.08f;
      else{float rev=(u-.55f)/.45f;p=ch==0?N-rev*N:rev*N;v=m121140Gauss(i-p,W*.32f);c=col2;}
    }break;
    case 14:
      p=m121140Ping(t*(ch?21.0f:29.0f),N);
      if(u<.45f)v=m121140Gauss(i-p,W*(.22f+.75f*(.5f-.5f*cosf(u*M121140_PI*6.0f+(float)ch))));
      else if(u<.72f){v=m121140Gauss(i-p,W*.8f);c=col2;}
      else{for(int k=0;k<2;k++)v=fmaxf(v,m121140Gauss(i-(p+(float)k*W*(ch?-1.0f:1.0f)),W*.22f));c=col3;}
    break;
    case 15:
      if(ch==0){
        if(u<.5f){p=u*2.0f*N;float d=u/.5f*W*1.7f;v=fmaxf(m121140Gauss(i-(p-d),W*.24f),m121140Gauss(i-(p+d),W*.24f));}
        else{p=(u-.5f)*2.0f*N;v=m121140Gauss(i-p,W*.5f);c=col2;}
      }else{
        if(u<.5f){float p1=u*2.0f*N,p2=N-u*2.0f*N;v=fmaxf(m121140Gauss(i-p1,W*.25f),m121140Gauss(i-p2,W*.25f));}
        else{p=N-(u-.5f)*2.0f*N;float d=(u-.5f)*2.0f*W*1.7f;v=fmaxf(m121140Gauss(i-(p-d),W*.22f),m121140Gauss(i-(p+d),W*.22f));c=col2;}
      }
    break;
    case 16:{
      const float steps[6]={.05f,.16f,.31f,.49f,.70f,.88f}; float pos=u*6.0f; int n=(int)floorf(pos); if(n>5)n=5;
      p=steps[n]*N;if(ch)p=N-p;
      if(u<.6f)v=m121140Gauss(i-p,W*.27f);
      else if(u<.73f){v=(((int)floorf(t*18.0f+i/(W*.5f)+(float)ch))%5==0)?1.0f:0.0f;c=col2;}
      else{p=ch==0?(u-.73f)/.27f*N:N-(u-.73f)/.27f*N;v=m121140Gauss(i-p,W*.38f);c=col3;}
    }break;
    case 17:
      if(u<.4f){for(int k=0;k<3;k++){float pp=m121140Ping(t*(12.0f+(float)k*4.0f+(float)ch*2.0f)+(float)k*N/3.0f,N);v=fmaxf(v,m121140Gauss(i-pp,W*.28f));}}
      else if(u<.68f){p=N*(ch?.62f:.38f);v=m121140Gauss(i-p,W*1.2f);c=col2;}
      else{for(int k=0;k<4;k++){float pp=m121140Ping((u-.68f)*N*8.0f+(float)k*N/4.0f+(ch?N*.15f:0.0f),N);v=fmaxf(v,m121140Gauss(i-pp,W*.2f));}c=col3;}
    break;
    case 18:{
      float center=N*.5f,rad;if(u<.5f)rad=(u/.5f)*N*.47f;else rad=(1.0f-(u-.5f)/.5f)*N*.47f;
      if(ch==1)rad=N*.47f-rad;
      v=fmaxf(m121140Gauss(i-(center-rad),W*.22f),m121140Gauss(i-(center+rad),W*.22f));
      if(u>.65f){p=m121140Ping(t*(ch?20.0f:27.0f),N);v=fmaxf(v,m121140Gauss(i-p,W*.28f));c=col2;}
    }break;
    case 19:{
      float uu=fmodf(t,7.4f)/7.4f;if(uu<0.0f)uu+=1.0f;int st=(int)floorf(uu*6.0f);float lo=fmodf(uu*6.0f,1.0f);
      int sv=(st+ch*2)%6; M121140Color seq[6]={col,col2,col3,col,col2,col3}; c=seq[sv];
      if(sv==0){p=ch==0?lo*N:N-lo*N;v=m121140Gauss(i-p,W*.35f);}
      else if(sv==1){p=lo*N;float d=W*(.5f+lo*1.6f);v=fmaxf(m121140Gauss(i-(p-d),W*.22f),m121140Gauss(i-(p+d),W*.22f));}
      else if(sv==2){float seg=N/7.0f;int idx=(int)floorf(i/seg);v=((idx+(int)floorf(lo*8.0f)+ch)%3==0)?1.0f:.08f;}
      else if(sv==3){p=N*.5f;v=m121140Gauss(i-p,W*(.3f+lo*2.0f));}
      else if(sv==4){p=ch==0?N-lo*N:lo*N;v=m121140Gauss(i-p,W*.42f);}
      else{p=m121140Ping(t*(ch?24.0f:30.0f),N);v=m121140Gauss(i-p,W*.20f);}
    }break;
    default: break;
  }
  // Exact HTML fallback head untuk area sangat redup.
  if(v<.015f){float hp=m121140Ping(t*(18.0f+(float)ch*5.0f)+(float)id*3.7f,N);v=m121140Gauss(i-hp,W*.16f)*.22f;c=col3;}
  M121140Sample out; out.v=m121140Clamp(v); out.c=c; return out;
}

static uint8_t m121140Byte(float x) {
  int v=(int)floorf(x+0.5f); if(v<0)v=0; if(v>255)v=255; return (uint8_t)v;
}
static CRGB m121140RenderHtml100(const M121140Sample &s) {
  const float v=s.v; float rr=s.c.r*v*1.55f+18.0f*v,gg=s.c.g*v*1.55f+18.0f*v,bb=s.c.b*v*1.55f+18.0f*v;
  if(rr>255.0f)rr=255.0f; if(gg>255.0f)gg=255.0f; if(bb>255.0f)bb=255.0f;
  return CRGB(m121140Byte(rr),m121140Byte(gg),m121140Byte(bb));
}
static void m121140RenderPair(uint8_t mode, CRGB *out1, CRGB *out2, uint16_t count, float t) {
  if (!out1 || !out2 || count == 0 || mode < 121 || mode > 140) return;
  const uint8_t id=(uint8_t)(mode-121); const float N=(float)count;
  for(uint16_t i=0;i<count;i++){
    M121140Sample a=m121140Sample(id,t,(float)i,N,0);
    M121140Sample b=m121140Sample(id,t,(float)i,N,1);
    out1[i]=m121140RenderHtml100(a); out2[i]=m121140RenderHtml100(b);
  }
}

struct Custom121SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom121SuiteState c121Suite;
void updateCustom121Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c121Suite.t, c121Suite.lastUpdate, c121Suite.lastCall, c121Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(121, out1, out2, count, c121Suite.t);
}

struct Custom122SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom122SuiteState c122Suite;
void updateCustom122Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c122Suite.t, c122Suite.lastUpdate, c122Suite.lastCall, c122Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(122, out1, out2, count, c122Suite.t);
}

struct Custom123SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom123SuiteState c123Suite;
void updateCustom123Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c123Suite.t, c123Suite.lastUpdate, c123Suite.lastCall, c123Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(123, out1, out2, count, c123Suite.t);
}

struct Custom124SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom124SuiteState c124Suite;
void updateCustom124Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c124Suite.t, c124Suite.lastUpdate, c124Suite.lastCall, c124Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(124, out1, out2, count, c124Suite.t);
}

struct Custom125SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom125SuiteState c125Suite;
void updateCustom125Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c125Suite.t, c125Suite.lastUpdate, c125Suite.lastCall, c125Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(125, out1, out2, count, c125Suite.t);
}

struct Custom126SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom126SuiteState c126Suite;
void updateCustom126Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c126Suite.t, c126Suite.lastUpdate, c126Suite.lastCall, c126Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(126, out1, out2, count, c126Suite.t);
}

struct Custom127SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom127SuiteState c127Suite;
void updateCustom127Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c127Suite.t, c127Suite.lastUpdate, c127Suite.lastCall, c127Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(127, out1, out2, count, c127Suite.t);
}

struct Custom128SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom128SuiteState c128Suite;
void updateCustom128Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c128Suite.t, c128Suite.lastUpdate, c128Suite.lastCall, c128Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(128, out1, out2, count, c128Suite.t);
}

struct Custom129SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom129SuiteState c129Suite;
void updateCustom129Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c129Suite.t, c129Suite.lastUpdate, c129Suite.lastCall, c129Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(129, out1, out2, count, c129Suite.t);
}

struct Custom130SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom130SuiteState c130Suite;
void updateCustom130Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c130Suite.t, c130Suite.lastUpdate, c130Suite.lastCall, c130Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(130, out1, out2, count, c130Suite.t);
}

struct Custom131SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom131SuiteState c131Suite;
void updateCustom131Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c131Suite.t, c131Suite.lastUpdate, c131Suite.lastCall, c131Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(131, out1, out2, count, c131Suite.t);
}

struct Custom132SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom132SuiteState c132Suite;
void updateCustom132Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c132Suite.t, c132Suite.lastUpdate, c132Suite.lastCall, c132Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(132, out1, out2, count, c132Suite.t);
}

struct Custom133SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom133SuiteState c133Suite;
void updateCustom133Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c133Suite.t, c133Suite.lastUpdate, c133Suite.lastCall, c133Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(133, out1, out2, count, c133Suite.t);
}

struct Custom134SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom134SuiteState c134Suite;
void updateCustom134Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c134Suite.t, c134Suite.lastUpdate, c134Suite.lastCall, c134Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(134, out1, out2, count, c134Suite.t);
}

struct Custom135SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom135SuiteState c135Suite;
void updateCustom135Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c135Suite.t, c135Suite.lastUpdate, c135Suite.lastCall, c135Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(135, out1, out2, count, c135Suite.t);
}

struct Custom136SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom136SuiteState c136Suite;
void updateCustom136Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c136Suite.t, c136Suite.lastUpdate, c136Suite.lastCall, c136Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(136, out1, out2, count, c136Suite.t);
}

struct Custom137SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom137SuiteState c137Suite;
void updateCustom137Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c137Suite.t, c137Suite.lastUpdate, c137Suite.lastCall, c137Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(137, out1, out2, count, c137Suite.t);
}

struct Custom138SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom138SuiteState c138Suite;
void updateCustom138Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c138Suite.t, c138Suite.lastUpdate, c138Suite.lastCall, c138Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(138, out1, out2, count, c138Suite.t);
}

struct Custom139SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom139SuiteState c139Suite;
void updateCustom139Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c139Suite.t, c139Suite.lastUpdate, c139Suite.lastCall, c139Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(139, out1, out2, count, c139Suite.t);
}

struct Custom140SuiteState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom140SuiteState c140Suite;
void updateCustom140Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long dtMs = 0;
  if (!sharedModeClockTick(c140Suite.t, c140Suite.lastUpdate, c140Suite.lastCall, c140Suite.nextDelay, dtMs, nullptr)) return;
  m121140RenderPair(140, out1, out2, count, c140Suite.t);
}

// ============================================================================
// MODE 141-160 — EXACT HTML "20 Efek Blok Panjang + Ekor 3-5"
// 141 Long Block Relay
// 142 Dual Long Scanner
// 143 Block Train 3x
// 144 Split Long Block
// 145 Long Pulse Runner
// 146 Long Zigzag
// 147 Color Block Swap
// 148 Reverse Long Chase
// 149 Twin Long Blocks
// 150 Long Center Out
// 151 Step Block Runner
// 152 Block Burst Chain
// 153 Long Orbit Pair
// 154 Block Ladder
// 155 Breathing Block
// 156 Block Bounce Duo
// 157 Long Domino
// 158 Triple Color Blocks
// 159 Gate Block
// 160 Long Finale
// Sumber HTML user: CH1/CH2 independen, blok ±10 LED, ekor 3-5 LED.
// GLOBAL fisik: CH1=CH3 dan CH2=CH4.
// RAM LOCK: seluruh keluarga 141-160 memakai SATU state kecil per channel,
// bukan 20 state per-mode dan tanpa buffer LED besar baru.
// ============================================================================
static const float M141160_PI = 3.14159265358979323846f;

static float m141160Clamp(float v, float a=0.0f, float b=1.0f) {
  return v<a?a:(v>b?b:v);
}
static float m141160Hash(float n) {
  float x=sinf(n*12.9898f+78.233f)*43758.5453f;
  return x-floorf(x);
}
static float m141160Ping(float u, float L) {
  float twoL=2.0f*L;
  float q=fmodf(fmodf(u,twoL)+twoL,twoL);
  return q<L?q:twoL-q;
}
static const M141160Color m141160Pal[8] = {
  {255.0f,255.0f,255.0f}, {255.0f,0.0f,0.0f}, {0.0f,90.0f,255.0f}, {180.0f,0.0f,255.0f},
  {0.0f,220.0f,120.0f}, {255.0f,40.0f,150.0f}, {0.0f,220.0f,255.0f}, {120.0f,255.0f,0.0f}
};
static M141160Color m141160RC(float c, float seed=0.0f) {
  int idx=(int)floorf(m141160Hash(c*7.17f+seed)*8.0f);
  if(idx<0)idx=0; if(idx>7)idx=7;
  return m141160Pal[idx];
}
static int m141160MinInt(int a,int b){ return a<b?a:b; }
static float m141160LongBlock(float i,float p,int dir,float N,float len=10.0f,float tail=4.0f) {
  (void)N;
  float half=len/2.0f,d=i-p;
  if(fabsf(d)<=half)return 1.0f;
  float td=dir>0?(p-half-i):(i-(p+half));
  if(td>0.0f&&td<=tail)return 1.0f-td/(tail+1.0f);
  return 0.0f;
}
static float m141160TwoBlocks(float i,float p1,float p2,int dir1,int dir2,float N,float len,float tail) {
  return fmaxf(m141160LongBlock(i,p1,dir1,N,len,tail),m141160LongBlock(i,p2,dir2,N,len,tail));
}

static M141160Sample m141160Sample(uint8_t id,float t,float i,float N,int ch) {
  int cyc=(int)floorf(t/6.0f);
  float u=fmodf(t,6.0f)/6.0f; if(u<0.0f)u+=1.0f;
  M141160Color c1=m141160RC((float)cyc,(float)id*2.1f+(float)ch*4.7f);
  M141160Color c2=m141160RC((float)(cyc+1),(float)id*4.3f+(float)ch*3.1f);
  M141160Color c3=m141160RC((float)(cyc+2),(float)id*6.2f+(float)ch*5.4f);
  float v=0.0f,p=0.0f,len=10.0f,tail=4.0f;
  M141160Color c=c1;
  int dir=1;

  switch(id) {
    case 0:
      if(u<.33f){dir=ch?-1:1;p=dir>0?u/.33f*N:N-u/.33f*N;v=m141160LongBlock(i,p,dir,N,10,4);}
      else if(u<.58f){dir=ch?1:-1;p=dir>0?(u-.33f)/.25f*N:N-(u-.33f)/.25f*N;v=m141160LongBlock(i,p,dir,N,12,3);c=c2;}
      else{dir=ch?-1:1;p=dir>0?(u-.58f)/.42f*N:N-(u-.58f)/.42f*N;v=m141160LongBlock(i,p,dir,N,10,5);c=c3;}
    break;

    case 1:
      p=m141160Ping(t*(ch?18.0f:23.0f),N);dir=sinf(t*(ch?18.0f:23.0f))>=0?1:-1;
      len=u<.33f?10:u<.66f?14:9;tail=u<.5f?3:5;v=m141160LongBlock(i,p,dir,N,len,tail);c=u<.33f?c1:(u<.66f?c2:c3);
    break;

    case 2:
      for(int k=0;k<3;k++){
        float sp=u<.5f?14.0f:21.0f;
        float pp=m141160Ping(t*sp+(float)k*(N/3.0f)+(ch?N*.15f:0.0f),N);
        int dd=sinf((t*sp+(float)k*N/3.0f)/N*M141160_PI)>=0?1:-1;
        v=fmaxf(v,m141160LongBlock(i,pp,dd,N,10,5));
      }
      c=u<.4f?c1:(u<.72f?c2:c3);
    break;

    case 3:
      if(u<.4f){p=ch?N-u/.4f*N:u/.4f*N;dir=ch?-1:1;v=m141160LongBlock(i,p,dir,N,11,4);}
      else if(u<.72f){float q=(u-.4f)/.32f,center=N*.5f,d=q*N*.35f;v=m141160TwoBlocks(i,center-d,center+d,-1,1,N,10,4);c=c2;}
      else{p=ch?(u-.72f)/.28f*N:N-(u-.72f)/.28f*N;dir=ch?1:-1;v=m141160LongBlock(i,p,dir,N,10,3);c=c3;}
    break;

    case 4:
      p=m141160Ping(t*(ch?17.0f:22.0f),N);dir=sinf(t*(ch?17.0f:22.0f))>0?1:-1;
      len=10.0f+floorf(4.0f*sinf(u*M141160_PI*4.0f+(float)ch)+0.5f);tail=u<.5f?5:3;
      v=m141160LongBlock(i,p,dir,N,len,tail);if(u>.5f)c=c2;if(u>.78f)c=c3;
    break;

    case 5:{
      const float pos[6]={.08f,.24f,.43f,.65f,.82f,.95f};
      int idx=m141160MinInt(5,(int)floorf(u*6.0f));float q=pos[idx]*N;if(ch)q=N-q;
      if(u<.7f){dir=idx%2?1:-1;v=m141160LongBlock(i,q,dir,N,10,3);}
      else{p=ch?N-(u-.7f)/.3f*N:(u-.7f)/.3f*N;dir=ch?-1:1;v=m141160LongBlock(i,p,dir,N,11,5);c=c3;}
      if(u>.35f&&u<.7f)c=c2;
    }break;

    case 6:
      p=m141160Ping(t*(ch?20.0f:24.0f),N);dir=sinf(t*(ch?20.0f:24.0f))>0?1:-1;
      v=m141160LongBlock(i,p,dir,N,10,4);c=u<.5f?(ch?c2:c1):(ch?c1:c2);if(u>.8f)c=c3;
    break;

    case 7:
      if(u<.45f){dir=ch?1:-1;p=dir>0?u/.45f*N:N-u/.45f*N;v=m141160LongBlock(i,p,dir,N,10,5);}
      else if(u<.6f){p=ch?N*.65f:N*.35f;dir=ch?-1:1;v=m141160LongBlock(i,p,dir,N,13,3);c=c2;}
      else{dir=ch?-1:1;p=dir>0?(u-.6f)/.4f*N:N-(u-.6f)/.4f*N;v=m141160LongBlock(i,p,dir,N,10,5);c=c3;}
    break;

    case 8:{
      float q=u<.6f?u/.6f:(u-.6f)/.4f,p1=q*N*.5f,p2=N-q*N*.5f;
      if(ch){float tmp=p1;p1=N-p2;p2=N-tmp;}
      v=m141160TwoBlocks(i,p1,p2,1,-1,N,10,u<.6f?3:5);c=u<.6f?c1:c2;
    }break;

    case 9:{
      float q=u<.5f?u/.5f:(1.0f-(u-.5f)/.5f),d=q*N*.48f,center=N*.5f;
      float p1=center-d,p2=center+d;
      if(ch){p1=center+d;p2=center-d;}
      v=m141160TwoBlocks(i,p1,p2,-1,1,N,10,4);c=u<.5f?c1:c2;
    }break;

    case 10:{
      const float st[7]={.05f,.18f,.32f,.48f,.66f,.84f,.96f};int k=m141160MinInt(6,(int)floorf(u*7.0f));p=st[k]*N;if(ch)p=N-p;
      if(u<.66f){dir=k%2?1:-1;v=m141160LongBlock(i,p,dir,N,10,5);}
      else{p=ch?N-(u-.66f)/.34f*N:(u-.66f)/.34f*N;dir=ch?-1:1;v=m141160LongBlock(i,p,dir,N,11,4);c=c3;}
      if(u>.33f&&u<.66f)c=c2;
    }break;

    case 11:{
      int phase=(int)floorf(u*5.0f);float base=fmodf(phase*.19f+ch*.11f,1.0f)*N;
      if(u<.58f){for(int k=0;k<3;k++){float pp=fmodf(base+k*N*.29f,N);v=fmaxf(v,m141160LongBlock(i,pp,k%2?1:-1,N,10,3));}}
      else{p=m141160Ping(t*(ch?22.0f:27.0f),N);dir=sinf(t*22.0f)>0?1:-1;v=m141160LongBlock(i,p,dir,N,12,5);c=c2;}
    }break;

    case 12:{
      p=m141160Ping(t*(ch?19.0f:24.0f),N);float sep=16+10*sinf(u*M141160_PI*2.0f);
      v=m141160TwoBlocks(i,p-sep/2.0f,p+sep/2.0f,-1,1,N,10,4);c=u<.45f?c1:(u<.75f?c2:c3);
    }break;

    case 13:{
      int step=(int)floorf(u*8.0f);float seg=N/8.0f;p=(step+.5f)*seg;if(ch)p=N-p;
      if(u<.7f){dir=ch?-1:1;v=m141160LongBlock(i,p,dir,N,10,5);}
      else{p=ch?N-(u-.7f)/.3f*N:(u-.7f)/.3f*N;dir=ch?-1:1;v=m141160LongBlock(i,p,dir,N,10,3);c=c3;}
      if(u>.38f&&u<.7f)c=c2;
    }break;

    case 14:
      p=m141160Ping(t*(ch?18.0f:23.0f),N);dir=sinf(t*(ch?18.0f:23.0f))>0?1:-1;
      len=8.0f+floorf(6.0f*(.5f-.5f*cosf(u*M141160_PI*4.0f+(float)ch))+.5f);tail=u<.5f?3:5;
      v=m141160LongBlock(i,p,dir,N,len,tail);c=u<.4f?c1:(u<.72f?c2:c3);
    break;

    case 15:
      p=m141160Ping(t*(ch?16.0f:25.0f),N);dir=sinf(t*(ch?16.0f:25.0f))>0?1:-1;v=m141160LongBlock(i,p,dir,N,10,4);
      if(u>.55f){float p2=m141160Ping(t*(ch?24.0f:18.0f)+N*.35f,N);int d2=sinf(t*20.0f)>0?1:-1;v=fmaxf(v,m141160LongBlock(i,p2,d2,N,10,5));c=c2;}
      if(u>.82f)c=c3;
    break;

    case 16:{
      float seg=N/6.0f;int idx=((int)floorf(u*8.0f))%6;p=(idx+.5f)*seg;if(ch)p=N-p;
      if(u<.62f){dir=idx%2?1:-1;v=m141160LongBlock(i,p,dir,N,10,5);}
      else{float q=(u-.62f)/.38f;p=ch?q*N:N-q*N;dir=ch?1:-1;v=m141160LongBlock(i,p,dir,N,12,4);c=c3;}
      if(u>.32f&&u<.62f)c=c2;
    }break;

    case 17:
      p=m141160Ping(t*(ch?20.0f:26.0f),N);dir=sinf(t*(ch?20.0f:26.0f))>0?1:-1;v=m141160LongBlock(i,p,dir,N,10,3);
      c=u<.33f?c1:(u<.66f?c2:c3);
    break;

    case 18:{
      float q=u<.5f?u/.5f:(1.0f-(u-.5f)/.5f),center=N*.5f,d=q*N*.45f,p1=center-d,p2=center+d;
      v=m141160TwoBlocks(i,p1,p2,-1,1,N,10,4);
      if(u>.72f){p=m141160Ping(t*(ch?25.0f:20.0f),N);dir=sinf(t*22.0f)>0?1:-1;v=fmaxf(v,m141160LongBlock(i,p,dir,N,10,5));c=c3;}
      else c=u<.5f?c1:c2;
    }break;

    case 19:{
      float uu=fmodf(t,7.2f)/7.2f;int st=(int)floorf(uu*6.0f);float lo=fmodf(uu*6.0f,1.0f);
      M141160Color cc[6]={c1,c2,c3,c2,c1,c3};c=cc[st];
      if(st==0){p=ch?N-lo*N:lo*N;dir=ch?-1:1;v=m141160LongBlock(i,p,dir,N,10,5);}
      else if(st==1){float p1=lo*N,p2=N-lo*N;v=m141160TwoBlocks(i,p1,p2,1,-1,N,10,4);}
      else if(st==2){int k=(int)floorf(lo*6.0f);float seg=N/6.0f;p=(k+.5f)*seg;if(ch)p=N-p;v=m141160LongBlock(i,p,k%2?1:-1,N,12,3);}
      else if(st==3){p=m141160Ping(t*(ch?18.0f:24.0f),N);dir=sinf(t*20.0f)>0?1:-1;v=m141160LongBlock(i,p,dir,N,14,5);}
      else if(st==4){for(int k=0;k<3;k++){float pp=m141160Ping(t*(16.0f+k*4.0f)+k*N/3.0f+(ch?N*.12f:0.0f),N);v=fmaxf(v,m141160LongBlock(i,pp,k%2?1:-1,N,10,4));}}
      else{p=ch?N-lo*N:lo*N;dir=ch?-1:1;v=m141160LongBlock(i,p,dir,N,10,5);}
    }break;
    default: break;
  }

  M141160Sample out;out.v=m141160Clamp(v);out.c=c;return out;
}

static uint8_t m141160Byte(float x) {
  int v=(int)floorf(x+0.5f);if(v<0)v=0;if(v>255)v=255;return (uint8_t)v;
}
static CRGB m141160RenderHtml100(const M141160Sample &s) {
  float v=s.v;
  float r=fminf(255.0f,s.c.r*v*1.55f+18.0f*v);
  float g=fminf(255.0f,s.c.g*v*1.55f+18.0f*v);
  float b=fminf(255.0f,s.c.b*v*1.55f+18.0f*v);
  return CRGB(m141160Byte(r),m141160Byte(g),m141160Byte(b));
}
static void m141160RenderPair(uint8_t mode, CRGB *out1, CRGB *out2, uint16_t count, float t) {
  if(!out1||!out2||count==0||mode<141||mode>160)return;
  uint8_t id=(uint8_t)(mode-141);float N=(float)count;
  for(uint16_t i=0;i<count;i++){
    M141160Sample a=m141160Sample(id,t,(float)i,N,0);
    M141160Sample b=m141160Sample(id,t,(float)i,N,1);
    out1[i]=m141160RenderHtml100(a);out2[i]=m141160RenderHtml100(b);
  }
}

// Satu state kecil dipakai oleh seluruh keluarga 141-160.
// Saat channel/mode berubah, resetSuiteStateForChannel() mereset state ini.
struct Custom141160SharedState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom141160SharedState c141160Suite;

static void updateCustom141160SuiteMode(uint8_t mode, CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c141160Suite.lastCall == 0 || (unsigned long)(now - c141160Suite.lastCall) > 250UL) {
    c141160Suite.t = 0.0f; c141160Suite.lastUpdate = 0;
  }
  c141160Suite.lastCall = now;
  unsigned long stepDelay = m7180GlobalStep10(c141160Suite.nextDelay);
  if (c141160Suite.lastUpdate != 0 && (unsigned long)(now - c141160Suite.lastUpdate) < stepDelay) return;
  unsigned long dtMs = (c141160Suite.lastUpdate == 0) ? 0UL : (unsigned long)(now - c141160Suite.lastUpdate);
  c141160Suite.lastUpdate = now; c141160Suite.nextDelay = 25;
  if (dtMs > 200UL) dtMs = 200UL;
  c141160Suite.t += ((float)dtMs * 0.001f) * liveSpeedFactor;
  if (c141160Suite.t > 7200.0f) c141160Suite.t = fmodf(c141160Suite.t, 7200.0f);
  m141160RenderPair(mode, out1, out2, count, c141160Suite.t);
}

void updateCustom141Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(141,out1,out2,count); }
void updateCustom142Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(142,out1,out2,count); }
void updateCustom143Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(143,out1,out2,count); }
void updateCustom144Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(144,out1,out2,count); }
void updateCustom145Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(145,out1,out2,count); }
void updateCustom146Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(146,out1,out2,count); }
void updateCustom147Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(147,out1,out2,count); }
void updateCustom148Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(148,out1,out2,count); }
void updateCustom149Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(149,out1,out2,count); }
void updateCustom150Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(150,out1,out2,count); }
void updateCustom151Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(151,out1,out2,count); }
void updateCustom152Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(152,out1,out2,count); }
void updateCustom153Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(153,out1,out2,count); }
void updateCustom154Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(154,out1,out2,count); }
void updateCustom155Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(155,out1,out2,count); }
void updateCustom156Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(156,out1,out2,count); }
void updateCustom157Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(157,out1,out2,count); }
void updateCustom158Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(158,out1,out2,count); }
void updateCustom159Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(159,out1,out2,count); }
void updateCustom160Suite(CRGB *out1, CRGB *out2, uint16_t count){ updateCustom141160SuiteMode(160,out1,out2,count); }


// ============================================================================
// MODE 161-180 — EXACT HTML METEOR MULTI-FASE (USER SOURCE)
// 161 Meteor Stop-Go
// 162 Meteor Split Pair
// 163 Meteor Step Jump
// 164 Meteor Compression
// 165 Meteor Triple Train
// 166 Meteor Center Burst
// 167 Meteor Domino
// 168 Meteor Pulse Gate
// 169 Meteor Cluster Burst
// 170 Meteor Grand Finale
// 171 Meteor Slingshot
// 172 Meteor Accordion
// 173 Meteor Leapfrog
// 174 Meteor Stairwave
// 175 Meteor Pocket Burst
// 176 Meteor Elastic
// 177 Meteor Fanout
// 178 Meteor Rhythm
// 179 Meteor Conveyor
// 180 Meteor Hyper Finale
// PATOKAN: HTML user. Kepala meteor terang, ekor meredup, fase/warna sama.
// CH1/CH2 bergerak sejajar. GLOBAL fisik: CH1=CH3 dan CH2=CH4.
// RAM LOCK: satu state kecil per channel untuk keluarga 161-180,
// tanpa buffer LED/trail besar baru. Timer non-blocking millis() + GLOBAL 10ms.
// ============================================================================
static const float M161180_PI = 3.14159265358979323846f;

static float m161180Clamp(float v,float a=0.0f,float b=1.0f){
  return v<a?a:(v>b?b:v);
}
static float m161180Hash(float n){
  float x=sinf(n*12.9898f+78.233f)*43758.5453f;
  return x-floorf(x);
}
static float m161180Ping(float u,float L){
  float twoL=2.0f*L;
  float q=fmodf(fmodf(u,twoL)+twoL,twoL);
  return q<L?q:twoL-q;
}
static const M161180Color m161180Pal[8]={
  {255.0f,255.0f,255.0f}, {255.0f,0.0f,0.0f}, {0.0f,90.0f,255.0f}, {180.0f,0.0f,255.0f},
  {0.0f,220.0f,120.0f}, {255.0f,40.0f,150.0f}, {0.0f,220.0f,255.0f}, {120.0f,255.0f,0.0f}
};
static M161180Color m161180RC(float c,float seed=0.0f){
  int idx=(int)floorf(m161180Hash(c*7.17f+seed)*8.0f);
  if(idx<0)idx=0; if(idx>7)idx=7;
  return m161180Pal[idx];
}
static int m161180MinInt(int a,int b){ return a<b?a:b; }

static float m161180Meteor(float i,float p,int dir,float head=3.0f,float tail=12.0f){
  float d=(i-p)*(float)dir;
  if(d>=-head/2.0f && d<=head/2.0f) return 1.0f;
  float back=-d-head/2.0f;
  if(back>0.0f && back<=tail){
    float q=1.0f-back/tail;
    return q*q*.92f;
  }
  return 0.0f;
}
static float m161180TwinMeteor(float i,float p1,int d1,float p2,int d2,float head,float tail){
  return fmaxf(m161180Meteor(i,p1,d1,head,tail),m161180Meteor(i,p2,d2,head,tail));
}

static M161180Sample m161180Sample(uint8_t id,float t,float i,float N,int ch){
  int cyc=(int)floorf(t/6.0f);
  float u=fmodf(t,6.0f)/6.0f;
  if(u<0.0f)u+=1.0f;
  M161180Color c1=m161180RC((float)cyc,(float)id*2.2f+(float)ch*3.7f);
  M161180Color c2=m161180RC((float)(cyc+1),(float)id*4.4f+(float)ch*5.1f);
  M161180Color c3=m161180RC((float)(cyc+2),(float)id*6.1f+(float)ch*2.9f);
  float v=0.0f,p=0.0f;
  M161180Color c=c1;
  int dir=1;

  switch(id){
    case 0:
      if(u<.28f){float q=u/.28f;p=q*N*.42f;dir=1;v=m161180Meteor(i,p,dir,3,10);}
      else if(u<.46f){p=N*.42f;dir=1;v=m161180Meteor(i,p,dir,6,18);c=c2;}
      else if(u<.72f){float q=(u-.46f)/.26f;p=N*.42f+q*N*.35f;dir=1;v=m161180Meteor(i,p,dir,3,12);c=c2;}
      else{float q=(u-.72f)/.28f;p=N*.77f+q*N*.23f;dir=1;v=m161180Meteor(i,p,dir,2,7);c=c3;}
    break;

    case 1:
      if(u<.3f){p=u/.3f*N*.42f;dir=1;v=m161180Meteor(i,p,dir,4,13);}
      else if(u<.68f){float q=(u-.3f)/.38f,center=N*.42f+q*N*.35f,d=4+q*12;v=m161180TwinMeteor(i,center-d,1,center+d,1,3,10);c=c2;}
      else{float q=(u-.68f)/.32f,center=N*.77f+q*N*.23f,d=(1-q)*16;v=m161180TwinMeteor(i,center-d,1,center+d,1,3,9);c=c3;}
    break;

    case 2:{
      const float pts[8]={.05f,.15f,.28f,.45f,.61f,.76f,.9f,.98f};
      if(u<.62f){
        float pos=u/.62f*7.0f; int n=(int)floorf(pos); float f=pos-(float)n; n=m161180MinInt(n,7);
        p=pts[n]*N; v=m161180Meteor(i,p,1,3,10); if(f>.72f)v*=.65f; c=n<3?c1:(n<6?c2:c3);
      }else{float q=(u-.62f)/.38f;p=(.15f+.85f*q)*N;v=m161180Meteor(i,p,1,3,14);c=c3;}
    }break;

    case 3:
      p=u*N;dir=1;
      if(u<.33f){v=m161180Meteor(i,p,dir,4,20);c=c1;}
      else if(u<.6f){float q=(u-.33f)/.27f;v=m161180Meteor(i,p,dir,4,20-14*q);c=c2;}
      else{float q=(u-.6f)/.4f;v=m161180Meteor(i,p,dir,3,6+12*q);c=c3;}
    break;

    case 4:{
      float q=u,p0=q*N,sep=u<.5f?(5+u*22):(16-(u-.5f)*18);
      for(int k=0;k<3;k++){float pp=p0-k*sep;v=fmaxf(v,m161180Meteor(i,pp,1,2.5f,8+k*2));}
      c=u<.33f?c1:(u<.67f?c2:c3);
    }break;

    case 5:{
      float center=N*.5f;
      if(u<.42f){float q=u/.42f,d=q*N*.48f;v=m161180TwinMeteor(i,center-d,-1,center+d,1,3,12);c=c1;}
      else if(u<.58f){float d=N*.48f;v=m161180TwinMeteor(i,center-d,1,center+d,-1,5,18);c=c2;}
      else{float q=(u-.58f)/.42f,d=(1-q)*N*.48f;v=m161180TwinMeteor(i,center-d,1,center+d,-1,3,10);c=c3;}
    }break;

    case 6:{
      const float segs[7]={.04f,.18f,.32f,.47f,.63f,.78f,.91f};
      if(u<.7f){int n=m161180MinInt(6,(int)floorf(u/.7f*7.0f));p=segs[n]*N;dir=1;v=m161180Meteor(i,p,dir,5,11);c=n%3==0?c1:(n%3==1?c2:c3);}
      else{float q=(u-.7f)/.3f;p=q*N;v=m161180Meteor(i,p,1,2,7);c=c3;}
    }break;

    case 7:{
      if(u<.52f){p=u/.52f*N;float pulse=.5f-.5f*cosf(u*M161180_PI*8);v=m161180Meteor(i,p,1,3+2*pulse,7+14*pulse);c=u<.26f?c1:c2;}
      else{float q=(u-.52f)/.48f,center=N*.5f,d=sinf(q*M161180_PI)*N*.42f;v=m161180TwinMeteor(i,center-d,-1,center+d,1,3,10);c=c3;}
    }break;

    case 8:
      if(u<.25f){p=u/.25f*N*.3f;v=m161180Meteor(i,p,1,4,13);}
      else if(u<.72f){float q=(u-.25f)/.47f,base=N*.3f+q*N*.5f,sep=3+q*13;for(int k=-1;k<=1;k++)v=fmaxf(v,m161180Meteor(i,base+k*sep,1,2.5f,8));c=q<.5f?c2:c3;}
      else{float q=(u-.72f)/.28f,p0=N*.8f+q*N*.2f;v=m161180Meteor(i,p0,1,3,10);c=c1;}
    break;

    case 9:{
      float uu=fmodf(t,7.8f)/7.8f; if(uu<0.0f)uu+=1.0f;
      int st=(int)floorf(uu*6.0f); float lo=fmodf(uu*6.0f,1.0f);
      M161180Color cc[6]={c1,c2,c3,c2,c1,c3}; c=cc[st];
      if(st==0){if(lo<.55f){p=lo/.55f*N*.45f;v=m161180Meteor(i,p,1,3,10);}else{p=N*.45f+(lo-.55f)/.45f*N*.15f;v=m161180Meteor(i,p,1,6,18);}}
      else if(st==1){float center=lo*N,d=8+10*sinf(lo*M161180_PI);v=m161180TwinMeteor(i,center-d,1,center+d,1,3,9);}
      else if(st==2){const float a[6]={.08f,.23f,.41f,.62f,.82f,.96f};int n=m161180MinInt(5,(int)floorf(lo*6));p=a[n]*N;v=m161180Meteor(i,p,1,4,10);}
      else if(st==3){float base=lo*N,sep=4+lo*14;for(int k=-1;k<=1;k++)v=fmaxf(v,m161180Meteor(i,base+k*sep,1,2.5f,8));}
      else if(st==4){float center=N*.5f,d=lo*N*.48f;v=m161180TwinMeteor(i,center-d,-1,center+d,1,3,12);}
      else{p=lo*N;v=m161180Meteor(i,p,1,2,6);}
    }break;


    case 10:
      if(u<.22f){
        p=N*.08f;v=m161180Meteor(i,p,1,5,14);
      }else if(u<.36f){
        float q=(u-.22f)/.14f;
        p=N*(.08f-.045f*q);
        v=m161180Meteor(i,p,-1,4,10);c=c2;
      }else{
        float q=(u-.36f)/.64f;
        p=N*(.035f+powf(q,1.65f)*.965f);
        v=m161180Meteor(i,p,1,2.5f,8+8*q);c=c3;
      }
    break;

    case 11:{
      p=u*N;dir=1;
      float a=.5f-.5f*cosf(u*M161180_PI*8);
      float tail=6+18*a,head=2.5f+2*(1-a);
      v=m161180Meteor(i,p,dir,head,tail);
      c=u<.33f?c1:(u<.66f?c2:c3);
    }break;

    case 12:{
      float base=u*N,phase=.5f-.5f*cosf(u*M161180_PI*6),sep=8+14*phase;
      float p1=base+(phase-.5f)*sep,p2=base-(phase-.5f)*sep;
      v=m161180TwinMeteor(i,p1,1,p2,1,3,9);
      if(u>.5f)c=c2;
      if(u>.8f)c=c3;
    }break;

    case 13:{
      if(u<.45f){
        float step=floorf(u/.45f*9)/8;
        p=step*N;v=m161180Meteor(i,p,1,4,10);c=c1;
      }else if(u<.78f){
        float q=(u-.45f)/.33f;
        p=(q+.08f*sinf(q*M161180_PI*6))*N;
        v=m161180Meteor(i,p,1,3,13);c=c2;
      }else{
        float q=(u-.78f)/.22f,step=floorf(q*6)/5;
        p=step*N;v=m161180Meteor(i,p,1,2.5f,7);c=c3;
      }
    }break;

    case 14:{
      const float pockets[5]={.12f,.31f,.52f,.73f,.91f};
      float pos=u*5;
      int n=m161180MinInt(4,(int)floorf(pos));
      float f=pos-n,center=pockets[n]*N;
      if(f<.58f){
        p=center;v=m161180Meteor(i,p,1,5,12);
      }else{
        float q=(f-.58f)/.42f,d=q*13;
        v=m161180TwinMeteor(i,center-d,-1,center+d,1,2.5f,7);
      }
      c=n%3==0?c1:(n%3==1?c2:c3);
    }break;

    case 15:
      if(u<.4f){
        float q=u/.4f;p=q*N*.5f;v=m161180Meteor(i,p,1,3,12);
      }else if(u<.57f){
        float q=(u-.4f)/.17f;p=N*(.5f-.12f*q);
        v=m161180Meteor(i,p,-1,4,14);c=c2;
      }else{
        float q=(u-.57f)/.43f;p=N*(.38f+.62f*q);
        v=m161180Meteor(i,p,1,3,8+14*q);c=c3;
      }
    break;

    case 16:{
      float base=u*N;
      if(u<.28f){
        v=m161180Meteor(i,base,1,4,12);
      }else if(u<.75f){
        float q=(u-.28f)/.47f,sep=2+sinf(q*M161180_PI)*18;
        for(int k=-1;k<=1;k++)
          v=fmaxf(v,m161180Meteor(i,base+k*sep,1,2.5f,8));
        c=q<.5f?c2:c3;
      }else{
        v=m161180Meteor(i,base,1,3,10);c=c1;
      }
    }break;

    case 17:{
      float q;
      if(u<.3f)q=(u/.3f)*.18f;
      else if(u<.65f)q=.18f+((u-.3f)/.35f)*.62f;
      else q=.8f+((u-.65f)/.35f)*.2f;
      p=q*N;
      float pulse=u<.3f?.2f:(u<.65f?1:.45f);
      v=m161180Meteor(i,p,1,3,7+10*pulse);
      c=u<.3f?c1:(u<.65f?c2:c3);
    }break;

    case 18:{
      const float slots[6]={.1f,.26f,.43f,.61f,.78f,.94f};
      float pos=u*5;
      int n=(int)floorf(pos);
      float f=pos-n;
      n=m161180MinInt(n,4);

      float p1=slots[n]*N,p2=slots[n+1]*N;
      v=fmaxf(
        m161180Meteor(i,p1,1,3,10)*(1-f),
        m161180Meteor(i,p2,1,3,10)*f
      );

      if(f>.55f)
        v=fmaxf(v,m161180Meteor(i,p2+f*5,1,2.5f,7));

      c=n%3==0?c1:(n%3==1?c2:c3);
    }break;

    case 19:{
      float uu=fmodf(t,9.2f)/9.2f;
      int st=(int)floorf(uu*8);
      float lo=fmodf(uu*8,1.0f);
      M161180Color cc[8]={c1,c2,c3,c1,c2,c3,c2,c1};
      c=cc[st];

      if(st==0){
        if(lo<.35f){p=N*.08f;v=m161180Meteor(i,p,1,5,13);}
        else{
          float q=(lo-.35f)/.65f;
          p=N*(.08f+q*.92f);v=m161180Meteor(i,p,1,2.5f,8);
        }
      }else if(st==1){
        float base=lo*N,ph=.5f-.5f*cosf(lo*M161180_PI*4),sep=7+12*ph;
        v=m161180TwinMeteor(
          i,base+(ph-.5f)*sep,1,base-(ph-.5f)*sep,1,3,8
        );
      }else if(st==2){
        p=lo*N;
        float a=.5f-.5f*cosf(lo*M161180_PI*6);
        v=m161180Meteor(i,p,1,3,6+17*a);
      }else if(st==3){
        const float pockets[4]={.15f,.38f,.62f,.86f};
        int n=m161180MinInt(3,(int)floorf(lo*4));
        float f=fmodf(lo*4,1.0f),center=pockets[n]*N;
        if(f<.6f)v=m161180Meteor(i,center,1,4,10);
        else{
          float d=(f-.6f)/.4f*12;
          v=m161180TwinMeteor(i,center-d,-1,center+d,1,2.5f,6);
        }
      }else if(st==4){
        float base=lo*N,sep=sinf(lo*M161180_PI)*16;
        for(int k=-1;k<=1;k++)
          v=fmaxf(v,m161180Meteor(i,base+k*sep,1,2.5f,8));
      }else if(st==5){
        float q=lo<.4f?lo*.35f:.14f+(lo-.4f)/.6f*.86f;
        p=q*N;v=m161180Meteor(i,p,1,3,12);
      }else if(st==6){
        const float slots[5]={.1f,.3f,.5f,.7f,.9f};
        int n=m161180MinInt(3,(int)floorf(lo*4));
        float f=fmodf(lo*4,1.0f);
        v=fmaxf(
          m161180Meteor(i,slots[n]*N,1,3,9)*(1-f),
          m161180Meteor(i,slots[n+1]*N,1,3,9)*f
        );
      }else{
        p=lo*N;v=m161180Meteor(i,p,1,2,6);
      }
    }break;
  }

  M161180Sample out; out.v=m161180Clamp(v); out.c=c; return out;
}

static uint8_t m161180Byte(float x){
  int v=(int)floorf(x+0.5f); if(v<0)v=0; if(v>255)v=255; return (uint8_t)v;
}
static CRGB m161180RenderHtml100(const M161180Sample &s){
  float v=s.v;
  float r=fminf(255.0f,s.c.r*v*1.55f+18.0f*v);
  float g=fminf(255.0f,s.c.g*v*1.55f+18.0f*v);
  float b=fminf(255.0f,s.c.b*v*1.55f+18.0f*v);
  return CRGB(m161180Byte(r),m161180Byte(g),m161180Byte(b));
}
static void m161170RenderPair(uint8_t mode,CRGB *out1,CRGB *out2,uint16_t count,float t){
  if(!out1||!out2||count==0||mode<161||mode>180)return;
  uint8_t id=(uint8_t)(mode-161); float N=(float)count;
  for(uint16_t i=0;i<count;i++){
    M161180Sample a=m161180Sample(id,t,(float)i,N,0);
    M161180Sample b=m161180Sample(id,t,(float)i,N,1);
    out1[i]=m161180RenderHtml100(a); out2[i]=m161180RenderHtml100(b);
  }
}

struct Custom161170SharedState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom161170SharedState c161170Suite;

static void updateCustom161170SuiteMode(uint8_t mode,CRGB *out1,CRGB *out2,uint16_t count){
  unsigned long now=millis();
  if(c161170Suite.lastCall==0 || (unsigned long)(now-c161170Suite.lastCall)>250UL){
    c161170Suite.t=0.0f; c161170Suite.lastUpdate=0;
  }
  c161170Suite.lastCall=now;
  unsigned long stepDelay=m7180GlobalStep10(c161170Suite.nextDelay);
  if(c161170Suite.lastUpdate!=0 && (unsigned long)(now-c161170Suite.lastUpdate)<stepDelay)return;
  unsigned long dtMs=(c161170Suite.lastUpdate==0)?0UL:(unsigned long)(now-c161170Suite.lastUpdate);
  c161170Suite.lastUpdate=now; c161170Suite.nextDelay=25;
  if(dtMs>200UL)dtMs=200UL;
  c161170Suite.t+=((float)dtMs*0.001f)*liveSpeedFactor;
  if(c161170Suite.t>7200.0f)c161170Suite.t=fmodf(c161170Suite.t,7200.0f);
  m161170RenderPair(mode,out1,out2,count,c161170Suite.t);
}

void updateCustom161Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(161,out1,out2,count);}
void updateCustom162Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(162,out1,out2,count);}
void updateCustom163Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(163,out1,out2,count);}
void updateCustom164Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(164,out1,out2,count);}
void updateCustom165Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(165,out1,out2,count);}
void updateCustom166Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(166,out1,out2,count);}
void updateCustom167Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(167,out1,out2,count);}
void updateCustom168Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(168,out1,out2,count);}
void updateCustom169Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(169,out1,out2,count);}
void updateCustom170Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(170,out1,out2,count);}
void updateCustom171Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(171,out1,out2,count);}
void updateCustom172Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(172,out1,out2,count);}
void updateCustom173Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(173,out1,out2,count);}
void updateCustom174Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(174,out1,out2,count);}
void updateCustom175Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(175,out1,out2,count);}
void updateCustom176Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(176,out1,out2,count);}
void updateCustom177Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(177,out1,out2,count);}
void updateCustom178Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(178,out1,out2,count);}
void updateCustom179Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(179,out1,out2,count);}
void updateCustom180Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom161170SuiteMode(180,out1,out2,count);}


// ============================================================================
// MODE 181-200 — USER SOURCE + CUSTOM REPLACE 185/186
// 181 Blade Sweep
// 182 Magnet Clash
// 183 Quadrant Fold
// 184 Width Scanner
// 185 Bi-Directional Silk Flow 8F (custom user request)
// 186 Eight Unique Fluid Phases (custom user request)
// 187 Phase Matrix
// 188 Center Compression
// 189 DNA Blocks
// 190 Heartbeat Runner
// 191 Binary Mosaic
// 192 Sawtooth Chase
// 193 Orbit Nodes
// 194 Counterphase Trio
// 195 Shockwave Rings
// 196 Ripple Cut
// 197 Pendulum Blocks
// 198 Color Staircase
// 199 Triad Exchange
// 200 Grand Machine X
// PATOKAN: 181-184/187-200 tetap sumber user; 185/186 diganti sesuai permintaan terbaru.
// GLOBAL fisik lurus: CH1=CH3 dan CH2=CH4.
// 185: maju CH1->CH3->CH4->CH2 lalu balik CH2->CH4->CH3->CH1. 186: 8 fase fluid unik.
// RAM LOCK: satu shared state kecil per channel, tanpa buffer LED/trail besar baru.
// Timer non-blocking millis() + m7180GlobalStep10() (minimum frame 10ms).
// ============================================================================
static const float M181200_PI = 3.14159265358979323846f;

static float m181200Clamp(float v,float a=0.0f,float b=1.0f){
  return v<a?a:(v>b?b:v);
}
static float m181200Hash(float n){
  float x=sinf(n*12.9898f+78.233f)*43758.5453f;
  return x-floorf(x);
}
static float m181200Ping(float u,float L){
  float twoL=2.0f*L;
  float q=fmodf(fmodf(u,twoL)+twoL,twoL);
  return q<L?q:twoL-q;
}
static float m181200Gauss(float x,float w){
  return expf(-(x*x)/(2.0f*w*w));
}
static float m181200Block(float d,float w){
  return d<=w?1.0f:0.0f;
}
static int m181200CeilToInt(float x){
  return (int)ceilf(x);
}
static const M181200Color m181200Pal[8]={
  {255.0f,255.0f,255.0f}, {255.0f,0.0f,0.0f}, {0.0f,90.0f,255.0f}, {180.0f,0.0f,255.0f},
  {0.0f,220.0f,120.0f}, {255.0f,40.0f,150.0f}, {0.0f,220.0f,255.0f}, {120.0f,255.0f,0.0f}
};
static M181200Color m181200RC(float c,float seed=0.0f){
  int idx=(int)floorf(m181200Hash(c*7.17f+seed)*8.0f);
  if(idx<0)idx=0; if(idx>7)idx=7; return m181200Pal[idx];
}

static M181200Sample m181200Sample(uint8_t id,float t,float i,float N,int ch){
  int cyc=(int)floorf(t/6.0f);
  float u=fmodf(t,6.0f)/6.0f;
  M181200Color c1=m181200RC((float)cyc,(float)id*2.1f+(float)ch*3.3f);
  M181200Color c2=m181200RC((float)(cyc+1),(float)id*4.2f+(float)ch*5.2f);
  M181200Color c3=m181200RC((float)(cyc+2),(float)id*6.3f+(float)ch*2.4f);
  float v=0.0f; M181200Color c=c1;
  auto B=[&](float x,float w)->float{return m181200Block(fabsf(i-x),w);};
  auto G=[&](float x,float w)->float{return m181200Gauss(i-x,w);};

  switch(id){
    case 0:{ // Blade Sweep
      if(u<.35f){float q=u/.35f,p=q*N*.55f;v=B(p,1.5f);c=c1;}
      else if(u<.65f){float q=(u-.35f)/.3f,p=N*(.55f+.2f*q);v=B(p,2+q*10);c=c2;}
      else{float q=(u-.65f)/.35f,p=N*(.75f+.25f*q),d=3+q*14;v=fmaxf(B(p-d,3),B(p+d,3));c=c3;}
    }break;

    case 1:{ // Magnet Clash
      if(u<.42f){float q=u/.42f,a=q*N*.48f,b=N-q*N*.48f;v=fmaxf(B(a,5),B(b,5));}
      else if(u<.58f){v=B(N*.5f,11);c=c2;}
      else{float q=(u-.58f)/.42f,a=N*.5f-q*N*.48f,b=N*.5f+q*N*.48f;v=fmaxf(B(a,4),B(b,4));c=c3;}
    }break;

    case 2:{ // Quadrant Fold
      if(u<.33f){
        float q=u/.33f;
        float p1=(.05f+.20f*q)*N,p2=(.35f-.10f*q)*N,p3=(.65f+.10f*q)*N,p4=(.95f-.20f*q)*N;
        v=fmaxf(fmaxf(B(p1,2.8f),B(p2,2.8f)),fmaxf(B(p3,2.8f),B(p4,2.8f))); c=c1;
      }else if(u<.66f){
        float q=(u-.33f)/.33f,sn=sinf(q*M181200_PI*2),w=3+5*(.5f-.5f*cosf(q*M181200_PI*2));
        float p1=(.25f+.14f*sn)*N,p2=(.75f-.14f*sn)*N; v=fmaxf(B(p1,w),B(p2,w)); c=c2;
      }else{
        float q=(u-.66f)/.34f; const float base[4]={.18f,.39f,.61f,.82f};
        for(int k=0;k<4;k++){float drift=(k%2==0?1.0f:-1.0f)*sinf(q*M181200_PI)*N*.10f;v=fmaxf(v,B(base[k]*N+drift,2.5f+q*2.5f));}
        c=c3;
      }
    }break;

    case 3:{ // Width Scanner
      float p=m181200Ping(t*18,N);
      if(u<.34f){v=B(p,1.5f);}
      else if(u<.67f){float q=(u-.34f)/.33f;v=B(p,2+q*9);c=c2;}
      else{float d=9+6*sinf(u*M181200_PI*4);v=fmaxf(B(p-d,2.5f),B(p+d,2.5f));c=c3;}
    }break;

    case 4:{ // 185 Bi-Directional Silk Flow 8F — fallback 2-output
      const float phaseLen=1.55f;
      int st=((int)floorf(t/phaseLen))%8; if(st<0)st+=8;
      float q=fmodf(t,phaseLen)/phaseLen; if(q<0.0f)q+=1.0f;
      const bool rev=(st>=4);
      const float z=rev?(N-1.0f-i):i;
      float p=q*(N-1.0f),back=p-z;
      if(st==0){ // maju: soft silk
        float tail=N*.22f; v=fmaxf(G(p,2.2f),(back>0&&back<tail)?powf(1.0f-back/tail,1.35f)*.92f:0.0f); c=c1;
      }else if(st==1){ // maju: breathing ribbon
        float tail=N*.40f,w=2.0f+3.0f*(.5f-.5f*cosf(q*M181200_PI*2.0f));
        float tr=(back>0&&back<tail)?powf(1.0f-back/tail,1.15f):0.0f;
        v=fmaxf(m181200Gauss(z-p,w),tr*(.76f+.24f*(.5f+.5f*sinf(back*.22f+q*M181200_PI*6.0f)))); c=c2;
      }else if(st==2){ // maju: twin overtake
        float sep=N*(.28f-.16f*(.5f-.5f*cosf(q*M181200_PI*2.0f)));
        v=fmaxf(m181200Gauss(z-p,2.1f),m181200Gauss(z-(p-sep),2.8f)*.78f); c=c3;
      }else if(st==3){ // maju: elastic dash
        float qe=(q<.34f)?(.22f*(q/.34f)):(.22f+.78f*powf((q-.34f)/.66f,.58f));
        p=qe*(N-1.0f); back=p-z; float tail=N*(.12f+.34f*qe);
        v=fmaxf(m181200Gauss(z-p,1.8f+1.8f*qe),(back>0&&back<tail)?powf(1.0f-back/tail,1.25f)*.90f:0.0f); c=c2;
      }else if(st==4){ // balik: echo wave
        float tail=N*.16f; v=fmaxf(m181200Gauss(z-p,2.0f),(back>0&&back<tail)?powf(1.0f-back/tail,1.4f)*.88f:0.0f);
        for(int k=1;k<=3;k++)v=fmaxf(v,m181200Gauss(z-(p-N*.13f*k),2.3f+.3f*k)*(.68f-.13f*k)); c=c3;
      }else if(st==5){ // balik: triple weave
        float sep=N*(.16f+.08f*sinf(q*M181200_PI));
        for(int k=0;k<3;k++)v=fmaxf(v,m181200Gauss(z-(p-sep*k),1.9f+.35f*k)*(1.0f-.18f*k)); c=c1;
      }else if(st==6){ // balik: long aurora
        float tail=N*.68f,tr=(back>0&&back<tail)?powf(1.0f-back/tail,.98f):0.0f;
        float wave=.70f+.30f*(.5f+.5f*sinf(back*.13f+t*5.0f));
        v=fmaxf(m181200Gauss(z-p,3.0f),tr*wave); c=c2;
      }else{ // balik: merge finale
        float sep=N*.26f*(1.0f-q);
        v=fmaxf(m181200Gauss(z-p,1.7f),fmaxf(m181200Gauss(z-(p-sep),2.1f)*.72f,m181200Gauss(z-(p-2.0f*sep),2.5f)*.50f));
        if(q>.72f){float qq=(q-.72f)/.28f,p2=(.72f+.28f*powf(qq,.55f))*(N-1.0f);v=fmaxf(v,m181200Gauss(z-p2,1.5f));} c=c3;
      }
    }break;

    case 5:{ // 186 Eight Unique Fluid Phases — fallback 2-output
      const float phaseLen=1.70f,L=N-1.0f;
      int st=((int)floorf(t/phaseLen))%8; if(st<0)st+=8;
      float q=fmodf(t,phaseLen)/phaseLen; if(q<0.0f)q+=1.0f;
      if(st==0){ // center split
        float a=L*.5f-q*L*.5f,b=L*.5f+q*L*.5f; v=fmaxf(G(a,2.4f),G(b,2.4f)); c=c1;
      }else if(st==1){ // edge merge
        float a=q*L*.5f,b=L-q*L*.5f; v=fmaxf(G(a,2.8f),G(b,2.8f)); c=c2;
      }else if(st==2){ // pendulum ribbon
        float p=m181200Ping(q*2.0f*L,L),w=2.2f+3.6f*(.5f-.5f*cosf(q*M181200_PI*4.0f)); v=G(p,w); c=c3;
      }else if(st==3){ // counterflow pass
        float a=q*L,b=L-q*L; v=fmaxf(G(a,2.1f),G(b,3.0f)*.85f); c=c1;
      }else if(st==4){ // breathing halo traveler
        float p=q*L,w=N*(.035f+.085f*(.5f-.5f*cosf(q*M181200_PI*2.0f))); v=G(p,fmaxf(1.6f,w)); c=c2;
      }else if(st==5){ // four-head fanout
        float base=q*L,sep=N*.10f*sinf(q*M181200_PI); for(int k=0;k<4;k++){float off=((float)k-1.5f)*sep;v=fmaxf(v,G(base+off,1.8f+.35f*k)*(1.0f-.10f*k));} c=c3;
      }else if(st==6){ // rhythm snake
        float qq=(q<.3f)?q*.55f:(q<.7f?.165f+(q-.3f)*1.55f:.785f+(q-.7f)*.7167f); float p=m181200Clamp(qq)*L+sinf(q*M181200_PI*6.0f)*N*.025f; v=G(p,2.4f+2.2f*(.5f+.5f*sinf(q*M181200_PI*4.0f))); c=c1;
      }else{ // grand fluid finale
        float a=q*L,b=L-q*L,mid=L*.5f+sinf(q*M181200_PI*2.0f)*N*.16f; v=fmaxf(fmaxf(G(a,2.0f),G(b,2.0f)),G(mid,4.2f)*.72f); c=c3;
      }
    }break;

    case 6:{ // Phase Matrix
      int cell=(int)floorf(i/5.0f), phase=(int)floorf(u*14);
      if(u<.5f){
        int code=(cell*3+phase*2)%11; v=(code==0||code==1||code==5)?1.0f:(code==8?.35f:0.0f); c=code<4?c1:(code<8?c2:c3);
      }else{
        float q=(u-.5f)/.5f; int code=(cell*5-phase+33)%9; if(code<0)code+=9;
        v=(code==0||code==4)?1.0f:((code==1||code==5)?.38f:0.0f); float p=(.05f+.90f*q)*N; v=fmaxf(v,G(p,2.2f)); c=q<.5f?c2:c3;
      }
    }break;

    case 7:{ // Center Compression
      if(u<.52f){float q=u/.52f,a=q*N*.5f,b=N-q*N*.5f;v=fmaxf(B(a,6),B(b,6));c=c1;}
      else{float q=(u-.52f)/.48f,d=q*N*.48f;v=fmaxf(B(N*.5f-d,3+5*q),B(N*.5f+d,3+5*q));c=q<.5f?c2:c3;}
    }break;

    case 8:{ // DNA Blocks
      float q=u,a=(.12f+.76f*q)*N,b=(.88f-.76f*q)*N,sn=sinf(q*M181200_PI*2),d=5+9*(sn*sn);
      v=fmaxf(fmaxf(B(a-d,2.5f),B(a+d,2.5f)),fmaxf(B(b-d,2.5f),B(b+d,2.5f))); c=u<.5f?c1:c2;
    }break;

    case 9:{ // Heartbeat Runner
      if(u<.38f){float ph=fmodf(u/.38f*4.0f,1.0f),beat=powf(sinf(ph*M181200_PI),5.0f),w=2+beat*10;v=B(N*.5f,w);c=u<.19f?c1:c2;}
      else{float q=(u-.38f)/.62f,p=q*N;v=B(p,3+(q>.7f?4:0));c=c3;}
    }break;

    case 10:{ // Binary Mosaic
      int seg=6,k=(int)floorf(i/(float)seg),code;

      if(u<.55f){
        code=(int)floorf(u/.55f*16);
        int gray=code^(code>>1);
        int bit=(gray>>(k%4))&1;
        bool parity=((k+code)%3==0);

        v=bit?1.0f:(parity?.28f:0.0f);
        int cc=(k+code)%3;
        c=cc==0?c1:(cc==1?c2:c3);
      }else{
        float q=(u-.55f)/.45f;
        code=15-(int)floorf(q*16);

        int gray=code^(code>>1);
        int bit=(gray>>(3-(k%4)))&1;
        int rot=(k+(int)floorf(q*8))%5;

        v=bit?(rot==0?.55f:1.0f):(rot==2?.25f:0.0f);
        c=rot<2?c3:(rot<4?c1:c2);
      }
    }break;

    case 11:{ // Sawtooth Chase
      float q=fmodf(u*4.0f,1.0f);
      int stage=(int)floorf(u*4.0f);
      float p=powf(q,1.8f)*N;
      v=B(p,3+stage*1.5f);
      c=stage%3==0?c1:(stage%3==1?c2:c3);
    }break;

    case 12:{ // Orbit Nodes
      float shift=.5f+.5f*sinf(t*2.7f);

      for(int k=0;k<4;k++){
        float p=fmodf((float)k/4.0f+u*(.35f+.25f*shift),1.0f)*N;
        v=fmaxf(v,G(p,2.2f+shift*2));
      }

      c=shift<.33f?c1:(shift<.66f?c2:c3);
    }break;

    case 13:{ // Counterphase Trio
      float p1=m181200Ping(t*13,N);
      float p2=N-p1;
      float p3=N*.5f+sinf(t*3.1f)*N*.24f;

      float w1=2.2f+3*(.5f+.5f*sinf(t*2.2f));
      float w2=2.2f+3*(.5f+.5f*sinf(t*2.2f+M181200_PI));
      float w3=2.5f+5*(.5f+.5f*sinf(t*1.4f+1.2f));

      v=fmaxf(B(p1,w1),fmaxf(B(p2,w2),B(p3,w3)));
      if(u<.33f)c=c1;
      else if(u<.66f)c=c2;
      else c=c3;
    }break;

    case 14:{ // Shockwave Rings
      float pos=u*4.0f;
      int n=(int)floorf(pos);
      float f=pos-n,d=f*N*.5f;

      v=fmaxf(B(N*.5f-d,2+n),B(N*.5f+d,2+n));

      if(n>0){
        float d2=fmodf(f+.48f,1.0f)*N*.5f;
        v=fmaxf(v,fmaxf(B(N*.5f-d2,1.5f),B(N*.5f+d2,1.5f)));
      }

      c=n%3==0?c1:(n%3==1?c2:c3);
    }break;

    case 15:{ // Ripple Cut
      float phase1=(i/N)*5-u*7;
      float f1=fmodf(fmodf(phase1,1.0f)+1.0f,1.0f);
      float wave1=.5f+.5f*sinf(i*.22f+t*5.2f);

      v=f1<.18f?(.35f+.65f*wave1):0;
      c=c1;

      if(u>.45f){
        float phase2=(i/N)*4+u*6;
        float f2=fmodf(fmodf(phase2,1.0f)+1.0f,1.0f);
        float wave2=.5f+.5f*sinf(i*.31f-t*4.1f);

        v=fmaxf(v,f2<.14f?(.25f+.70f*wave2):0);
        c=c2;
      }

      if(u>.78f){
        float p=m181200Ping(t*20,N);
        v=fmaxf(v,G(p,2.0f));
        c=c3;
      }
    }break;

    case 16:{ // Pendulum Blocks
      float p=m181200Ping(t*15,N);
      float edge=fabsf(p-N*.5f)/(N*.5f);
      float w=3+edge*10;

      v=B(p,w);
      c=p<N*.33f?c1:(p<N*.66f?c2:c3);
    }break;

    case 17:{ // Color Staircase
      int seg=7;
      int k=(int)floorf(i/(float)seg);
      int count=m181200CeilToInt(N/(float)seg);

      if(u<.55f){
        v=k<=(int)floorf(u/.55f*count)?1.0f:0.0f;
        c=k%3==0?c1:(k%3==1?c2:c3);
      }else{
        float q=(u-.55f)/.45f;
        int cut=(int)floorf(q*count);
        v=k>=cut?1.0f:0.0f;
        c=k%3==0?c3:(k%3==1?c1:c2);
      }
    }break;

    case 18:{ // Triad Exchange
      if(u<.5f){
        float q=u/.5f;
        float left=(.10f+.38f*q)*N,right=(.90f-.38f*q)*N;
        float mid=N*.5f+sinf(q*M181200_PI*2)*N*.16f;

        v=fmaxf(
          B(left,3),
          fmaxf(B(right,3),B(mid,2.4f+3*powf(sinf(q*M181200_PI),2.0f)))
        );

        c=q<.5f?c1:c2;
      }else{
        float q=(u-.5f)/.5f;
        float left=(.48f-.38f*q)*N,right=(.52f+.38f*q)*N;
        float mid=N*.5f+sinf(q*M181200_PI*3)*N*.22f*(1-q*.4f);

        v=fmaxf(
          B(left,2.5f+2*q),
          fmaxf(B(right,2.5f+2*q),G(mid,2.0f+2*q))
        );

        c=c3;
      }
    }break;

    case 19:{ // Grand Machine X
      const float cycle20=8.0f;
      float uu=fmodf(fmodf(t,cycle20)+cycle20,cycle20);
      int st=(int)floorf(uu);
      float lo=uu-st;

      M181200Color cc[8]={c1,c2,c3,c2,c1,c3,c2,c1};
      c=(st>=0&&st<8)?cc[st]:c1;

      if(st==0){
        const float base[4]={.16f,.38f,.62f,.84f};

        for(int k=0;k<4;k++){
          float drift=(k%2==0?1.0f:-1.0f)*sinf(lo*M181200_PI)*N*.10f;
          v=fmaxf(v,B(base[k]*N+drift,2.5f+lo*2));
        }
      }else if(st==1){
        float center=(.08f+.84f*lo)*N,w=9;
        bool inside=fabsf(i-center)<=w;

        int slice=((int)floorf((i-center+30)/3.0f)+(int)floorf(lo*9))%3;
        v=inside&&slice!=1?1.0f:0.0f;
      }else if(st==2){
        int cell=(int)floorf(i/5.0f);
        int phase=(int)floorf(lo*12);
        int code=(cell*3+phase*2)%10;

        v=(code==0||code==3||code==7)?1.0f:(code==1?.3f:0.0f);
      }else if(st==3){
        int k=(int)floorf(i/6.0f);
        int code=(int)floorf(lo*16);
        int gray=code^(code>>1);

        v=((gray>>(k%4))&1)?1.0f:(((k+code)%4==0)?.25f:0.0f);
      }else if(st==4){
        float p1=m181200Ping(lo*N*2.2f,N);
        float p2=N-p1;
        float p3=N*.5f+sinf(lo*M181200_PI*4)*N*.20f;

        v=fmaxf(B(p1,3),fmaxf(B(p2,3),B(p3,5)));
      }else if(st==5){
        float f1=fmodf(fmodf((i/N)*5-lo*7,1.0f)+1.0f,1.0f);
        float f2=fmodf(fmodf((i/N)*4+lo*6,1.0f)+1.0f,1.0f);

        float v1=f1<.18f?(.4f+.6f*(.5f+.5f*sinf(i*.22f+t*5))):0.0f;
        float v2=f2<.12f?(.3f+.6f*(.5f+.5f*sinf(i*.31f-t*4))):0.0f;

        v=fmaxf(v1,v2);
      }else if(st==6){
        float left=(.10f+.38f*lo)*N;
        float right=(.90f-.38f*lo)*N;
        float mid=N*.5f+sinf(lo*M181200_PI*2)*N*.18f;

        v=fmaxf(B(left,3),fmaxf(B(right,3),G(mid,2.5f)));
      }else{
        float center=(.08f+.84f*lo)*N;

        if(lo<.45f){
          v=B(center,2+lo*18);
        }else{
          float q=(lo-.45f)/.55f,d=3+q*15;
          v=fmaxf(
            fmaxf(B(center-d,2.5f),B(center+d,2.5f)),
            fmaxf(B(center-d*.35f,1.8f),B(center+d*.35f,1.8f))
          );
        }
      }
    }break;
  }
  M181200Sample out; out.v=m181200Clamp(v); out.c=c; return out;
}

static uint8_t m181200Byte(float x){
  int v=(int)floorf(x+0.5f); if(v<0)v=0; if(v>255)v=255; return (uint8_t)v;
}
static CRGB m181200RenderHtml100(const M181200Sample &s){
  float v=s.v;
  float r=fminf(255.0f,s.c.r*v*1.55f+18.0f*v);
  float g=fminf(255.0f,s.c.g*v*1.55f+18.0f*v);
  float b=fminf(255.0f,s.c.b*v*1.55f+18.0f*v);
  return CRGB(m181200Byte(r),m181200Byte(g),m181200Byte(b));
}

// ---------------------------------------------------------------------------
// MODE 185/186 — CONNECTED 4CH FLOW
// Jalur virtual tunggal: CH1 -> CH3 -> CH4 -> CH2.
// Tanpa array pixel tambahan; semua frame dihitung langsung dari posisi virtual.
// Masing-masing mode punya 8 fase berbeda dan tidak memakai pola blok/gate.
// ---------------------------------------------------------------------------
static M181200Color m185186MixColor(const M181200Color &a,const M181200Color &b,float q){
  q=m181200Clamp(q);
  M181200Color c;
  c.r=a.r+(b.r-a.r)*q; c.g=a.g+(b.g-a.g)*q; c.b=a.b+(b.b-a.b)*q;
  return c;
}

static float m185186SoftComet(float x,float head,float headW,float tail){
  float d=x-head;
  float core=m181200Gauss(d,headW);
  float back=head-x;
  float tr=0.0f;
  if(back>0.0f && back<=tail){
    float q=1.0f-back/tail;
    tr=powf(q,1.35f)*0.94f;
  }
  return fmaxf(core,tr);
}

static float m185186SoftCometDir(float x,float head,int dir,float headW,float tail){
  return (dir>=0)
    ? m185186SoftComet(x,head,headW,tail)
    : m185186SoftComet(-x,-head,headW,tail);
}

static void renderCustom185186All4Frame(
  uint8_t mode,CRGB *ch1,CRGB *ch2,CRGB *ch3,CRGB *ch4,uint16_t count,float tf
){
  if((mode!=185 && mode!=186)||!ch1||!ch2||!ch3||!ch4||count==0)return;
  fill_solid(ch1,count,CRGB::Black); fill_solid(ch2,count,CRGB::Black);
  fill_solid(ch3,count,CRGB::Black); fill_solid(ch4,count,CRGB::Black);

  // Virtual path increases exactly as requested:
  // 0 ... total : CH1 -> CH3 -> CH4 -> CH2.
  // Mode 185 phases 1-4 run forward, phases 5-8 run the exact reverse:
  // CH2 -> CH4 -> CH3 -> CH1.
  CRGB *order[4]={ch1,ch3,ch4,ch2};
  const float N=(float)count, total=N*4.0f, L=total-1.0f;
  const float t=(float)tf;
  const float phaseLen=(mode==185)?1.55f:1.70f;
  int st=((int)floorf(t/phaseLen))%8; if(st<0)st+=8;
  float q=fmodf(t,phaseLen)/phaseLen; if(q<0.0f)q+=1.0f;

  const int cyc=(int)floorf(t/(phaseLen*8.0f));
  M181200Color ca=m181200RC((float)(cyc+st),(mode==185)?18.5f:28.6f);
  M181200Color cb=m181200RC((float)(cyc+st+1),(mode==185)?37.2f:49.1f);
  M181200Color cc=m181200RC((float)(cyc+st+2),(mode==185)?62.4f:71.7f);

  for(int vp=0;vp<(int)total;vp++){
    const float x=(float)vp;
    float v=0.0f;
    M181200Color col=ca;

    if(mode==185){
      // 185 — BI-DIRECTIONAL SILK FLOW 8F.
      // F1-F4: CH1 -> CH3 -> CH4 -> CH2.
      // F5-F8: CH2 -> CH4 -> CH3 -> CH1.
      const bool rev=(st>=4);
      const int dir=rev?-1:1;
      float head=rev ? (L-q*L) : (q*L);
      float back=(dir>0)?(head-x):(x-head);

      if(st==0){ // F1 forward — Soft Silk Comet
        v=m185186SoftCometDir(x,head,dir,2.25f,N*.22f); col=ca;
      }else if(st==1){ // F2 forward — Breathing Wave Ribbon
        float w=2.0f+3.5f*(.5f-.5f*cosf(q*M181200_PI*2.0f));
        float tail=N*.42f;
        v=m185186SoftCometDir(x,head,dir,w,tail);
        if(back>0.0f&&back<tail)v*=.76f+.24f*(.5f+.5f*sinf(back*.19f+q*M181200_PI*6.0f));
        col=m185186MixColor(ca,cb,m181200Clamp(back/tail));
      }else if(st==2){ // F3 forward — Twin Overtake Stream
        float sep=N*(.30f-.18f*(.5f-.5f*cosf(q*M181200_PI*2.0f)));
        v=fmaxf(m185186SoftCometDir(x,head,dir,2.0f,N*.15f),
               m185186SoftCometDir(x,head-sep,dir,2.65f,N*.12f)*.76f);
        col=(q<.50f)?cb:cc;
      }else if(st==3){ // F4 forward — Elastic Slow-to-Rush
        float qe=(q<.34f)?(.22f*(q/.34f)):(.22f+.78f*powf((q-.34f)/.66f,.58f));
        head=qe*L; back=head-x;
        float tail=N*(.13f+.36f*qe);
        v=m185186SoftCometDir(x,head,1,1.8f+1.8f*qe,tail);
        col=m185186MixColor(cb,cc,qe);
      }else if(st==4){ // F5 reverse — Echo Wave Return
        v=m185186SoftCometDir(x,head,-1,2.0f,N*.15f);
        for(int k=1;k<=4;k++){
          float eh=head+N*(.115f*k+.012f*sinf(q*M181200_PI*2.0f+k));
          v=fmaxf(v,m181200Gauss(x-eh,2.0f+.35f*k)*(.72f-.12f*k));
        }
        col=cc;
      }else if(st==5){ // F6 reverse — Triple Weave Return
        float sep=N*(.15f+.09f*sinf(q*M181200_PI));
        for(int k=0;k<3;k++){
          float h=head+sep*k;
          v=fmaxf(v,m185186SoftCometDir(x,h,-1,1.8f+.28f*k,N*(.09f+.025f*k))*(1.0f-.17f*k));
        }
        col=(q<.34f)?ca:(q<.67f?cb:cc);
      }else if(st==6){ // F7 reverse — Long Aurora Return
        float tail=N*.70f;
        v=m185186SoftCometDir(x,head,-1,3.0f,tail);
        if(back>0.0f&&back<tail){
          float wave=.68f+.32f*(.5f+.5f*sinf(back*.115f+t*5.1f));
          float wave2=.86f+.14f*sinf(back*.043f-q*M181200_PI*4.0f);
          v*=wave*wave2;
        }
        col=m185186MixColor(ca,cc,m181200Clamp(back/tail));
      }else{ // F8 reverse — Three-to-One Merge Finale
        float sep=N*.28f*(1.0f-q);
        v=m185186SoftCometDir(x,head,-1,1.7f,N*.10f);
        v=fmaxf(v,m185186SoftCometDir(x,head+sep,-1,2.0f,N*.09f)*.72f);
        v=fmaxf(v,m185186SoftCometDir(x,head+2.0f*sep,-1,2.35f,N*.08f)*.50f);
        if(q>.72f){
          float qq=(q-.72f)/.28f;
          float h2=L-(.72f+.28f*powf(qq,.55f))*L;
          v=fmaxf(v,m185186SoftCometDir(x,h2,-1,1.45f,N*.065f));
        }
        col=m185186MixColor(cc,ca,q);
      }
    }else{
      // 186 — 8 UNIQUE FLUID PHASES.
      // Tidak mengikuti vocabulary Mode 185; tiap fase punya geometri gerak berbeda.
      if(st==0){ // F1 — Center Split Out
        float hl=L*.5f-q*L*.5f;
        float hr=L*.5f+q*L*.5f;
        v=fmaxf(m185186SoftCometDir(x,hl,-1,2.35f,N*.15f),
               m185186SoftCometDir(x,hr, 1,2.35f,N*.15f));
        col=m185186MixColor(ca,cb,m181200Clamp(fabsf(x-L*.5f)/(L*.5f)));
      }else if(st==1){ // F2 — Edge Merge In
        float hl=q*L*.5f;
        float hr=L-q*L*.5f;
        v=fmaxf(m185186SoftCometDir(x,hl, 1,2.7f,N*.18f),
               m185186SoftCometDir(x,hr,-1,2.7f,N*.18f));
        float glow=m181200Gauss(x-L*.5f,3.8f)*powf(q,3.0f)*.75f;
        v=fmaxf(v,glow); col=cb;
      }else if(st==2){ // F3 — Pendulum Ribbon Bounce
        float phase=q*2.0f;
        float head=m181200Ping(phase*L,L);
        int dir=(q<.5f)?1:-1;
        float w=2.0f+4.4f*(.5f-.5f*cosf(q*M181200_PI*4.0f));
        float tail=N*(.16f+.22f*(.5f+.5f*sinf(q*M181200_PI*2.0f)));
        v=m185186SoftCometDir(x,head,dir,w,tail);
        col=m185186MixColor(ca,cc,.5f+.5f*sinf(q*M181200_PI*2.0f));
      }else if(st==3){ // F4 — Dual Counterflow Pass
        float a=q*L,b=L-q*L;
        float va=m185186SoftCometDir(x,a, 1,1.9f,N*.13f);
        float vb=m185186SoftCometDir(x,b,-1,2.8f,N*.21f)*.88f;
        v=fmaxf(va,vb);
        float side=m181200Clamp(x/L);
        col=(side<.5f)?m185186MixColor(ca,cb,side*2.0f):m185186MixColor(cb,cc,(side-.5f)*2.0f);
      }else if(st==4){ // F5 — Breathing Halo Traveler
        float center=q*L;
        float width=N*(.035f+.095f*(.5f-.5f*cosf(q*M181200_PI*2.0f)));
        float env=m181200Gauss(x-center,fmaxf(1.8f,width));
        float ripple=.72f+.28f*(.5f+.5f*cosf((x-center)*.10f-t*6.0f));
        v=env*ripple;
        v=fmaxf(v,m181200Gauss(x-center,2.2f));
        col=m185186MixColor(cc,ca,.5f+.5f*sinf(q*M181200_PI));
      }else if(st==5){ // F6 — Four-Head Fanout / Rejoin
        float base=q*L;
        float sep=N*.105f*sinf(q*M181200_PI);
        for(int k=0;k<4;k++){
          float off=((float)k-1.5f)*sep;
          v=fmaxf(v,m185186SoftCometDir(x,base+off,1,1.65f+.28f*k,N*(.075f+.018f*k))*(1.0f-.09f*k));
        }
        col=(q<.5f)?cb:cc;
      }else if(st==6){ // F7 — Rhythm Snake Flow
        float prog;
        if(q<.30f)prog=(q/.30f)*.17f;
        else if(q<.70f)prog=.17f+((q-.30f)/.40f)*.66f;
        else prog=.83f+((q-.70f)/.30f)*.17f;
        float head=prog*L+sinf(q*M181200_PI*6.0f)*N*.026f;
        float pulse=.5f+.5f*sinf(q*M181200_PI*4.0f);
        float tail=N*(.10f+.24f*pulse);
        v=m185186SoftCometDir(x,head,1,2.1f+2.0f*pulse,tail);
        if(head-x>0.0f&&head-x<tail)v*=.72f+.28f*(.5f+.5f*sinf((head-x)*.20f+t*7.0f));
        col=(q<.30f)?ca:(q<.70f?cb:cc);
      }else{ // F8 — Grand Fluid Convergence Finale
        float a=q*L;
        float b=L-q*L;
        float mid=L*.5f+sinf(q*M181200_PI*2.0f)*N*.16f;
        v=fmaxf(m185186SoftCometDir(x,a, 1,1.75f,N*.09f),
               m185186SoftCometDir(x,b,-1,1.75f,N*.09f));
        v=fmaxf(v,m181200Gauss(x-mid,4.0f)*(.52f+.28f*sinf(q*M181200_PI)*sinf(q*M181200_PI)));
        if(q>.68f){
          float qq=(q-.68f)/.32f;
          float sprint=qq*L;
          v=fmaxf(v,m185186SoftCometDir(x,sprint,1,1.45f,N*.065f));
        }
        col=m185186MixColor(ca,cc,q);
      }
    }

    M181200Sample s; s.v=m181200Clamp(v); s.c=col;
    const int seg=vp/(int)count, idx=vp%(int)count;
    order[seg][idx]=m181200RenderHtml100(s);
  }
}

static void m181200RenderPair(uint8_t mode,CRGB *out1,CRGB *out2,uint16_t count,float t){
  if(!out1||!out2||count==0||mode<181||mode>200)return;
  uint8_t id=(uint8_t)(mode-181); float N=(float)count;
  for(uint16_t i=0;i<count;i++){
    M181200Sample a=m181200Sample(id,t,(float)i,N,0);
    M181200Sample b=m181200Sample(id,t,(float)i,N,1);
    out1[i]=m181200RenderHtml100(a); out2[i]=m181200RenderHtml100(b);
  }
}

struct Custom181200SharedState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom181200SharedState c181200Suite;

static void updateCustom185186SuiteAll4(
  uint8_t mode,CRGB *ch1,CRGB *ch2,CRGB *ch3,CRGB *ch4,uint16_t count
){
  unsigned long now=millis();
  if(c181200Suite.lastCall==0 || (unsigned long)(now-c181200Suite.lastCall)>250UL){
    c181200Suite.t=0.0f; c181200Suite.lastUpdate=0;
  }
  c181200Suite.lastCall=now;
  unsigned long stepDelay=m7180GlobalStep10(c181200Suite.nextDelay);
  if(c181200Suite.lastUpdate!=0 && (unsigned long)(now-c181200Suite.lastUpdate)<stepDelay)return;
  unsigned long dtMs=(c181200Suite.lastUpdate==0)?0UL:(unsigned long)(now-c181200Suite.lastUpdate);
  c181200Suite.lastUpdate=now; c181200Suite.nextDelay=25;
  if(dtMs>200UL)dtMs=200UL;
  c181200Suite.t+=((float)dtMs*0.001f)*liveSpeedFactor;
  if(c181200Suite.t>7200.0f)c181200Suite.t=fmodf(c181200Suite.t,7200.0f);
  renderCustom185186All4Frame(mode,ch1,ch2,ch3,ch4,count,c181200Suite.t);
}

static void updateCustom181200SuiteMode(uint8_t mode,CRGB *out1,CRGB *out2,uint16_t count){
  unsigned long now=millis();
  if(c181200Suite.lastCall==0 || (unsigned long)(now-c181200Suite.lastCall)>250UL){
    c181200Suite.t=0.0f; c181200Suite.lastUpdate=0;
  }
  c181200Suite.lastCall=now;
  unsigned long stepDelay=m7180GlobalStep10(c181200Suite.nextDelay);
  if(c181200Suite.lastUpdate!=0 && (unsigned long)(now-c181200Suite.lastUpdate)<stepDelay)return;
  unsigned long dtMs=(c181200Suite.lastUpdate==0)?0UL:(unsigned long)(now-c181200Suite.lastUpdate);
  c181200Suite.lastUpdate=now; c181200Suite.nextDelay=25;
  if(dtMs>200UL)dtMs=200UL;
  c181200Suite.t+=((float)dtMs*0.001f)*liveSpeedFactor;
  if(c181200Suite.t>7200.0f)c181200Suite.t=fmodf(c181200Suite.t,7200.0f);
  m181200RenderPair(mode,out1,out2,count,c181200Suite.t);
}

void updateCustom181Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(181,out1,out2,count);}
void updateCustom182Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(182,out1,out2,count);}
void updateCustom183Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(183,out1,out2,count);}
void updateCustom184Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(184,out1,out2,count);}
void updateCustom185Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(185,out1,out2,count);}
void updateCustom186Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(186,out1,out2,count);}
void updateCustom187Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(187,out1,out2,count);}
void updateCustom188Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(188,out1,out2,count);}
void updateCustom189Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(189,out1,out2,count);}
void updateCustom190Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(190,out1,out2,count);}
void updateCustom191Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(191,out1,out2,count);}
void updateCustom192Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(192,out1,out2,count);}
void updateCustom193Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(193,out1,out2,count);}
void updateCustom194Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(194,out1,out2,count);}
void updateCustom195Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(195,out1,out2,count);}
void updateCustom196Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(196,out1,out2,count);}
void updateCustom197Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(197,out1,out2,count);}
void updateCustom198Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(198,out1,out2,count);}
void updateCustom199Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(199,out1,out2,count);}
void updateCustom200Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom181200SuiteMode(200,out1,out2,count);}

// MODE 201-210 — NEW 8-PHASE FLOW FAMILY
//
// Dibuat ulang setelah cek karakter Welcome 0..3:
// multi-fase, perubahan bentuk/arah/ritme nyata, bukan sekadar ganti warna.
//
// ALL4 route utama:
//   CH1 -> CH3 -> CH4 -> CH2
// Tiap mode = 8 fase berbeda.
// Tidak ada per-pixel buffer baru; hanya formula + shared timer kecil.
// Timing non-blocking: millis() + GLOBAL minimum 10 ms.
// =========================================================================

static const float M201210_PI = 3.14159265358979323846f;

static float m201210Clamp(float v,float a=0.0f,float b=1.0f){
  return v<a?a:(v>b?b:v);
}
static float m201210Smooth(float q){
  q=m201210Clamp(q);
  return q*q*(3.0f-2.0f*q);
}
static float m201210Ping(float x,float L){
  if(L<=0.0f)return 0.0f;
  float p=fmodf(fmodf(x,2.0f*L)+2.0f*L,2.0f*L);
  return p<L?p:2.0f*L-p;
}
static float m201210Hash(float n){
  float x=sinf(n*12.9898f+78.233f)*43758.5453f;
  return x-floorf(x);
}
static float m201210Gauss(float d,float w){
  if(w<0.001f)w=0.001f;
  return expf(-(d*d)/(2.0f*w*w));
}
static float m201210Bar(float x,float c,float halfW){
  if(halfW<0.001f)halfW=0.001f;
  return m201210Clamp(1.0f-fabsf(x-c)/halfW);
}
static float m201210Comet(float x,float head,int dir,float headW,float tail){
  float d=(x-head)*(float)dir;
  if(fabsf(d)<=headW)return 1.0f;
  float back=-d-headW;
  if(back>0.0f && back<=tail){
    float q=1.0f-back/tail;
    return q*q*.94f;
  }
  return 0.0f;
}
static float m201210Ring(float x,float c,float radius,float width){
  return m201210Gauss(fabsf(x-c)-radius,width);
}

static const M201210Color m201210Pal[12]={
  {255.0f,255.0f,255.0f}, {255.0f,40.0f,40.0f}, {30.0f,120.0f,255.0f},
  {190.0f,30.0f,255.0f}, {0.0f,230.0f,150.0f}, {255.0f,45.0f,165.0f},
  {0.0f,225.0f,255.0f}, {255.0f,170.0f,0.0f}, {140.0f,255.0f,20.0f},
  {255.0f,80.0f,25.0f}, {80.0f,110.0f,255.0f}, {255.0f,235.0f,80.0f}
};

static M201210Color m201210RC(float c,float s=0.0f){
  int idx=(int)floorf(m201210Hash(c*7.17f+s)*12.0f);
  if(idx<0)idx=0; if(idx>11)idx=11;
  return m201210Pal[idx];
}
static M201210Color m201210Mix(const M201210Color &a,const M201210Color &b,float q){
  q=m201210Clamp(q);
  M201210Color c={
    a.r+(b.r-a.r)*q,
    a.g+(b.g-a.g)*q,
    a.b+(b.b-a.b)*q
  };
  return c;
}

static M201210Sample m201210NewSample(
  uint8_t id,float t,float x,float L,float N
){
  // SPEED FIX: st, q, c1, c2, c3 sama untuk SEMUA pixel dalam 1 frame (id & t sama).
  // Dulu dihitung ulang tiap pixel (3x sinf + fmodf + floorf) -> berat di ESP32-C3 (tanpa FPU).
  // Sekarang dihitung sekali per frame lalu dipakai ulang. Hasil visual tetap sama.
  static bool m201210CacheValid=false;
  static uint8_t m201210CacheId=0;
  static float m201210CacheT=0.0f;
  static int m201210CacheSt=0;
  static float m201210CacheQ=0.0f;
  static M201210Color m201210CacheC1,m201210CacheC2,m201210CacheC3;
  if(!(m201210CacheValid && m201210CacheId==id && m201210CacheT==t)){
    const float PHASE_LEN=1.45f;
    float cycleLen=PHASE_LEN*8.0f;
    float tt=fmodf(fmodf(t,cycleLen)+cycleLen,cycleLen);
    int st0=(int)floorf(tt/PHASE_LEN);
    if(st0<0)st0=0; if(st0>7)st0=7;
    int cyc=(int)floorf(t/cycleLen);
    m201210CacheSt=st0;
    m201210CacheQ=(tt-(float)st0*PHASE_LEN)/PHASE_LEN;
    m201210CacheC1=m201210RC((float)(cyc+st0),(float)id*11.13f+1.0f);
    m201210CacheC2=m201210RC((float)(cyc+st0+1),(float)id*17.71f+3.0f);
    m201210CacheC3=m201210RC((float)(cyc+st0+2),(float)id*23.29f+7.0f);
    m201210CacheId=id; m201210CacheT=t; m201210CacheValid=true;
  }
  int st=m201210CacheSt;
  float q=m201210CacheQ;
  M201210Color c1=m201210CacheC1;
  M201210Color c2=m201210CacheC2;
  M201210Color c3=m201210CacheC3;
  M201210Color c=m201210Mix(c1,c2,q);
  float v=0.0f, p=0.0f, a1=0.0f, a2=0.0f;

  switch(id){
    case 0:{ // 201 SILK RELAY
      switch(st){
        case 0:{ // single silk relay
          p=m201210Smooth(q)*L;
          v=m201210Comet(x,p,1,2.2f,N*.23f); c=c1;
        }break;
        case 1:{ // breathing ribbon
          p=q*L; float w=2.5f+5.5f*(.5f-.5f*cosf(q*M201210_PI*2.0f));
          v=m201210Comet(x,p,1,w,N*.42f);
          float back=p-x;
          if(back>0.0f&&back<N*.42f)v*=.62f+.38f*(.5f+.5f*sinf(back*.16f+q*M201210_PI*6.0f));
          c=m201210Mix(c1,c2,m201210Clamp(back/(N*.42f)));
        }break;
        case 2:{ // twin overtake
          p=q*L; float sep=N*(.34f-.24f*(.5f-.5f*cosf(q*M201210_PI*2.0f)));
          v=fmaxf(m201210Comet(x,p,1,2.0f,N*.14f),
                 m201210Comet(x,p-sep,1,3.0f,N*.11f)*.78f);
          c=q<.5f?c1:c2;
        }break;
        case 3:{ // ribbon with wave-cut tail
          p=q*L; float base=m201210Comet(x,p,1,3.0f,N*.52f);
          float back=p-x;
          if(back>0.0f)base*=.55f+.45f*(.5f+.5f*sinf(back*.23f+t*5.0f));
          v=base; c=m201210Mix(c2,c3,m201210Clamp(back/(N*.5f)));
        }break;
        case 4:{ // hard reverse return
          p=L-q*L;
          v=m201210Comet(x,p,-1,2.4f,N*.18f); c=c3;
        }break;
        case 5:{ // echo return
          p=L-q*L;
          v=m201210Comet(x,p,-1,2.0f,N*.12f);
          for(int k=1;k<=4;k++)v=fmaxf(v,m201210Gauss(x-(p+N*.10f*k),2.0f+.4f*k)*(.75f-.12f*k));
          c=m201210Mix(c3,c1,q);
        }break;
        case 6:{ // center split
          float l=L*.5f-q*L*.5f, r=L*.5f+q*L*.5f;
          v=fmaxf(m201210Comet(x,l,-1,2.6f,N*.14f),
                 m201210Comet(x,r, 1,2.6f,N*.14f));
          c=m201210Mix(c1,c2,m201210Clamp(fabsf(x-L*.5f)/(L*.5f)));
        }break;
        default:{ // edge merge + center bloom
          float l=q*L*.5f, r=L-q*L*.5f;
          v=fmaxf(m201210Comet(x,l,1,2.6f,N*.15f),
                 m201210Comet(x,r,-1,2.6f,N*.15f));
          v=fmaxf(v,m201210Gauss(x-L*.5f,3.8f)*powf(q,3.0f));
          c=m201210Mix(c2,c3,q);
        }break;
      }
    }break;

    case 1:{ // 202 CROSS CEREMONY
      switch(st){
        case 0:{ // edge collision
          float l=q*L*.5f, r=L-q*L*.5f;
          v=fmaxf(m201210Comet(x,l,1,3.0f,N*.18f),m201210Comet(x,r,-1,3.0f,N*.18f));
          c=c1;
        }break;
        case 1:{ // collision explosion
          float rad=q*L*.5f;
          v=m201210Ring(x,L*.5f,rad,3.2f);
          v=fmaxf(v,m201210Ring(x,L*.5f,rad*.62f,2.2f)*.55f); c=c2;
        }break;
        case 2:{ // pendulum shuttle
          p=m201210Ping(q*2.0f*L,L);
          int dir=q<.5f?1:-1;
          v=m201210Comet(x,p,dir,2.2f,N*.21f); c=m201210Mix(c1,c3,q);
        }break;
        case 3:{ // dual counterflow pass
          float p1=q*L,p2=L-q*L;
          v=fmaxf(m201210Comet(x,p1,1,1.9f,N*.11f),
                 m201210Comet(x,p2,-1,3.3f,N*.24f)*.88f);
          c=m201210Mix(c2,c3,x/L);
        }break;
        case 4:{ // four-head fanout
          float centers[4]={L*.20f,L*.40f,L*.60f,L*.80f};
          for(int k=0;k<4;k++){
            float dir=(k<2)?-1.0f:1.0f;
            float pp=centers[k]+dir*q*L*.20f;
            v=fmaxf(v,m201210Comet(x,pp,dir>0?1:-1,1.8f+.35f*k,N*.085f)*(1.0f-.12f*k));
          } c=c1;
        }break;
        case 5:{ // liquid zipper — alternating small gates, not static blocks
          float front=q*L;
          float cell=fmodf(floorf(x/fmaxf(3.0f,N*.055f)),2.0f);
          float d=front-x;
          float wave=(cell<.5f)?m201210Gauss(d,5.0f):m201210Gauss(d-N*.10f,5.0f);
          v=fmaxf(wave,m201210Comet(x,front,1,1.5f,N*.08f)*.55f); c=c2;
        }break;
        case 6:{ // center halo + orbiting runners
          float rad=(.08f+.34f*q)*L*.5f;
          v=m201210Ring(x,L*.5f,rad,2.7f)*.72f;
          float p1=L*.5f+sinf(q*M201210_PI*4.0f)*rad;
          float p2=L*.5f-sinf(q*M201210_PI*4.0f)*rad;
          v=fmaxf(v,m201210Gauss(x-p1,2.0f)); v=fmaxf(v,m201210Gauss(x-p2,2.0f)*.8f); c=c3;
        }break;
        default:{ // accelerating crossing finale
          float qe=powf(q,.58f);
          float p1=qe*L,p2=L-powf(q,1.55f)*L;
          v=fmaxf(m201210Comet(x,p1,1,2.0f,N*.12f),
                 m201210Comet(x,p2,-1,2.8f,N*.17f));
          c=m201210Mix(c1,c3,q);
        }break;
      }
    }break;

    case 2:{ // 203 ELASTIC STAIRFLOW
      switch(st){
        case 0:{ // six step jumps
          const float pts[7]={.02f,.14f,.28f,.43f,.60f,.78f,.96f};
          float pos=q*6.999f; int n=(int)floorf(pos); if(n>6)n=6;
          p=pts[n]*L;
          v=m201210Comet(x,p,1,3.0f,N*.10f); c=c1;
        }break;
        case 1:{ // steps dissolve into smooth catch-up
          float qe=m201210Smooth(q); p=(.08f+.92f*qe)*L;
          v=m201210Comet(x,p,1,2.0f,N*(.10f+.20f*q));
          for(int k=1;k<=3;k++)v=fmaxf(v,m201210Gauss(x-(p-N*.11f*k),2.2f)*(.65f-.12f*k)); c=c2;
        }break;
        case 2:{ // elastic overshoot / recoil
          float s=q<.72f?powf(q/.72f,.68f):(1.0f-(q-.72f)/.28f*.22f);
          p=s*L;
          int dir=q<.72f?1:-1;
          v=m201210Comet(x,p,dir,3.4f,N*.19f); c=c3;
        }break;
        case 3:{ // domino checkpoints with crossfade
          const float pts[6]={.06f,.22f,.40f,.58f,.77f,.95f};
          float pos=q*5.0f; int n=(int)floorf(pos); if(n>4)n=4; float f=pos-n;
          v=fmaxf(m201210Gauss(x-pts[n]*L,3.1f)*(1-f),
                 m201210Gauss(x-pts[n+1]*L,3.1f)*f);
          if(f>.5f)v=fmaxf(v,m201210Comet(x,pts[n+1]*L,1,1.5f,N*.06f)*.55f);
          c=(n&1)?c1:c2;
        }break;
        case 4:{ // three-head train changing spacing
          float base=q*L, sep=N*(.12f+.18f*sinf(q*M201210_PI));
          for(int k=0;k<3;k++)v=fmaxf(v,m201210Comet(x,base-k*sep,1,2.0f+.3f*k,N*(.07f+.025f*k))*(1.0f-.16f*k));
          c=c1;
        }break;
        case 5:{ // compression tunnel
          p=q*L;
          float w=6.0f-4.2f*q, tail=N*(.48f-.32f*q);
          v=m201210Comet(x,p,1,w,tail);
          float ring=m201210Ring(x,p,N*(.04f+.09f*q),2.3f)*.55f;
          v=fmaxf(v,ring); c=m201210Mix(c2,c3,q);
        }break;
        case 6:{ // reverse staircase
          const float pts[7]={.98f,.84f,.70f,.55f,.39f,.21f,.03f};
          float pos=q*6.999f; int n=(int)floorf(pos); if(n>6)n=6;
          p=pts[n]*L; v=m201210Comet(x,p,-1,3.0f,N*.10f); c=c3;
        }break;
        default:{ // long accelerating sprint
          float qe=powf(q,.52f); p=qe*L;
          v=m201210Comet(x,p,1,1.7f,N*(.10f+.42f*qe)); c=m201210Mix(c1,c3,qe);
        }break;
      }
    }break;

    case 3:{ // 204 SPLIT-MERGE RIVER
      switch(st){
        case 0:{ // one becomes two
          float center=q*L;
          float sep=N*.28f*q;
          v=fmaxf(m201210Comet(x,center-sep,1,2.3f,N*.12f),
                 m201210Comet(x,center+sep,1,2.3f,N*.12f)); c=c1;
        }break;
        case 1:{ // two become one while moving
          float center=q*L,sep=N*.32f*(1-q);
          v=fmaxf(m201210Comet(x,center-sep,1,2.0f,N*.10f),
                 m201210Comet(x,center+sep,1,2.0f,N*.10f));
          v=fmaxf(v,m201210Gauss(x-center,2.8f)*powf(q,2.0f)); c=c2;
        }break;
        case 2:{ // triple fan split from center
          float base=L*.5f;
          for(int k=-1;k<=1;k++){
            float pp=base+q*(float)k*L*.45f;
            int dir=k<0?-1:(k>0?1:1);
            v=fmaxf(v,m201210Comet(x,pp,dir,2.2f,N*.11f)*(k==0?.72f:1.0f));
          } c=c3;
        }break;
        case 3:{ // three weave forward
          float base=q*L;
          for(int k=0;k<3;k++){
            float pp=base+sinf(q*M201210_PI*4.0f+k*2.094f)*N*.16f;
            v=fmaxf(v,m201210Comet(x,pp,1,1.8f,N*.08f)*(1.0f-.12f*k));
          } c=m201210Mix(c1,c2,q);
        }break;
        case 4:{ // opposite rivers merge
          float p1=q*L*.5f,p2=L-q*L*.5f;
          v=fmaxf(m201210Comet(x,p1,1,2.5f,N*.20f),
                 m201210Comet(x,p2,-1,2.5f,N*.20f)); c=c2;
        }break;
        case 5:{ // swirl around center
          float rad=(.08f+.32f*(.5f-.5f*cosf(q*M201210_PI*2.0f)))*L*.5f;
          float p1=L*.5f+sinf(q*M201210_PI*6)*rad;
          float p2=L*.5f-sinf(q*M201210_PI*6)*rad;
          v=fmaxf(m201210Gauss(x-p1,3.0f),m201210Gauss(x-p2,3.0f)*.85f); c=c3;
        }break;
        case 6:{ // edge suction into center
          float p1=q*L*.5f,p2=L-q*L*.5f;
          float w=2.0f+5.0f*q;
          v=fmaxf(m201210Comet(x,p1,1,w,N*.16f),
                 m201210Comet(x,p2,-1,w,N*.16f));
          c=m201210Mix(c1,c3,q);
        }break;
        default:{ // four-way center blast
          float d=q*L*.48f;
          float ps[4]={L*.5f-d,L*.5f-d*.45f,L*.5f+d*.45f,L*.5f+d};
          for(int k=0;k<4;k++)v=fmaxf(v,m201210Gauss(x-ps[k],2.4f)*(1.0f-.10f*fabsf(k-1.5f)));
          c=c1;
        }break;
      }
    }break;

    case 4:{ // 205 COMET CEREMONY
      switch(st){
        case 0:{ p=m201210Smooth(q)*L; v=m201210Comet(x,p,1,5.5f,N*.28f); c=c1; }break;
        case 1:{ p=powf(q,.55f)*L; v=m201210Comet(x,p,1,1.6f,N*.08f); c=c2; }break;
        case 2:{ // comet plus pulse echoes
          p=q*L; v=m201210Comet(x,p,1,2.6f,N*.17f);
          for(int k=1;k<=5;k++){
            float pp=p-N*.10f*k;
            float pulse=.35f+.65f*(.5f+.5f*sinf(q*M201210_PI*8.0f-k));
            v=fmaxf(v,m201210Gauss(x-pp,2.2f)*pulse*(1.0f-.12f*k));
          } c=c3;
        }break;
        case 3:{ // orbit companions
          p=q*L;
          v=m201210Comet(x,p,1,2.5f,N*.12f);
          float orb=N*.15f*sinf(q*M201210_PI*6);
          v=fmaxf(v,m201210Gauss(x-(p+orb),2.0f)*.72f);
          v=fmaxf(v,m201210Gauss(x-(p-orb-N*.08f),2.0f)*.58f); c=c1;
        }break;
        case 4:{ // stop-go ceremony
          const float pts[5]={.08f,.30f,.50f,.72f,.94f};
          float pos=q*5.0f; int n=(int)floorf(pos); if(n>4)n=4; float f=pos-n;
          p=pts[n]*L; float breathe=.55f+.45f*(.5f+.5f*cosf(f*M201210_PI*4.0f));
          v=m201210Comet(x,p,1,4.0f,N*.14f)*breathe; c=(n&1)?c2:c3;
        }break;
        case 5:{ p=L-m201210Smooth(q)*L; v=m201210Comet(x,p,-1,3.0f,N*.55f); c=c3; }break;
        case 6:{ // opposite comets
          float p1=q*L,p2=L-q*L;
          v=fmaxf(m201210Comet(x,p1,1,2.2f,N*.12f),
                 m201210Comet(x,p2,-1,2.2f,N*.12f)); c=m201210Mix(c1,c2,x/L);
        }break;
        default:{ // five streamlet finale
          float base=q*L;
          for(int k=-2;k<=2;k++){
            float pp=base+(float)k*N*.075f*(1-q);
            v=fmaxf(v,m201210Comet(x,pp,1,1.5f+.15f*abs(k),N*.07f)*(1.0f-.12f*abs(k)));
          } c=m201210Mix(c2,c3,q);
        }break;
      }
    }break;

    case 5:{ // 206 WAVE GATE FLOW
      switch(st){
        case 0:{ // traveling sine ridge
          float ph=(x/L)*M201210_PI*8.0f-q*M201210_PI*10.0f;
          float w=.5f+.5f*sinf(ph); v=powf(m201210Clamp(w),4.0f); c=c1;
        }break;
        case 1:{ // moving aperture
          float center=q*L, width=N*(.10f+.28f*(.5f-.5f*cosf(q*M201210_PI*2)));
          float d=fabsf(x-center);
          v=(d<width)?(.35f+.65f*cosf((d/width)*(M201210_PI/2.0f))):0.0f; c=c2;
        }break;
        case 2:{ // wave packet
          p=q*L;
          float env=m201210Gauss(x-p,N*.18f);
          float wave=.5f+.5f*sinf((x-p)*.23f-q*M201210_PI*8);
          v=env*(.25f+.75f*wave); c=c3;
        }break;
        case 3:{ // interference
          float a=.5f+.5f*sinf(x*.18f-q*M201210_PI*7);
          float b=.5f+.5f*sinf(x*.27f+q*M201210_PI*9);
          v=powf(m201210Clamp(a*b),1.6f); c=m201210Mix(c1,c3,x/L);
        }break;
        case 4:{ // breathing corridor with traveling dark notch
          float breathe=.24f+.76f*(.5f-.5f*cosf(q*M201210_PI*2));
          float notch=m201210Gauss(x-q*L,N*.08f);
          v=m201210Clamp(breathe-notch*.95f); c=c2;
        }break;
        case 5:{ // diagonal zipper wave
          float cell=floorf(x/fmaxf(3.0f,N*.07f));
          float shift=fmodf(cell*0.13f+q,1.0f);
          v=m201210Gauss(shift-.5f,.13f); c=(fmodf(cell,2.0f)<1.0f)?c1:c3;
        }break;
        case 6:{ // reverse ripple train
          float center=L-q*L;
          for(int k=0;k<4;k++){
            float rad=(q+k*.23f)*N*.32f;
            v=fmaxf(v,m201210Ring(x,center,rad,2.0f)*(.88f-.14f*k));
          } c=c3;
        }break;
        default:{ // wave collapse into comet
          float center=(1-q)*L*.5f+q*L;
          float wave=m201210Gauss(x-center,N*(.25f-.17f*q))*(.5f+.5f*sinf((x-center)*(.10f+.25f*q)));
          v=fmaxf(wave,m201210Comet(x,q*L,1,2.0f,N*.11f)*powf(q,2.0f)); c=m201210Mix(c2,c1,q);
        }break;
      }
    }break;

    case 6:{ // 207 ORBIT SHUTTLE
      switch(st){
        case 0:{ p=m201210Ping(q*2.0f*L,L); v=m201210Comet(x,p,q<.5f?1:-1,2.2f,N*.15f); c=c1; }break;
        case 1:{ // orbit pair around moving center
          float center=q*L, d=N*.16f*sinf(q*M201210_PI*6);
          v=fmaxf(m201210Gauss(x-(center+d),2.5f),m201210Gauss(x-(center-d),2.5f)*.8f); c=c2;
        }break;
        case 2:{ // triple orbit
          float center=q*L;
          for(int k=0;k<3;k++){
            float pp=center+sinf(q*M201210_PI*6+k*2.094f)*N*.18f;
            v=fmaxf(v,m201210Gauss(x-pp,2.0f)*(1.0f-.14f*k));
          } c=c3;
        }break;
        case 3:{ // boomerang
          float qq=q<.62f?q/.62f:1.0f-(q-.62f)/.38f;
          p=m201210Clamp(qq)*L;
          v=m201210Comet(x,p,q<.62f?1:-1,3.0f,N*.20f); c=m201210Mix(c1,c2,q);
        }break;
        case 4:{ // edge bounce with widening head
          p=m201210Ping(q*3.0f*L,L);
          int dir=((int)floorf(q*3.0f)%2)==0?1:-1;
          v=m201210Comet(x,p,dir,2.0f+4.0f*q,N*.13f); c=c2;
        }break;
        case 5:{ // center crossing pair
          float p1=q*L,p2=L-q*L;
          float pulse=.65f+.35f*(.5f+.5f*sinf(q*M201210_PI*4));
          v=fmaxf(m201210Comet(x,p1,1,2.1f,N*.11f),
                 m201210Comet(x,p2,-1,2.1f,N*.11f))*pulse; c=c3;
        }break;
        case 6:{ // accelerating ping-pong
          float qq=powf(q,.48f);
          p=m201210Ping(qq*2.0f*L,L);
          int dir=qq<.5f?1:-1;
          v=m201210Comet(x,p,dir,1.7f,N*(.08f+.22f*q)); c=c1;
        }break;
        default:{ // orbit collapse
          float rad=(1-q)*L*.42f;
          float p1=L*.5f+sinf(q*M201210_PI*8)*rad;
          float p2=L*.5f-sinf(q*M201210_PI*8)*rad;
          v=fmaxf(m201210Gauss(x-p1,2.6f),m201210Gauss(x-p2,2.6f));
          v=fmaxf(v,m201210Gauss(x-L*.5f,4.0f)*powf(q,3.0f)); c=m201210Mix(c2,c3,q);
        }break;
      }
    }break;

    case 7:{ // 208 CASCADE BLOOM
      switch(st){
        case 0:{ // sequential cascade
          float base=q*L;
          for(int k=0;k<5;k++)v=fmaxf(v,m201210Comet(x,base-k*N*.13f,1,1.8f,N*.07f)*(1.0f-.13f*k));
          c=c1;
        }break;
        case 1:{ // checkpoint blooms
          const float pts[5]={.10f,.30f,.50f,.70f,.90f};
          float pos=q*5.0f; int n=(int)floorf(pos); if(n>4)n=4; float f=pos-n;
          float rad=f*N*.18f;
          v=m201210Ring(x,pts[n]*L,rad,2.2f); v=fmaxf(v,m201210Gauss(x-pts[n]*L,2.4f)*(1-f)); c=c2;
        }break;
        case 2:{ // forward fountain
          float origin=q*L;
          for(int k=0;k<4;k++){
            float pp=origin+(k-1.5f)*N*.08f*sinf(q*M201210_PI);
            v=fmaxf(v,m201210Comet(x,pp,1,1.7f,N*.09f)*(1.0f-.12f*k));
          } c=c3;
        }break;
        case 3:{ // reverse waterfall
          float base=L-q*L;
          for(int k=0;k<6;k++)v=fmaxf(v,m201210Gauss(x-(base+k*N*.095f),2.1f)*(.95f-.11f*k));
          c=c1;
        }break;
        case 4:{ // center fanout
          for(int k=-2;k<=2;k++){
            float pp=L*.5f+q*(float)k*L*.18f;
            v=fmaxf(v,m201210Gauss(x-pp,2.5f)*(1.0f-.12f*abs(k)));
          } c=c2;
        }break;
        case 5:{ // fanin from distributed points
          for(int k=0;k<4;k++){
            float s=(.12f+.25f*k)*L;
            float pp=s+(L*.5f-s)*q;
            v=fmaxf(v,m201210Comet(x,pp,(pp<L*.5f)?1:-1,2.0f,N*.08f));
          } c=c3;
        }break;
        case 6:{ // four segment relay
          float seg=L/4.0f;
          int active=(int)floorf(q*4.0f); if(active>3)active=3;
          float local=fmodf(q*4.0f,1.0f);
          float pp=(active+local)*seg;
          v=m201210Comet(x,pp,1,2.5f,N*.10f);
          for(int k=0;k<active;k++)v=fmaxf(v,m201210Bar(x,(k+.5f)*seg,seg*.28f)*.28f); c=c1;
        }break;
        default:{ // grand cascade
          float base=q*L;
          for(int k=0;k<7;k++){
            float pp=base-k*N*.10f*(.6f+.4f*sinf(q*M201210_PI));
            v=fmaxf(v,m201210Comet(x,pp,1,1.4f+.18f*k,N*.055f)*(1.0f-.09f*k));
          } c=m201210Mix(c2,c3,q);
        }break;
      }
    }break;

    case 8:{ // 209 ZIPPER AURORA
      switch(st){
        case 0:{ // forward liquid zipper
          float front=q*L;
          float cell=floorf(x/fmaxf(3.0f,N*.05f));
          float offset=(fmodf(cell,2.0f)<1.0f)?0.0f:N*.065f;
          v=m201210Gauss(x-(front-offset),3.0f); c=c1;
        }break;
        case 1:{ // reverse zipper
          float front=L-q*L;
          float cell=floorf(x/fmaxf(3.0f,N*.055f));
          float offset=(fmodf(cell,2.0f)<1.0f)?0.0f:N*.07f;
          v=m201210Gauss(x-(front+offset),3.0f); c=c2;
        }break;
        case 2:{ // center dual zipper
          float l=L*.5f-q*L*.5f,r=L*.5f+q*L*.5f;
          float pattern=.55f+.45f*(.5f+.5f*sinf(x*.45f));
          v=fmaxf(m201210Gauss(x-l,3.2f),m201210Gauss(x-r,3.2f))*pattern; c=c3;
        }break;
        case 3:{ // zipper collapse to edges
          float l=q*L*.5f,r=L-q*L*.5f;
          float mask=.5f+.5f*cosf(x*.38f+q*M201210_PI*6);
          v=fmaxf(m201210Gauss(x-l,3.0f),m201210Gauss(x-r,3.0f))*(.35f+.65f*mask); c=c1;
        }break;
        case 4:{ // broad aurora ribbon
          p=q*L; float env=m201210Gauss(x-p,N*.30f);
          float w=.55f+.45f*sinf(x*.10f+t*4.5f);
          v=env*(.55f+.45f*w); c=m201210Mix(c1,c3,m201210Clamp((x-p)/(N*.6f)+.5f));
        }break;
        case 5:{ // two aurora bands opposite
          float p1=q*L,p2=L-q*L;
          a1=m201210Gauss(x-p1,N*.16f)*(.6f+.4f*sinf(x*.12f+t*5));
          a2=m201210Gauss(x-p2,N*.20f)*(.6f+.4f*cosf(x*.09f-t*4));
          v=fmaxf(a1,a2); c=m201210Mix(c2,c3,x/L);
        }break;
        case 6:{ // soft segmented pulse chase
          float cell=floorf(x/fmaxf(5.0f,N*.12f));
          float local=fmodf(q*7.0f-cell*.22f,1.0f); if(local<0)local+=1.0f;
          v=powf(.5f+.5f*cosf((local-.5f)*M201210_PI*2),5.0f);
          v*=.50f+.50f*m201210Gauss(x-q*L,N*.35f); c=c2;
        }break;
        default:{ // zipper -> aurora finale
          p=q*L;
          float zip=m201210Gauss(x-p,3.0f)*(.55f+.45f*(.5f+.5f*sinf(x*.42f)));
          float aur=m201210Gauss(x-p,N*(.08f+.34f*q))*(.45f+.55f*(.5f+.5f*sinf(x*.10f+t*5.5f)));
          v=fmaxf(zip,aur); c=m201210Mix(c1,c3,q);
        }break;
      }
    }break;

    default:{ // 210 GRAND CEREMONY X
      switch(st){
        case 0:{ // full route relay
          p=m201210Smooth(q)*L; v=m201210Comet(x,p,1,2.4f,N*.24f); c=c1;
        }break;
        case 1:{ // exact reverse relay
          p=L-m201210Smooth(q)*L; v=m201210Comet(x,p,-1,2.4f,N*.24f); c=c2;
        }break;
        case 2:{ // center split
          float l=L*.5f-q*L*.5f,r=L*.5f+q*L*.5f;
          v=fmaxf(m201210Comet(x,l,-1,2.3f,N*.13f),m201210Comet(x,r,1,2.3f,N*.13f)); c=c3;
        }break;
        case 3:{ // edge merge
          float l=q*L*.5f,r=L-q*L*.5f;
          v=fmaxf(m201210Comet(x,l,1,2.6f,N*.16f),m201210Comet(x,r,-1,2.6f,N*.16f));
          v=fmaxf(v,m201210Gauss(x-L*.5f,4.0f)*powf(q,3)); c=c1;
        }break;
        case 4:{ // triple weave
          float base=q*L;
          for(int k=0;k<3;k++){
            float pp=base+sinf(q*M201210_PI*6+k*2.094f)*N*.17f;
            v=fmaxf(v,m201210Comet(x,pp,1,1.8f,N*.08f)*(1.0f-.12f*k));
          } c=c2;
        }break;
        case 5:{ // wave gate
          float center=q*L, env=m201210Gauss(x-center,N*.22f);
          float wave=.5f+.5f*sinf((x-center)*.20f-q*M201210_PI*8);
          v=env*(.25f+.75f*wave); c=c3;
        }break;
        case 6:{ // step pulse then chase
          const float pts[6]={.05f,.20f,.38f,.57f,.76f,.94f};
          float pos=q*5.999f; int n=(int)floorf(pos); if(n>5)n=5;
          p=pts[n]*L;
          v=m201210Comet(x,p,1,3.4f,N*.10f);
          v=fmaxf(v,m201210Gauss(x-p,N*.055f)*(.55f+.45f*sinf(q*M201210_PI*12))); c=(n&1)?c1:c2;
        }break;
        default:{ // four-head grand finale, converging spacing
          float base=q*L, sep=N*.22f*(1-q)+N*.055f;
          for(int k=-2;k<=1;k++){
            float pp=base+k*sep;
            v=fmaxf(v,m201210Comet(x,pp,1,1.6f+.25f*abs(k),N*.07f)*(1.0f-.11f*abs(k)));
          }
          float bloom=m201210Gauss(x-base,N*(.04f+.18f*q))*.48f;
          v=fmaxf(v,bloom); c=m201210Mix(c1,c3,q);
        }break;
      }
    }break;
  }

  M201210Sample out;
  out.v=m201210Clamp(v);
  out.c=c;
  return out;
}

static uint8_t m201210Byte(float x){
  int v=(int)floorf(x+.5f);
  if(v<0)v=0; if(v>255)v=255;
  return (uint8_t)v;
}
static CRGB m201210RenderHtml100(const M201210Sample &s){
  float v=s.v;
  return CRGB(
    m201210Byte(fminf(255.0f,s.c.r*v*1.55f+18*v)),
    m201210Byte(fminf(255.0f,s.c.g*v*1.55f+18*v)),
    m201210Byte(fminf(255.0f,s.c.b*v*1.55f+18*v))
  );
}

// GLOBAL/RAM-safe: satu shared timer kecil per channel, tanpa buffer pixel tambahan.
struct Custom201210SharedState {
  float t = 0.0f;
  unsigned long lastUpdate = 0;
  unsigned long lastCall = 0;
  unsigned long nextDelay = 25;
};
Custom201210SharedState c201210Suite;

static void m201210RenderPair(
  uint8_t mode,CRGB *out1,CRGB *out2,uint16_t count,float tf
){
  if(mode<201||mode>210||!out1||!out2||count==0)return;
  uint8_t id=(uint8_t)(mode-201);
  float N=(float)count,L=N*2.0f-1.0f;
  for(uint16_t i=0;i<count;i++){
    M201210Sample a=m201210NewSample(id,(float)tf,(float)i,L,N);
    M201210Sample b=m201210NewSample(id,(float)tf,N+(float)i,L,N);
    out1[i]=m201210RenderHtml100(a);
    out2[i]=m201210RenderHtml100(b);
  }
}

static void m201210RenderAll4Frame(
  uint8_t mode,CRGB *ch1,CRGB *ch2,CRGB *ch3,CRGB *ch4,uint16_t count,float tf
){
  if(mode<201||mode>210||!ch1||!ch2||!ch3||!ch4||count==0)return;
  CRGB *order[4]={ch1,ch3,ch4,ch2};
  uint8_t id=(uint8_t)(mode-201);
  float N=(float)count,L=N*4.0f-1.0f;
  for(int s=0;s<4;s++){
    for(uint16_t i=0;i<count;i++){
      float x=(float)s*N+(float)i;
      M201210Sample sm=m201210NewSample(id,(float)tf,x,L,N);
      order[s][i]=m201210RenderHtml100(sm);
    }
  }
}

static void updateCustom201210SuiteMode(
  uint8_t mode,CRGB *out1,CRGB *out2,uint16_t count
){
  unsigned long now=millis();
  if(c201210Suite.lastCall==0||(unsigned long)(now-c201210Suite.lastCall)>250UL){
    c201210Suite.t=0.0f; c201210Suite.lastUpdate=0;
  }
  c201210Suite.lastCall=now;
  unsigned long stepDelay=m7180GlobalStep10(c201210Suite.nextDelay);
  if(c201210Suite.lastUpdate!=0&&(unsigned long)(now-c201210Suite.lastUpdate)<stepDelay)return;
  unsigned long dtMs=(c201210Suite.lastUpdate==0)?0UL:(unsigned long)(now-c201210Suite.lastUpdate);
  c201210Suite.lastUpdate=now; c201210Suite.nextDelay=25;
  if(dtMs>200UL)dtMs=200UL;
  c201210Suite.t+=((float)dtMs*.001f)*liveSpeedFactor;
  if(c201210Suite.t>7200.0f)c201210Suite.t=fmodf(c201210Suite.t,7200.0f);
  m201210RenderPair(mode,out1,out2,count,c201210Suite.t);
}

static void updateCustom201210SuiteAll4(
  uint8_t mode,CRGB *ch1,CRGB *ch2,CRGB *ch3,CRGB *ch4,uint16_t count
){
  unsigned long now=millis();
  if(c201210Suite.lastCall==0||(unsigned long)(now-c201210Suite.lastCall)>250UL){
    c201210Suite.t=0.0f; c201210Suite.lastUpdate=0;
  }
  c201210Suite.lastCall=now;
  unsigned long stepDelay=m7180GlobalStep10(c201210Suite.nextDelay);
  if(c201210Suite.lastUpdate!=0&&(unsigned long)(now-c201210Suite.lastUpdate)<stepDelay)return;
  unsigned long dtMs=(c201210Suite.lastUpdate==0)?0UL:(unsigned long)(now-c201210Suite.lastUpdate);
  c201210Suite.lastUpdate=now; c201210Suite.nextDelay=25;
  if(dtMs>200UL)dtMs=200UL;
  c201210Suite.t+=((float)dtMs*.001f)*liveSpeedFactor;
  if(c201210Suite.t>7200.0f)c201210Suite.t=fmodf(c201210Suite.t,7200.0f);
  m201210RenderAll4Frame(mode,ch1,ch2,ch3,ch4,count,c201210Suite.t);
}

void updateCustom201Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom201210SuiteMode(201,out1,out2,count);}
void updateCustom202Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom201210SuiteMode(202,out1,out2,count);}
void updateCustom203Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom201210SuiteMode(203,out1,out2,count);}
void updateCustom204Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom201210SuiteMode(204,out1,out2,count);}
void updateCustom205Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom201210SuiteMode(205,out1,out2,count);}
void updateCustom206Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom201210SuiteMode(206,out1,out2,count);}
void updateCustom207Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom201210SuiteMode(207,out1,out2,count);}
void updateCustom208Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom201210SuiteMode(208,out1,out2,count);}
void updateCustom209Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom201210SuiteMode(209,out1,out2,count);}
void updateCustom210Suite(CRGB *out1,CRGB *out2,uint16_t count){updateCustom201210SuiteMode(210,out1,out2,count);}


// State efek terpisah per channel agar CH1..CH4 bisa menjalankan mode berbeda bersamaan.
Custom1SuiteState c1SuiteByChannel[4];
Custom2SuiteState c2SuiteByChannel[4];
Custom3SuiteState c3SuiteByChannel[4];
Custom4SuiteState c4SuiteByChannel[4];
Custom5SuiteState c5SuiteByChannel[4];
Custom6SuiteState c6SuiteByChannel[4];
Custom7SuiteState c7SuiteByChannel[4];
Custom8SuiteState c8SuiteByChannel[4];
Custom9SuiteState c9SuiteByChannel[4];
Custom10SuiteState c10SuiteByChannel[4];
Custom11SuiteState c11SuiteByChannel[4];
Custom12SuiteState c12SuiteByChannel[4];
Custom13SuiteState c13SuiteByChannel[4];
Custom14SuiteState c14SuiteByChannel[4];
Custom21SuiteState c21SuiteByChannel[4];
Custom22SuiteState c22SuiteByChannel[4];
Custom23SuiteState c23SuiteByChannel[4];
Custom24SuiteState c24SuiteByChannel[4];
Custom25SuiteState c25SuiteByChannel[4];
Custom26SuiteState c26SuiteByChannel[4];
Custom27SuiteState c27SuiteByChannel[4];
Custom28SuiteState c28SuiteByChannel[4];
Custom29SuiteState c29SuiteByChannel[4];
Custom30SuiteState c30SuiteByChannel[4];
Custom31SuiteState c31SuiteByChannel[4];
Custom32SuiteState c32SuiteByChannel[4];
Custom33SuiteState c33SuiteByChannel[4];
Custom34SuiteState c34SuiteByChannel[4];
Custom35SuiteState c35SuiteByChannel[4];
Custom36SuiteState c36SuiteByChannel[4];
Custom37SuiteState c37SuiteByChannel[4];
Custom38SuiteState c38SuiteByChannel[4];
Custom39SuiteState c39SuiteByChannel[4];
Custom40SuiteState c40SuiteByChannel[4];
Custom41SuiteState c41SuiteByChannel[4];
Custom42SuiteState c42SuiteByChannel[4];
Custom43SuiteState c43SuiteByChannel[4];
Custom44SuiteState c44SuiteByChannel[4];
Custom45SuiteState c45SuiteByChannel[4];
Custom46SuiteState c46SuiteByChannel[4];
Custom47SuiteState c47SuiteByChannel[4];
Custom48SuiteState c48SuiteByChannel[4];
Custom49SuiteState c49SuiteByChannel[4];
Custom50SuiteState c50SuiteByChannel[4];
Custom51SuiteState c51SuiteByChannel[4];
Custom52SuiteState c52SuiteByChannel[4];
Custom53SuiteState c53SuiteByChannel[4];
Custom54SuiteState c54SuiteByChannel[4];
Custom55SuiteState c55SuiteByChannel[4];
Custom56SuiteState c56SuiteByChannel[4];
Custom57SuiteState c57SuiteByChannel[4];
Custom58SuiteState c58SuiteByChannel[4];
Custom59SuiteState c59SuiteByChannel[4];
Custom60SuiteState c60SuiteByChannel[4];
Custom61SuiteState c61SuiteByChannel[4];
Custom62SuiteState c62SuiteByChannel[4];
Custom63SuiteState c63SuiteByChannel[4];
Custom64SuiteState c64SuiteByChannel[4];
Custom65SuiteState c65SuiteByChannel[4];
Custom66SuiteState c66SuiteByChannel[4];
Custom67SuiteState c67SuiteByChannel[4];
Custom68SuiteState c68SuiteByChannel[4];
Custom69SuiteState c69SuiteByChannel[4];
Custom70SuiteState c70SuiteByChannel[4];
Custom71SuiteState c71SuiteByChannel[4];
Custom72SuiteState c72SuiteByChannel[4];
Custom73SuiteState c73SuiteByChannel[4];
Custom74SuiteState c74SuiteByChannel[4];
Custom75SuiteState c75SuiteByChannel[4];
Custom76SuiteState c76SuiteByChannel[4];
Custom77SuiteState c77SuiteByChannel[4];
Custom78SuiteState c78SuiteByChannel[4];
Custom79SuiteState c79SuiteByChannel[4];
Custom80SuiteState c80SuiteByChannel[4];
Custom81SuiteState c81SuiteByChannel[4];
Custom82SuiteState c82SuiteByChannel[4];
Custom83SuiteState c83SuiteByChannel[4];
Custom84SuiteState c84SuiteByChannel[4];
Custom85SuiteState c85SuiteByChannel[4];
Custom86SuiteState c86SuiteByChannel[4];
Custom87SuiteState c87SuiteByChannel[4];
Custom88SuiteState c88SuiteByChannel[4];
Custom89SuiteState c89SuiteByChannel[4];
Custom90SuiteState c90SuiteByChannel[4];
Custom91SuiteState c91SuiteByChannel[4];
Custom92SuiteState c92SuiteByChannel[4];
Custom93SuiteState c93SuiteByChannel[4];
Custom94SuiteState c94SuiteByChannel[4];
Custom95SuiteState c95SuiteByChannel[4];
Custom96SuiteState c96SuiteByChannel[4];
Custom97SuiteState c97SuiteByChannel[4];
Custom98SuiteState c98SuiteByChannel[4];
Custom99SuiteState c99SuiteByChannel[4];
Custom100SuiteState c100SuiteByChannel[4];
Custom101SuiteState c101SuiteByChannel[4];
Custom102SuiteState c102SuiteByChannel[4];
Custom103SuiteState c103SuiteByChannel[4];
Custom104SuiteState c104SuiteByChannel[4];
Custom105SuiteState c105SuiteByChannel[4];
Custom106SuiteState c106SuiteByChannel[4];
Custom107SuiteState c107SuiteByChannel[4];
Custom108SuiteState c108SuiteByChannel[4];
Custom109SuiteState c109SuiteByChannel[4];
Custom110SuiteState c110SuiteByChannel[4];
Custom111SuiteState c111SuiteByChannel[4];
Custom112SuiteState c112SuiteByChannel[4];
Custom113SuiteState c113SuiteByChannel[4];
Custom114SuiteState c114SuiteByChannel[4];
Custom115SuiteState c115SuiteByChannel[4];
Custom116SuiteState c116SuiteByChannel[4];
Custom117SuiteState c117SuiteByChannel[4];
Custom118SuiteState c118SuiteByChannel[4];
Custom119SuiteState c119SuiteByChannel[4];
Custom120SuiteState c120SuiteByChannel[4];
Custom121SuiteState c121SuiteByChannel[4];
Custom122SuiteState c122SuiteByChannel[4];
Custom123SuiteState c123SuiteByChannel[4];
Custom124SuiteState c124SuiteByChannel[4];
Custom125SuiteState c125SuiteByChannel[4];
Custom126SuiteState c126SuiteByChannel[4];
Custom127SuiteState c127SuiteByChannel[4];
Custom128SuiteState c128SuiteByChannel[4];
Custom129SuiteState c129SuiteByChannel[4];
Custom130SuiteState c130SuiteByChannel[4];
Custom131SuiteState c131SuiteByChannel[4];
Custom132SuiteState c132SuiteByChannel[4];
Custom133SuiteState c133SuiteByChannel[4];
Custom134SuiteState c134SuiteByChannel[4];
Custom135SuiteState c135SuiteByChannel[4];
Custom136SuiteState c136SuiteByChannel[4];
Custom137SuiteState c137SuiteByChannel[4];
Custom138SuiteState c138SuiteByChannel[4];
Custom139SuiteState c139SuiteByChannel[4];
Custom140SuiteState c140SuiteByChannel[4];
Custom141160SharedState c141160SuiteByChannel[4];
Custom161170SharedState c161170SuiteByChannel[4];
Custom181200SharedState c181200SuiteByChannel[4];
Custom201210SharedState c201210SuiteByChannel[4];
CRGB *modeDummyByChannel[4] = {nullptr, nullptr, nullptr, nullptr};

static inline void loadSuiteStateForChannel(uint8_t ch) {
  c1Suite = c1SuiteByChannel[ch]; c2Suite = c2SuiteByChannel[ch]; c3Suite = c3SuiteByChannel[ch];
  c4Suite = c4SuiteByChannel[ch]; c5Suite = c5SuiteByChannel[ch];
  c6Suite = c6SuiteByChannel[ch]; c7Suite = c7SuiteByChannel[ch]; c8Suite = c8SuiteByChannel[ch];
  c9Suite = c9SuiteByChannel[ch]; c10Suite = c10SuiteByChannel[ch];
  c11Suite = c11SuiteByChannel[ch]; c12Suite = c12SuiteByChannel[ch];
  c13Suite = c13SuiteByChannel[ch]; c14Suite = c14SuiteByChannel[ch];
  c21Suite = c21SuiteByChannel[ch]; c22Suite = c22SuiteByChannel[ch];
  c23Suite = c23SuiteByChannel[ch]; c24Suite = c24SuiteByChannel[ch];
  c25Suite = c25SuiteByChannel[ch]; c26Suite = c26SuiteByChannel[ch];
  if (selectedMode[ch] == 27) c27Suite = c27SuiteByChannel[ch];
  c28Suite = c28SuiteByChannel[ch]; c29Suite = c29SuiteByChannel[ch]; c30Suite = c30SuiteByChannel[ch];
  c31Suite = c31SuiteByChannel[ch]; c32Suite = c32SuiteByChannel[ch]; c33Suite = c33SuiteByChannel[ch];
  c34Suite = c34SuiteByChannel[ch]; c35Suite = c35SuiteByChannel[ch]; c36Suite = c36SuiteByChannel[ch];
  c37Suite = c37SuiteByChannel[ch]; c38Suite = c38SuiteByChannel[ch]; c39Suite = c39SuiteByChannel[ch]; c40Suite = c40SuiteByChannel[ch];
  c41Suite = c41SuiteByChannel[ch]; c42Suite = c42SuiteByChannel[ch]; c43Suite = c43SuiteByChannel[ch]; c44Suite = c44SuiteByChannel[ch]; c45Suite = c45SuiteByChannel[ch];
  c46Suite = c46SuiteByChannel[ch]; c47Suite = c47SuiteByChannel[ch]; c48Suite = c48SuiteByChannel[ch]; c49Suite = c49SuiteByChannel[ch]; c50Suite = c50SuiteByChannel[ch];
  c51Suite = c51SuiteByChannel[ch];
  c52Suite = c52SuiteByChannel[ch];
  c53Suite = c53SuiteByChannel[ch];
  c54Suite = c54SuiteByChannel[ch];
  c55Suite = c55SuiteByChannel[ch];
  c56Suite = c56SuiteByChannel[ch];
  c57Suite = c57SuiteByChannel[ch];
  c58Suite = c58SuiteByChannel[ch];
  c59Suite = c59SuiteByChannel[ch];
  c60Suite = c60SuiteByChannel[ch];
  c61Suite = c61SuiteByChannel[ch];
  c62Suite = c62SuiteByChannel[ch];
  c63Suite = c63SuiteByChannel[ch];
  c64Suite = c64SuiteByChannel[ch];
  c65Suite = c65SuiteByChannel[ch];
  c66Suite = c66SuiteByChannel[ch];
  c67Suite = c67SuiteByChannel[ch];
  c68Suite = c68SuiteByChannel[ch];
  c69Suite = c69SuiteByChannel[ch];
  c70Suite = c70SuiteByChannel[ch];
  c71Suite = c71SuiteByChannel[ch];
  c72Suite = c72SuiteByChannel[ch];
  c73Suite = c73SuiteByChannel[ch];
  c74Suite = c74SuiteByChannel[ch];
  c75Suite = c75SuiteByChannel[ch];
  c76Suite = c76SuiteByChannel[ch];
  c77Suite = c77SuiteByChannel[ch];
  c78Suite = c78SuiteByChannel[ch];
  c79Suite = c79SuiteByChannel[ch];
  c80Suite = c80SuiteByChannel[ch];
  c81Suite = c81SuiteByChannel[ch];
  c82Suite = c82SuiteByChannel[ch];
  c83Suite = c83SuiteByChannel[ch];
  c84Suite = c84SuiteByChannel[ch];
  c85Suite = c85SuiteByChannel[ch];
  c86Suite = c86SuiteByChannel[ch];
  c87Suite = c87SuiteByChannel[ch];
  c88Suite = c88SuiteByChannel[ch];
  c89Suite = c89SuiteByChannel[ch];
  c90Suite = c90SuiteByChannel[ch];
  c91Suite = c91SuiteByChannel[ch];
  c92Suite = c92SuiteByChannel[ch];
  c93Suite = c93SuiteByChannel[ch];
  c94Suite = c94SuiteByChannel[ch];
  c95Suite = c95SuiteByChannel[ch];
  c96Suite = c96SuiteByChannel[ch];
  c97Suite = c97SuiteByChannel[ch];
  c98Suite = c98SuiteByChannel[ch];
  c99Suite = c99SuiteByChannel[ch];
  c100Suite = c100SuiteByChannel[ch];
  c101Suite = c101SuiteByChannel[ch];
  c102Suite = c102SuiteByChannel[ch];
  c103Suite = c103SuiteByChannel[ch];
  c104Suite = c104SuiteByChannel[ch];
  c105Suite = c105SuiteByChannel[ch];
  c106Suite = c106SuiteByChannel[ch];
  c107Suite = c107SuiteByChannel[ch];
  c108Suite = c108SuiteByChannel[ch];
  c109Suite = c109SuiteByChannel[ch];
  c110Suite = c110SuiteByChannel[ch];
  c111Suite = c111SuiteByChannel[ch];
  c112Suite = c112SuiteByChannel[ch];
  c113Suite = c113SuiteByChannel[ch];
  c114Suite = c114SuiteByChannel[ch];
  c115Suite = c115SuiteByChannel[ch];
  c116Suite = c116SuiteByChannel[ch];
  c117Suite = c117SuiteByChannel[ch];
  c118Suite = c118SuiteByChannel[ch];
  c119Suite = c119SuiteByChannel[ch];
  c120Suite = c120SuiteByChannel[ch];
  c121Suite = c121SuiteByChannel[ch];
  c122Suite = c122SuiteByChannel[ch];
  c123Suite = c123SuiteByChannel[ch];
  c124Suite = c124SuiteByChannel[ch];
  c125Suite = c125SuiteByChannel[ch];
  c126Suite = c126SuiteByChannel[ch];
  c127Suite = c127SuiteByChannel[ch];
  c128Suite = c128SuiteByChannel[ch];
  c129Suite = c129SuiteByChannel[ch];
  c130Suite = c130SuiteByChannel[ch];
  c131Suite = c131SuiteByChannel[ch];
  c132Suite = c132SuiteByChannel[ch];
  c133Suite = c133SuiteByChannel[ch];
  c134Suite = c134SuiteByChannel[ch];
  c135Suite = c135SuiteByChannel[ch];
  c136Suite = c136SuiteByChannel[ch];
  c137Suite = c137SuiteByChannel[ch];
  c138Suite = c138SuiteByChannel[ch];
  c139Suite = c139SuiteByChannel[ch];
  c140Suite = c140SuiteByChannel[ch];
  c141160Suite = c141160SuiteByChannel[ch];
  c161170Suite = c161170SuiteByChannel[ch];
  c181200Suite = c181200SuiteByChannel[ch];
  c201210Suite = c201210SuiteByChannel[ch];
  activeSuiteChannel = ch;
}

static inline void saveSuiteStateForChannel(uint8_t ch) {
  c1SuiteByChannel[ch] = c1Suite; c2SuiteByChannel[ch] = c2Suite; c3SuiteByChannel[ch] = c3Suite;
  c4SuiteByChannel[ch] = c4Suite; c5SuiteByChannel[ch] = c5Suite;
  c6SuiteByChannel[ch] = c6Suite; c7SuiteByChannel[ch] = c7Suite; c8SuiteByChannel[ch] = c8Suite;
  c9SuiteByChannel[ch] = c9Suite; c10SuiteByChannel[ch] = c10Suite;
  c11SuiteByChannel[ch] = c11Suite; c12SuiteByChannel[ch] = c12Suite;
  c13SuiteByChannel[ch] = c13Suite; c14SuiteByChannel[ch] = c14Suite;
  c21SuiteByChannel[ch] = c21Suite; c22SuiteByChannel[ch] = c22Suite;
  c23SuiteByChannel[ch] = c23Suite; c24SuiteByChannel[ch] = c24Suite;
  c25SuiteByChannel[ch] = c25Suite; c26SuiteByChannel[ch] = c26Suite;
  if (selectedMode[ch] == 27) c27SuiteByChannel[ch] = c27Suite;
  c28SuiteByChannel[ch] = c28Suite; c29SuiteByChannel[ch] = c29Suite; c30SuiteByChannel[ch] = c30Suite;
  c31SuiteByChannel[ch] = c31Suite; c32SuiteByChannel[ch] = c32Suite; c33SuiteByChannel[ch] = c33Suite;
  c34SuiteByChannel[ch] = c34Suite; c35SuiteByChannel[ch] = c35Suite; c36SuiteByChannel[ch] = c36Suite;
  c37SuiteByChannel[ch] = c37Suite; c38SuiteByChannel[ch] = c38Suite; c39SuiteByChannel[ch] = c39Suite; c40SuiteByChannel[ch] = c40Suite;
  c41SuiteByChannel[ch] = c41Suite; c42SuiteByChannel[ch] = c42Suite; c43SuiteByChannel[ch] = c43Suite; c44SuiteByChannel[ch] = c44Suite; c45SuiteByChannel[ch] = c45Suite;
  c46SuiteByChannel[ch] = c46Suite; c47SuiteByChannel[ch] = c47Suite; c48SuiteByChannel[ch] = c48Suite; c49SuiteByChannel[ch] = c49Suite; c50SuiteByChannel[ch] = c50Suite;
  c51SuiteByChannel[ch] = c51Suite;
  c52SuiteByChannel[ch] = c52Suite;
  c53SuiteByChannel[ch] = c53Suite;
  c54SuiteByChannel[ch] = c54Suite;
  c55SuiteByChannel[ch] = c55Suite;
  c56SuiteByChannel[ch] = c56Suite;
  c57SuiteByChannel[ch] = c57Suite;
  c58SuiteByChannel[ch] = c58Suite;
  c59SuiteByChannel[ch] = c59Suite;
  c60SuiteByChannel[ch] = c60Suite;
  c61SuiteByChannel[ch] = c61Suite;
  c62SuiteByChannel[ch] = c62Suite;
  c63SuiteByChannel[ch] = c63Suite;
  c64SuiteByChannel[ch] = c64Suite;
  c65SuiteByChannel[ch] = c65Suite;
  c66SuiteByChannel[ch] = c66Suite;
  c67SuiteByChannel[ch] = c67Suite;
  c68SuiteByChannel[ch] = c68Suite;
  c69SuiteByChannel[ch] = c69Suite;
  c70SuiteByChannel[ch] = c70Suite;
  c71SuiteByChannel[ch] = c71Suite;
  c72SuiteByChannel[ch] = c72Suite;
  c73SuiteByChannel[ch] = c73Suite;
  c74SuiteByChannel[ch] = c74Suite;
  c75SuiteByChannel[ch] = c75Suite;
  c76SuiteByChannel[ch] = c76Suite;
  c77SuiteByChannel[ch] = c77Suite;
  c78SuiteByChannel[ch] = c78Suite;
  c79SuiteByChannel[ch] = c79Suite;
  c80SuiteByChannel[ch] = c80Suite;
  c81SuiteByChannel[ch] = c81Suite;
  c82SuiteByChannel[ch] = c82Suite;
  c83SuiteByChannel[ch] = c83Suite;
  c84SuiteByChannel[ch] = c84Suite;
  c85SuiteByChannel[ch] = c85Suite;
  c86SuiteByChannel[ch] = c86Suite;
  c87SuiteByChannel[ch] = c87Suite;
  c88SuiteByChannel[ch] = c88Suite;
  c89SuiteByChannel[ch] = c89Suite;
  c90SuiteByChannel[ch] = c90Suite;
  c91SuiteByChannel[ch] = c91Suite;
  c92SuiteByChannel[ch] = c92Suite;
  c93SuiteByChannel[ch] = c93Suite;
  c94SuiteByChannel[ch] = c94Suite;
  c95SuiteByChannel[ch] = c95Suite;
  c96SuiteByChannel[ch] = c96Suite;
  c97SuiteByChannel[ch] = c97Suite;
  c98SuiteByChannel[ch] = c98Suite;
  c99SuiteByChannel[ch] = c99Suite;
  c100SuiteByChannel[ch] = c100Suite;
  c101SuiteByChannel[ch] = c101Suite;
  c102SuiteByChannel[ch] = c102Suite;
  c103SuiteByChannel[ch] = c103Suite;
  c104SuiteByChannel[ch] = c104Suite;
  c105SuiteByChannel[ch] = c105Suite;
  c106SuiteByChannel[ch] = c106Suite;
  c107SuiteByChannel[ch] = c107Suite;
  c108SuiteByChannel[ch] = c108Suite;
  c109SuiteByChannel[ch] = c109Suite;
  c110SuiteByChannel[ch] = c110Suite;
  c111SuiteByChannel[ch] = c111Suite;
  c112SuiteByChannel[ch] = c112Suite;
  c113SuiteByChannel[ch] = c113Suite;
  c114SuiteByChannel[ch] = c114Suite;
  c115SuiteByChannel[ch] = c115Suite;
  c116SuiteByChannel[ch] = c116Suite;
  c117SuiteByChannel[ch] = c117Suite;
  c118SuiteByChannel[ch] = c118Suite;
  c119SuiteByChannel[ch] = c119Suite;
  c120SuiteByChannel[ch] = c120Suite;
  c121SuiteByChannel[ch] = c121Suite;
  c122SuiteByChannel[ch] = c122Suite;
  c123SuiteByChannel[ch] = c123Suite;
  c124SuiteByChannel[ch] = c124Suite;
  c125SuiteByChannel[ch] = c125Suite;
  c126SuiteByChannel[ch] = c126Suite;
  c127SuiteByChannel[ch] = c127Suite;
  c128SuiteByChannel[ch] = c128Suite;
  c129SuiteByChannel[ch] = c129Suite;
  c130SuiteByChannel[ch] = c130Suite;
  c131SuiteByChannel[ch] = c131Suite;
  c132SuiteByChannel[ch] = c132Suite;
  c133SuiteByChannel[ch] = c133Suite;
  c134SuiteByChannel[ch] = c134Suite;
  c135SuiteByChannel[ch] = c135Suite;
  c136SuiteByChannel[ch] = c136Suite;
  c137SuiteByChannel[ch] = c137Suite;
  c138SuiteByChannel[ch] = c138Suite;
  c139SuiteByChannel[ch] = c139Suite;
  c140SuiteByChannel[ch] = c140Suite;
  c141160SuiteByChannel[ch] = c141160Suite;
  c161170SuiteByChannel[ch] = c161170Suite;
  c181200SuiteByChannel[ch] = c181200Suite;
  c201210SuiteByChannel[ch] = c201210Suite;
}

static void resetSuiteStateForChannel(uint8_t ch) {
  if (ch > 3) return;
  c1SuiteByChannel[ch] = Custom1SuiteState{};
  c2SuiteByChannel[ch] = Custom2SuiteState{};
  c3SuiteByChannel[ch] = Custom3SuiteState{};
  c4SuiteByChannel[ch] = Custom4SuiteState{};
  c5SuiteByChannel[ch] = Custom5SuiteState{};
  c6SuiteByChannel[ch] = Custom6SuiteState{};
  c7SuiteByChannel[ch] = Custom7SuiteState{};
  c8SuiteByChannel[ch] = Custom8SuiteState{};
  c9SuiteByChannel[ch] = Custom9SuiteState{};
  c10SuiteByChannel[ch] = Custom10SuiteState{};
  c11SuiteByChannel[ch] = Custom11SuiteState{};
  c12SuiteByChannel[ch] = Custom12SuiteState{};
  c13SuiteByChannel[ch] = Custom13SuiteState{};
  c14SuiteByChannel[ch] = Custom14SuiteState{};
  c21SuiteByChannel[ch] = Custom21SuiteState{};
  c22SuiteByChannel[ch] = Custom22SuiteState{};
  c23SuiteByChannel[ch] = Custom23SuiteState{};
  c24SuiteByChannel[ch] = Custom24SuiteState{};
  c25SuiteByChannel[ch] = Custom25SuiteState{};
  c26SuiteByChannel[ch] = Custom26SuiteState{};
  c27SuiteByChannel[ch] = Custom27SuiteState{};
  c28SuiteByChannel[ch] = Custom28SuiteState{};
  c29SuiteByChannel[ch] = Custom29SuiteState{};
  c30SuiteByChannel[ch] = Custom30SuiteState{};
  c31SuiteByChannel[ch] = Custom31SuiteState{};
  c32SuiteByChannel[ch] = Custom32SuiteState{};
  c33SuiteByChannel[ch] = Custom33SuiteState{};
  c34SuiteByChannel[ch] = Custom34SuiteState{};
  c35SuiteByChannel[ch] = Custom35SuiteState{};
  c36SuiteByChannel[ch] = Custom36SuiteState{};
  c37SuiteByChannel[ch] = Custom37SuiteState{};
  c38SuiteByChannel[ch] = Custom38SuiteState{};
  c39SuiteByChannel[ch] = Custom39SuiteState{};
  c40SuiteByChannel[ch] = Custom40SuiteState{};
  c41SuiteByChannel[ch] = Custom41SuiteState{};
  c42SuiteByChannel[ch] = Custom42SuiteState{};
  c43SuiteByChannel[ch] = Custom43SuiteState{};
  c44SuiteByChannel[ch] = Custom44SuiteState{};
  c45SuiteByChannel[ch] = Custom45SuiteState{};
  c46SuiteByChannel[ch] = Custom46SuiteState{};
  c47SuiteByChannel[ch] = Custom47SuiteState{};
  c48SuiteByChannel[ch] = Custom48SuiteState{};
  c49SuiteByChannel[ch] = Custom49SuiteState{};
  c50SuiteByChannel[ch] = Custom50SuiteState{};
  c51SuiteByChannel[ch] = Custom51SuiteState{};
  c52SuiteByChannel[ch] = Custom52SuiteState{};
  c53SuiteByChannel[ch] = Custom53SuiteState{};
  c54SuiteByChannel[ch] = Custom54SuiteState{};
  c55SuiteByChannel[ch] = Custom55SuiteState{};
  c56SuiteByChannel[ch] = Custom56SuiteState{};
  c57SuiteByChannel[ch] = Custom57SuiteState{};
  c58SuiteByChannel[ch] = Custom58SuiteState{};
  c59SuiteByChannel[ch] = Custom59SuiteState{};
  c60SuiteByChannel[ch] = Custom60SuiteState{};
  c61SuiteByChannel[ch] = Custom61SuiteState{};
  c62SuiteByChannel[ch] = Custom62SuiteState{};
  c63SuiteByChannel[ch] = Custom63SuiteState{};
  c64SuiteByChannel[ch] = Custom64SuiteState{};
  c65SuiteByChannel[ch] = Custom65SuiteState{};
  c66SuiteByChannel[ch] = Custom66SuiteState{};
  c67SuiteByChannel[ch] = Custom67SuiteState{};
  c68SuiteByChannel[ch] = Custom68SuiteState{};
  c69SuiteByChannel[ch] = Custom69SuiteState{};
  c70SuiteByChannel[ch] = Custom70SuiteState{};
  c71SuiteByChannel[ch] = Custom71SuiteState{};
  c72SuiteByChannel[ch] = Custom72SuiteState{};
  c73SuiteByChannel[ch] = Custom73SuiteState{};
  c74SuiteByChannel[ch] = Custom74SuiteState{};
  c75SuiteByChannel[ch] = Custom75SuiteState{};
  c76SuiteByChannel[ch] = Custom76SuiteState{};
  c77SuiteByChannel[ch] = Custom77SuiteState{};
  c78SuiteByChannel[ch] = Custom78SuiteState{};
  c79SuiteByChannel[ch] = Custom79SuiteState{};
  c80SuiteByChannel[ch] = Custom80SuiteState{};
  c81SuiteByChannel[ch] = Custom81SuiteState{};
  c82SuiteByChannel[ch] = Custom82SuiteState{};
  c83SuiteByChannel[ch] = Custom83SuiteState{};
  c84SuiteByChannel[ch] = Custom84SuiteState{};
  c85SuiteByChannel[ch] = Custom85SuiteState{};
  c86SuiteByChannel[ch] = Custom86SuiteState{};
  c87SuiteByChannel[ch] = Custom87SuiteState{};
  c88SuiteByChannel[ch] = Custom88SuiteState{};
  c89SuiteByChannel[ch] = Custom89SuiteState{};
  c90SuiteByChannel[ch] = Custom90SuiteState{};
  c91SuiteByChannel[ch] = Custom91SuiteState{};
  c92SuiteByChannel[ch] = Custom92SuiteState{};
  c93SuiteByChannel[ch] = Custom93SuiteState{};
  c94SuiteByChannel[ch] = Custom94SuiteState{};
  c95SuiteByChannel[ch] = Custom95SuiteState{};
  c96SuiteByChannel[ch] = Custom96SuiteState{};
  c97SuiteByChannel[ch] = Custom97SuiteState{};
  c98SuiteByChannel[ch] = Custom98SuiteState{};
  c99SuiteByChannel[ch] = Custom99SuiteState{};
  c100SuiteByChannel[ch] = Custom100SuiteState{};
  c101SuiteByChannel[ch] = Custom101SuiteState{};
  c102SuiteByChannel[ch] = Custom102SuiteState{};
  c103SuiteByChannel[ch] = Custom103SuiteState{};
  c104SuiteByChannel[ch] = Custom104SuiteState{};
  c105SuiteByChannel[ch] = Custom105SuiteState{};
  c106SuiteByChannel[ch] = Custom106SuiteState{};
  c107SuiteByChannel[ch] = Custom107SuiteState{};
  c108SuiteByChannel[ch] = Custom108SuiteState{};
  c109SuiteByChannel[ch] = Custom109SuiteState{};
  c110SuiteByChannel[ch] = Custom110SuiteState{};
  c111SuiteByChannel[ch] = Custom111SuiteState{};
  c112SuiteByChannel[ch] = Custom112SuiteState{};
  c113SuiteByChannel[ch] = Custom113SuiteState{};
  c114SuiteByChannel[ch] = Custom114SuiteState{};
  c115SuiteByChannel[ch] = Custom115SuiteState{};
  c116SuiteByChannel[ch] = Custom116SuiteState{};
  c117SuiteByChannel[ch] = Custom117SuiteState{};
  c118SuiteByChannel[ch] = Custom118SuiteState{};
  c119SuiteByChannel[ch] = Custom119SuiteState{};
  c120SuiteByChannel[ch] = Custom120SuiteState{};
  c121SuiteByChannel[ch] = Custom121SuiteState{};
  c122SuiteByChannel[ch] = Custom122SuiteState{};
  c123SuiteByChannel[ch] = Custom123SuiteState{};
  c124SuiteByChannel[ch] = Custom124SuiteState{};
  c125SuiteByChannel[ch] = Custom125SuiteState{};
  c126SuiteByChannel[ch] = Custom126SuiteState{};
  c127SuiteByChannel[ch] = Custom127SuiteState{};
  c128SuiteByChannel[ch] = Custom128SuiteState{};
  c129SuiteByChannel[ch] = Custom129SuiteState{};
  c130SuiteByChannel[ch] = Custom130SuiteState{};
  c131SuiteByChannel[ch] = Custom131SuiteState{};
  c132SuiteByChannel[ch] = Custom132SuiteState{};
  c133SuiteByChannel[ch] = Custom133SuiteState{};
  c134SuiteByChannel[ch] = Custom134SuiteState{};
  c135SuiteByChannel[ch] = Custom135SuiteState{};
  c136SuiteByChannel[ch] = Custom136SuiteState{};
  c137SuiteByChannel[ch] = Custom137SuiteState{};
  c138SuiteByChannel[ch] = Custom138SuiteState{};
  c139SuiteByChannel[ch] = Custom139SuiteState{};
  c140SuiteByChannel[ch] = Custom140SuiteState{};
  c141160SuiteByChannel[ch] = Custom141160SharedState{};
  c161170SuiteByChannel[ch] = Custom161170SharedState{};
  c181200SuiteByChannel[ch] = Custom181200SharedState{};
  c201210SuiteByChannel[ch] = Custom201210SharedState{};
  m93100ClearPhysicalTrail(ch, activeLedCount);
  fill_solid(c12TrailKByChannel[ch], runtimeAuxCount, CRGB::Black);
  fill_solid(c12TrailNByChannel[ch], runtimeAuxCount, CRGB::Black);
  fill_solid(modeDummyByChannel[ch], runtimeAuxCount, CRGB::Black);
}

static void resetAllChannelSuiteStates() {
  for (uint8_t ch = 0; ch < 4; ch++) resetSuiteStateForChannel(ch);
}

void updateCustom5Suite(CRGB *out1, CRGB *out2, uint16_t count) {
  unsigned long now = millis();
  if (c5Suite.lastUpdate != 0 && (now - c5Suite.lastUpdate < getMode210StepDelay(c5Suite.nextDelay))) return;
  c5Suite.lastUpdate = now;
  for (int i = 0; i < count; i++) { out1[i].nscale8(180); out2[i].nscale8(180); }
  if (now - c5Suite.lastChangeTime > getMode210Duration(6000UL)) {
    c5Suite.fase = !c5Suite.fase; c5Suite.lastChangeTime = now; fill_solid(out1, count, CRGB::Black); fill_solid(out2, count, CRGB::Black);
  }
  if (c5Suite.fase == 0) {
    for (int i = 0; i < count; i++) out2[i] = CHSV(c5Suite.gHue + (i * 15), 255, 255);
    int idx = (c5Suite.meteorDir == 1) ? (count - 1 - c5Suite.meteorPos) : c5Suite.meteorPos;
    if (idx >= 0 && idx < count) out1[idx] = CHSV(c5Suite.meteorHue, 255, 255);
  } else {
    for (int i = 0; i < count; i++) out1[(count - 1) - i] = CHSV(c5Suite.gHue + (i * 15), 255, 255);
    int idx = (c5Suite.meteorDir == 1) ? c5Suite.meteorPos : (count - 1 - c5Suite.meteorPos);
    if (idx >= 0 && idx < count) out2[idx] = CHSV(c5Suite.meteorHue, 255, 255);
  }
  c5Suite.gHue += 3; c5Suite.meteorPos++;
  if (c5Suite.meteorPos >= count) { c5Suite.meteorPos = 0; c5Suite.meteorDir = -c5Suite.meteorDir; c5Suite.meteorHue = random(0, 255); }
  c5Suite.nextDelay = 25;
}

static unsigned long modeLastRenderAt = 0;
void resetCustomSuites() {
  c1Suite.lastUpdate = 0; c1Suite.isPause = false;
  c2Suite.lastUpdate = 0; c2Suite.isPause = false;
  c3Suite.lastUpdate = 0; c3Suite.isPause = false;
  c4Suite.lastUpdate = 0; c4Suite.isOn = true;
  c5Suite.lastUpdate = 0;
  c6Suite = Custom6SuiteState{};
  c7Suite = Custom7SuiteState{};
  c8Suite = Custom8SuiteState{};
  c9Suite = Custom9SuiteState{};
  c10Suite = Custom10SuiteState{};
  c11Suite = Custom11SuiteState{};
  c12Suite = Custom12SuiteState{};
  resetCustom13And14Suites();
  c21Suite = Custom21SuiteState{}; c22Suite = Custom22SuiteState{};
  c23Suite = Custom23SuiteState{}; c24Suite = Custom24SuiteState{};
  c25Suite = Custom25SuiteState{}; c26Suite = Custom26SuiteState{};
  c27Suite = Custom27SuiteState{}; c28Suite = Custom28SuiteState{};
  c29Suite = Custom29SuiteState{}; c30Suite = Custom30SuiteState{};
  c31Suite = Custom31SuiteState{}; c32Suite = Custom32SuiteState{}; c33Suite = Custom33SuiteState{};
  c34Suite = Custom34SuiteState{}; c35Suite = Custom35SuiteState{}; c36Suite = Custom36SuiteState{};
  c37Suite = Custom37SuiteState{}; c38Suite = Custom38SuiteState{}; c39Suite = Custom39SuiteState{}; c40Suite = Custom40SuiteState{};
  c41Suite = Custom41SuiteState{}; c42Suite = Custom42SuiteState{}; c43Suite = Custom43SuiteState{}; c44Suite = Custom44SuiteState{}; c45Suite = Custom45SuiteState{};
  c46Suite = Custom46SuiteState{}; c47Suite = Custom47SuiteState{}; c48Suite = Custom48SuiteState{}; c49Suite = Custom49SuiteState{}; c50Suite = Custom50SuiteState{};
  c51Suite = Custom51SuiteState{};
  c52Suite = Custom52SuiteState{};
  c53Suite = Custom53SuiteState{};
  c54Suite = Custom54SuiteState{};
  c55Suite = Custom55SuiteState{};
  c56Suite = Custom56SuiteState{};
  c57Suite = Custom57SuiteState{};
  c58Suite = Custom58SuiteState{};
  c59Suite = Custom59SuiteState{};
  c60Suite = Custom60SuiteState{};
  c61Suite = Custom61SuiteState{};
  c62Suite = Custom62SuiteState{};
  c63Suite = Custom63SuiteState{};
  c64Suite = Custom64SuiteState{};
  c65Suite = Custom65SuiteState{};
  c66Suite = Custom66SuiteState{};
  c67Suite = Custom67SuiteState{};
  c68Suite = Custom68SuiteState{};
  c69Suite = Custom69SuiteState{};
  c70Suite = Custom70SuiteState{};
  c71Suite = Custom71SuiteState{};
  c72Suite = Custom72SuiteState{};
  c73Suite = Custom73SuiteState{};
  c74Suite = Custom74SuiteState{};
  c75Suite = Custom75SuiteState{};
  c76Suite = Custom76SuiteState{};
  c77Suite = Custom77SuiteState{};
  c78Suite = Custom78SuiteState{};
  c79Suite = Custom79SuiteState{};
  c80Suite = Custom80SuiteState{};
  c81Suite = Custom81SuiteState{};
  c82Suite = Custom82SuiteState{};
  c83Suite = Custom83SuiteState{};
  c84Suite = Custom84SuiteState{};
  c85Suite = Custom85SuiteState{};
  c86Suite = Custom86SuiteState{};
  c87Suite = Custom87SuiteState{};
  c88Suite = Custom88SuiteState{};
  c89Suite = Custom89SuiteState{};
  c90Suite = Custom90SuiteState{};
  c91Suite = Custom91SuiteState{};
  c92Suite = Custom92SuiteState{};
  c93Suite = Custom93SuiteState{};
  c94Suite = Custom94SuiteState{};
  c95Suite = Custom95SuiteState{};
  c96Suite = Custom96SuiteState{};
  c97Suite = Custom97SuiteState{};
  c98Suite = Custom98SuiteState{};
  c99Suite = Custom99SuiteState{};
  c100Suite = Custom100SuiteState{};
  c101Suite = Custom101SuiteState{};
  c102Suite = Custom102SuiteState{};
  c103Suite = Custom103SuiteState{};
  c104Suite = Custom104SuiteState{};
  c105Suite = Custom105SuiteState{};
  c106Suite = Custom106SuiteState{};
  c107Suite = Custom107SuiteState{};
  c108Suite = Custom108SuiteState{};
  c109Suite = Custom109SuiteState{};
  c110Suite = Custom110SuiteState{};
  c111Suite = Custom111SuiteState{};
  c112Suite = Custom112SuiteState{};
  c113Suite = Custom113SuiteState{};
  c114Suite = Custom114SuiteState{};
  c115Suite = Custom115SuiteState{};
  c116Suite = Custom116SuiteState{};
  c117Suite = Custom117SuiteState{};
  c118Suite = Custom118SuiteState{};
  c119Suite = Custom119SuiteState{};
  c120Suite = Custom120SuiteState{};
  c121Suite = Custom121SuiteState{};
  c122Suite = Custom122SuiteState{};
  c123Suite = Custom123SuiteState{};
  c124Suite = Custom124SuiteState{};
  c125Suite = Custom125SuiteState{};
  c126Suite = Custom126SuiteState{};
  c127Suite = Custom127SuiteState{};
  c128Suite = Custom128SuiteState{};
  c129Suite = Custom129SuiteState{};
  c130Suite = Custom130SuiteState{};
  c131Suite = Custom131SuiteState{};
  c132Suite = Custom132SuiteState{};
  c133Suite = Custom133SuiteState{};
  c134Suite = Custom134SuiteState{};
  c135Suite = Custom135SuiteState{};
  c136Suite = Custom136SuiteState{};
  c137Suite = Custom137SuiteState{};
  c138Suite = Custom138SuiteState{};
  c139Suite = Custom139SuiteState{};
  c140Suite = Custom140SuiteState{};
  c141160Suite = Custom141160SharedState{};
  c161170Suite = Custom161170SharedState{};
  c181200Suite = Custom181200SharedState{};
  c201210Suite = Custom201210SharedState{};
  for (uint8_t _ch=0; _ch<4; _ch++) m93100ClearPhysicalTrail(_ch, activeLedCount);
}

static void renderMode210Pattern(uint8_t modeNum, CRGB *out1, CRGB *out2, uint16_t count) {
  switch (modeNum) {
    case 1: updateCustom1Suite(out1, out2, count); break;
    case 2: updateCustom2Suite(out1, out2, count); break;
    case 3: updateCustom3Suite(out1, out2, count); break;
    case 4: updateCustom4Suite(out1, out2, count); break;
    case 5: updateCustom5Suite(out1, out2, count); break;
    case 6: updateCustom6Suite(out1, out2, count); break;
    case 7: updateCustom7Suite(out1, out2, count); break;
    case 8: updateCustom8Suite(out1, out2, count); break;
    case 9: updateCustom9Suite(out1, out2, count); break;
    case 10: updateCustom10Suite(out1, out2, count); break;
    case 11: updateCustom11Suite(out1, out2, count); break;
    case 12: updateCustom12Suite(out1, out2, count); break;
    case 13: updateCustom13Suite(out1, out2, count); break;
    case 14: updateCustom14Suite(out1, out2, count); break;
    case 15: updateCustom15Suite(out1, out2, count); break;
    case 16: updateCustom16Suite(out1, out2, count); break;
    case 17: updateCustom17Suite(out1, out2, count); break;
    case 18: updateCustom18Suite(out1, out2, count); break;
    case 19: updateCustom19Suite(out1, out2, count); break;
    case 20: updateCustom20Suite(out1, out2, count); break;
    case 21: updateCustom21Suite(out1, out2, count); break;
    case 22: updateCustom22Suite(out1, out2, count); break;
    case 23: updateCustom23Suite(out1, out2, count); break;
    case 24: updateCustom24Suite(out1, out2, count); break;
    case 25: updateCustom25Suite(out1, out2, count); break;
    case 26: updateCustom26Suite(out1, out2, count); break;
    case 27: updateCustom27Suite(out1, out2, count); break;
    case 28: updateCustom28Suite(out1, out2, count); break;
    case 29: updateCustom29Suite(out1, out2, count); break;
    case 30: updateCustom30Suite(out1, out2, count); break;
    case 31: updateCustom31Suite(out1, out2, count); break;
    case 32: updateCustom32Suite(out1, out2, count); break;
    case 33: updateCustom33Suite(out1, out2, count); break;
    case 34: updateCustom34Suite(out1, out2, count); break;
    case 35: updateCustom35Suite(out1, out2, count); break;
    case 36: updateCustom36Suite(out1, out2, count); break;
    case 37: updateCustom37Suite(out1, out2, count); break;
    case 38: updateCustom38Suite(out1, out2, count); break;
    case 39: updateCustom39Suite(out1, out2, count); break;
    case 40: updateCustom40Suite(out1, out2, count); break;
    case 41: updateCustom41Suite(out1, out2, count); break;
    case 42: updateCustom42Suite(out1, out2, count); break;
    case 43: updateCustom43Suite(out1, out2, count); break;
    case 44: updateCustom44Suite(out1, out2, count); break;
    case 45: updateCustom45Suite(out1, out2, count); break;
    case 46: updateCustom46Suite(out1, out2, count); break;
    case 47: updateCustom47Suite(out1, out2, count); break;
    case 48: updateCustom48Suite(out1, out2, count); break;
    case 49: updateCustom49Suite(out1, out2, count); break;
    case 50: updateCustom50Suite(out1, out2, count); break;
    case 51: updateCustom51Suite(out1, out2, count); break;
    case 52: updateCustom52Suite(out1, out2, count); break;
    case 53: updateCustom53Suite(out1, out2, count); break;
    case 54: updateCustom54Suite(out1, out2, count); break;
    case 55: updateCustom55Suite(out1, out2, count); break;
    case 56: updateCustom56Suite(out1, out2, count); break;
    case 57: updateCustom57Suite(out1, out2, count); break;
    case 58: updateCustom58Suite(out1, out2, count); break;
    case 59: updateCustom59Suite(out1, out2, count); break;
    case 60: updateCustom60Suite(out1, out2, count); break;
    case 61: updateCustom61Suite(out1, out2, count); break;
    case 62: updateCustom62Suite(out1, out2, count); break;
    case 63: updateCustom63Suite(out1, out2, count); break;
    case 64: updateCustom64Suite(out1, out2, count); break;
    case 65: updateCustom65Suite(out1, out2, count); break;
    case 66: updateCustom66Suite(out1, out2, count); break;
    case 67: updateCustom67Suite(out1, out2, count); break;
    case 68: updateCustom68Suite(out1, out2, count); break;
    case 69: updateCustom69Suite(out1, out2, count); break;
    case 70: updateCustom70Suite(out1, out2, count); break;
    case 71: updateCustom71Suite(out1, out2, count); break;
    case 72: updateCustom72Suite(out1, out2, count); break;
    case 73: updateCustom73Suite(out1, out2, count); break;
    case 74: updateCustom74Suite(out1, out2, count); break;
    case 75: updateCustom75Suite(out1, out2, count); break;
    case 76: updateCustom76Suite(out1, out2, count); break;
    case 77: updateCustom77Suite(out1, out2, count); break;
    case 78: updateCustom78Suite(out1, out2, count); break;
    case 79: updateCustom79Suite(out1, out2, count); break;
    case 80: updateCustom80Suite(out1, out2, count); break;
    case 81: updateCustom81Suite(out1, out2, count); break;
    case 82: updateCustom82Suite(out1, out2, count); break;
    case 83: updateCustom83Suite(out1, out2, count); break;
    case 84: updateCustom84Suite(out1, out2, count); break;
    case 85: updateCustom85Suite(out1, out2, count); break;
    case 86: updateCustom86Suite(out1, out2, count); break;
    case 87: updateCustom87Suite(out1, out2, count); break;
    case 88: updateCustom88Suite(out1, out2, count); break;
    case 89: updateCustom89Suite(out1, out2, count); break;
    case 90: updateCustom90Suite(out1, out2, count); break;
    case 91: updateCustom91Suite(out1, out2, count); break;
    case 92: updateCustom92Suite(out1, out2, count); break;
    case 93: updateCustom93Suite(out1, out2, count); break;
    case 94: updateCustom94Suite(out1, out2, count); break;
    case 95: updateCustom95Suite(out1, out2, count); break;
    case 96: updateCustom96Suite(out1, out2, count); break;
    case 97: updateCustom97Suite(out1, out2, count); break;
    case 98: updateCustom98Suite(out1, out2, count); break;
    case 99: updateCustom99Suite(out1, out2, count); break;
    case 100: updateCustom100Suite(out1, out2, count); break;
    case 101: updateCustom101Suite(out1, out2, count); break;
    case 102: updateCustom102Suite(out1, out2, count); break;
    case 103: updateCustom103Suite(out1, out2, count); break;
    case 104: updateCustom104Suite(out1, out2, count); break;
    case 105: updateCustom105Suite(out1, out2, count); break;
    case 106: updateCustom106Suite(out1, out2, count); break;
    case 107: updateCustom107Suite(out1, out2, count); break;
    case 108: updateCustom108Suite(out1, out2, count); break;
    case 109: updateCustom109Suite(out1, out2, count); break;
    case 110: updateCustom110Suite(out1, out2, count); break;
    case 111: updateCustom111Suite(out1, out2, count); break;
    case 112: updateCustom112Suite(out1, out2, count); break;
    case 113: updateCustom113Suite(out1, out2, count); break;
    case 114: updateCustom114Suite(out1, out2, count); break;
    case 115: updateCustom115Suite(out1, out2, count); break;
    case 116: updateCustom116Suite(out1, out2, count); break;
    case 117: updateCustom117Suite(out1, out2, count); break;
    case 118: updateCustom118Suite(out1, out2, count); break;
    case 119: updateCustom119Suite(out1, out2, count); break;
    case 120: updateCustom120Suite(out1, out2, count); break;
    case 121: updateCustom121Suite(out1, out2, count); break;
    case 122: updateCustom122Suite(out1, out2, count); break;
    case 123: updateCustom123Suite(out1, out2, count); break;
    case 124: updateCustom124Suite(out1, out2, count); break;
    case 125: updateCustom125Suite(out1, out2, count); break;
    case 126: updateCustom126Suite(out1, out2, count); break;
    case 127: updateCustom127Suite(out1, out2, count); break;
    case 128: updateCustom128Suite(out1, out2, count); break;
    case 129: updateCustom129Suite(out1, out2, count); break;
    case 130: updateCustom130Suite(out1, out2, count); break;
    case 131: updateCustom131Suite(out1, out2, count); break;
    case 132: updateCustom132Suite(out1, out2, count); break;
    case 133: updateCustom133Suite(out1, out2, count); break;
    case 134: updateCustom134Suite(out1, out2, count); break;
    case 135: updateCustom135Suite(out1, out2, count); break;
    case 136: updateCustom136Suite(out1, out2, count); break;
    case 137: updateCustom137Suite(out1, out2, count); break;
    case 138: updateCustom138Suite(out1, out2, count); break;
    case 139: updateCustom139Suite(out1, out2, count); break;
    case 140: updateCustom140Suite(out1, out2, count); break;
    case 141: updateCustom141Suite(out1, out2, count); break;
    case 142: updateCustom142Suite(out1, out2, count); break;
    case 143: updateCustom143Suite(out1, out2, count); break;
    case 144: updateCustom144Suite(out1, out2, count); break;
    case 145: updateCustom145Suite(out1, out2, count); break;
    case 146: updateCustom146Suite(out1, out2, count); break;
    case 147: updateCustom147Suite(out1, out2, count); break;
    case 148: updateCustom148Suite(out1, out2, count); break;
    case 149: updateCustom149Suite(out1, out2, count); break;
    case 150: updateCustom150Suite(out1, out2, count); break;
    case 151: updateCustom151Suite(out1, out2, count); break;
    case 152: updateCustom152Suite(out1, out2, count); break;
    case 153: updateCustom153Suite(out1, out2, count); break;
    case 154: updateCustom154Suite(out1, out2, count); break;
    case 155: updateCustom155Suite(out1, out2, count); break;
    case 156: updateCustom156Suite(out1, out2, count); break;
    case 157: updateCustom157Suite(out1, out2, count); break;
    case 158: updateCustom158Suite(out1, out2, count); break;
    case 159: updateCustom159Suite(out1, out2, count); break;
    case 160: updateCustom160Suite(out1, out2, count); break;
    case 161: updateCustom161Suite(out1, out2, count); break;
    case 162: updateCustom162Suite(out1, out2, count); break;
    case 163: updateCustom163Suite(out1, out2, count); break;
    case 164: updateCustom164Suite(out1, out2, count); break;
    case 165: updateCustom165Suite(out1, out2, count); break;
    case 166: updateCustom166Suite(out1, out2, count); break;
    case 167: updateCustom167Suite(out1, out2, count); break;
    case 168: updateCustom168Suite(out1, out2, count); break;
    case 169: updateCustom169Suite(out1, out2, count); break;
    case 170: updateCustom170Suite(out1, out2, count); break;
    case 171: updateCustom171Suite(out1, out2, count); break;
    case 172: updateCustom172Suite(out1, out2, count); break;
    case 173: updateCustom173Suite(out1, out2, count); break;
    case 174: updateCustom174Suite(out1, out2, count); break;
    case 175: updateCustom175Suite(out1, out2, count); break;
    case 176: updateCustom176Suite(out1, out2, count); break;
    case 177: updateCustom177Suite(out1, out2, count); break;
    case 178: updateCustom178Suite(out1, out2, count); break;
    case 179: updateCustom179Suite(out1, out2, count); break;
    case 180: updateCustom180Suite(out1, out2, count); break;
    case 181: updateCustom181Suite(out1, out2, count); break;
    case 182: updateCustom182Suite(out1, out2, count); break;
    case 183: updateCustom183Suite(out1, out2, count); break;
    case 184: updateCustom184Suite(out1, out2, count); break;
    case 185: updateCustom185Suite(out1, out2, count); break;
    case 186: updateCustom186Suite(out1, out2, count); break;
    case 187: updateCustom187Suite(out1, out2, count); break;
    case 188: updateCustom188Suite(out1, out2, count); break;
    case 189: updateCustom189Suite(out1, out2, count); break;
    case 190: updateCustom190Suite(out1, out2, count); break;
    case 191: updateCustom191Suite(out1, out2, count); break;
    case 192: updateCustom192Suite(out1, out2, count); break;
    case 193: updateCustom193Suite(out1, out2, count); break;
    case 194: updateCustom194Suite(out1, out2, count); break;
    case 195: updateCustom195Suite(out1, out2, count); break;
    case 196: updateCustom196Suite(out1, out2, count); break;
    case 197: updateCustom197Suite(out1, out2, count); break;
    case 198: updateCustom198Suite(out1, out2, count); break;
    case 199: updateCustom199Suite(out1, out2, count); break;
    case 200: updateCustom200Suite(out1, out2, count); break;
    case 201: updateCustom201Suite(out1, out2, count); break;
    case 202: updateCustom202Suite(out1, out2, count); break;
    case 203: updateCustom203Suite(out1, out2, count); break;
    case 204: updateCustom204Suite(out1, out2, count); break;
    case 205: updateCustom205Suite(out1, out2, count); break;
    case 206: updateCustom206Suite(out1, out2, count); break;
    case 207: updateCustom207Suite(out1, out2, count); break;
    case 208: updateCustom208Suite(out1, out2, count); break;
    case 209: updateCustom209Suite(out1, out2, count); break;
    case 210: updateCustom210Suite(out1, out2, count); break;
    default: updateCustom1Suite(out1, out2, count); break;
  }
}

// ============================================================================
// MODE PICKER SISTEM LAMA — tanpa mengubah parser/menu aplikasi MOD.
// LED1 (0x01): CH1 -> diam 5 detik -> target otomatis CH3, tetap di menu LED1.
// LED2 (0x02): CH2 -> diam 5 detik -> target otomatis CH4, tetap di menu LED2.
// LED3 (0x04) dan LED4 (0x05) dari aplikasi MOD tetap direct seperti sebelumnya.
// ============================================================================
struct LegacyModePairPickerState {
  bool active = false;
  uint8_t pair = 0;          // 1 = CH1->CH3, 2 = CH2->CH4
  uint8_t stage = 0;         // 1 = base, 2 = extra
  bool stageTouched = false;
  uint32_t lastActivityAt = 0;
};

static LegacyModePairPickerState legacyModePair;
static constexpr uint32_t LEGACY_MODE_PAIR_SETTLE_MS = 5000UL;

static inline void legacyModePairCancel() {
  legacyModePair = LegacyModePairPickerState{};
}

static inline uint8_t legacyModePairTargetIndex() {
  if (!legacyModePair.active) return 0xFF;
  if (legacyModePair.pair == 1) return (legacyModePair.stage == 1) ? 0U : 2U; // CH1 -> CH3
  if (legacyModePair.pair == 2) return (legacyModePair.stage == 1) ? 1U : 3U; // CH2 -> CH4
  return 0xFF;
}

static inline void legacyApplyModeSingle(uint8_t mode, uint8_t ch) {
  if (ch > 3U) return;
  selectedMode[ch] = mode;
  channelSource[ch] = MAIN_MODE;
  resetSuiteStateForChannel(ch);
  refreshBaseSourceFlags();
  modeForceRender = true;
  solidRgbForceRender = true;
  markSettingsUrgent();
}

static void serviceLegacyModePairPicker() {
  if (!legacyModePair.active || !legacyModePair.stageTouched) return;

  uint32_t now = millis();
  if ((uint32_t)(now - legacyModePair.lastActivityAt) < LEGACY_MODE_PAIR_SETTLE_MS) return;

  if (legacyModePair.stage == 1U) {
    // CH1/CH2 selesai dipilih selama 5 detik -> pindah target CH3/CH4.
    legacyModePair.stage = 2U;
    legacyModePair.stageTouched = false;

    uint8_t nextCh = legacyModePairTargetIndex();
    if (nextCh <= 3U) {
      // Putih 1x = target pasangan berikutnya sudah aktif.
      triggerTargetBlink(CRGB::White, 1, (uint8_t)(1U << nextCh));
    }
    return;
  }

  // CH3/CH4 sudah diam 5 detik -> sesi pasangan selesai.
  uint8_t doneCh = legacyModePairTargetIndex();
  legacyModePairCancel();
  if (doneCh <= 3U) {
    // KEDIP HIJAU DIMATIKAN (ganti mode): triggerTargetBlink(CRGB::Green, 1, (uint8_t)(1U << doneCh));
  }
}

static void selectModeRealtime(uint8_t mode, uint8_t channelCode) {
  if (turnEngine.active && !turnEngine.isPhysical) {
    turnEngine.active = false;
    turnEngine.finishRequested = false;
  }
  if (brakeEngine.active && !brakeEngine.isPhysical) {
    brakeEngine.active = false;
  }

  cancelVisualFeedback();
  welcomeReturnSource = MAIN_MODE;
  mainSource = MAIN_MODE;
  welcomeRunning = false;
  pendingWelcomeRestart = false;
  lampOn = true;

  // LED1: tahap pertama CH1, setelah 5 detik target berubah ke CH3.
  if (channelCode == 0x01) {
    if (!legacyModePair.active || legacyModePair.pair != 1U) {
      legacyModePair.active = true;
      legacyModePair.pair = 1U;
      legacyModePair.stage = 1U;
      legacyModePair.stageTouched = false;
    }

    uint8_t ch = legacyModePairTargetIndex();
    legacyApplyModeSingle(mode, ch);
    legacyModePair.stageTouched = true;
    legacyModePair.lastActivityAt = millis();

    // Hijau 1x = pilihan mode target saat ini sudah diterapkan/disimpan.
    // KEDIP HIJAU DIMATIKAN (ganti mode): triggerTargetBlink(CRGB::Green, 1, (uint8_t)(1U << ch));
    return;
  }

  // LED2: tahap pertama CH2, setelah 5 detik target berubah ke CH4.
  if (channelCode == 0x02) {
    if (!legacyModePair.active || legacyModePair.pair != 2U) {
      legacyModePair.active = true;
      legacyModePair.pair = 2U;
      legacyModePair.stage = 1U;
      legacyModePair.stageTouched = false;
    }

    uint8_t ch = legacyModePairTargetIndex();
    legacyApplyModeSingle(mode, ch);
    legacyModePair.stageTouched = true;
    legacyModePair.lastActivityAt = millis();

    // KEDIP HIJAU DIMATIKAN (ganti mode): triggerTargetBlink(CRGB::Green, 1, (uint8_t)(1U << ch));
    return;
  }

  // Menu LED3 / LED4 bawaan aplikasi MOD tetap dipertahankan.
  if (channelCode == 0x04) {
    legacyModePairCancel();
    legacyApplyModeSingle(mode, 2U);
    // KEDIP HIJAU DIMATIKAN (ganti mode): triggerTargetBlink(CRGB::Green, 1, 0x04);
    return;
  }

  if (channelCode == 0x05) {
    legacyModePairCancel();
    legacyApplyModeSingle(mode, 3U);
    // KEDIP HIJAU DIMATIKAN (ganti mode): triggerTargetBlink(CRGB::Green, 1, 0x08);
    return;
  }

  // ALL tetap mengubah CH1..CH4 bersama.
  legacyModePairCancel();
  for (uint8_t ch = 0; ch < 4U; ch++) {
    selectedMode[ch] = mode;
    channelSource[ch] = MAIN_MODE;
    resetSuiteStateForChannel(ch);
  }
  refreshBaseSourceFlags();
  modeForceRender = true;
  solidRgbForceRender = true;
  markSettingsUrgent();
  // KEDIP HIJAU DIMATIKAN (ganti mode): triggerTargetBlink(CRGB::Green, 1, 0x0F);
}

static void renderIndependentModeChannel(uint8_t ch, uint16_t n) {
  if (ch > 3 || channelSource[ch] != MAIN_MODE) return;
  uint8_t m = selectedMode[ch]; if (m < 1 || m > 210) m = 1;
  loadSuiteStateForChannel(ch);
  CRGB *out = (ch == 0) ? leds1 : (ch == 1) ? leds2 : (ch == 2) ? leds3 : leds4;
  CRGB *dummy = modeDummyByChannel[ch];
  if (ch == 0 || ch == 2) renderMode210Pattern(m, out, dummy, n);
  else renderMode210Pattern(m, dummy, out, n);
  saveSuiteStateForChannel(ch);
}

static void renderModePairOrIndependent(uint8_t leftCh, uint8_t rightCh, CRGB *leftOut, CRGB *rightOut, uint16_t n) {
  bool leftMode = channelSource[leftCh] == MAIN_MODE;
  bool rightMode = channelSource[rightCh] == MAIN_MODE;
  if (leftMode && rightMode && selectedMode[leftCh] == selectedMode[rightCh]) {
    uint8_t m = selectedMode[leftCh]; if (m < 1 || m > 210) m = 1;
    loadSuiteStateForChannel(leftCh);
    renderMode210Pattern(m, leftOut, rightOut, n);
    saveSuiteStateForChannel(leftCh);
    // Kedua channel satu pair tetap sinkron bila memakai mode yang sama.
    c1SuiteByChannel[rightCh] = c1SuiteByChannel[leftCh];
    c2SuiteByChannel[rightCh] = c2SuiteByChannel[leftCh];
    c3SuiteByChannel[rightCh] = c3SuiteByChannel[leftCh];
    c4SuiteByChannel[rightCh] = c4SuiteByChannel[leftCh];
    c5SuiteByChannel[rightCh] = c5SuiteByChannel[leftCh];
    c6SuiteByChannel[rightCh] = c6SuiteByChannel[leftCh];
    c7SuiteByChannel[rightCh] = c7SuiteByChannel[leftCh];
    c8SuiteByChannel[rightCh] = c8SuiteByChannel[leftCh];
    c9SuiteByChannel[rightCh] = c9SuiteByChannel[leftCh];
    c10SuiteByChannel[rightCh] = c10SuiteByChannel[leftCh];
    c11SuiteByChannel[rightCh] = c11SuiteByChannel[leftCh];
    c12SuiteByChannel[rightCh] = c12SuiteByChannel[leftCh];
    c13SuiteByChannel[rightCh] = c13SuiteByChannel[leftCh];
    c14SuiteByChannel[rightCh] = c14SuiteByChannel[leftCh];
    c21SuiteByChannel[rightCh] = c21SuiteByChannel[leftCh]; c22SuiteByChannel[rightCh] = c22SuiteByChannel[leftCh];
    c23SuiteByChannel[rightCh] = c23SuiteByChannel[leftCh]; c24SuiteByChannel[rightCh] = c24SuiteByChannel[leftCh];
    c25SuiteByChannel[rightCh] = c25SuiteByChannel[leftCh]; c26SuiteByChannel[rightCh] = c26SuiteByChannel[leftCh];
    if (m == 27) c27SuiteByChannel[rightCh] = c27SuiteByChannel[leftCh];
    c28SuiteByChannel[rightCh] = c28SuiteByChannel[leftCh]; c29SuiteByChannel[rightCh] = c29SuiteByChannel[leftCh]; c30SuiteByChannel[rightCh] = c30SuiteByChannel[leftCh];
    c31SuiteByChannel[rightCh] = c31SuiteByChannel[leftCh]; c32SuiteByChannel[rightCh] = c32SuiteByChannel[leftCh];
    c33SuiteByChannel[rightCh] = c33SuiteByChannel[leftCh]; c34SuiteByChannel[rightCh] = c34SuiteByChannel[leftCh];
    c35SuiteByChannel[rightCh] = c35SuiteByChannel[leftCh]; c36SuiteByChannel[rightCh] = c36SuiteByChannel[leftCh];
    c37SuiteByChannel[rightCh] = c37SuiteByChannel[leftCh]; c38SuiteByChannel[rightCh] = c38SuiteByChannel[leftCh];
    c39SuiteByChannel[rightCh] = c39SuiteByChannel[leftCh]; c40SuiteByChannel[rightCh] = c40SuiteByChannel[leftCh];
    c41SuiteByChannel[rightCh] = c41SuiteByChannel[leftCh];
    c42SuiteByChannel[rightCh] = c42SuiteByChannel[leftCh];
    c43SuiteByChannel[rightCh] = c43SuiteByChannel[leftCh];
    c44SuiteByChannel[rightCh] = c44SuiteByChannel[leftCh];
    c45SuiteByChannel[rightCh] = c45SuiteByChannel[leftCh];
    c46SuiteByChannel[rightCh] = c46SuiteByChannel[leftCh];
    c47SuiteByChannel[rightCh] = c47SuiteByChannel[leftCh];
    c48SuiteByChannel[rightCh] = c48SuiteByChannel[leftCh];
    c49SuiteByChannel[rightCh] = c49SuiteByChannel[leftCh];
    c50SuiteByChannel[rightCh] = c50SuiteByChannel[leftCh];
    c51SuiteByChannel[rightCh] = c51SuiteByChannel[leftCh];
    c52SuiteByChannel[rightCh] = c52SuiteByChannel[leftCh];
    c53SuiteByChannel[rightCh] = c53SuiteByChannel[leftCh];
    c54SuiteByChannel[rightCh] = c54SuiteByChannel[leftCh];
    c55SuiteByChannel[rightCh] = c55SuiteByChannel[leftCh];
    c56SuiteByChannel[rightCh] = c56SuiteByChannel[leftCh];
    c57SuiteByChannel[rightCh] = c57SuiteByChannel[leftCh];
    c58SuiteByChannel[rightCh] = c58SuiteByChannel[leftCh];
    c59SuiteByChannel[rightCh] = c59SuiteByChannel[leftCh];
    c60SuiteByChannel[rightCh] = c60SuiteByChannel[leftCh];
    c61SuiteByChannel[rightCh] = c61SuiteByChannel[leftCh];
    c62SuiteByChannel[rightCh] = c62SuiteByChannel[leftCh];
    c63SuiteByChannel[rightCh] = c63SuiteByChannel[leftCh];
    c64SuiteByChannel[rightCh] = c64SuiteByChannel[leftCh];
    c65SuiteByChannel[rightCh] = c65SuiteByChannel[leftCh];
    c66SuiteByChannel[rightCh] = c66SuiteByChannel[leftCh];
    c67SuiteByChannel[rightCh] = c67SuiteByChannel[leftCh];
    c68SuiteByChannel[rightCh] = c68SuiteByChannel[leftCh];
    c69SuiteByChannel[rightCh] = c69SuiteByChannel[leftCh];
    c70SuiteByChannel[rightCh] = c70SuiteByChannel[leftCh];
    c71SuiteByChannel[rightCh] = c71SuiteByChannel[leftCh];
    c72SuiteByChannel[rightCh] = c72SuiteByChannel[leftCh];
    c73SuiteByChannel[rightCh] = c73SuiteByChannel[leftCh];
    c74SuiteByChannel[rightCh] = c74SuiteByChannel[leftCh];
    c75SuiteByChannel[rightCh] = c75SuiteByChannel[leftCh];
    c76SuiteByChannel[rightCh] = c76SuiteByChannel[leftCh];
    c77SuiteByChannel[rightCh] = c77SuiteByChannel[leftCh];
    c78SuiteByChannel[rightCh] = c78SuiteByChannel[leftCh];
    c79SuiteByChannel[rightCh] = c79SuiteByChannel[leftCh];
    c80SuiteByChannel[rightCh] = c80SuiteByChannel[leftCh];
    c81SuiteByChannel[rightCh] = c81SuiteByChannel[leftCh];
    c82SuiteByChannel[rightCh] = c82SuiteByChannel[leftCh];
    c83SuiteByChannel[rightCh] = c83SuiteByChannel[leftCh];
    c84SuiteByChannel[rightCh] = c84SuiteByChannel[leftCh];
    c85SuiteByChannel[rightCh] = c85SuiteByChannel[leftCh];
    c86SuiteByChannel[rightCh] = c86SuiteByChannel[leftCh];
    c87SuiteByChannel[rightCh] = c87SuiteByChannel[leftCh];
    c88SuiteByChannel[rightCh] = c88SuiteByChannel[leftCh];
    c89SuiteByChannel[rightCh] = c89SuiteByChannel[leftCh];
    c90SuiteByChannel[rightCh] = c90SuiteByChannel[leftCh];
    c91SuiteByChannel[rightCh] = c91SuiteByChannel[leftCh];
    c92SuiteByChannel[rightCh] = c92SuiteByChannel[leftCh];
    c93SuiteByChannel[rightCh] = c93SuiteByChannel[leftCh];
    c94SuiteByChannel[rightCh] = c94SuiteByChannel[leftCh];
    c95SuiteByChannel[rightCh] = c95SuiteByChannel[leftCh];
    c96SuiteByChannel[rightCh] = c96SuiteByChannel[leftCh];
    c97SuiteByChannel[rightCh] = c97SuiteByChannel[leftCh];
    c98SuiteByChannel[rightCh] = c98SuiteByChannel[leftCh];
    c99SuiteByChannel[rightCh] = c99SuiteByChannel[leftCh];
    c100SuiteByChannel[rightCh] = c100SuiteByChannel[leftCh];
    c101SuiteByChannel[rightCh] = c101SuiteByChannel[leftCh];
    c102SuiteByChannel[rightCh] = c102SuiteByChannel[leftCh];
    c103SuiteByChannel[rightCh] = c103SuiteByChannel[leftCh];
    c104SuiteByChannel[rightCh] = c104SuiteByChannel[leftCh];
    c105SuiteByChannel[rightCh] = c105SuiteByChannel[leftCh];
    c106SuiteByChannel[rightCh] = c106SuiteByChannel[leftCh];
    c107SuiteByChannel[rightCh] = c107SuiteByChannel[leftCh];
    c108SuiteByChannel[rightCh] = c108SuiteByChannel[leftCh];
    c109SuiteByChannel[rightCh] = c109SuiteByChannel[leftCh];
    c110SuiteByChannel[rightCh] = c110SuiteByChannel[leftCh];
    c111SuiteByChannel[rightCh] = c111SuiteByChannel[leftCh];
    c112SuiteByChannel[rightCh] = c112SuiteByChannel[leftCh];
    c113SuiteByChannel[rightCh] = c113SuiteByChannel[leftCh];
    c114SuiteByChannel[rightCh] = c114SuiteByChannel[leftCh];
    c115SuiteByChannel[rightCh] = c115SuiteByChannel[leftCh];
    c116SuiteByChannel[rightCh] = c116SuiteByChannel[leftCh];
    c117SuiteByChannel[rightCh] = c117SuiteByChannel[leftCh];
    c118SuiteByChannel[rightCh] = c118SuiteByChannel[leftCh];
    c119SuiteByChannel[rightCh] = c119SuiteByChannel[leftCh];
    c120SuiteByChannel[rightCh] = c120SuiteByChannel[leftCh];
    c121SuiteByChannel[rightCh] = c121SuiteByChannel[leftCh];
    c122SuiteByChannel[rightCh] = c122SuiteByChannel[leftCh];
    c123SuiteByChannel[rightCh] = c123SuiteByChannel[leftCh];
    c124SuiteByChannel[rightCh] = c124SuiteByChannel[leftCh];
    c125SuiteByChannel[rightCh] = c125SuiteByChannel[leftCh];
    c126SuiteByChannel[rightCh] = c126SuiteByChannel[leftCh];
    c127SuiteByChannel[rightCh] = c127SuiteByChannel[leftCh];
    c128SuiteByChannel[rightCh] = c128SuiteByChannel[leftCh];
    c129SuiteByChannel[rightCh] = c129SuiteByChannel[leftCh];
    c130SuiteByChannel[rightCh] = c130SuiteByChannel[leftCh];
    c131SuiteByChannel[rightCh] = c131SuiteByChannel[leftCh];
    c132SuiteByChannel[rightCh] = c132SuiteByChannel[leftCh];
    c133SuiteByChannel[rightCh] = c133SuiteByChannel[leftCh];
    c134SuiteByChannel[rightCh] = c134SuiteByChannel[leftCh];
    c135SuiteByChannel[rightCh] = c135SuiteByChannel[leftCh];
    c136SuiteByChannel[rightCh] = c136SuiteByChannel[leftCh];
    c137SuiteByChannel[rightCh] = c137SuiteByChannel[leftCh];
    c138SuiteByChannel[rightCh] = c138SuiteByChannel[leftCh];
    c139SuiteByChannel[rightCh] = c139SuiteByChannel[leftCh];
    c140SuiteByChannel[rightCh] = c140SuiteByChannel[leftCh];
    c141160SuiteByChannel[rightCh] = c141160SuiteByChannel[leftCh];
    c161170SuiteByChannel[rightCh] = c161170SuiteByChannel[leftCh];
    c181200SuiteByChannel[rightCh] = c181200SuiteByChannel[leftCh];
    c201210SuiteByChannel[rightCh] = c201210SuiteByChannel[leftCh];
    return;
  }
  if (leftMode) renderIndependentModeChannel(leftCh, n);
  if (rightMode) renderIndependentModeChannel(rightCh, n);
}

static void serviceModeRealtime() {
  if (!modeRunning || !lampOn || !contactOn || mainSource == MAIN_WELCOME) return;
  uint16_t n = activeLedCount; if (n < 1) n = 1; if (n > STAGE0_LED_BUFFER) n = STAGE0_LED_BUFFER;
  unsigned long now = millis();
  const bool all4Same51to160Fast =
      channelSource[0] == MAIN_MODE && channelSource[1] == MAIN_MODE &&
      channelSource[2] == MAIN_MODE && channelSource[3] == MAIN_MODE &&
      selectedMode[0] >= 51 && selectedMode[0] <= 210 &&
      selectedMode[1] == selectedMode[0] && selectedMode[2] == selectedMode[0] && selectedMode[3] == selectedMode[0];
  const unsigned long modeServiceMinMs = all4Same51to160Fast ? 10UL : 15UL;
  if (!modeForceRender && (now - modeLastRenderAt) < modeServiceMinMs) return;
  modeForceRender = false; modeLastRenderAt = now;

  // KHUSUS MODE 51: approved HTML memakai satu jalur fisik 4CH menyambung.
  // CH1 -> CH3 -> CH4 -> CH2, lalu berganti arah pada pengulangan berikutnya.
  const bool mode51ConnectedAll4 =
      channelSource[0] == MAIN_MODE && channelSource[1] == MAIN_MODE &&
      channelSource[2] == MAIN_MODE && channelSource[3] == MAIN_MODE &&
      selectedMode[0] == 51 && selectedMode[1] == 51 && selectedMode[2] == 51 && selectedMode[3] == 51;
  if (mode51ConnectedAll4) {
    loadSuiteStateForChannel(0);
    updateCustom51SuiteAll4(leds1, leds2, leds3, leds4, n);
    saveSuiteStateForChannel(0);
    c51SuiteByChannel[1] = c51SuiteByChannel[0];
    c51SuiteByChannel[2] = c51SuiteByChannel[0];
    c51SuiteByChannel[3] = c51SuiteByChannel[0];
    k3SafeShow();
    return;
  }

  // KHUSUS MODE 185/186: jalur menyambung fisik CH1 -> CH3 -> CH4 -> CH2.
  // Mode 185 bolak-balik: CH1->CH3->CH4->CH2 lalu CH2->CH4->CH3->CH1. Mode 186 punya 8 fase fluid unik.
  const bool mode185186ConnectedAll4 =
      channelSource[0] == MAIN_MODE && channelSource[1] == MAIN_MODE &&
      channelSource[2] == MAIN_MODE && channelSource[3] == MAIN_MODE &&
      (selectedMode[0] == 185 || selectedMode[0] == 186) &&
      selectedMode[1] == selectedMode[0] && selectedMode[2] == selectedMode[0] && selectedMode[3] == selectedMode[0];
  if (mode185186ConnectedAll4) {
    const uint8_t m = selectedMode[0];
    loadSuiteStateForChannel(0);
    updateCustom185186SuiteAll4(m, leds1, leds2, leds3, leds4, n);
    saveSuiteStateForChannel(0);
    c181200SuiteByChannel[1]=c181200SuiteByChannel[0];
    c181200SuiteByChannel[2]=c181200SuiteByChannel[0];
    c181200SuiteByChannel[3]=c181200SuiteByChannel[0];
    c201210SuiteByChannel[1]=c201210SuiteByChannel[0];
    c201210SuiteByChannel[2]=c201210SuiteByChannel[0];
    c201210SuiteByChannel[3]=c201210SuiteByChannel[0];
    k3SafeShow();
    return;
  }

  // KHUSUS MODE 201-210 BARU: 8 fase unik pada SATU jalur fisik 4CH.
  // Jalur: CH1 -> CH3 -> CH4 -> CH2.
  const bool mode201210FlowAll4 =
      channelSource[0] == MAIN_MODE && channelSource[1] == MAIN_MODE &&
      channelSource[2] == MAIN_MODE && channelSource[3] == MAIN_MODE &&
      selectedMode[0] >= 201 && selectedMode[0] <= 210 &&
      selectedMode[1] == selectedMode[0] &&
      selectedMode[2] == selectedMode[0] &&
      selectedMode[3] == selectedMode[0];
  if(mode201210FlowAll4){
    const uint8_t m=selectedMode[0];
    loadSuiteStateForChannel(0);
    updateCustom201210SuiteAll4(m,leds1,leds2,leds3,leds4,n);
    saveSuiteStateForChannel(0);
    c201210SuiteByChannel[1]=c201210SuiteByChannel[0];
    c201210SuiteByChannel[2]=c201210SuiteByChannel[0];
    c201210SuiteByChannel[3]=c201210SuiteByChannel[0];
    k3SafeShow();
    return;
  }

  // MODE 121-210: GLOBAL lurus sesuai pilihan terbaru.
  // Output virtual A -> CH1 + CH3. Output virtual B -> CH2 + CH4.
  // Jadi CH1=CH3 dan CH2=CH4 frame-per-frame.
  const bool map121to160_13_24 =
      channelSource[0] == MAIN_MODE && channelSource[1] == MAIN_MODE &&
      channelSource[2] == MAIN_MODE && channelSource[3] == MAIN_MODE &&
      selectedMode[0] >= 121 && selectedMode[0] <= 210 &&
      selectedMode[1] == selectedMode[0] && selectedMode[2] == selectedMode[0] && selectedMode[3] == selectedMode[0];

  if (map121to160_13_24) {
    const uint8_t m = selectedMode[0];
    loadSuiteStateForChannel(0);
    renderMode210Pattern(m, leds1, leds2, n);
    saveSuiteStateForChannel(0);

    memcpy(leds3, leds1, sizeof(CRGB) * n);
    memcpy(leds4, leds2, sizeof(CRGB) * n);
    c121SuiteByChannel[1]=c121SuiteByChannel[0]; c121SuiteByChannel[2]=c121SuiteByChannel[0]; c121SuiteByChannel[3]=c121SuiteByChannel[0];
    c122SuiteByChannel[1]=c122SuiteByChannel[0]; c122SuiteByChannel[2]=c122SuiteByChannel[0]; c122SuiteByChannel[3]=c122SuiteByChannel[0];
    c123SuiteByChannel[1]=c123SuiteByChannel[0]; c123SuiteByChannel[2]=c123SuiteByChannel[0]; c123SuiteByChannel[3]=c123SuiteByChannel[0];
    c124SuiteByChannel[1]=c124SuiteByChannel[0]; c124SuiteByChannel[2]=c124SuiteByChannel[0]; c124SuiteByChannel[3]=c124SuiteByChannel[0];
    c125SuiteByChannel[1]=c125SuiteByChannel[0]; c125SuiteByChannel[2]=c125SuiteByChannel[0]; c125SuiteByChannel[3]=c125SuiteByChannel[0];
    c126SuiteByChannel[1]=c126SuiteByChannel[0]; c126SuiteByChannel[2]=c126SuiteByChannel[0]; c126SuiteByChannel[3]=c126SuiteByChannel[0];
    c127SuiteByChannel[1]=c127SuiteByChannel[0]; c127SuiteByChannel[2]=c127SuiteByChannel[0]; c127SuiteByChannel[3]=c127SuiteByChannel[0];
    c128SuiteByChannel[1]=c128SuiteByChannel[0]; c128SuiteByChannel[2]=c128SuiteByChannel[0]; c128SuiteByChannel[3]=c128SuiteByChannel[0];
    c129SuiteByChannel[1]=c129SuiteByChannel[0]; c129SuiteByChannel[2]=c129SuiteByChannel[0]; c129SuiteByChannel[3]=c129SuiteByChannel[0];
    c130SuiteByChannel[1]=c130SuiteByChannel[0]; c130SuiteByChannel[2]=c130SuiteByChannel[0]; c130SuiteByChannel[3]=c130SuiteByChannel[0];
    c131SuiteByChannel[1]=c131SuiteByChannel[0]; c131SuiteByChannel[2]=c131SuiteByChannel[0]; c131SuiteByChannel[3]=c131SuiteByChannel[0];
    c132SuiteByChannel[1]=c132SuiteByChannel[0]; c132SuiteByChannel[2]=c132SuiteByChannel[0]; c132SuiteByChannel[3]=c132SuiteByChannel[0];
    c133SuiteByChannel[1]=c133SuiteByChannel[0]; c133SuiteByChannel[2]=c133SuiteByChannel[0]; c133SuiteByChannel[3]=c133SuiteByChannel[0];
    c134SuiteByChannel[1]=c134SuiteByChannel[0]; c134SuiteByChannel[2]=c134SuiteByChannel[0]; c134SuiteByChannel[3]=c134SuiteByChannel[0];
    c135SuiteByChannel[1]=c135SuiteByChannel[0]; c135SuiteByChannel[2]=c135SuiteByChannel[0]; c135SuiteByChannel[3]=c135SuiteByChannel[0];
    c136SuiteByChannel[1]=c136SuiteByChannel[0]; c136SuiteByChannel[2]=c136SuiteByChannel[0]; c136SuiteByChannel[3]=c136SuiteByChannel[0];
    c137SuiteByChannel[1]=c137SuiteByChannel[0]; c137SuiteByChannel[2]=c137SuiteByChannel[0]; c137SuiteByChannel[3]=c137SuiteByChannel[0];
    c138SuiteByChannel[1]=c138SuiteByChannel[0]; c138SuiteByChannel[2]=c138SuiteByChannel[0]; c138SuiteByChannel[3]=c138SuiteByChannel[0];
    c139SuiteByChannel[1]=c139SuiteByChannel[0]; c139SuiteByChannel[2]=c139SuiteByChannel[0]; c139SuiteByChannel[3]=c139SuiteByChannel[0];
    c140SuiteByChannel[1]=c140SuiteByChannel[0]; c140SuiteByChannel[2]=c140SuiteByChannel[0]; c140SuiteByChannel[3]=c140SuiteByChannel[0];
    c141160SuiteByChannel[1]=c141160SuiteByChannel[0]; c141160SuiteByChannel[2]=c141160SuiteByChannel[0]; c141160SuiteByChannel[3]=c141160SuiteByChannel[0];
    c161170SuiteByChannel[1]=c161170SuiteByChannel[0]; c161170SuiteByChannel[2]=c161170SuiteByChannel[0]; c161170SuiteByChannel[3]=c161170SuiteByChannel[0];
    c181200SuiteByChannel[1]=c181200SuiteByChannel[0]; c181200SuiteByChannel[2]=c181200SuiteByChannel[0]; c181200SuiteByChannel[3]=c181200SuiteByChannel[0];
    c201210SuiteByChannel[1]=c201210SuiteByChannel[0]; c201210SuiteByChannel[2]=c201210SuiteByChannel[0]; c201210SuiteByChannel[3]=c201210SuiteByChannel[0];
    k3SafeShow();
    return;
  }

  // MODE 101-120: GLOBAL silang ALIS/SHROUD seperti pilihan terbaru.
  // Output virtual A -> CH1 + CH4.
  // Output virtual B -> CH2 + CH3.
  // Jadi CH1=CH4 dan CH2=CH3 frame-per-frame.
  const bool map101to120_14_23 =
      channelSource[0] == MAIN_MODE && channelSource[1] == MAIN_MODE &&
      channelSource[2] == MAIN_MODE && channelSource[3] == MAIN_MODE &&
      selectedMode[0] >= 101 && selectedMode[0] <= 120 &&
      selectedMode[1] == selectedMode[0] &&
      selectedMode[2] == selectedMode[0] && selectedMode[3] == selectedMode[0];

  if (map101to120_14_23) {
    const uint8_t m = selectedMode[0];
    loadSuiteStateForChannel(0);
    renderMode210Pattern(m, leds1, leds2, n);
    saveSuiteStateForChannel(0);

    // Silang fisik: A ke CH1+CH4, B ke CH2+CH3.
    memcpy(leds4, leds1, sizeof(CRGB) * n);
    memcpy(leds3, leds2, sizeof(CRGB) * n);

    c101SuiteByChannel[1]=c101SuiteByChannel[0]; c101SuiteByChannel[2]=c101SuiteByChannel[0]; c101SuiteByChannel[3]=c101SuiteByChannel[0];
    c102SuiteByChannel[1]=c102SuiteByChannel[0]; c102SuiteByChannel[2]=c102SuiteByChannel[0]; c102SuiteByChannel[3]=c102SuiteByChannel[0];
    c103SuiteByChannel[1]=c103SuiteByChannel[0]; c103SuiteByChannel[2]=c103SuiteByChannel[0]; c103SuiteByChannel[3]=c103SuiteByChannel[0];
    c104SuiteByChannel[1]=c104SuiteByChannel[0]; c104SuiteByChannel[2]=c104SuiteByChannel[0]; c104SuiteByChannel[3]=c104SuiteByChannel[0];
    c105SuiteByChannel[1]=c105SuiteByChannel[0]; c105SuiteByChannel[2]=c105SuiteByChannel[0]; c105SuiteByChannel[3]=c105SuiteByChannel[0];
    c106SuiteByChannel[1]=c106SuiteByChannel[0]; c106SuiteByChannel[2]=c106SuiteByChannel[0]; c106SuiteByChannel[3]=c106SuiteByChannel[0];
    c107SuiteByChannel[1]=c107SuiteByChannel[0]; c107SuiteByChannel[2]=c107SuiteByChannel[0]; c107SuiteByChannel[3]=c107SuiteByChannel[0];
    c108SuiteByChannel[1]=c108SuiteByChannel[0]; c108SuiteByChannel[2]=c108SuiteByChannel[0]; c108SuiteByChannel[3]=c108SuiteByChannel[0];
    c109SuiteByChannel[1]=c109SuiteByChannel[0]; c109SuiteByChannel[2]=c109SuiteByChannel[0]; c109SuiteByChannel[3]=c109SuiteByChannel[0];
    c110SuiteByChannel[1]=c110SuiteByChannel[0]; c110SuiteByChannel[2]=c110SuiteByChannel[0]; c110SuiteByChannel[3]=c110SuiteByChannel[0];
    c111SuiteByChannel[1]=c111SuiteByChannel[0]; c111SuiteByChannel[2]=c111SuiteByChannel[0]; c111SuiteByChannel[3]=c111SuiteByChannel[0];
    c112SuiteByChannel[1]=c112SuiteByChannel[0]; c112SuiteByChannel[2]=c112SuiteByChannel[0]; c112SuiteByChannel[3]=c112SuiteByChannel[0];
    c113SuiteByChannel[1]=c113SuiteByChannel[0]; c113SuiteByChannel[2]=c113SuiteByChannel[0]; c113SuiteByChannel[3]=c113SuiteByChannel[0];
    c114SuiteByChannel[1]=c114SuiteByChannel[0]; c114SuiteByChannel[2]=c114SuiteByChannel[0]; c114SuiteByChannel[3]=c114SuiteByChannel[0];
    c115SuiteByChannel[1]=c115SuiteByChannel[0]; c115SuiteByChannel[2]=c115SuiteByChannel[0]; c115SuiteByChannel[3]=c115SuiteByChannel[0];
    c116SuiteByChannel[1]=c116SuiteByChannel[0]; c116SuiteByChannel[2]=c116SuiteByChannel[0]; c116SuiteByChannel[3]=c116SuiteByChannel[0];
    c117SuiteByChannel[1]=c117SuiteByChannel[0]; c117SuiteByChannel[2]=c117SuiteByChannel[0]; c117SuiteByChannel[3]=c117SuiteByChannel[0];
    c118SuiteByChannel[1]=c118SuiteByChannel[0]; c118SuiteByChannel[2]=c118SuiteByChannel[0]; c118SuiteByChannel[3]=c118SuiteByChannel[0];
    c119SuiteByChannel[1]=c119SuiteByChannel[0]; c119SuiteByChannel[2]=c119SuiteByChannel[0]; c119SuiteByChannel[3]=c119SuiteByChannel[0];
    c120SuiteByChannel[1]=c120SuiteByChannel[0]; c120SuiteByChannel[2]=c120SuiteByChannel[0]; c120SuiteByChannel[3]=c120SuiteByChannel[0];
    k3SafeShow();
    return;
  }

  // MODE 31-100: mapping GLOBAL silang seperti yang disetujui.
  // Output virtual A -> CH1 + CH3.
  // Output virtual B -> CH2 + CH4.
  // Semua 4 channel tetap nyala; CH1=CH3 dan CH2=CH4 frame-per-frame.
  const bool map31to100_13_24 =
      channelSource[0] == MAIN_MODE && channelSource[1] == MAIN_MODE &&
      channelSource[2] == MAIN_MODE && channelSource[3] == MAIN_MODE &&
      selectedMode[0] >= 31 && selectedMode[0] <= 100 &&
      selectedMode[1] == selectedMode[0] &&
      selectedMode[2] == selectedMode[0] && selectedMode[3] == selectedMode[0];

  if (map31to100_13_24) {
    const uint8_t m = selectedMode[0];
    loadSuiteStateForChannel(0);

    // Mode 31 khusus mengikuti source user sebagai dua jalur virtual 150 LED:
    // kiri CH1 -> CH3, kanan CH2 -> CH4. Mode 32-100 TIDAK disentuh.
    if (m == 31U) {
      updateCustom31Suite4(leds1, leds2, leds3, leds4, n);
      saveSuiteStateForChannel(0);
      c31SuiteByChannel[1]=c31SuiteByChannel[0];
      c31SuiteByChannel[2]=c31SuiteByChannel[0];
      c31SuiteByChannel[3]=c31SuiteByChannel[0];
      k3SafeShow();
      return;
    }

    renderMode210Pattern(m, leds1, leds2, n);
    saveSuiteStateForChannel(0);

    memcpy(leds3, leds1, sizeof(CRGB) * n);
    memcpy(leds4, leds2, sizeof(CRGB) * n);

    c31SuiteByChannel[1]=c31SuiteByChannel[0]; c31SuiteByChannel[2]=c31SuiteByChannel[0]; c31SuiteByChannel[3]=c31SuiteByChannel[0];
    c32SuiteByChannel[1]=c32SuiteByChannel[0]; c32SuiteByChannel[2]=c32SuiteByChannel[0]; c32SuiteByChannel[3]=c32SuiteByChannel[0];
    c33SuiteByChannel[1]=c33SuiteByChannel[0]; c33SuiteByChannel[2]=c33SuiteByChannel[0]; c33SuiteByChannel[3]=c33SuiteByChannel[0];
    c34SuiteByChannel[1]=c34SuiteByChannel[0]; c34SuiteByChannel[2]=c34SuiteByChannel[0]; c34SuiteByChannel[3]=c34SuiteByChannel[0];
    c35SuiteByChannel[1]=c35SuiteByChannel[0]; c35SuiteByChannel[2]=c35SuiteByChannel[0]; c35SuiteByChannel[3]=c35SuiteByChannel[0];
    c36SuiteByChannel[1]=c36SuiteByChannel[0]; c36SuiteByChannel[2]=c36SuiteByChannel[0]; c36SuiteByChannel[3]=c36SuiteByChannel[0];
    c37SuiteByChannel[1]=c37SuiteByChannel[0]; c37SuiteByChannel[2]=c37SuiteByChannel[0]; c37SuiteByChannel[3]=c37SuiteByChannel[0];
    c38SuiteByChannel[1]=c38SuiteByChannel[0]; c38SuiteByChannel[2]=c38SuiteByChannel[0]; c38SuiteByChannel[3]=c38SuiteByChannel[0];
    c39SuiteByChannel[1]=c39SuiteByChannel[0]; c39SuiteByChannel[2]=c39SuiteByChannel[0]; c39SuiteByChannel[3]=c39SuiteByChannel[0];
    c40SuiteByChannel[1]=c40SuiteByChannel[0]; c40SuiteByChannel[2]=c40SuiteByChannel[0]; c40SuiteByChannel[3]=c40SuiteByChannel[0];
    c41SuiteByChannel[1]=c41SuiteByChannel[0]; c41SuiteByChannel[2]=c41SuiteByChannel[0]; c41SuiteByChannel[3]=c41SuiteByChannel[0];
    c42SuiteByChannel[1]=c42SuiteByChannel[0]; c42SuiteByChannel[2]=c42SuiteByChannel[0]; c42SuiteByChannel[3]=c42SuiteByChannel[0];
    c43SuiteByChannel[1]=c43SuiteByChannel[0]; c43SuiteByChannel[2]=c43SuiteByChannel[0]; c43SuiteByChannel[3]=c43SuiteByChannel[0];
    c44SuiteByChannel[1]=c44SuiteByChannel[0]; c44SuiteByChannel[2]=c44SuiteByChannel[0]; c44SuiteByChannel[3]=c44SuiteByChannel[0];
    c45SuiteByChannel[1]=c45SuiteByChannel[0]; c45SuiteByChannel[2]=c45SuiteByChannel[0]; c45SuiteByChannel[3]=c45SuiteByChannel[0];
    c46SuiteByChannel[1]=c46SuiteByChannel[0]; c46SuiteByChannel[2]=c46SuiteByChannel[0]; c46SuiteByChannel[3]=c46SuiteByChannel[0];
    c47SuiteByChannel[1]=c47SuiteByChannel[0]; c47SuiteByChannel[2]=c47SuiteByChannel[0]; c47SuiteByChannel[3]=c47SuiteByChannel[0];
    c48SuiteByChannel[1]=c48SuiteByChannel[0]; c48SuiteByChannel[2]=c48SuiteByChannel[0]; c48SuiteByChannel[3]=c48SuiteByChannel[0];
    c49SuiteByChannel[1]=c49SuiteByChannel[0]; c49SuiteByChannel[2]=c49SuiteByChannel[0]; c49SuiteByChannel[3]=c49SuiteByChannel[0];
    c50SuiteByChannel[1]=c50SuiteByChannel[0]; c50SuiteByChannel[2]=c50SuiteByChannel[0]; c50SuiteByChannel[3]=c50SuiteByChannel[0];
    c51SuiteByChannel[1]=c51SuiteByChannel[0]; c51SuiteByChannel[2]=c51SuiteByChannel[0]; c51SuiteByChannel[3]=c51SuiteByChannel[0];
    c52SuiteByChannel[1]=c52SuiteByChannel[0]; c52SuiteByChannel[2]=c52SuiteByChannel[0]; c52SuiteByChannel[3]=c52SuiteByChannel[0];
    c53SuiteByChannel[1]=c53SuiteByChannel[0]; c53SuiteByChannel[2]=c53SuiteByChannel[0]; c53SuiteByChannel[3]=c53SuiteByChannel[0];
    c54SuiteByChannel[1]=c54SuiteByChannel[0]; c54SuiteByChannel[2]=c54SuiteByChannel[0]; c54SuiteByChannel[3]=c54SuiteByChannel[0];
    c55SuiteByChannel[1]=c55SuiteByChannel[0]; c55SuiteByChannel[2]=c55SuiteByChannel[0]; c55SuiteByChannel[3]=c55SuiteByChannel[0];
    c56SuiteByChannel[1]=c56SuiteByChannel[0]; c56SuiteByChannel[2]=c56SuiteByChannel[0]; c56SuiteByChannel[3]=c56SuiteByChannel[0];
    c57SuiteByChannel[1]=c57SuiteByChannel[0]; c57SuiteByChannel[2]=c57SuiteByChannel[0]; c57SuiteByChannel[3]=c57SuiteByChannel[0];
    c58SuiteByChannel[1]=c58SuiteByChannel[0]; c58SuiteByChannel[2]=c58SuiteByChannel[0]; c58SuiteByChannel[3]=c58SuiteByChannel[0];
    c59SuiteByChannel[1]=c59SuiteByChannel[0]; c59SuiteByChannel[2]=c59SuiteByChannel[0]; c59SuiteByChannel[3]=c59SuiteByChannel[0];
    c60SuiteByChannel[1]=c60SuiteByChannel[0]; c60SuiteByChannel[2]=c60SuiteByChannel[0]; c60SuiteByChannel[3]=c60SuiteByChannel[0];
    c61SuiteByChannel[1]=c61SuiteByChannel[0]; c61SuiteByChannel[2]=c61SuiteByChannel[0]; c61SuiteByChannel[3]=c61SuiteByChannel[0];
    c62SuiteByChannel[1]=c62SuiteByChannel[0]; c62SuiteByChannel[2]=c62SuiteByChannel[0]; c62SuiteByChannel[3]=c62SuiteByChannel[0];
    c63SuiteByChannel[1]=c63SuiteByChannel[0]; c63SuiteByChannel[2]=c63SuiteByChannel[0]; c63SuiteByChannel[3]=c63SuiteByChannel[0];
    c64SuiteByChannel[1]=c64SuiteByChannel[0]; c64SuiteByChannel[2]=c64SuiteByChannel[0]; c64SuiteByChannel[3]=c64SuiteByChannel[0];
    c65SuiteByChannel[1]=c65SuiteByChannel[0]; c65SuiteByChannel[2]=c65SuiteByChannel[0]; c65SuiteByChannel[3]=c65SuiteByChannel[0];
    c66SuiteByChannel[1]=c66SuiteByChannel[0]; c66SuiteByChannel[2]=c66SuiteByChannel[0]; c66SuiteByChannel[3]=c66SuiteByChannel[0];
    c67SuiteByChannel[1]=c67SuiteByChannel[0]; c67SuiteByChannel[2]=c67SuiteByChannel[0]; c67SuiteByChannel[3]=c67SuiteByChannel[0];
    c68SuiteByChannel[1]=c68SuiteByChannel[0]; c68SuiteByChannel[2]=c68SuiteByChannel[0]; c68SuiteByChannel[3]=c68SuiteByChannel[0];
    c69SuiteByChannel[1]=c69SuiteByChannel[0]; c69SuiteByChannel[2]=c69SuiteByChannel[0]; c69SuiteByChannel[3]=c69SuiteByChannel[0];
    c70SuiteByChannel[1]=c70SuiteByChannel[0]; c70SuiteByChannel[2]=c70SuiteByChannel[0]; c70SuiteByChannel[3]=c70SuiteByChannel[0];
    c71SuiteByChannel[1]=c71SuiteByChannel[0]; c71SuiteByChannel[2]=c71SuiteByChannel[0]; c71SuiteByChannel[3]=c71SuiteByChannel[0];
    c72SuiteByChannel[1]=c72SuiteByChannel[0]; c72SuiteByChannel[2]=c72SuiteByChannel[0]; c72SuiteByChannel[3]=c72SuiteByChannel[0];
    c73SuiteByChannel[1]=c73SuiteByChannel[0]; c73SuiteByChannel[2]=c73SuiteByChannel[0]; c73SuiteByChannel[3]=c73SuiteByChannel[0];
    c74SuiteByChannel[1]=c74SuiteByChannel[0]; c74SuiteByChannel[2]=c74SuiteByChannel[0]; c74SuiteByChannel[3]=c74SuiteByChannel[0];
    c75SuiteByChannel[1]=c75SuiteByChannel[0]; c75SuiteByChannel[2]=c75SuiteByChannel[0]; c75SuiteByChannel[3]=c75SuiteByChannel[0];
    c76SuiteByChannel[1]=c76SuiteByChannel[0]; c76SuiteByChannel[2]=c76SuiteByChannel[0]; c76SuiteByChannel[3]=c76SuiteByChannel[0];
    c77SuiteByChannel[1]=c77SuiteByChannel[0]; c77SuiteByChannel[2]=c77SuiteByChannel[0]; c77SuiteByChannel[3]=c77SuiteByChannel[0];
    c78SuiteByChannel[1]=c78SuiteByChannel[0]; c78SuiteByChannel[2]=c78SuiteByChannel[0]; c78SuiteByChannel[3]=c78SuiteByChannel[0];
    c79SuiteByChannel[1]=c79SuiteByChannel[0]; c79SuiteByChannel[2]=c79SuiteByChannel[0]; c79SuiteByChannel[3]=c79SuiteByChannel[0];
    c80SuiteByChannel[1]=c80SuiteByChannel[0]; c80SuiteByChannel[2]=c80SuiteByChannel[0]; c80SuiteByChannel[3]=c80SuiteByChannel[0];
    c81SuiteByChannel[1]=c81SuiteByChannel[0]; c81SuiteByChannel[2]=c81SuiteByChannel[0]; c81SuiteByChannel[3]=c81SuiteByChannel[0];
    c82SuiteByChannel[1]=c82SuiteByChannel[0]; c82SuiteByChannel[2]=c82SuiteByChannel[0]; c82SuiteByChannel[3]=c82SuiteByChannel[0];
    c83SuiteByChannel[1]=c83SuiteByChannel[0]; c83SuiteByChannel[2]=c83SuiteByChannel[0]; c83SuiteByChannel[3]=c83SuiteByChannel[0];
    c84SuiteByChannel[1]=c84SuiteByChannel[0]; c84SuiteByChannel[2]=c84SuiteByChannel[0]; c84SuiteByChannel[3]=c84SuiteByChannel[0];
    c85SuiteByChannel[1]=c85SuiteByChannel[0]; c85SuiteByChannel[2]=c85SuiteByChannel[0]; c85SuiteByChannel[3]=c85SuiteByChannel[0];
    c86SuiteByChannel[1]=c86SuiteByChannel[0]; c86SuiteByChannel[2]=c86SuiteByChannel[0]; c86SuiteByChannel[3]=c86SuiteByChannel[0];
    c87SuiteByChannel[1]=c87SuiteByChannel[0]; c87SuiteByChannel[2]=c87SuiteByChannel[0]; c87SuiteByChannel[3]=c87SuiteByChannel[0];
    c88SuiteByChannel[1]=c88SuiteByChannel[0]; c88SuiteByChannel[2]=c88SuiteByChannel[0]; c88SuiteByChannel[3]=c88SuiteByChannel[0];
    c89SuiteByChannel[1]=c89SuiteByChannel[0]; c89SuiteByChannel[2]=c89SuiteByChannel[0]; c89SuiteByChannel[3]=c89SuiteByChannel[0];
    c90SuiteByChannel[1]=c90SuiteByChannel[0]; c90SuiteByChannel[2]=c90SuiteByChannel[0]; c90SuiteByChannel[3]=c90SuiteByChannel[0];
    c91SuiteByChannel[1]=c91SuiteByChannel[0]; c91SuiteByChannel[2]=c91SuiteByChannel[0]; c91SuiteByChannel[3]=c91SuiteByChannel[0];
    c92SuiteByChannel[1]=c92SuiteByChannel[0]; c92SuiteByChannel[2]=c92SuiteByChannel[0]; c92SuiteByChannel[3]=c92SuiteByChannel[0];
    c93SuiteByChannel[1]=c93SuiteByChannel[0]; c93SuiteByChannel[2]=c93SuiteByChannel[0]; c93SuiteByChannel[3]=c93SuiteByChannel[0];
    c94SuiteByChannel[1]=c94SuiteByChannel[0]; c94SuiteByChannel[2]=c94SuiteByChannel[0]; c94SuiteByChannel[3]=c94SuiteByChannel[0];
    c95SuiteByChannel[1]=c95SuiteByChannel[0]; c95SuiteByChannel[2]=c95SuiteByChannel[0]; c95SuiteByChannel[3]=c95SuiteByChannel[0];
    c96SuiteByChannel[1]=c96SuiteByChannel[0]; c96SuiteByChannel[2]=c96SuiteByChannel[0]; c96SuiteByChannel[3]=c96SuiteByChannel[0];
    c97SuiteByChannel[1]=c97SuiteByChannel[0]; c97SuiteByChannel[2]=c97SuiteByChannel[0]; c97SuiteByChannel[3]=c97SuiteByChannel[0];
    c98SuiteByChannel[1]=c98SuiteByChannel[0]; c98SuiteByChannel[2]=c98SuiteByChannel[0]; c98SuiteByChannel[3]=c98SuiteByChannel[0];
    c99SuiteByChannel[1]=c99SuiteByChannel[0]; c99SuiteByChannel[2]=c99SuiteByChannel[0]; c99SuiteByChannel[3]=c99SuiteByChannel[0];
    c100SuiteByChannel[1]=c100SuiteByChannel[0]; c100SuiteByChannel[2]=c100SuiteByChannel[0]; c100SuiteByChannel[3]=c100SuiteByChannel[0];

    k3SafeShow();
    return;
  }

  // MODE 21-30 tetap memakai mapping yang sudah disetujui sebelumnya:
  // output virtual A -> CH1+CH2, output virtual B -> CH3+CH4.
  const bool map21to30_12_34 =
      channelSource[0] == MAIN_MODE && channelSource[1] == MAIN_MODE &&
      channelSource[2] == MAIN_MODE && channelSource[3] == MAIN_MODE &&
      selectedMode[0] >= 21 && selectedMode[0] <= 30 &&
      selectedMode[1] == selectedMode[0] && selectedMode[2] == selectedMode[0] && selectedMode[3] == selectedMode[0];

  if (map21to30_12_34) {
    const uint8_t m = selectedMode[0];
    CRGB *virtualB = modeDummyByChannel[0];
    loadSuiteStateForChannel(0);
    renderMode210Pattern(m, leds1, virtualB, n);
    saveSuiteStateForChannel(0);
    memcpy(leds2, leds1, sizeof(CRGB) * n);
    memcpy(leds3, virtualB, sizeof(CRGB) * n);
    memcpy(leds4, virtualB, sizeof(CRGB) * n);

    c21SuiteByChannel[1]=c21SuiteByChannel[0]; c21SuiteByChannel[2]=c21SuiteByChannel[0]; c21SuiteByChannel[3]=c21SuiteByChannel[0];
    c22SuiteByChannel[1]=c22SuiteByChannel[0]; c22SuiteByChannel[2]=c22SuiteByChannel[0]; c22SuiteByChannel[3]=c22SuiteByChannel[0];
    c23SuiteByChannel[1]=c23SuiteByChannel[0]; c23SuiteByChannel[2]=c23SuiteByChannel[0]; c23SuiteByChannel[3]=c23SuiteByChannel[0];
    c24SuiteByChannel[1]=c24SuiteByChannel[0]; c24SuiteByChannel[2]=c24SuiteByChannel[0]; c24SuiteByChannel[3]=c24SuiteByChannel[0];
    c25SuiteByChannel[1]=c25SuiteByChannel[0]; c25SuiteByChannel[2]=c25SuiteByChannel[0]; c25SuiteByChannel[3]=c25SuiteByChannel[0];
    c26SuiteByChannel[1]=c26SuiteByChannel[0]; c26SuiteByChannel[2]=c26SuiteByChannel[0]; c26SuiteByChannel[3]=c26SuiteByChannel[0];
    if (m==27) {c27SuiteByChannel[1]=c27SuiteByChannel[0];c27SuiteByChannel[2]=c27SuiteByChannel[0];c27SuiteByChannel[3]=c27SuiteByChannel[0];}
    c28SuiteByChannel[1]=c28SuiteByChannel[0]; c28SuiteByChannel[2]=c28SuiteByChannel[0]; c28SuiteByChannel[3]=c28SuiteByChannel[0];
    c29SuiteByChannel[1]=c29SuiteByChannel[0]; c29SuiteByChannel[2]=c29SuiteByChannel[0]; c29SuiteByChannel[3]=c29SuiteByChannel[0];
    c30SuiteByChannel[1]=c30SuiteByChannel[0]; c30SuiteByChannel[2]=c30SuiteByChannel[0]; c30SuiteByChannel[3]=c30SuiteByChannel[0];
    k3SafeShow();
    return;
  }

  // Mode 1-20 dan konfigurasi channel independen tetap memakai jalur yang sudah ada.
  renderModePairOrIndependent(0, 1, leds1, leds2, n);

  // Jika CH3+CH4 memakai mode/source yang sama dengan CH1+CH2,
  // jangan render ulang: copy hasil pair utama. Ini mengembalikan perilaku
  // GLOBAL 4CH dan sekaligus mengurangi beban CPU/BLE.
  const bool mirrorPair =
      channelSource[0] == MAIN_MODE && channelSource[1] == MAIN_MODE &&
      channelSource[2] == MAIN_MODE && channelSource[3] == MAIN_MODE &&
      selectedMode[2] == selectedMode[0] && selectedMode[3] == selectedMode[1];

  if (mirrorPair) {
    memcpy(leds3, leds1, sizeof(CRGB) * n);
    memcpy(leds4, leds2, sizeof(CRGB) * n);
  } else {
    // LED3/LED4 yang memang dipilih terpisah tetap independen.
    renderModePairOrIndependent(2, 3, leds3, leds4, n);
  }

  k3SafeShow();
}

#define TOTAL_PHASES 8
static const uint32_t DUR_PHASE[TOTAL_PHASES] = { 4000, 4000, 4500, 4500, 4000, 4000, 4000, 4000 };
static uint32_t T_F[TOTAL_PHASES + 1];
static uint32_t TOTAL_CEREMONY = 0;
static CRGB colorDRL = CRGB::White;

static float getBlockDist(float dist, float width) {
  if (dist >= width) return 0.0f; return cosf((dist / width) * (PI / 2.0f));
}

static void initTiming() {
  T_F[0] = 0;
  for (int i = 0; i < TOTAL_PHASES; i++) { T_F[i + 1] = T_F[i] + DUR_PHASE[i]; }
  TOTAL_CEREMONY = T_F[TOTAL_PHASES];
}

static uint8_t getActivePhase(uint32_t tMod) {
  for (uint8_t p = 0; p < TOTAL_PHASES; p++) { if (tMod >= T_F[p] && tMod < T_F[p + 1]) return p; }
  return TOTAL_PHASES - 1;
}

static void evaluateNewCeremony(uint32_t tMod, uint8_t curPhase, uint16_t n, float *outL, float *outR) {
  for (int i = 0; i < n; i++) { outL[i] = 0.0f; outR[i] = 0.0f; }
  uint32_t localT = tMod - T_F[curPhase]; uint32_t dur = DUR_PHASE[curPhase];
  uint8_t numRepeats = 2; uint32_t repDur = dur / numRepeats;
  uint8_t repIdx = localT / repDur; if (repIdx >= numRepeats) repIdx = numRepeats - 1;
  float subT = (float)(localT - repIdx * repDur) / (float)repDur;

  switch (curPhase) {
    case 0: {
      if (subT < 0.50f) {
        float p = subT / 0.50f; float head = p * (float)(n - 1); float w = 6.0f + p * 10.0f;
        for (int i = 0; i < n; i++) { float v = getBlockDist(fabsf((float)i - head), w); outL[i] = v; outR[i] = v; }
      } else if (subT < 0.90f) {
        float p = (subT - 0.50f) / 0.40f; float head = (1.0f - p) * (float)(n - 1); float w = 14.0f - p * 8.0f;
        for (int i = 0; i < n; i++) { float v = getBlockDist(fabsf((float)i - head), w); outL[i] = v; outR[i] = v; }
      } else {
        bool flash = sinf((subT - 0.90f) * 80.0f) > 0;
        for (int i = 0; i < n; i++) { float v = (i < 12 && flash) ? 1.0f : 0.0f; outL[i] = v; outR[i] = v; }
      } break;
    }
    case 1: {
      float p1 = (sinf(subT * PI * 2.0f) * 0.5f + 0.5f) * (float)(n - 1); float p2 = (float)(n - 1) - p1;
      for (int i = 0; i < n; i++) {
        float d1 = getBlockDist(fabsf((float)i - p1), 5.5f); float d2 = getBlockDist(fabsf((float)i - p2), 5.5f);
        float v = fmaxf(d1, d2); outL[i] = v; outR[i] = v;
      } break;
    }
    case 2: {
      float centerWave = subT * (float)(n + 15) - 8.0f;
      float osc1 = sinf(subT * PI * 6.0f) * 8.0f; float osc2 = cosf(subT * PI * 6.0f) * 8.0f;
      float posA = centerWave + osc1; float posB = centerWave + osc2;
      for (int i = 0; i < n; i++) {
        float a = getBlockDist(fabsf((float)i - posA), 7.0f); float b = getBlockDist(fabsf((float)i - posB), 7.0f) * 0.85f;
        float v = fmaxf(a, b); outL[i] = v; outR[i] = v;
      } break;
    }
    case 3: {
      float stretch = sinf(subT * PI * 2.0f) * 0.5f + 0.5f; float segSpan = (float)n / 5.0f;
      for (int i = 0; i < n; i++) {
        int segIdx = (int)((float)i / segSpan); float localPos = (float)i - (float)segIdx * segSpan;
        float segCenter = segSpan * 0.5f; float dynamicWidth = (segSpan * 0.35f) + stretch * (segSpan * 0.45f);
        float v = getBlockDist(fabsf(localPos - segCenter), dynamicWidth); outL[i] = v; outR[i] = v;
      } break;
    }
    case 4: {
      float stepProgress = subT * 5.0f; int curStep = (int)stepProgress; if (curStep > 4) curStep = 4;
      float subFract = stepProgress - (float)curStep; int startIdx = curStep * 15; int endIdx = startIdx + 15;
      bool spark = sinf(subFract * PI * 14.0f) > 0.2f;
      for (int i = 0; i < n; i++) {
        float v = 0.0f; if (i >= startIdx && i < endIdx) v = spark ? 1.0f : 0.05f; else if (i < startIdx) v = 0.25f;
        outL[i] = v; outR[i] = v;
      } break;
    }
    case 5: {
      float travel = (1.0f - subT) * (float)(n + 25);
      for (int i = 0; i < n; i++) {
        float bTotal = 0.0f;
        for (int k = 0; k < 4; k++) {
          float head = travel - (float)k * 18.0f; float v = getBlockDist(fabsf((float)i - head), 8.0f) * (1.0f - (float)k * 0.18f);
          if (v > bTotal) bTotal = v;
        }
        outL[i] = bTotal; outR[i] = bTotal;
      } break;
    }
    case 6: {
      float briCurve = (subT < 0.50f) ? sinf((subT / 0.50f) * (PI / 2.0f)) : cosf(((subT - 0.50f) / 0.50f) * (PI / 2.0f));
      float activeHead = briCurve * (float)n;
      for (int i = 0; i < n; i++) { float v = ((float)i <= activeHead) ? fmaxf(0.10f, briCurve) : 0.0f; outL[i] = v; outR[i] = v; }
      break;
    }
    case 7:
    default: {
      float pOut = subT * (float)(n + 12) - 6.0f; float pEcho = (1.0f - subT) * (float)(n + 12) - 6.0f;
      float crossDist = fabsf(pOut - pEcho);
      for (int i = 0; i < n; i++) {
        float d1 = getBlockDist(fabsf((float)i - pOut), 8.5f); float d2 = getBlockDist(fabsf((float)i - pEcho), 7.0f) * 0.75f;
        float crossSpark = (crossDist < 12.0f) ? (getBlockDist(fabsf((float)i - pOut), 5.0f) * 0.60f) : 0.0f;
        float v = fminf(1.0f, fmaxf(d1, d2) + crossSpark); outL[i] = v; outR[i] = v;
      } break;
    }
  }
}

static unsigned long welcomeLastClockAt = 0;
static unsigned long welcomeLastRenderAt = 0;
static float welcomeAnimClockVirtual = 0.0f;

#define W1_TOTAL_PHASES 14
static const CRGB W1_PHASE_COLORS[W1_TOTAL_PHASES] = {
  CRGB(255, 255, 255), CRGB(0, 220, 255), CRGB(255, 255, 255), CRGB(0, 210, 255),
  CRGB(255, 255, 255), CRGB(217, 70, 239), CRGB(255, 255, 255), CRGB(255, 153, 0),
  CRGB(0, 240, 255), CRGB(239, 68, 68), CRGB(59, 130, 246), CRGB(255, 255, 255),
  CRGB(220, 38, 38), CRGB(255, 255, 255)
};
static const uint8_t W1_BLOCK_SIZE = 5;
static const uint16_t W1_MAX_BLOCKS = (STAGE0_LED_BUFFER + W1_BLOCK_SIZE - 1) / W1_BLOCK_SIZE;
static const uint32_t W1_DUR_P1  = 3500;
static const uint32_t W1_DUR_P2  = 3000;
static const uint32_t W1_DUR_P3  = 3500;
static const uint32_t W1_DUR_P4  = 3500;
static const uint32_t W1_DUR_P5  = 3500;
static const uint32_t W1_DUR_P6  = 3500;
static const uint32_t W1_DUR_P7  = 3500;
static const uint32_t W1_DUR_P8  = 4000;
static const uint32_t W1_DUR_P10 = 4000;
static const uint32_t W1_DUR_P11 = 3500;
static const uint32_t W1_DUR_P12 = 3500;
static const uint32_t W1_DUR_P13 = 3000;
static const uint32_t W1_DUR_P14 = 4000;

static uint16_t w1StackBlockDelays[W1_MAX_BLOCKS];
static uint32_t w1StackBlockDurs[W1_MAX_BLOCKS];
static uint32_t w1StackBlockStarts[W1_MAX_BLOCKS];
static uint16_t w1StackBlockCount = 0;
static uint32_t w1DurStackTotal = 0;
static uint16_t w1TimingLedCount = 0;
static uint32_t W1_T_F[15];
static uint32_t W1_TOTAL_CEREMONY = 0;
static float *w1OutL = nullptr;
static float *w1OutR = nullptr;

// ============================================================================
// RAM OPTIMIZER — hanya buffer tambahan/trail/scratch yang dinamis.
// Layout efek, jumlah LED maksimum, timing, warna, CH mapping, BLE dan OTA tidak diubah.
// 26 plane CRGB + 6 plane float dialokasikan sesuai jumlah LED yang AKTIF.
// ============================================================================
static const uint8_t RUNTIME_CRGB_AUX_PLANES = 26;
static const uint8_t RUNTIME_FLOAT_AUX_PLANES = 6;

static void bindRuntimeAuxPointers(uint16_t count) {
  CRGB *cp = runtimeCrgbAuxPool;
  k3LastVisible1 = cp; cp += count;
  k3LastVisible2 = cp; cp += count;
  k3LastVisible3 = cp; cp += count;
  k3LastVisible4 = cp; cp += count;
  k3EditBase = cp; cp += count;
  k3EditPreview = cp; cp += count;
  k3ShowScratch1 = cp; cp += count;
  k3ShowScratch2 = cp; cp += count;
  k3ShowScratch3 = cp; cp += count;
  k3ShowScratch4 = cp; cp += count;
  for (uint8_t ch = 0; ch < 4; ch++) { c12TrailKByChannel[ch] = cp; cp += count; }
  for (uint8_t ch = 0; ch < 4; ch++) { c12TrailNByChannel[ch] = cp; cp += count; }
  for (uint8_t ch = 0; ch < 4; ch++) { m93100TrailColor4[ch] = cp; cp += count; }
  for (uint8_t ch = 0; ch < 4; ch++) { modeDummyByChannel[ch] = cp; cp += count; }

  float *fp = runtimeFloatAuxPool;
  for (uint8_t ch = 0; ch < 4; ch++) { m93100TrailV4[ch] = fp; fp += count; }
  w1OutL = fp; fp += count;
  w1OutR = fp;
}

static bool resizeRuntimeAuxBuffers(uint16_t requestedCount) {
  if (requestedCount < 1) requestedCount = 1;
  if (requestedCount > STAGE0_LED_BUFFER) requestedCount = STAGE0_LED_BUFFER;
  if (runtimeAuxCount == requestedCount && runtimeCrgbAuxPool && runtimeFloatAuxPool) return true;

  const size_t crgbElems = (size_t)RUNTIME_CRGB_AUX_PLANES * (size_t)requestedCount;
  const size_t floatElems = (size_t)RUNTIME_FLOAT_AUX_PLANES * (size_t)requestedCount;
  CRGB *newCrgb = (CRGB*)calloc(crgbElems, sizeof(CRGB));
  float *newFloat = (float*)calloc(floatElems, sizeof(float));

  if (!newCrgb || !newFloat) {
    if (newCrgb) free(newCrgb);
    if (newFloat) free(newFloat);
    Serial.printf("[RAM] AUX resize GAGAL count=%u heap=%u\n", (unsigned)requestedCount, (unsigned)ESP.getFreeHeap());
    return false;
  }

  if (runtimeCrgbAuxPool && runtimeFloatAuxPool && runtimeAuxCount > 0) {
    const uint16_t copyCount = (runtimeAuxCount < requestedCount) ? runtimeAuxCount : requestedCount;
    for (uint8_t plane = 0; plane < RUNTIME_CRGB_AUX_PLANES; plane++) {
      memcpy(newCrgb + (size_t)plane * requestedCount,
             runtimeCrgbAuxPool + (size_t)plane * runtimeAuxCount,
             (size_t)copyCount * sizeof(CRGB));
    }
    for (uint8_t plane = 0; plane < RUNTIME_FLOAT_AUX_PLANES; plane++) {
      memcpy(newFloat + (size_t)plane * requestedCount,
             runtimeFloatAuxPool + (size_t)plane * runtimeAuxCount,
             (size_t)copyCount * sizeof(float));
    }
  }

  if (runtimeCrgbAuxPool) free(runtimeCrgbAuxPool);
  if (runtimeFloatAuxPool) free(runtimeFloatAuxPool);
  runtimeCrgbAuxPool = newCrgb;
  runtimeFloatAuxPool = newFloat;
  runtimeAuxCount = requestedCount;
  bindRuntimeAuxPointers(runtimeAuxCount);

  Serial.printf("[RAM] AUX count=%u bytes=%u heap=%u\n",
                (unsigned)runtimeAuxCount,
                (unsigned)(crgbElems * sizeof(CRGB) + floatElems * sizeof(float)),
                (unsigned)ESP.getFreeHeap());
  return true;
}

static void initWelcome1Timing() {
  uint16_t n = activeLedCount; if (n < 1) n = 1; if (n > STAGE0_LED_BUFFER) n = STAGE0_LED_BUFFER;
  w1StackBlockCount = (n + W1_BLOCK_SIZE - 1) / W1_BLOCK_SIZE;
  if (w1StackBlockCount < 1) w1StackBlockCount = 1; if (w1StackBlockCount > W1_MAX_BLOCKS) w1StackBlockCount = W1_MAX_BLOCKS;
  uint32_t cur = 0;
  for (uint16_t b = 0; b < w1StackBlockCount; b++) {
    float frac = (w1StackBlockCount > 1) ? ((float)b / (float)(w1StackBlockCount - 1)) : 1.0f;
    float dMs = 50.0f - frac * (50.0f - 5.0f);
    int steps = (int)n - (int)(b + 1) * (int)W1_BLOCK_SIZE;
    uint32_t dur_ms = (steps > 0) ? (uint32_t)((float)steps * dMs) : 120UL;
    if (dur_ms < 120UL) dur_ms = 120UL;
    w1StackBlockDelays[b] = (uint16_t)dMs; w1StackBlockDurs[b] = dur_ms; w1StackBlockStarts[b] = cur; cur += dur_ms;
  }
  w1DurStackTotal = cur; w1TimingLedCount = n;
  W1_T_F[0]  = 0; W1_T_F[1]  = W1_DUR_P1; W1_T_F[2]  = W1_T_F[1] + W1_DUR_P2; W1_T_F[3]  = W1_T_F[2] + W1_DUR_P3;
  W1_T_F[4]  = W1_T_F[3] + W1_DUR_P4; W1_T_F[5]  = W1_T_F[4] + W1_DUR_P5; W1_T_F[6]  = W1_T_F[5] + W1_DUR_P6;
  W1_T_F[7]  = W1_T_F[6] + W1_DUR_P7; W1_T_F[8]  = W1_T_F[7] + W1_DUR_P8; W1_T_F[9]  = W1_T_F[8] + w1DurStackTotal;
  W1_T_F[10] = W1_T_F[9] + W1_DUR_P10; W1_T_F[11] = W1_T_F[10] + W1_DUR_P11; W1_T_F[12] = W1_T_F[11] + W1_DUR_P12;
  W1_T_F[13] = W1_T_F[12] + W1_DUR_P13; W1_T_F[14] = W1_T_F[13] + W1_DUR_P14; W1_TOTAL_CEREMONY = W1_T_F[14];
}

static void evaluateWelcome1(uint32_t tMod, float *outL, float *outR, uint16_t n) {
  if (w1TimingLedCount != n || W1_TOTAL_CEREMONY == 0) initWelcome1Timing();
  for (uint16_t i = 0; i < n; i++) { outL[i] = 0.0f; outR[i] = 0.0f; }
  if (tMod < W1_T_F[1]) {
    float p = (float)tMod / (float)W1_DUR_P1;
    if (p < 0.82f) { float head = (1.0f - p / 0.82f) * ((float)n - 1.0f); for (uint16_t i = 0; i < n; i++) { float d = fabsf((float)i - head); outL[i] = getBlockDist(d, 14.0f); outR[i] = outL[i]; } }
    else { bool flash = sinf((p - 0.82f) * 45.0f) > 0.0f; for (uint16_t i = 0; i < n; i++) { float v = (i < 12U && flash) ? 1.0f : 0.0f; outL[i] = v; outR[i] = v; } }
    return;
  }
  if (tMod < W1_T_F[2]) {
    float p = (float)(tMod - W1_T_F[1]) / (float)W1_DUR_P2; float waveFront = p * (float)n;
    for (uint16_t i = 0; i < n; i++) { float d = fabsf((float)i - waveFront); float v = getBlockDist(d, 12.0f) * (1.0f - p * 0.3f); outL[i] = v; outR[i] = v; } return;
  }
  if (tMod < W1_T_F[4]) {
    uint32_t localT = (tMod < W1_T_F[3]) ? (tMod - W1_T_F[2]) : (tMod - W1_T_F[3]); float tSec = (float)localT / 1000.0f; float durSec = (float)W1_DUR_P3 / 1000.0f; float speed = ((float)n + 25.0f) / durSec;
    float waveL = ((float)n - 1.0f) - (fmodf(tSec * speed, (float)n + 25.0f) - 10.0f); float waveR = ((float)n - 1.0f) - (fmodf(tSec * speed, (float)n + 25.0f) - 18.0f);
    for (uint16_t i = 0; i < n; i++) { outL[i] = getBlockDist(fabsf((float)i - waveL), 16.0f); outR[i] = getBlockDist(fabsf((float)i - waveR), 16.0f); } return;
  }
  if (tMod < W1_T_F[5]) {
    uint32_t localT = tMod - W1_T_F[4]; float tSec = (float)localT / 1000.0f; float wipeSpeed = ((float)n + 15.0f) / (((float)W1_DUR_P5 / 1000.0f) * 0.72f); float head = tSec * wipeSpeed;
    for (uint16_t i = 0; i < n; i++) { float v = (head >= (float)n || (float)i <= head) ? 1.0f : 0.0f; outL[i] = v; outR[i] = v; } return;
  }
  if (tMod < W1_T_F[6]) {
    uint32_t localT = tMod - W1_T_F[5]; float tSec = (float)localT / 1000.0f;
    float p1 = (sinf(tSec * 3.6f) * 0.5f + 0.5f) * ((float)n * 0.44f); float p2 = ((float)n * 0.52f) + (cosf(tSec * 4.2f) * 0.5f + 0.5f) * ((float)n * 0.44f);
    for (uint16_t i = 0; i < n; i++) { float b1 = getBlockDist(fabsf((float)i - p1), 14.0f); float b2 = getBlockDist(fabsf((float)i - p2), 14.0f); float v = fmaxf(b1, b2); outL[i] = v; outR[i] = v; } return;
  }
  if (tMod < W1_T_F[7]) {
    uint32_t localT = tMod - W1_T_F[6]; uint32_t cycleTime = localT % 400UL; bool isLeftTurn = (cycleTime < 200UL); uint32_t subTime = isLeftTurn ? cycleTime : (cycleTime - 200UL);
    bool isFlashOn = (subTime % 66UL) < 38UL; float briL = (isLeftTurn && isFlashOn) ? 1.0f : 0.0f; float briR = (!isLeftTurn && isFlashOn) ? 1.0f : 0.0f;
    for (uint16_t i = 0; i < n; i++) { outL[i] = briL; outR[i] = briR; } return;
  }
  if (tMod < W1_T_F[8]) {
    uint32_t localT = tMod - W1_T_F[7]; uint32_t half = W1_DUR_P8 / 2UL; float combinedLen = (float)(n * 2U); float posCombined;
    if (localT < half) posCombined = ((float)localT / (float)half) * combinedLen; else posCombined = combinedLen - (((float)(localT - half) / (float)half) * combinedLen);
    uint8_t beamCh = (posCombined < (float)n) ? 0U : 1U; float beamIdx = (beamCh == 0U) ? ((float)(n - 1U) - posCombined) : (posCombined - (float)n);
    float *targetBuffer = (beamCh == 0U) ? outL : outR;
    for (uint16_t i = 0; i < n; i++) { float dist = fabsf((float)i - beamIdx); if (dist < 12.0f) targetBuffer[i] = cosf((dist / 12.0f) * (PI / 2.0f)); } return;
  }
  if (tMod < W1_T_F[9]) {
    uint32_t localT = tMod - W1_T_F[8]; uint16_t curBlock = 0;
    for (uint16_t b = 0; b < w1StackBlockCount; b++) { if (localT >= w1StackBlockStarts[b]) curBlock = b; }
    uint32_t bTime = localT - w1StackBlockStarts[curBlock]; float frac = (w1StackBlockDurs[curBlock] > 0UL) ? ((float)bTime / (float)w1StackBlockDurs[curBlock]) : 1.0f; if (frac > 1.0f) frac = 1.0f;
    int targetPos = (int)n - (int)(curBlock + 1) * (int)W1_BLOCK_SIZE; if (targetPos < 0) targetPos = 0; float movingPos = frac * (float)targetPos;
    int stackedStart = (int)n - (int)curBlock * (int)W1_BLOCK_SIZE; if (stackedStart < 0) stackedStart = 0; if (stackedStart > (int)n) stackedStart = (int)n;
    for (int i = stackedStart; i < (int)n; i++) { outL[i] = 1.0f; outR[i] = 1.0f; }
    for (uint16_t i = 0; i < n; i++) {
      if ((int)i >= (int)movingPos && (int)i < (int)movingPos + W1_BLOCK_SIZE) { outL[i] = 1.0f; outR[i] = 1.0f; }
      else if ((int)i < (int)movingPos && (int)i >= (int)movingPos - 4) { float tail = 1.0f - ((movingPos - (float)i) / 4.0f); if (tail > outL[i]) { outL[i] = tail * 0.85f; outR[i] = tail * 0.85f; } }
    } return;
  }
  if (tMod < W1_T_F[10]) {
    float p = (float)(tMod - W1_T_F[9]) / (float)W1_DUR_P10; int remaining = (int)((1.0f - p) * (float)n);
    for (uint16_t i = 0; i < n; i++) { float v = ((int)i < remaining) ? 1.0f : 0.0f; outL[i] = v; outR[i] = v; } return;
  }
  if (tMod < W1_T_F[11]) {
    float p = ((float)(tMod - W1_T_F[10]) / (float)W1_DUR_P11) * (float)n;
    for (uint16_t i = 0; i < n; i++) {
      bool even = ((i % 2) == 0);
      outL[i] = ((float)i <= p && even) ? 1.0f : (((float)i <= p * 0.6f) ? 0.4f : 0.0f); outR[i] = ((float)i <= p && !even) ? 1.0f : (((float)i <= p * 0.6f) ? 0.4f : 0.0f);
    } return;
  }
  if (tMod < W1_T_F[12]) {
    float p = (float)(tMod - W1_T_F[11]) / (float)W1_DUR_P12;
    if (p < 0.80f) { float ramp = 0.15f + (p / 0.80f) * 0.85f; for (uint16_t i = 0; i < n; i++) { outL[i] = ramp; outR[i] = ramp; } }
    else if (p < 0.90f) { for (uint16_t i = 0; i < n; i++) { outL[i] = 1.8f; outR[i] = 1.8f; } }
    else { for (uint16_t i = 0; i < n; i++) { outL[i] = 0.0f; outR[i] = 0.0f; } } return;
  }
  if (tMod < W1_T_F[13]) {
    float p = fmodf((float)(tMod - W1_T_F[12]) / 1000.0f, 1.0f); float pulse = powf(sinf(p * PI * 4.0f), 6.0f);
    for (uint16_t i = 0; i < n; i++) { float v = 0.2f + 0.8f * pulse; outL[i] = v; outR[i] = v; } return;
  }
  for (uint16_t i = 0; i < n; i++) { outL[i] = 1.0f; outR[i] = 1.0f; }
}


// ============================================================================
// WELCOME 40-50 — SOURCE COMPARE ENGINE
// Basis: source Welcome yang sudah ditelusuri sebelumnya.
// GLOBAL SPEED: timeline memakai welcomeAnimClockVirtual, sehingga slider speed
// GLOBAL mengubah kecepatan tanpa mengubah bentuk/fase/warna source.
//
// W40 = source 75 LED, block 10, 22 posisi, 40ms, 5x flash,
//       fase normal -> urutan sama versi rainbow.
// W41/W42 = SOURCE USER 30s.
// W43/W44/W45 = SOURCE USER Collision 30s.
// W46 = SOURCE USER Alis Vario 12.8s.
// W47 = source Random Ping-Pong -> 5x strobe -> sequential amber 2x/3s.
// W48 = gerak W49 + warna per-segmen.
// W49 = source one-shot block 5 + tail 5, maju 10/recoil 5.
// W50 = SOURCE USER "Cyber Neon", 8 fase.
//       Jalur virtual kiri CH1->CH3 dan kanan CH2->CH4.
//       currentMode=3, mulai phase=2, 160 tick/fase, source frame 15ms.
// Tidak ada delay() dan tidak ada buffer pixel baru.
// ============================================================================

static bool gw4050Done = false;

static inline float gw4050Clamp(float x) {
  return x < 0.0f ? 0.0f : (x > 1.0f ? 1.0f : x);
}
static inline float gw4050Fract(float x) {
  return x - floorf(x);
}
static inline float gw4050Tri(float x) {
  float f = gw4050Fract(x);
  return f < 0.5f ? f * 2.0f : 2.0f - f * 2.0f;
}
static inline float gw4050Smooth(float x) {
  x = gw4050Clamp(x);
  return x * x * (3.0f - 2.0f * x);
}
static inline float gw4050Gauss(float d, float w) {
  if (w < 0.000001f) w = 0.000001f;
  return expf(-0.5f * powf(d / w, 2.0f));
}
static inline CRGB gw4050Scale(CRGB c, float br) {
  br = gw4050Clamp(br);
  c.nscale8_video((uint8_t)(br * 255.0f));
  return c;
}
static inline CRGB gw4050Mix(CRGB a, CRGB b, float t) {
  t = gw4050Clamp(t);
  return CRGB(
    (uint8_t)(a.r * (1.0f - t) + b.r * t),
    (uint8_t)(a.g * (1.0f - t) + b.g * t),
    (uint8_t)(a.b * (1.0f - t) + b.b * t)
  );
}
static inline float gw4050Comet(
  float pTarget, int dir, float p, float wB, float wT
) {
  float d = (dir >= 0) ? (p - pTarget) : (pTarget - p);
  if (d <= 0.0f && d >= -wB) {
    return 0.72f + 0.28f * (1.0f + d / wB);
  }
  if (d < -wB && d >= -wB - wT) {
    return 0.60f * (1.0f - (-wB - d) / wT);
  }
  return 0.0f;
}

static void gw4050Clear12(uint16_t count) {
  fill_solid(leds1, count, CRGB::Black);
  fill_solid(leds2, count, CRGB::Black);
}

// ---------------- W40 SOURCE: 22 BLOK, 10 LED, 40ms, 5x ----------------
static const uint8_t GW40_BLOCK_COUNT = 22U;
static const uint8_t GW40_BLOCK_SIZE = 10U;
static const uint8_t gw40Side[GW40_BLOCK_COUNT] = {
  0,0,1,1,1,0,0,0,1,1,1,1,1,1,0,1,0,0,0,1,0,1
};
static const uint8_t gw40Start[GW40_BLOCK_COUNT] = {
  21,33,43,34,20,8,49,62,65,0,5,58,51,29,0,13,16,44,56,58,65,65
};

static void gw40Render(uint32_t tMs, uint16_t count) {
  gw4050Clear12(count);

  // 22 blok x 5 flash x ON/OFF x 2 fase x 40ms.
  const uint32_t ticksPerPhase = (uint32_t)GW40_BLOCK_COUNT * 10UL;
  const uint32_t totalTicks = ticksPerPhase * 2UL;
  if (tMs < 40UL) return;

  uint32_t tick = (tMs / 40UL) - 1UL;
  if (tick >= totalTicks) {
    gw4050Done = true;
    return;
  }

  bool rainbowPhase = tick >= ticksPerPhase;
  uint32_t localTick = tick % ticksPerPhase;
  uint8_t blockPos = (uint8_t)(localTick / 10UL);
  uint8_t sub = (uint8_t)(localTick % 10UL);
  bool flashOn = ((sub & 1U) == 0U);
  if (!flashOn) return;

  uint8_t side = gw40Side[blockPos];
  int start = (int)gw40Start[blockPos];
  CRGB *out = side == 0U ? leds1 : leds2;

  if (!rainbowPhase) {
    uint8_t hue = (uint8_t)(blockPos * (255U / GW40_BLOCK_COUNT));
    CRGB color = CHSV(hue, 255, 255);
    for (uint8_t i = 0; i < GW40_BLOCK_SIZE; i++) {
      int idx = start + (int)i;
      if (idx >= 0 && idx < (int)count) out[idx] = color;
    }
  } else {
    uint8_t baseHue = (uint8_t)((tMs / 8UL) + ((uint16_t)blockPos * 36U));
    for (uint8_t i = 0; i < GW40_BLOCK_SIZE; i++) {
      int idx = start + (int)i;
      if (idx >= 0 && idx < (int)count) {
        out[idx] = CHSV((uint8_t)(baseHue + i * 28U), 255, 255);
      }
    }
  }
}

// ---------------- W41/W42 SOURCE USER, 30s ----------------
static inline float gw4142Pg(uint8_t ch, uint16_t idx, uint16_t n) {
  float den = (n == 0) ? 1.0f : (float)((uint32_t)n * 2UL - 1UL);
  return ch == 0U
    ? (float)idx / den
    : (float)((uint32_t)n + (uint32_t)(n - 1U - idx)) / den;
}

static CRGB gw4142Sen(
  uint8_t mode, uint8_t ch, uint16_t idx, uint16_t n, float lt
) {
  const float SD = 2.8f;
  float p = gw4142Pg(ch, idx, n);
  float u = gw4050Clamp(lt / SD);
  float br = 0.0f;

  if (mode == 2U) {
    if (u < 0.5f) {
      float q = gw4050Smooth(u * 2.0f) * 1.05f;
      br = p <= q ? 0.88f : gw4050Gauss(p - q, 0.045f);
    } else {
      float q = gw4050Smooth((u - 0.5f) * 2.0f) * 1.05f;
      float edge = 1.0f - q;
      br = p >= edge ? 0.88f : gw4050Gauss(p - edge, 0.045f);
    }
  } else if (mode == 4U) {
    float q = u < 0.5f
      ? gw4050Smooth(u * 2.0f)
      : gw4050Smooth((1.0f - u) * 2.0f);
    float l = 0.02f + 0.48f * q;
    float r = 0.98f - 0.48f * q;
    float a = gw4050Gauss(p - l, 0.045f);
    float b = gw4050Gauss(p - r, 0.045f);
    float impact = gw4050Gauss(p - 0.5f, 0.09f) *
                   fmaxf(0.0f, 1.0f - fabsf(q - 1.0f) * 8.0f);
    br = gw4050Clamp(fmaxf(a, b) + impact * 0.75f);
  }

  if (u > 0.94f) br *= 1.0f - (u - 0.94f) / 0.06f;
  return gw4050Scale(CRGB(255, 50, 0), br);
}

static CRGB gw4142Core(
  uint8_t fx, bool intro, uint8_t introMode,
  uint8_t ch, uint16_t idx, uint16_t n, float ts
) {
  const float TD = 30.0f, SD = 2.8f;
  float t = fmodf(ts, TD); if (t < 0) t += TD;
  float id = intro ? SD : 0.0f, ed = SD;

  if (intro && t < id) return gw4142Sen(introMode, ch, idx, n, t);
  if (t >= TD - ed) return gw4142Sen(4U, ch, idx, n, t - (TD - ed));

  float wd = TD - id - ed;
  float d1 = wd / 3.0f, d2 = wd / 3.0f, d3 = wd - d1 - d2;
  float wt = t - id, u;
  uint8_t ph;
  if (wt < d1) { ph = 1; u = gw4050Clamp(wt / d1); }
  else if (wt < d1 + d2) { ph = 2; u = gw4050Clamp((wt - d1) / d2); }
  else { ph = 3; u = gw4050Clamp((wt - d1 - d2) / d3); }

  const uint8_t blockLen = 5U;
  float maxIdx = n <= 1 ? 0.0f : (float)(n - 1U);
  float snap = floorf((float)idx / blockLen) * blockLen + (blockLen - 1U) * 0.5f;
  if (snap > maxIdx) snap = maxIdx;

  float p = n <= 1 ? 0.5f : snap / maxIdx;
  float den = n == 0 ? 1.0f : (float)((uint32_t)n * 2UL - 1UL);
  float pG = ch == 0U ? snap / den : ((float)n + (maxIdx - snap)) / den;

  CRGB main = ch == 0U ? CRGB(0,229,255) : CRGB(255,25,25);
  CRGB sec  = ch == 0U ? CRGB(255,0,119) : CRGB(0,255,102);
  float br = 0.0f;
  CRGB col = main;

  if (fx == 5U) {
    if (ph == 1U) {
      float spring = 0.5f + 0.45f * expf(-u * 2.8f) * cosf(u * PI * 11.0f);
      br = gw4050Gauss(p - spring, 0.022f);
    } else if (ph == 2U) {
      float amp = 0.46f * expf(-u * 1.2f);
      float h1 = 0.5f - amp * cosf(u * PI * 8.0f);
      float h2 = 0.5f + amp * cosf(u * PI * 8.0f);
      float a = gw4050Gauss(pG - h1, 0.018f);
      float b = gw4050Gauss(pG - h2, 0.018f);
      br = a > b ? a : b;
      col = a > b ? main : sec;
    } else {
      float q = gw4050Smooth(u);
      float pos = 0.5f + 0.34f * expf(-u * 2.2f) * cosf(u * PI * 7.0f);
      br = gw4050Gauss(pG - pos, 0.020f);
      col = gw4050Mix(main, sec, q);
    }
  } else {
    if (ph == 1U) {
      const int blocks = 14;
      float head = gw4050Fract(u * 2.15f) * (blocks + 3) - 1.0f;
      int bi = (int)floorf(pG * blocks);
      float d = head - (float)bi;
      if (d >= 0.0f && d < 1.0f) br = 1.0f;
      else if (d >= 1.0f && d < 2.0f) br = 0.62f;
      else if (d >= 2.0f && d < 4.0f) br = 0.34f * (1.0f - (d - 2.0f) / 2.0f);
      else br = 0.02f;
      col = gw4050Mix(main, sec, gw4050Fract(head / blocks));
    } else if (ph == 2U) {
      float cyc = gw4050Fract(u * 1.75f);
      float aPos = gw4050Fract(cyc * 1.25f);
      float bPos = gw4050Fract(cyc * 1.25f + 0.36f);
      bool ds = (((int)floorf(u * 3.5f)) % 2) == 0;
      float hA = ds ? aPos : 1.0f - aPos;
      float hB = ds ? bPos : 1.0f - bPos;
      float aa = gw4050Gauss(pG - hA, 0.050f);
      float bb = gw4050Gauss(pG - hB, 0.050f);
      br = (aa > bb ? aa : bb) + 0.28f * fminf(1.0f, aa + bb);
      col = aa >= bb ? main : sec;
    } else {
      const int steps = 12;
      float ps = gw4050Fract(u * 5.0f);
      float head = ps * (steps + 2);
      int bi = (int)floorf(pG * steps);
      float d = head - (float)bi;
      float burst = gw4050Fract(u * 18.0f);
      bool fl = burst < 0.13f || (burst > 0.25f && burst < 0.34f);
      br = (d >= 0.0f && d < 2.2f && fl) ? (d < 1.0f ? 1.0f : 0.62f) : 0.02f;
      col = gw4050Mix(main, sec, (float)bi / (steps - 1));
    }
  }

  return gw4050Scale(col, br);
}

static CRGB gw4142Eval(
  uint8_t fx, bool intro, uint8_t introMode,
  uint8_t ch, uint16_t idx, uint16_t n, float ts
) {
  const float TD = 30.0f, SD = 2.8f;
  const uint8_t TL = 3U;
  float t = fmodf(ts, TD); if (t < 0) t += TD;
  float id = intro ? SD : 0.0f, ed = SD;

  if ((intro && t < id) || t >= TD - ed) {
    return gw4142Core(fx, intro, introMode, ch, idx, n, ts);
  }

  float wd = TD - id - ed;
  float d1 = wd / 3.0f, d2 = wd / 3.0f, d3 = wd - d1 - d2;
  float wt = t - id;
  uint8_t ph = wt < d1 ? 1U : (wt < d1 + d2 ? 2U : 3U);

  CRGB out = gw4142Core(fx, intro, introMode, ch, idx, n, ts);
  float pd = ph == 1U ? d1 : (ph == 2U ? d2 : d3);
  float step = fminf(0.085f, pd / 70.0f);

  for (uint8_t k = 1; k <= TL; k++) {
    float pt = t - step * k;
    if (pt < 0.0f) break;
    if ((intro && pt < id) || pt >= TD - ed) break;
    float pwt = pt - id;
    uint8_t pph = pwt < d1 ? 1U : (pwt < d1 + d2 ? 2U : 3U);
    if (pph != ph) break;

    CRGB smp = gw4142Core(fx, intro, introMode, ch, idx, n, ts - step * k);
    float df = powf(1.0f - (float)k / (TL + 1.0f), 1.15f) * 0.82f;
    smp.nscale8_video((uint8_t)(gw4050Clamp(df) * 255.0f));
    if (smp.r > out.r) out.r = smp.r;
    if (smp.g > out.g) out.g = smp.g;
    if (smp.b > out.b) out.b = smp.b;
  }
  return out;
}

static void gw4142Render(uint8_t which, uint32_t tMs, uint16_t count) {
  gw4050Clear12(count);
  if (tMs >= 30000UL) {
    gw4050Done = true;
    return;
  }
  float t = (float)tMs * 0.001f;
  uint8_t fx = which == 41U ? 5U : 6U;
  bool intro = which == 41U;
  uint8_t introMode = which == 41U ? 2U : 1U;

  for (uint16_t i = 0; i < count; i++) {
    leds1[i] = gw4142Eval(fx, intro, introMode, 0U, i, count, t);
    leds2[i] = gw4142Eval(fx, intro, introMode, 1U, i, count, t);
  }
}

// ---------------- W43/W44/W45 SOURCE USER ----------------
static CRGB gw4445Eval(
  uint8_t fx, uint8_t ch, uint16_t idx, uint16_t count, float tSec, bool is43
) {
  const float TOTAL_DUR = 30.0f;
  const float SEN_DUR = 2.8f;
  const float WELCOME_DUR = 27.2f;

  float t = fmodf(tSec, TOTAL_DUR); if (t < 0) t += TOTAL_DUR;
  uint32_t totalLeds = (uint32_t)count * 2UL;
  float denom = totalLeds <= 1UL ? 1.0f : (float)(totalLeds - 1UL);
  float pGlobal = ch == 0U
    ? (float)idx / denom
    : (float)((uint32_t)count + (uint32_t)(count - 1U - idx)) / denom;

  if (t < SEN_DUR) {
    float u = t / SEN_DUR;
    float head = u < 0.5f
      ? (u * 2.4f - 0.1f)
      : (1.0f - ((u - 0.5f) * 2.4f - 0.1f));
    float d = u < 0.5f ? (pGlobal - head) : (head - pGlobal);
    float br = d > 0.0f ? gw4050Gauss(d, 0.045f) : gw4050Gauss(d, 0.18f);
    if (u > 0.90f) br *= 1.0f - (u - 0.90f) / 0.10f;
    return gw4050Scale(CRGB(255,50,0), br);
  }

  float wt = t - SEN_DUR;
  float p1End = is43 ? 8.7f : 9.2f;
  float p2End = 19.2f;

  CRGB colA(255,20,20), colB(0,255,100);
  float pMeet = 0.25f;

  if (fx == 2U) {
    colA = CRGB(0,230,255);
    colB = CRGB(255,0,160);
    pMeet = 0.75f;
  } else if (fx == 3U) {
    if (is43) {
      colA = CRGB(255,20,20);
      colB = CRGB(0,255,100);
    } else {
      colA = CRGB(180,40,255);
      colB = CRGB(255,170,0);
    }
    pMeet = 0.50f;
  }

  if (wt < p1End) {
    float posA = 0.0f, posB = 0.0f, flash = 0.0f;
    int dirA = 0, dirB = 0;

    if (is43) {
      float u = fmodf((wt / p1End) * 2.5f, 1.0f);
      if (u < 0.45f) {
        float prog = u / 0.45f;
        posB = prog * pMeet;
        posA = 1.0f - prog * (1.0f - pMeet);
        dirB = 1; dirA = -1;
      } else if (u < 0.55f) {
        posB = pMeet; posA = pMeet;
        float fp = (u - 0.45f) / 0.10f;
        flash = gw4050Gauss(pGlobal - pMeet, 0.10f) * sinf(fp * PI);
      } else {
        float prog = (u - 0.55f) / 0.45f;
        posB = pMeet - prog * pMeet;
        posA = pMeet + prog * (1.0f - pMeet);
        dirB = -1; dirA = 1;
      }
    } else {
      float uCycle = fmodf((wt / p1End) * 2.0f, 1.0f);
      float meet = uCycle < 0.5f ? 0.25f : 0.75f;
      float subU = uCycle < 0.5f ? uCycle / 0.5f : (uCycle - 0.5f) / 0.5f;

      if (subU < 0.44f) {
        float prog = subU / 0.44f;
        posB = prog * meet;
        posA = 1.0f - prog * (1.0f - meet);
        dirB = 1; dirA = -1;
      } else if (subU < 0.56f) {
        posB = meet; posA = meet;
        float fp = (subU - 0.44f) / 0.12f;
        flash = gw4050Gauss(pGlobal - meet, 0.10f) * sinf(fp * PI);
      } else {
        float prog = (subU - 0.56f) / 0.44f;
        posB = meet - prog * meet;
        posA = meet + prog * (1.0f - meet);
        dirB = -1; dirA = 1;
      }
    }

    float brB = gw4050Comet(posB, dirB, pGlobal, 0.08f, 0.06f);
    float brA = gw4050Comet(posA, dirA, pGlobal, 0.08f, 0.06f);

    if (flash > 0.08f) return gw4050Scale(CRGB::White, flash);
    if (brA >= brB && brA > 0.04f) return gw4050Scale(colA, brA);
    if (brB > 0.04f) return gw4050Scale(colB, brB);
    return CRGB::Black;
  }

  if (wt < p2End) {
    float lt = (wt - p1End) / (p2End - p1End);
    float phase = fmodf(lt * 3.5f, 1.0f);
    float pos1 = gw4050Tri(phase);
    float pos2 = 1.0f - pos1;
    int dir1 = phase < 0.5f ? 1 : -1;
    float br1 = gw4050Comet(pos1, dir1, pGlobal, 0.09f, 0.06f);
    float br2 = gw4050Comet(pos2, -dir1, pGlobal, 0.09f, 0.06f);

    if (br1 >= br2 && br1 > 0.04f) return gw4050Scale(colA, br1);
    if (br2 > 0.04f) return gw4050Scale(colB, br2);
    return CRGB::Black;
  }

  float lt = (wt - p2End) / (WELCOME_DUR - p2End);
  uint8_t step = (uint8_t)(lt * 16.0f) % 4U;
  bool flash = fmodf(lt * 32.0f, 1.0f) < 0.65f;

  if (step == 0U) {
    return gw4050Scale(pGlobal < 0.5f ? colB : colA, flash ? 1.0f : 0.08f);
  }
  if (step == 1U) {
    return gw4050Scale(pGlobal < 0.5f ? colA : colB, flash ? 1.0f : 0.08f);
  }
  if (step == 2U) {
    float midDist = fabsf(pGlobal - 0.5f);
    return midDist < 0.25f
      ? gw4050Scale(CRGB::White, flash ? 1.0f : 0.08f)
      : CRGB::Black;
  }

  float breath = 0.5f + 0.5f * sinf(lt * PI * 6.0f);
  return gw4050Scale(pGlobal < 0.5f ? colB : colA, 0.4f + 0.6f * breath);
}

static void gw4345Render(uint8_t which, uint32_t tMs, uint16_t count) {
  gw4050Clear12(count);
  if (tMs >= 30000UL) {
    gw4050Done = true;
    return;
  }
  float tSec = (float)tMs * 0.001f;
  uint8_t fx = which == 43U ? 3U : (which == 44U ? 1U : 2U);
  bool is43 = which == 43U;

  for (uint16_t i = 0; i < count; i++) {
    leds1[i] = gw4445Eval(fx, 0U, i, count, tSec, is43);
    leds2[i] = gw4445Eval(fx, 1U, i, count, tSec, is43);
  }
}

// ---------------- W46 SOURCE USER, 12.8s ----------------
static CRGB gw46Eval(
  uint8_t ch, uint16_t idx, uint16_t count, float timeSec
) {
  const float SEN_DURATION = 2.8f;
  const float WELCOME_DURATION = 10.0f;
  const float TOTAL_CYCLE = 12.8f;

  const CRGB COL_SEN_AMBER(255,50,0);
  const CRGB COL_CYAN(0,230,255);
  const CRGB COL_MAGENTA(255,0,160);
  const CRGB COL_AMBER(255,75,0);
  const CRGB COL_WHITE(255,255,255);
  const CRGB COL_RED(255,25,25);
  const CRGB COL_BLUE(0,110,255);

  float t = fmodf(timeSec, TOTAL_CYCLE); if (t < 0) t += TOTAL_CYCLE;
  CRGB color = CRGB::Black;
  float brightness = 0.0f;

  if (t < SEN_DURATION) {
    uint32_t virtualTotal = (uint32_t)count * 2UL;
    float denom = virtualTotal <= 1UL ? 1.0f : (float)(virtualTotal - 1UL);
    float pLtr = ch == 0U
      ? (float)idx / denom
      : (float)((uint32_t)count + (uint32_t)(count - 1U - idx)) / denom;

    float u = t / SEN_DURATION;
    float d;
    if (u < 0.5f) {
      float sub = u / 0.5f;
      float head = sub * 1.25f - 0.12f;
      d = pLtr - head;
    } else {
      float sub = (u - 0.5f) / 0.5f;
      float head = 1.0f - (sub * 1.25f - 0.12f);
      d = head - pLtr;
    }
    brightness = d > 0.0f
      ? gw4050Gauss(d, 0.045f)
      : gw4050Gauss(d, 0.18f);

    if (u > 0.90f) brightness *= 1.0f - (u - 0.90f) / 0.10f;
    return gw4050Scale(COL_SEN_AMBER, brightness);
  }

  float welcomeT = t - SEN_DURATION;
  float p = count <= 1U ? 0.5f : (float)idx / (float)(count - 1U);
  float p1Dur = WELCOME_DURATION * 0.32f;
  float p2Dur = WELCOME_DURATION * 0.44f;
  float p1End = p1Dur, p2End = p1Dur + p2Dur;

  if (welcomeT < p1End) {
    float u = welcomeT / p1Dur;
    float headPos = fminf(1.0f, u * 1.15f);
    float dist1 = fabsf(p - headPos);
    float dist2 = fabsf((1.0f - p) - headPos);
    float br1 = fmaxf(0.0f, 1.0f - dist1 / 0.14f);
    float br2 = fmaxf(0.0f, 1.0f - dist2 / 0.14f);
    CRGB col1 = ch == 0U ? COL_CYAN : COL_MAGENTA;
    CRGB col2 = ch == 0U ? COL_MAGENTA : COL_CYAN;
    if (br1 > br2) { brightness = powf(br1, 1.4f); color = col1; }
    else { brightness = powf(br2, 1.4f); color = col2; }
  } else if (welcomeT < p2End) {
    float lt = (welcomeT - p1End) / p2Dur;
    float pp1 = gw4050Tri(fmodf(lt * 2.2f, 1.0f));
    float pp2 = 1.0f - pp1;
    float br1 = fmaxf(0.0f, 1.0f - fabsf(p - pp1) / 0.16f);
    float br2 = fmaxf(0.0f, 1.0f - fabsf(p - pp2) / 0.16f);
    CRGB col1 = ch == 0U ? COL_AMBER : COL_WHITE;
    CRGB col2 = ch == 0U ? COL_WHITE : COL_AMBER;
    if (br1 >= br2) { brightness = powf(br1, 1.3f); color = col1; }
    else { brightness = powf(br2, 1.3f); color = col2; }
  } else {
    float p3Dur = WELCOME_DURATION - p2End;
    float lt = (welcomeT - p2End) / p3Dur;
    uint8_t strobeStep = (uint8_t)(lt * 12.0f);
    bool flash = fmodf(lt * 24.0f, 1.0f) < 0.65f;
    uint8_t step = strobeStep % 4U;

    if (step == 0U && p < 0.35f) {
      brightness = flash ? 1.0f : 0.08f;
      color = ch == 0U ? COL_RED : COL_BLUE;
    } else if (step == 1U && p > 0.65f) {
      brightness = flash ? 1.0f : 0.08f;
      color = ch == 0U ? COL_BLUE : COL_RED;
    } else if (step == 2U && p >= 0.25f && p <= 0.75f) {
      brightness = flash ? 1.0f : 0.08f;
      color = COL_WHITE;
    } else if (step == 3U) {
      float breath = 0.5f + 0.5f * sinf(lt * PI * 4.0f);
      brightness = 0.35f + 0.65f * breath;
      color = ch == 0U ? COL_RED : COL_BLUE;
    }
  }

  return gw4050Scale(color, brightness);
}

static void gw46Render(uint32_t tMs, uint16_t count) {
  gw4050Clear12(count);
  if (tMs >= 12800UL) {
    gw4050Done = true;
    return;
  }
  float t = (float)tMs * 0.001f;
  for (uint16_t i = 0; i < count; i++) {
    leds1[i] = gw46Eval(0U, i, count, t);
    leds2[i] = gw46Eval(1U, i, count, t);
  }
}

// ---------------- W47 SOURCE STATE ----------------
struct GW47State {
  bool initialized = false;
  uint8_t phase = 0;       // 0 ping, 1 strobe, 2 sequential
  uint8_t channel = 1;     // 1 CH1, 2 CH2
  int16_t start = 0;
  int8_t dir = 1;
  uint8_t localTravel = 0;
  uint8_t localLimit = 8;
  uint8_t bounceCount = 0;
  uint8_t jumpCount = 1;
  uint8_t strobeFlashCount = 0;
  bool strobeOn = true;
  uint8_t colorIndex = 0;
  uint32_t phaseStart = 0;
  uint32_t lastStep = 0;
};
static GW47State gw47;

static const CRGB GW47_PALETTE[8] = {
  CRGB(0,255,255), CRGB(255,0,180), CRGB(0,120,255), CRGB(0,255,90),
  CRGB(255,90,0), CRGB(170,0,255), CRGB(255,20,20), CRGB(255,255,255)
};
static void gw47NewColor() {
  uint8_t old = gw47.colorIndex, next = old;
  for (uint8_t tries = 0; tries < 20U && next == old; tries++) next = random8(8);
  if (next == old) next = (old + 1U) % 8U;
  gw47.colorIndex = next;
}
static void gw47Reset(uint16_t count) {
  gw47 = GW47State();
  gw47.initialized = true;
  uint16_t block = count < 10U ? count : 10U;
  int maxStart = max(0, (int)count - (int)block);
  gw47.start = maxStart > 0 ? (int16_t)(((long)maxStart * 28L) / 60L) : 0;
}
static void gw47Set(CRGB *arr, uint16_t count, int idx, CRGB base, uint8_t level) {
  if (idx < 0 || idx >= (int)count) return;
  base.nscale8_video(level);
  arr[idx] = base;
}
static void gw47DrawPing(uint16_t count) {
  gw4050Clear12(count);
  CRGB *arr = gw47.channel == 1U ? leds1 : leds2;
  CRGB color = GW47_PALETTE[gw47.colorIndex];
  uint16_t block = count < 10U ? count : 10U;
  uint16_t tailLen = count < 5U ? count : 5U;
  static const uint8_t bodyR[10] = {148,163,179,196,214,230,242,250,255,255};
  static const uint8_t bodyL[10] = {255,255,250,242,230,214,196,179,163,148};
  static const uint8_t tail[5] = {117,82,56,33,18};

  if (gw47.dir > 0) {
    for (uint16_t i = 0; i < block; i++) gw47Set(arr,count,gw47.start+i,color,bodyR[i]);
    for (uint16_t i = 0; i < tailLen; i++) gw47Set(arr,count,gw47.start-1-(int)i,color,tail[i]);
  } else {
    for (uint16_t i = 0; i < block; i++) gw47Set(arr,count,gw47.start+i,color,bodyL[i]);
    for (uint16_t i = 0; i < tailLen; i++) gw47Set(arr,count,gw47.start+block+i,color,tail[i]);
  }
}
static void gw47PickAnchor(uint16_t count) {
  uint16_t block = count < 10U ? count : 10U;
  int maxStart = max(0, (int)count - (int)block);
  uint8_t newChannel = random8(100) < 65U ? (gw47.channel == 1U ? 2U : 1U) : gw47.channel;
  int newStart = gw47.start;
  uint8_t tries = 0;
  do {
    newStart = maxStart > 0 ? (int)random16((uint16_t)(maxStart + 1)) : 0;
    tries++;
  } while (
    newChannel == gw47.channel &&
    abs(newStart - (int)gw47.start) < min(18, maxStart) &&
    tries < 50U
  );

  gw47.channel = newChannel;
  gw47.start = (int16_t)newStart;
  gw47.dir = random8(2) == 0 ? 1 : -1;
  if (gw47.start < 6) gw47.dir = 1;
  if (gw47.start > maxStart - 6) gw47.dir = -1;
  if (maxStart <= 0) gw47.dir = 1;
  gw47.localTravel = 0;
  gw47.bounceCount = 0;
  gw47.localLimit = 5U + random8(8);
  gw47.jumpCount++;
  gw47NewColor();

  if (gw47.jumpCount > 14U) {
    gw47.phase = 1U;
    gw47.strobeFlashCount = 0;
    gw47.strobeOn = true;
  }
}
static void gw47StepPing(uint16_t count) {
  uint16_t block = count < 10U ? count : 10U;
  int maxStart = max(0, (int)count - (int)block);
  gw47.start += gw47.dir;
  gw47.localTravel++;

  if (gw47.start <= 0) {
    gw47.start = 0; gw47.dir = 1; gw47.bounceCount++;
  } else if (gw47.start >= maxStart) {
    gw47.start = maxStart; gw47.dir = -1; gw47.bounceCount++;
  }

  if (gw47.localTravel >= gw47.localLimit) {
    gw47.dir *= -1;
    gw47.localTravel = 0;
    gw47.bounceCount++;
    gw47.localLimit = 4U + random8(6);
  }

  if (gw47.bounceCount >= 2U) gw47PickAnchor(count);
}
static void gw47DrawStrobe(uint16_t count) {
  gw4050Clear12(count);
  uint8_t mode = random8(3);
  gw47NewColor();
  CRGB color = GW47_PALETTE[gw47.colorIndex];

  uint8_t firstCh = mode == 1U ? 2U : 1U;
  uint8_t lastCh  = mode == 0U ? 1U : 2U;
  for (uint8_t ch = firstCh; ch <= lastCh; ch++) {
    CRGB *arr = ch == 1U ? leds1 : leds2;
    uint8_t blockCount = 1U + random8(3);
    for (uint8_t b = 0; b < blockCount; b++) {
      uint16_t len = 4U + random8(8);
      if (len > count) len = count;
      if (len == 0) continue;
      uint16_t maxS = count - len;
      uint16_t s = maxS > 0 ? random16((uint16_t)(maxS + 1U)) : 0U;
      for (uint16_t i = 0; i < len; i++) {
        gw47Set(arr, count, (int)s + (int)i, color, (uint8_t)(184U + random8(72)));
      }
    }
  }
}
static void gw47Render(uint32_t tMs, uint16_t count) {
  if (!gw47.initialized) gw47Reset(count);

  // Source HTML step = 35ms. GLOBAL speed bekerja melalui tMs virtual.
  while (gw47.phase < 2U && (uint32_t)(tMs - gw47.lastStep) >= 35UL) {
    gw47.lastStep += 35UL;
    if (gw47.phase == 0U) {
      gw47StepPing(count);
    } else {
      if (gw47.strobeFlashCount >= 5U && gw47.strobeOn) {
        gw47.phase = 2U;
        gw47.phaseStart = gw47.lastStep;
        break;
      }
      if (gw47.strobeOn) {
        gw47DrawStrobe(count);
        gw47.strobeFlashCount++;
      } else {
        gw4050Clear12(count);
      }
      gw47.strobeOn = !gw47.strobeOn;
    }
  }

  if (gw47.phase == 0U) {
    gw47DrawPing(count);
    return;
  }
  if (gw47.phase == 1U) {
    if (!gw47.strobeOn) gw4050Clear12(count);
    return;
  }

  gw4050Clear12(count);
  uint32_t elapsed = tMs - gw47.phaseStart;
  if (elapsed >= 3000UL) {
    gw4050Done = true;
    return;
  }

  const uint32_t passMs = 1500UL;
  uint32_t localMs = elapsed % passMs;
  uint16_t lit = (uint16_t)(((uint64_t)localMs * (uint64_t)count) / passMs);
  if (lit >= count && count > 0U) lit = count - 1U;
  CRGB amber(255,50,0);

  for (uint16_t i = 0; i <= lit && i < count; i++) {
    uint8_t level = (i >= (lit >= 3U ? lit - 3U : 0U)) ? 255U : 184U;
    gw47Set(leds1, count, i, amber, level);
    gw47Set(leds2, count, i, amber, level);
  }
}

// ---------------- W48/W49 SOURCE ONE-SHOT ----------------
struct GW4849State {
  bool initialized = false;
  int16_t pos = 0;
  int16_t target = 0;
  int8_t mainDir = 1;
  bool advance = true;
  uint8_t hue = 0;
  bool ending = false;
  bool done = false;
  uint32_t endingAt = 0;
  uint32_t lastStep = 0;
};
static GW4849State gw4849;

static CRGB gw48Color(uint8_t idx) {
  static const CRGB pal[9] = {
    CRGB(255,0,0), CRGB(255,70,0), CRGB(255,200,0),
    CRGB(0,255,0), CRGB(0,180,255), CRGB(0,70,255),
    CRGB(170,0,255), CRGB(255,0,140), CRGB(255,255,255)
  };
  return pal[idx % 9U];
}
static void gw4849SetVirtual(
  uint16_t count, int virtualIndex, CRGB base, uint8_t level
) {
  int total = (int)count * 2;
  if (virtualIndex < 0 || virtualIndex >= total) return;
  base.nscale8_video(level);

  if (virtualIndex < (int)count) {
    leds1[virtualIndex] = base;
  } else {
    int i = virtualIndex - (int)count;
    i = ((int)count - 1) - i; // CH2_REVERSED source
    if (i >= 0 && i < (int)count) leds2[i] = base;
  }
}
static void gw4849Draw(uint8_t which, uint16_t count) {
  gw4050Clear12(count);
  int total = (int)count * 2;
  int blockLen = total < 5 ? total : 5;
  int instantDir = gw4849.advance ? gw4849.mainDir : -gw4849.mainDir;

  static const uint8_t bodyRight[5] = {210,225,240,250,255};
  static const uint8_t bodyLeft[5]  = {255,250,240,225,210};
  static const uint8_t tailLevel[5] = {160,118,82,50,28};

  CRGB base = which == 48U ? gw48Color(gw4849.hue) : CRGB::White;
  int startPos = gw4849.pos;

  if (instantDir > 0) {
    for (int i = 0; i < blockLen; i++) gw4849SetVirtual(count,startPos+i,base,bodyRight[i]);
    for (int i = 0; i < 5; i++) gw4849SetVirtual(count,startPos-1-i,base,tailLevel[i]);
  } else {
    for (int i = 0; i < blockLen; i++) gw4849SetVirtual(count,startPos+i,base,bodyLeft[i]);
    for (int i = 0; i < 5; i++) gw4849SetVirtual(count,startPos+blockLen+i,base,tailLevel[i]);
  }
}
static void gw4849Reset(uint8_t which, uint16_t count) {
  gw4849 = GW4849State();
  gw4849.initialized = true;
  gw4849.pos = 0;
  gw4849.mainDir = 1;
  gw4849.advance = true;
  gw4849.hue = which == 48U ? random8(9) : 0U;
  int maxStart = max(0, (int)count * 2 - 5);
  gw4849.target = min(10, maxStart);
}
static void gw4849NextColor(uint8_t which) {
  if (which == 48U) gw4849.hue++;
}
static void gw4849Step(uint8_t which, uint16_t count, uint32_t stepNow) {
  int total = (int)count * 2;
  int blockLen = total < 5 ? total : 5;
  int minStart = 0;
  int maxStart = max(0, total - blockLen);
  const int advanceLen = 10, recoilLen = 5;

  int startPos = gw4849.pos;
  int targetPos = gw4849.target;
  int mainDir = gw4849.mainDir;

  if (gw4849.advance) {
    if (mainDir > 0) {
      if (startPos < targetPos) startPos++;
      else if (startPos >= maxStart) {
        gw4849.mainDir = -1;
        targetPos = max(minStart, startPos - advanceLen);
        gw4849.advance = true;
        gw4849NextColor(which);
      } else {
        gw4849.advance = false;
        targetPos = max(minStart, startPos - recoilLen);
        gw4849NextColor(which);
      }
    } else {
      if (startPos > targetPos) startPos--;
      else if (startPos <= minStart) {
        gw4849.ending = true;
        gw4849.endingAt = stepNow;
      } else {
        gw4849.advance = false;
        targetPos = min(maxStart, startPos + recoilLen);
        gw4849NextColor(which);
      }
    }
  } else {
    if (mainDir > 0) {
      if (startPos > targetPos) startPos--;
      else {
        gw4849.advance = true;
        targetPos = min(maxStart, startPos + advanceLen);
        gw4849NextColor(which);
      }
    } else {
      if (startPos < targetPos) startPos++;
      else {
        gw4849.advance = true;
        targetPos = max(minStart, startPos - advanceLen);
        gw4849NextColor(which);
      }
    }
  }

  gw4849.pos = (int16_t)startPos;
  gw4849.target = (int16_t)targetPos;
}
static void gw4849Render(uint8_t which, uint32_t tMs, uint16_t count) {
  if (!gw4849.initialized) gw4849Reset(which, count);

  if (gw4849.done) {
    gw4050Clear12(count);
    gw4050Done = true;
    return;
  }

  if (gw4849.ending) {
    gw4050Clear12(count);
    if ((uint32_t)(tMs - gw4849.endingAt) >= 1000UL) {
      gw4849.done = true;
      gw4050Done = true;
    }
    return;
  }

  // Source standalone = 20ms/step. GLOBAL speed melalui tMs virtual.
  while (!gw4849.ending && (uint32_t)(tMs - gw4849.lastStep) >= 20UL) {
    gw4849.lastStep += 20UL;
    gw4849Step(which, count, gw4849.lastStep);
  }
  gw4849Draw(which, count);
}

// ---------------- W50 CYBER NEON — SOURCE USER ----------------
// Source standalone:
// currentMode=3 (Cyber Neon), currentPhase=2, AUTO_NEXT_TICK=160,
// frameDelay=15ms, virtual path per sisi CH1->CH3 dan CH2->CH4.
// Integrasi GLOBAL:
// - tanpa setup()/loop()/delay()/FastLED.show()/setBrightness()
// - speed mengikuti welcomeAnimClockVirtual / liveSpeedFactor
// - brightness tetap GLOBAL
// - 1 putaran penuh 8 fase, mulai fase 2 sesuai source, lalu Welcome selesai.
struct GW50State {
  bool initialized = false;
  bool finished = false;
  uint8_t currentPhase = 2U;
  int16_t pos = 0;
  int8_t dir = 1;
  uint32_t globalStep = 0;
  uint16_t phaseTick = 0;
  uint8_t phaseTransitions = 0;
  uint32_t nextFrame = 0;
};
static GW50State gw50;

static inline CRGB* gw50LeftPtr(uint16_t idx, uint16_t count) {
  return (idx < count) ? &leds1[idx] : &leds3[idx - count];
}
static inline CRGB* gw50RightPtr(uint16_t idx, uint16_t count) {
  return (idx < count) ? &leds2[idx] : &leds4[idx - count];
}
static inline void gw50Clear4(uint16_t count) {
  fill_solid(leds1, count, CRGB::Black);
  fill_solid(leds2, count, CRGB::Black);
  fill_solid(leds3, count, CRGB::Black);
  fill_solid(leds4, count, CRGB::Black);
}

// currentMode source = 3, jadi hanya formula aktif Cyber Neon yang dibawa.
// Source hslToRgbFast(h,255,128) sebenarnya memakai CHSV(h,255,128).
static inline CRGB gw50CyberColor(uint16_t i, uint16_t total, uint32_t step) {
  if (total == 0U) return CRGB::Black;
  uint32_t timeShift = step * 3UL;
  uint8_t wave = sin8((uint8_t)(step * 2UL + (uint32_t)i * 2UL));
  uint16_t hue = (uint16_t)((180UL + (uint32_t)(wave / 3U) + timeShift) & 0xFFUL);
  return CHSV((uint8_t)hue, 255, 128);
}

static void gw50ProcessOneFrame(uint16_t count) {
  const uint16_t total = (uint16_t)(count * 2U);
  if (total == 0U || gw50.finished) {
    gw50Clear4(count);
    return;
  }

  // Source loop: phaseTick++ dilakukan SEBELUM render frame.
  gw50.phaseTick++;
  if (gw50.phaseTick > 160U) {
    gw50.currentPhase = (uint8_t)((gw50.currentPhase % 8U) + 1U);
    gw50.pos = 0;
    gw50.dir = 1;
    gw50.globalStep = 0;
    gw50.phaseTick = 0;
    gw50.phaseTransitions++;

    // Mulai dari fase 2. Setelah 8 transisi, fase 2 akan mengulang.
    // Welcome dihentikan tepat sebelum frame pengulangan tersebut.
    if (gw50.phaseTransitions >= 8U) {
      gw50.finished = true;
      gw50Clear4(count);
      return;
    }
  }

  gw50Clear4(count);

  switch (gw50.currentPhase) {
    case 1U: {
      const int size = 40;
      for (int j = 0; j < size; j++) {
        int idx = ((int)gw50.pos - j + (int)total) % (int)total;
        fract8 fade = (fract8)(255 - (j * 255 / size));
        CRGB cL = gw50CyberColor((uint16_t)idx, total, gw50.globalStep);
        CRGB cR = gw50CyberColor((uint16_t)idx, total, gw50.globalStep + 15UL);
        cL.nscale8(fade); cR.nscale8(fade);
        *gw50LeftPtr((uint16_t)idx, count) = cL;
        *gw50RightPtr((uint16_t)idx, count) = cR;
      }
      gw50.pos = (int16_t)(((int)gw50.pos + 1) % (int)total);
      break;
    }

    case 2U: {
      const int trail = 50;
      for (int k = 0; k < 2; k++) {
        int headPos = ((int)gw50.pos + k * ((int)total / 2)) % (int)total;
        for (int j = 0; j < trail; j++) {
          int idx = (headPos - j + (int)total) % (int)total;
          fract8 dim = (fract8)(255 - (j * 255 / trail));
          CRGB cL = gw50CyberColor((uint16_t)idx, total, gw50.globalStep);
          CRGB cR = gw50CyberColor((uint16_t)idx, total, gw50.globalStep + 15UL);
          cL.nscale8(dim); cR.nscale8(dim);
          *gw50LeftPtr((uint16_t)idx, count) |= cL;
          *gw50RightPtr((uint16_t)idx, count) |= cR;
        }
      }
      gw50.pos = (int16_t)(((int)gw50.pos + 1) % (int)total);
      break;
    }

    case 3U: {
      const int width = 35;
      for (int j = 0; j < width; j++) {
        int idx = ((int)gw50.pos + (gw50.dir == 1 ? -j : j) + (int)total) % (int)total;
        fract8 fade = sin8((uint8_t)((j * 255) / width));
        CRGB cL = gw50CyberColor((uint16_t)idx, total, gw50.globalStep);
        CRGB cR = gw50CyberColor((uint16_t)idx, total, gw50.globalStep + 15UL);
        cL.nscale8(fade); cR.nscale8(fade);
        *gw50LeftPtr((uint16_t)idx, count) = cL;
        *gw50RightPtr((uint16_t)idx, count) = cR;
      }
      gw50.pos = (int16_t)((int)gw50.pos + (int)gw50.dir * 2);
      if (gw50.pos >= (int16_t)total) { gw50.pos = (int16_t)(total - 1U); gw50.dir = -1; }
      else if (gw50.pos < 0) { gw50.pos = 0; gw50.dir = 1; }
      break;
    }

    case 4U: {
      const int sweepLen = 50;
      int head = (int)gw50.pos % ((int)total + sweepLen);
      for (int j = 0; j < sweepLen; j++) {
        int idx = head - j;
        if (idx >= 0 && idx < (int)total) {
          fract8 fade = sin8((uint8_t)((j * 255) / sweepLen));
          CRGB cL = gw50CyberColor((uint16_t)idx, total, gw50.globalStep);
          CRGB cR = gw50CyberColor((uint16_t)idx, total, gw50.globalStep + 15UL);
          cL.nscale8(fade); cR.nscale8(fade);
          *gw50LeftPtr((uint16_t)idx, count) = cL;
          *gw50RightPtr((uint16_t)idx, count) = cR;
        }
      }
      gw50.pos++;
      if (gw50.pos > (int16_t)((int)total + sweepLen)) gw50.pos = 0;
      break;
    }

    case 5U: {
      for (uint16_t i = 0; i < total; i++) {
        uint8_t wave = (uint8_t)((sin8((uint8_t)(gw50.globalStep * 6UL + (uint32_t)i * 4UL)) + 1U) / 2U);
        CRGB cL = gw50CyberColor(i, total, gw50.globalStep);
        CRGB cR = gw50CyberColor(i, total, gw50.globalStep + 15UL);
        cL.nscale8(wave); cR.nscale8(wave);
        *gw50LeftPtr(i, count) = cL;
        *gw50RightPtr(i, count) = cR;
      }
      gw50.pos++;
      break;
    }

    case 6U: {
      int center = (int)total / 2;
      int span = (int)gw50.pos % ((int)total / 2);
      int idx1 = (center + span + (int)total) % (int)total;
      int idx2 = (center - span + (int)total) % (int)total;
      for (int j = 0; j < 20; j++) {
        fract8 fade = (fract8)(255 - (j * 255 / 20));
        int i1 = (idx1 - j + (int)total) % (int)total;
        int i2 = (idx2 + j + (int)total) % (int)total;
        CRGB cL1 = gw50CyberColor((uint16_t)i1, total, gw50.globalStep);
        CRGB cL2 = gw50CyberColor((uint16_t)i2, total, gw50.globalStep);
        cL1.nscale8(fade); cL2.nscale8(fade);
        *gw50LeftPtr((uint16_t)i1, count) = cL1;
        *gw50LeftPtr((uint16_t)i2, count) = cL2;
        *gw50RightPtr((uint16_t)i1, count) = cL1;
        *gw50RightPtr((uint16_t)i2, count) = cL2;
      }
      gw50.pos++;
      if (gw50.pos > (int16_t)(total / 2U)) gw50.pos = 0;
      break;
    }

    case 7U: {
      int p1 = (int)gw50.pos % (int)total;
      int p2 = ((int)gw50.pos * 2) % (int)total;
      for (int j = 0; j < 25; j++) {
        fract8 fade = sin8((uint8_t)((j * 255) / 25));
        int i1 = (p1 - j + (int)total) % (int)total;
        int i2 = (p2 - j + (int)total) % (int)total;
        CRGB cL1 = gw50CyberColor((uint16_t)i1, total, gw50.globalStep);
        CRGB cL2 = gw50CyberColor((uint16_t)i2, total, gw50.globalStep + 30UL);
        cL1.nscale8(fade); cL2.nscale8(fade);
        *gw50LeftPtr((uint16_t)i1, count) = cL1;
        *gw50RightPtr((uint16_t)i2, count) = cL2;
      }
      gw50.pos++;
      break;
    }

    case 8U: {
      uint8_t breath = (uint8_t)((sin8((uint8_t)(gw50.globalStep * 4UL)) + 1U) / 2U);
      uint8_t scale = (uint8_t)(scale8(breath, 210U) + 45U);
      for (uint16_t i = 0; i < total; i++) {
        CRGB cL = gw50CyberColor(i, total, gw50.globalStep);
        CRGB cR = gw50CyberColor(i, total, gw50.globalStep + 15UL);
        cL.nscale8(scale); cR.nscale8(scale);
        *gw50LeftPtr(i, count) = cL;
        *gw50RightPtr(i, count) = cR;
      }
      break;
    }

    default:
      break;
  }

  gw50.globalStep++;
}

static void gw50Render(uint32_t tMs, uint16_t count) {
  if (!gw50.initialized) {
    gw50 = GW50State();
    gw50.initialized = true;
  }

  if (gw50.finished) {
    gw50Clear4(count);
    gw4050Done = true;
    return;
  }

  // Source frameDelay = 15 ms. Clock virtual sudah dikali GLOBAL speed.
  const uint32_t targetFrame = tMs / 15UL;
  while (!gw50.finished && gw50.nextFrame <= targetFrame) {
    gw50ProcessOneFrame(count);
    gw50.nextFrame++;
  }

  if (gw50.finished) gw4050Done = true;
}

static void gw4050ResetRuntime() {
  gw4050Done = false;
  gw47 = GW47State();
  gw4849 = GW4849State();
  gw50 = GW50State();
}

static bool gw4050DirectSourceActive() {
  if (selectedWelcome < 40U || selectedWelcome > 50U) return false;

  // W50 adalah source Cyber Neon baru. Selalu render source W50 sendiri,
  // jangan sampai mapping lama/NVS/K1 mengalihkan W50 ke Mode 210.
  if (selectedWelcome == 50U) return true;

  uint8_t m = mappedWelcome[selectedWelcome];
  return !(m >= 1U && m <= 210U);
}

static void gw4050RenderSelected(uint8_t welcomeNo, uint32_t tMs, uint16_t count) {
  gw4050Done = false;

  switch (welcomeNo) {
    case 40U: gw40Render(tMs, count); break;
    case 41U:
    case 42U: gw4142Render(welcomeNo, tMs, count); break;
    case 43U:
    case 44U:
    case 45U: gw4345Render(welcomeNo, tMs, count); break;
    case 46U: gw46Render(tMs, count); break;
    case 47U: gw47Render(tMs, count); break;
    case 48U:
    case 49U: gw4849Render(welcomeNo, tMs, count); break;
    case 50U: gw50Render(tMs, count); break;
    default: return;
  }

  // W40-49: mapping GLOBAL lurus lama.
  // W50: source memakai jalur virtual CH1->CH3 dan CH2->CH4,
  // jadi CH3/CH4 sudah dirender langsung dan TIDAK boleh dicopy dari CH1/CH2.
  if (welcomeNo != 50U) {
    memcpy(leds3, leds1, sizeof(CRGB) * count);
    memcpy(leds4, leds2, sizeof(CRGB) * count);
  }
}



// ============================================================================
// WELCOME 30-39 — SOURCE ORIGINAL RECOVERY
//
// Urutan aktual source firmware:
// W30 = generated source 06 (FX26..30)
// W31 = generated source 01 (FX01..05)
// W32 = generated source 02 (FX06..10)
// W33 = generated source 03 (FX11..15)
// W34 = generated source 04 (FX16..20)
// W35 = generated source 05 (FX21..25)
// W36 = source custom 170 posisi, 5x flash
// W37 = source custom 42 posisi, 5x flash
// W38 = source 2026-08-31 exact formulas
// W39 = source 2026-08-31 exact formulas
//
// HANYA integrasi timing yang mengikuti permintaan terbaru:
// semua memakai welcomeAnimClockVirtual => SPEED GLOBAL.
// Rumus gerak, fase, warna, urutan, blok, tail, repeat source tidak diubah.
// Output 4CH tetap mapping lurus: CH1=CH3, CH2=CH4.
// ============================================================================

static bool gw3039Done = false;

static inline float gw3039c(float x) {
  return x < 0.0f ? 0.0f : (x > 1.0f ? 1.0f : x);
}
static inline float gw3039f(float x) {
  return x - floorf(x);
}
static inline float gw3039gauss(float x, float c, float w) {
  if (w < 0.000001f) w = 0.000001f;
  float d = (x - c) / w;
  return expf(-0.5f * d * d);
}
static CRGB gw3039hsv(float h, float sat = 1.0f, float val = 1.0f) {
  h = gw3039f(h);
  if (h < 0.0f) h += 1.0f;
  float hf = h * 6.0f;
  int ii = (int)floorf(hf);
  float ff = hf - ii;
  float p = val * (1.0f - sat);
  float q = val * (1.0f - ff * sat);
  float tt = val * (1.0f - (1.0f - ff) * sat);
  float r, g, b;
  switch (ii % 6) {
    case 0: r = val; g = tt;  b = p;   break;
    case 1: r = q;   g = val; b = p;   break;
    case 2: r = p;   g = val; b = tt;  break;
    case 3: r = p;   g = q;   b = val; break;
    case 4: r = tt;  g = p;   b = val; break;
    default:r = val; g = p;   b = q;   break;
  }
  return CRGB(
    (uint8_t)constrain(r * 255.0f, 0.0f, 255.0f),
    (uint8_t)constrain(g * 255.0f, 0.0f, 255.0f),
    (uint8_t)constrain(b * 255.0f, 0.0f, 255.0f)
  );
}
static CRGB gw3039scale(CRGB c, float br) {
  br = gw3039c(br);
  return CRGB(
    (uint8_t)(c.r * br),
    (uint8_t)(c.g * br),
    (uint8_t)(c.b * br)
  );
}

static float gw3135Fract(float x) { return x - floorf(x); }
static float gw3135Tri(float x) {
  x = gw3039f(x);
  return x < .5f ? x * 2.0f : (1.0f - x) * 2.0f;
}
static float gw3135Gauss(float x, float c, float w) {
  float d = x - c;
  return expf(-(d * d) / (2.0f * w * w));
}
static float gw3135Band(float g, float pos, float half, float fade = 4.0f) {
  float d = fabsf(g - pos);
  return d <= half ? 1.0f : (d < half + fade ? 1.0f - (d - half) / fade : 0.0f);
}
static float gw3135TailDir(float g, float pos, float dir, float head, float tail, float amp = .72f) {
  float dd = dir >= 0 ? pos - g : g - pos;
  return gw3135Gauss(g, pos, head) + ((dd >= 0 && dd < tail) ? amp * (1.0f - dd / tail) : 0.0f);
}
static float gw3135Ease(float t) { return t * t * (3.0f - 2.0f * t); }
static float gw3135Clamp(float x) { return x < 0 ? 0 : (x > 1 ? 1 : x); }

static CRGB gw3135HSV(float h) {
  h = fmodf(h, 360.0f);
  if (h < 0) h += 360.0f;
  float x = 1.0f - fabsf(fmodf(h / 60.0f, 2.0f) - 1.0f);
  float r = 0, g = 0, b = 0;
  if (h < 60)       { r = 1; g = x; }
  else if (h < 120) { r = x; g = 1; }
  else if (h < 180) { g = 1; b = x; }
  else if (h < 240) { g = x; b = 1; }
  else if (h < 300) { r = x; b = 1; }
  else              { r = 1; b = x; }
  return CRGB((uint8_t)(r * 255.0f), (uint8_t)(g * 255.0f), (uint8_t)(b * 255.0f));
}

static CRGB gw3135Rainbow(float sourceG, float phaseP) {
  return gw3135HSV(sourceG * 10.0f + phaseP * 360.0f);
}static float gw3135FxValue(uint8_t id, float q, uint8_t rep, float g) {
  uint8_t rp=rep%3;
  float b=0,pos=0,p2=0,p3=0,p4=0,z=0,front=0,dd=0,u=0,dir=1,w=0,base=0;
  int block=0,head=0;
  switch(id){
    case 0:{ // MARTIL KIRI -> KANAN, blok 10 LED didorong +5 LED per hantaman
      float T=(rep+q)/3.0f,firstEnd=.22f,holdEnd=.28f,target0=94.0f,target=target0;
      if(T<firstEnd){float t=gw3135Ease(T/firstEnd);pos=5+(target0-5)*t;b=gw3135Band(g,pos,4.5f,1.2f);}
      else if(T<holdEnd){b=gw3135Band(g,target0,4.5f,1.2f);}
      else{
        z=(T-holdEnd)/(1-holdEnd);int hits=8;float cyc=fminf(hits-.0001f,z*hits);int h=(int)cyc;float f=cyc-h;target=target0+h*5.0f;
        if(f<.70f){float t=gw3135Ease(f/.70f),hammer=5+((target-10)-5)*t;b=fmaxf(gw3135Band(g,target,4.5f,1.2f),gw3135Band(g,hammer,4.5f,1.2f));}
        else if(f<.86f){float t=gw3135Ease((f-.70f)/.16f),pushed=fminf(134.0f,target+5*t),hammer=(target-10)+4*t;b=fmaxf(fmaxf(gw3135Band(g,pushed,4.5f,1.2f),gw3135Band(g,hammer,4.5f,1.2f)),gw3135Band(g,target-5,2.2f,1.5f)*(.35f+.65f*sinf(t*PI)));}
        else{target=fminf(134.0f,target+5);b=gw3135Band(g,target,4.5f,1.2f);}
      }
      break;}
    case 1:{pos=gw3135Tri(q)*139;b=gw3135Band(g,pos,6+rp*2,4);break;}
    case 2:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;p2=pos-dir*24;b=fmaxf(gw3135Band(g,pos,6,3),gw3135Band(g,p2,6,3)*.7f);break;}
    case 3:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;p2=pos-dir*22;p3=pos-dir*44;b=fmaxf(gw3135TailDir(g,pos,dir,2.2f,14,.72f),fmaxf(gw3135TailDir(g,p2,dir,2.2f,12,.55f),gw3135TailDir(g,p3,dir,2.2f,10,.38f)));break;}
    case 4:{float s=q*4;int k=(int)s;float t=s-k;base=k*35;float local=t<.65f?(t/.65f)*45:45-((t-.65f)/.35f)*10;pos=fminf(139.0f,base+local);dir=t<.65f?1:-1;b=gw3135TailDir(g,pos,dir,2.5f,18,.68f);break;}

    case 5:{ // MARTIL KANAN -> KIRI, kebalikan Mode 1 Fase 1
      float T=(rep+q)/3.0f,firstEnd=.22f,holdEnd=.28f,target0=45.0f,target=target0;
      if(T<firstEnd){float t=gw3135Ease(T/firstEnd);pos=134-(134-target0)*t;b=gw3135Band(g,pos,4.5f,1.2f);}
      else if(T<holdEnd){b=gw3135Band(g,target0,4.5f,1.2f);}
      else{
        z=(T-holdEnd)/(1-holdEnd);int hits=8;float cyc=fminf(hits-.0001f,z*hits);int h=(int)cyc;float f=cyc-h;target=target0-h*5.0f;
        if(f<.70f){float t=gw3135Ease(f/.70f),hammer=134-((134-(target+10))*t);b=fmaxf(gw3135Band(g,target,4.5f,1.2f),gw3135Band(g,hammer,4.5f,1.2f));}
        else if(f<.86f){float t=gw3135Ease((f-.70f)/.16f),pushed=fmaxf(5.0f,target-5*t),hammer=(target+10)-4*t;b=fmaxf(fmaxf(gw3135Band(g,pushed,4.5f,1.2f),gw3135Band(g,hammer,4.5f,1.2f)),gw3135Band(g,target+5,2.2f,1.5f)*(.35f+.65f*sinf(t*PI)));}
        else{target=fmaxf(5.0f,target-5);b=gw3135Band(g,target,4.5f,1.2f);}
      }
      break;}
    case 6:{if(q<.4f)pos=(q/.4f)*66;else if(q<.56f)pos=66+(q-.4f)/.16f*7;else pos=73+((q-.56f)/.44f)*66;b=gw3135Band(g,pos,6,4);break;}
    case 7:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;b=fmaxf(gw3135Band(g,pos,4,3),gw3135TailDir(g,pos,dir,2.0f,30,.48f));break;}
    case 8:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;float tl=rp==0?16:(rp==1?28:40);b=gw3135TailDir(g,pos,dir,2.8f,tl,.7f);break;}
    case 9:{if(q<.5f){front=(q/.5f)*139;b=g<=front?.62f:0;b=fmaxf(b,gw3135Band(g,front,5,4));}else{front=(1-(q-.5f)/.5f)*139;b=g<=front?.62f:0;b=fmaxf(b,gw3135Band(g,front,5,4));}break;}

    case 10:{head=(int)roundf(gw3135Tri(q)*19);block=g/7;dd=fabsf(block-head);b=dd==0?1:(dd==1?.42f:(dd==2?.16f:0));break;}
    case 11:{float s=q*7;int k=(int)s;float t=s-k;base=k*20;float local=t<.68f?(t/.68f)*28:28-((t-.68f)/.32f)*8;pos=fminf(139.0f,base+local);dir=t<.68f?1:-1;b=gw3135Band(g,pos,5,3);break;}
    case 12:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;p2=pos-dir*36;b=fmaxf(gw3135Band(g,pos,7,4),gw3135Band(g,p2,7,4)*.68f);break;}
    case 13:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;p2=pos-dir*28;p3=pos-dir*56;b=fmaxf(gw3135Band(g,pos,5,3),fmaxf(gw3135Band(g,p2,5,3)*.72f,gw3135Band(g,p3,5,3)*.48f));break;}
    case 14:{z=q<.5f?powf(q*2,1.7f):1-powf((q-.5f)*2,1.7f);pos=z*139;dir=q<.5f?1:-1;b=gw3135TailDir(g,pos,dir,2.5f,20,.65f);break;}

    case 15:{z=gw3135Ease(q);pos=z*139;b=gw3135Band(g,pos,8,5);break;}
    case 16:{if(q<.42f)pos=(q/.42f)*62;else if(q<.60f)pos=62+((q-.42f)/.18f)*15;else pos=77+((q-.60f)/.40f)*62;b=gw3135TailDir(g,pos,1,2.7f,22,.64f);break;}
    case 17:{pos=gw3135Tri(q)*139;w=5+6*(.5f+.5f*sinf(q*PI*2));b=gw3135Band(g,pos,w,5);break;}
    case 18:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;float gap=18+18*fabsf(.5f-q)*2;p2=pos-dir*gap;p3=pos-dir*gap*2;b=fmaxf(gw3135Band(g,pos,5,3),fmaxf(gw3135Band(g,p2,5,3)*.7f,gw3135Band(g,p3,5,3)*.45f));break;}
    case 19:{if(q<.68f){pos=(q/.68f)*139;b=gw3135TailDir(g,pos,1,2.6f,24,.7f);}else if(q<.84f){int k=(int)((q-.68f)/.16f*6);b=k%2==0?1:.02f;}else{pos=(1-(q-.84f)/.16f)*139;b=gw3135TailDir(g,pos,-1,2.6f,24,.7f);}break;}

    case 20:{if(q<.5f){head=min(19,(int)((q/.5f)*20));block=g/7;b=block<=head?.72f:0;if(block==head)b=1;}else{head=min(19,(int)(((q-.5f)/.5f)*20));block=g/7;b=block<20-head?.72f:0;if(block==19-head)b=1;}break;}
    case 21:{head=(int)roundf(gw3135Tri(q)*13);block=g/10;int flash=(int)(gw3135Fract(q*14)*5);dd=fabsf(block-head);b=(dd==0&&flash%2==0)?1:(dd==1?.2f:0);break;}
    case 22:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;b=fmaxf(gw3135Band(g,pos,10,5),gw3135TailDir(g,pos,dir,2.5f,24,.4f));break;}
    case 23:{float t;int seg;if(q<.33f){t=q/.33f;seg=0;}else if(q<.66f){t=(q-.33f)/.33f;seg=1;}else{t=(q-.66f)/.34f;seg=2;}float starts[3]={0,45,95},ends[3]={45,95,139};float shaped=seg==0?t*t:(seg==1?t:gw3135Ease(t));pos=starts[seg]+(ends[seg]-starts[seg])*shaped;b=gw3135TailDir(g,pos,1,2.5f,18,.66f);break;}
    case 24:{float s=q*5;int k=(int)s;float t=s-k;base=k*28;float local=t<.72f?(t/.72f)*36:36-((t-.72f)/.28f)*8;pos=fminf(139.0f,base+local);dir=t<.72f?1:-1;b=gw3135TailDir(g,pos,dir,2.4f,16,.66f);break;}

    case 25:{u=gw3135Fract(q);float t=gw3135Tri(q);z=t+sinf(t*PI*5)*(1-t)*.05f;pos=fminf(1.0f,fmaxf(0.0f,z))*139;dir=u<.5f?1:-1;b=gw3135TailDir(g,pos,dir,2.6f,22,.66f);break;}
    case 26:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;p2=pos-dir*22;p3=pos-dir*44;b=fmaxf(gw3135Band(g,pos,4,3),fmaxf(gw3135Band(g,p2,4,3)*.7f,gw3135Band(g,p3,4,3)*.46f));break;}
    case 27:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;p2=pos-dir*34;p3=pos-dir*68;b=fmaxf(gw3135Band(g,pos,11,5),fmaxf(gw3135Band(g,p2,9,4)*.62f,gw3135Band(g,p3,7,4)*.38f));break;}
    case 28:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;p2=pos-dir*32;float w1=rp==1?5:10,w2=rp==1?10:5;b=fmaxf(gw3135Band(g,pos,w1,4),gw3135Band(g,p2,w2,4)*.68f);break;}
    case 29:{front=gw3135Tri(q)*139;b=g<=front?.16f:0;b=fmaxf(b,gw3135Band(g,front,5,4));break;}

    case 30:{if(q<.5f){front=(q/.5f)*139;b=g<=front?.7f:0;b=fmaxf(b,gw3135Band(g,front,5,4));}else{front=(1-(q-.5f)/.5f)*139;b=g<=front?.7f:0;b=fmaxf(b,gw3135Band(g,front,5,4));}break;}
    case 31:{head=(int)roundf(gw3135Tri(q)*27);block=g/5;dd=fabsf(block-head);b=dd==0?1:(dd==1?.72f:(dd==2?.4f:(dd==3?.16f:0)));break;}
    case 32:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;b=fmaxf(gw3135Band(g,pos,13+rp*2,6),gw3135TailDir(g,pos,dir,3.0f,24,.28f));break;}
    case 33:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;p2=pos-dir*42;b=fmaxf(gw3135Band(g,pos,7,4),gw3135Band(g,p2,7,4)*.7f);break;}
    case 34:{pos=gw3135Tri(q)*139;w=4+12*gw3135Tri(q*2);b=gw3135Band(g,pos,w,5);break;}

    case 35:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;b=gw3135TailDir(g,pos,dir,2.6f,20,.62f);float boost=gw3135Gauss(pos,69.5f,10)*.45f;b=fmaxf(b,gw3135Gauss(g,69.5f,7)*boost);break;}
    case 36:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;p2=pos-dir*22;p3=pos-dir*44;p4=pos-dir*66;b=fmaxf(fmaxf(gw3135TailDir(g,pos,dir,2.2f,12,.72f),gw3135TailDir(g,p2,dir,2.2f,12,.56f)),fmaxf(gw3135TailDir(g,p3,dir,2.2f,12,.42f),gw3135TailDir(g,p4,dir,2.2f,12,.28f)));break;}
    case 37:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;p2=pos-dir*40;b=fmaxf(gw3135Band(g,pos,12,5),gw3135Band(g,p2,7,4)*.62f);break;}
    case 38:{head=(int)roundf(gw3135Tri(q)*19);block=g/7;dd=fabsf(block-head);b=dd==0?1:(dd==1?.58f:(dd==2?.26f:0));break;}
    case 39:{if(q<.38f)pos=(q/.38f)*62;else if(q<.62f)pos=62+((q-.38f)/.24f)*15;else pos=77+((q-.62f)/.38f)*62;b=gw3135Band(g,pos,11+rp*2,6);break;}

    case 40:{float s=q*4;int k=(int)s;float t=s-k;base=k*35;float local=t<.7f?(t/.7f)*43:43-((t-.7f)/.3f)*8;pos=fminf(139.0f,base+local);dir=t<.7f?1:-1;b=fmaxf(gw3135Band(g,pos,4,3),gw3135TailDir(g,pos,dir,2.0f,26,.48f));break;}
    case 41:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;b=gw3135TailDir(g,pos,dir,2.5f,22,.68f);if(pos>62&&pos<77)b=fmaxf(b,gw3135Band(g,pos,7,4));break;}
    case 42:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;p2=pos-dir*46;b=fmaxf(gw3135Band(g,pos,11,5),gw3135Band(g,p2,11,5)*.66f);break;}
    case 43:{if(q<.38f){pos=(q/.38f)*139;b=gw3135Band(g,pos,7,4);}else if(q<.52f){int k=(int)((q-.38f)/.14f*6);b=k%2==0?1:.02f;}else if(q<.9f){pos=(1-(q-.52f)/.38f)*139;b=gw3135Band(g,pos,7,4);}else{int k=(int)((q-.9f)/.1f*4);b=k%2==0?1:.02f;}break;}
    case 44:{head=(int)roundf(gw3135Tri(q)*19);block=g/7;dd=fabsf(block-head);b=dd==0?1:(dd==1?.66f:(dd==2?.34f:(dd==3?.14f:0)));break;}

    case 45:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;p2=pos-dir*22;p3=pos-dir*44;p4=pos-dir*66;b=fmaxf(fmaxf(gw3135Band(g,pos,5,3),gw3135Band(g,p2,5,3)*.82f),fmaxf(gw3135Band(g,p3,5,3)*.64f,gw3135Band(g,p4,5,3)*.46f));break;}
    case 46:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;float arr[6]={0,20,40,60,80,100},amp[6]={1,.86f,.72f,.58f,.44f,.3f};for(int j=0;j<6;j++)b=fmaxf(b,gw3135Band(g,pos-dir*arr[j],4,3)*amp[j]);break;}
    case 47:{u=gw3135Fract(q);pos=gw3135Tri(q)*139;dir=u<.5f?1:-1;p2=pos-dir*30;p3=pos-dir*60;b=fmaxf(gw3135Band(g,pos,4,3),fmaxf(gw3135Band(g,p2,7,4)*.70f,gw3135Band(g,p3,11,5)*.48f));break;}
    case 48:{head=(int)roundf(gw3135Tri(q)*27);block=g/5;dd=fabsf(block-head);b=dd==0?1:(dd==1?.78f:(dd==2?.58f:(dd==3?.38f:(dd==4?.20f:0))));break;}
    case 49:{if(q<.52f){front=(q/.52f)*139;b=g<=front?.62f:0;b=fmaxf(b,gw3135Band(g,front,6,4));}else if(q<.68f){int k=(int)((q-.52f)/.16f*6);b=k%2==0?1:.02f;}else{front=(1-(q-.68f)/.32f)*139;b=g<=front?.62f:0;b=fmaxf(b,gw3135Band(g,front,6,4));}break;}
  }
  return gw3135Clamp(b);
}



// ---------------- W30-W35 wrapper: source formulas + GLOBAL clock ----------------
static void gw3035Render(uint8_t welcomeNo, uint32_t elapsed, uint16_t count) {
  fill_solid(leds1, count, CRGB::Black);
  fill_solid(leds2, count, CRGB::Black);

  if (elapsed >= 30000UL) {
    gw3039Done = true;
    return;
  }

  // Source exact: 5 fase x 6000ms, 3 repetition/fase.
  uint8_t phase = (uint8_t)(elapsed / 6000UL);
  float p = (float)(elapsed % 6000UL) / 6000.0f;
  float cyc = p * 3.0f;
  uint8_t rep = (uint8_t)min(2, (int)cyc);
  float q = cyc - rep;

  uint8_t modeIndex;
  if (welcomeNo >= 31U) modeIndex = (uint8_t)(welcomeNo - 31U);
  else                  modeIndex = (uint8_t)(35U - welcomeNo);
  uint8_t fxId = (uint8_t)(modeIndex * 5U + phase);

  static const CRGB palettes[10][3] = {
    { CRGB(234,252,255), CRGB(56,216,255),  CRGB(255,53,83)  },
    { CRGB(255,178,47),  CRGB(255,255,255), CRGB(255,102,41) },
    { CRGB(32,233,255),  CRGB(138,92,255),  CRGB(255,66,207) },
    { CRGB(255,255,255), CRGB(96,207,255),  CRGB(53,108,255) },
    { CRGB(255,49,72),   CRGB(255,255,255), CRGB(255,139,55) },
    { CRGB(36,255,211),  CRGB(47,201,255),  CRGB(122,93,255) },
    { CRGB(255,47,73),   CRGB(255,117,135), CRGB(255,255,255) },
    { CRGB(255,255,255), CRGB(81,227,255),  CRGB(255,72,96)  },
    { CRGB(0,255,208),   CRGB(0,191,255),   CRGB(255,255,255) },
    { CRGB(255,255,255), CRGB(154,88,255),  CRGB(53,223,255) }
  };

  uint32_t totalVirtual = (uint32_t)count * 2U;
  float denom = totalVirtual > 1U ? (float)(totalVirtual - 1U) : 1.0f;

  for (uint32_t vg = 0; vg < totalVirtual; vg++) {
    float sourceG = ((float)vg * 139.0f) / denom;
    float bri = gw3135FxValue(fxId, q, rep, sourceG);
    if (bri <= .01f) continue;

    CRGB c;
    if (welcomeNo == 32U && phase == 0U) {
      static const CRGB w32Phase1Colors[3] = {
        CRGB(154,88,255),
        CRGB(96,207,255),
        CRGB(255,255,255)
      };
      c = w32Phase1Colors[rep % 3U];
    } else {
      c = (phase == 2U)
        ? gw3135Rainbow(sourceG, p)
        : palettes[modeIndex][rep % 3U];
    }

    c.nscale8_video((uint8_t)(255.0f * gw3039c(bri)));
    if (vg < count) leds1[vg] += c;
    else leds2[vg - count] += c;
  }
}

// ---------------- exact W38 formulas from source ----------------
static inline float gw38Clamp01(float x) {
  return x < 0.0f ? 0.0f : (x > 1.0f ? 1.0f : x);
}
static inline float gw38Fract(float x) {
  return x - floorf(x);
}
static inline float gw38Lerp(float a, float b, float t) {
  return a + (b - a) * t;
}
static inline float gw38Gauss(float x, float c, float w) {
  float d = (x - c) / w;
  return expf(-0.5f * d * d);
}
static inline float gw38Ease(float x) {
  return -(cosf(PI * x) - 1.0f) * 0.5f;
}
static inline float gw38Tri(float p) {
  return p < 0.5f ? p * 2.0f : 2.0f - p * 2.0f;
}

static CRGB gw38HSV(float h, float sat, float val) {
  h = gw3039f(h);
  if (h < 0.0f) h += 1.0f;

  float hf = h * 6.0f;
  int ii = (int)floorf(hf);
  float ff = hf - ii;

  float p = val * (1.0f - sat);
  float q = val * (1.0f - ff * sat);
  float tt = val * (1.0f - (1.0f - ff) * sat);

  float r, g, b;
  switch (ii % 6) {
    case 0: r = val; g = tt;  b = p;   break;
    case 1: r = q;   g = val; b = p;   break;
    case 2: r = p;   g = val; b = tt;  break;
    case 3: r = p;   g = q;   b = val; break;
    case 4: r = tt;  g = p;   b = val; break;
    default:r = val; g = p;   b = q;   break;
  }

  return CRGB(
    (uint8_t)constrain(r * 255.0f, 0.0f, 255.0f),
    (uint8_t)constrain(g * 255.0f, 0.0f, 255.0f),
    (uint8_t)constrain(b * 255.0f, 0.0f, 255.0f)
  );
}

static CRGB gw38Scale(CRGB c, float br) {
  br = gw3039c(br);
  return CRGB(
    (uint8_t)(c.r * br),
    (uint8_t)(c.g * br),
    (uint8_t)(c.b * br)
  );
}

static CRGB gw38Mix(CRGB a, CRGB b, float t) {
  t = gw3039c(t);
  return CRGB(
    (uint8_t)gw38Lerp(a.r, b.r, t),
    (uint8_t)gw38Lerp(a.g, b.g, t),
    (uint8_t)gw38Lerp(a.b, b.b, t)
  );
}

static uint32_t gw38Hash32(uint32_t x) {
  x = (uint32_t)((x ^ 0x9e3779b9u) * 1664525u + 1013904223u);
  x ^= x >> 16;
  return x;
}



static GW38Shape gw38Shape(
  uint8_t block,
  uint8_t tail,
  uint16_t total
) {
  float tt = max(1, (int)total);
  float bn = max(1, (int)block) / tt;
  float tn = tail / tt;

  GW38Shape sh;
  sh.head = max(1.0f / tt, bn * 0.35f);
  sh.headPing = max(1.0f / tt, bn * 0.30f);
  sh.back = max(1.0f / tt, (bn + tn) * 1.07f);
  sh.backPing = max(1.0f / tt, bn + tn);
  sh.broad = max(1.0f / tt, bn * 0.50f + tn * 0.50f);
  sh.edgeK = max(
    10.0f,
    min(80.0f, 1.2f / max(1.0f / tt, bn * 0.35f))
  );
  sh.freq = max(
    0.35f,
    min(3.5f, 11.2f / max(1.0f, (float)block + tail * 0.30f))
  );
  sh.tailMix = max(
    0.0f,
    min(
      0.35f,
      tail / max(1.0f, (float)block + tail) * 0.32f
    )
  );
  return sh;
}

static float gw38ShapedWave(float v, const GW38Shape &sh) {
  float x = gw3039c(v);
  return gw3039c(gw38Lerp(x, sqrtf(x), sh.tailMix));
}

// Exact subset source motion1() used by W38:
// M_COMET=0, M_CONVERGE=1, M_INTERFERE=9
static float gw38Motion(
  uint8_t motion,
  float p,
  float t,
  float speed,
  int dir,
  uint8_t block,
  uint8_t tail,
  uint16_t totalLeds
) {
  GW38Shape sh = gw38Shape(block, tail, totalLeds);

  // M_COMET
  if (motion == 0U) {
    float ce = gw3039f(t * speed * 0.27f) * 1.3f - 0.15f;
    if (dir < 0) ce = 1.0f - ce;
    float d = (p - ce) * dir;
    return gw3039gauss(p, ce, d > 0.0f ? sh.head : sh.back);
  }

  // M_CONVERGE
  if (motion == 1U) {
    float z = gw38Ease(gw38Tri(gw3039f(t * speed * 0.18f)));
    float w = max(sh.broad, 0.012f);

    return max(
      gw3039gauss(p, z * 0.5f, w),
      gw3039gauss(p, 1.0f - z * 0.5f, w)
    );
  }

  // M_INTERFERE
  float pp = dir > 0 ? p : 1.0f - p;

  float v =
    0.5f +
    0.25f * sinf(
      2.0f * PI * (pp * 4.0f * sh.freq - t * speed * 0.20f)
    ) +
    0.25f * sinf(
      2.0f * PI * (pp * 2.3f * sh.freq + t * speed * 0.13f)
    );

  return gw38ShapedWave(v, sh);
}

static CRGB gw38PhaseColor(
  uint8_t phaseIndex,
  uint8_t ch,
  float p,
  float t
) {
  // Source COLOR_STYLE=0 and no RAINBOW_PHASE flags,
  // so direct phase colors.
  if (ch == 0U) {
    if (phaseIndex == 0U) return CRGB(68, 47, 147);
    if (phaseIndex == 1U) return CRGB(255, 255, 255);
    return CRGB(13, 213, 217);
  }

  if (phaseIndex == 0U) return CRGB(255, 42, 42);
  if (phaseIndex == 1U) return CRGB(255, 115, 0);
  return CRGB(216, 231, 4);
}

// SEN intro mode 9, per-channel.
static CRGB gw38SenIntro(
  uint16_t idx,
  uint16_t count,
  float localSec
) {
  const float SEN_DUR = 2.4f;

  float p =
    count <= 1U
      ? 0.5f
      : (float)idx / (float)(count - 1U);

  float u = gw3039c(localSec / SEN_DUR);
  float pass = gw3039f(u * 2.0f);

  float ce = gw38Ease(gw38Tri(pass));
  bool right = pass < 0.5f;

  float d = right ? p - ce : ce - p;

  float br = gw3039gauss(
    p,
    ce,
    d > 0.0f ? 0.03f : 0.14f
  );

  if (u > 0.90f) {
    br *= 1.0f - gw38Ease((u - 0.90f) / 0.10f);
  }

  return gw3039scale(CRGB(255, 50, 0), br);
}

static float gw38StrobeBlockBrightness(
  uint16_t ledIndex,
  int targetBlock,
  uint8_t blockLen,
  uint8_t tailLen,
  uint16_t ledCount
) {
  if (targetBlock < 0) return 0.0f;

  uint16_t st = targetBlock * blockLen;
  uint16_t en = min(
    (int)ledCount - 1,
    (int)st + blockLen - 1
  );

  if (ledIndex >= st && ledIndex <= en) return 1.0f;
  if (tailLen == 0U) return 0.0f;

  uint16_t d =
    ledIndex < st
      ? st - ledIndex
      : ledIndex - en;

  return d > tailLen
    ? 0.0f
    : gw3039c(1.0f - d / (tailLen + 1.0f));
}

// STROBE_MODE=2 => internal mode=1, 70ms step.
// Rainbow on both channels.
static CRGB gw38Strobe(
  uint8_t ch,
  uint16_t idx,
  uint16_t count,
  float localSec
) {
  const uint8_t blockLen = 10U;
  const uint8_t tailLen = 4U;

  uint16_t blocks =
    max(1, (int)((count + blockLen - 1U) / blockLen));

  uint32_t step = (uint32_t)floorf(localSec / 0.07f);
  uint8_t sub = step % 6U;
  uint32_t cycle = step / 6U;

  uint16_t bA =
    gw38Hash32(30U * 149U + cycle * 23U + 7U) % blocks;
  uint16_t bB =
    gw38Hash32(30U * 163U + cycle * 31U + 13U) % blocks;

  bool flash = (sub % 2U) == 0U;
  int target =
    flash
      ? (ch == 0U ? bA : bB)
      : -1;

  float br =
    flash
      ? gw38StrobeBlockBrightness(
          idx, target, blockLen, tailLen, count
        )
      : 0.0f;

  float p =
    count <= 1U
      ? 0.5f
      : (float)idx / (float)(count - 1U);

  // Source strobeColor1:
  // hue = p*.92 + t*.32 + effect*.031 + stepArg*.13 + chOffset
  // stepArg = step + mode*7 = step + 7
  float hue =
    p * 0.92f +
    localSec * 0.32f +
    30.0f * 0.031f +
    (step + 7U) * 0.13f +
    (ch ? 0.18f : 0.0f);

  CRGB col = gw3039hsv(hue, 1.0f, 1.0f);
  return gw3039scale(col, br);
}

static CRGB gw38CorePixel(
  uint8_t ch,
  uint16_t idx,
  uint16_t count,
  float coreSec
) {
  // targetDuration = 20 sec.
  // strobeDuration1(20) = 4 sec.
  // baseTarget = 16 sec.
  // sourceTotal = 34 sec.
  const float MASTER_SPEED = 2.2f;
  const float BASE_SCALE = 16.0f / 34.0f;
  const float STROBE_DISP = 4.0f;
  const float P2_DISP = 12.0f * BASE_SCALE; // source phase index1, order2
  const float P3_DISP = 11.0f * BASE_SCALE; // source phase index2, order3
  const float P1_DISP = 11.0f * BASE_SCALE; // source phase index0, order4
  const float PHASE_X = 0.75f;

  float p =
    count <= 1U
      ? 0.5f
      : (float)idx / (float)(count - 1U);

  // ------------------------------------------------------------
  // ORDER 1: STROBE
  // ------------------------------------------------------------
  if (coreSec < STROBE_DISP) {
    return gw38Strobe(ch, idx, count, coreSec);
  }

  // ------------------------------------------------------------
  // ORDER 2: source phase index1 = M_COMET
  // ------------------------------------------------------------
  float x = coreSec - STROBE_DISP;

  if (x < P2_DISP) {
    float lt = x / BASE_SCALE;

    float br = gw38Motion(
      0U,
      p,
      lt,
      MASTER_SPEED * 1.085711f,
      1,
      8U,
      4U,
      count
    );

    CRGB col = gw38PhaseColor(1U, ch, p, lt);
    return gw3039scale(col, br);
  }

  // ------------------------------------------------------------
  // ORDER 3: source phase index2 = M_CONVERGE
  // Crossfade from previous phase for .75 source sec.
  // ------------------------------------------------------------
  x -= P2_DISP;

  if (x < P3_DISP) {
    float lt = x / BASE_SCALE;

    float br = gw38Motion(
      1U,
      p,
      lt,
      MASTER_SPEED * 0.904884f,
      -1,
      8U,
      4U,
      count
    );

    CRGB col = gw38PhaseColor(2U, ch, p, lt);

    if (lt < PHASE_X) {
      float prevT = 12.0f + lt;

      float prevBr = gw38Motion(
        0U,
        p,
        prevT,
        MASTER_SPEED * 1.085711f,
        1,
        8U,
        4U,
        count
      );

      CRGB prevCol = gw38PhaseColor(1U, ch, p, prevT);
      float m = lt / PHASE_X;

      br = gw38Lerp(prevBr, br, m);
      col = gw38Mix(prevCol, col, m);
    }

    return gw3039scale(col, br);
  }

  // ------------------------------------------------------------
  // ORDER 4: source phase index0 = M_INTERFERE
  // Crossfade from previous phase for .75 source sec.
  // ------------------------------------------------------------
  x -= P3_DISP;

  float lt = x / BASE_SCALE;

  float br = gw38Motion(
    9U,
    p,
    lt,
    MASTER_SPEED * 1.219970f,
    -1,
    8U,
    4U,
    count
  );

  CRGB col = gw38PhaseColor(0U, ch, p, lt);

  if (lt < PHASE_X) {
    float prevT = 11.0f + lt;

    float prevBr = gw38Motion(
      1U,
      p,
      prevT,
      MASTER_SPEED * 0.904884f,
      -1,
      8U,
      4U,
      count
    );

    CRGB prevCol = gw38PhaseColor(2U, ch, p, prevT);
    float m = lt / PHASE_X;

    br = gw38Lerp(prevBr, br, m);
    col = gw38Mix(prevCol, col, m);
  }

  return gw3039scale(col, br);
}



// ---------------- exact W39 formulas from source ----------------
static inline float gw39Clamp01(float x) {
  return x < 0.0f ? 0.0f : (x > 1.0f ? 1.0f : x);
}
static inline float gw39Fract(float x) {
  return x - floorf(x);
}
static inline float gw39Lerp(float a, float b, float t) {
  return a + (b - a) * t;
}
static inline float gw39Gauss(float x, float c, float w) {
  float d = (x - c) / w;
  return expf(-0.5f * d * d);
}
static inline float gw39Ease(float x) {
  return -(cosf(PI * x) - 1.0f) * 0.5f;
}
static inline float gw39Tri(float p) {
  return p < 0.5f ? p * 2.0f : 2.0f - p * 2.0f;
}

static CRGB gw39HSV(float h, float sat, float val) {
  h = gw3039f(h);
  if (h < 0.0f) h += 1.0f;

  float hf = h * 6.0f;
  int ii = (int)floorf(hf);
  float ff = hf - ii;

  float p = val * (1.0f - sat);
  float q = val * (1.0f - ff * sat);
  float tt = val * (1.0f - (1.0f - ff) * sat);

  float r, g, b;
  switch (ii % 6) {
    case 0: r = val; g = tt;  b = p;   break;
    case 1: r = q;   g = val; b = p;   break;
    case 2: r = p;   g = val; b = tt;  break;
    case 3: r = p;   g = q;   b = val; break;
    case 4: r = tt;  g = p;   b = val; break;
    default:r = val; g = p;   b = q;   break;
  }

  return CRGB(
    (uint8_t)constrain(r * 255.0f, 0.0f, 255.0f),
    (uint8_t)constrain(g * 255.0f, 0.0f, 255.0f),
    (uint8_t)constrain(b * 255.0f, 0.0f, 255.0f)
  );
}

static CRGB gw39Scale(CRGB c, float br) {
  br = gw3039c(br);
  return CRGB(
    (uint8_t)(c.r * br),
    (uint8_t)(c.g * br),
    (uint8_t)(c.b * br)
  );
}

static CRGB gw39Mix(CRGB a, CRGB b, float t) {
  t = gw3039c(t);
  return CRGB(
    (uint8_t)gw38Lerp(a.r, b.r, t),
    (uint8_t)gw38Lerp(a.g, b.g, t),
    (uint8_t)gw38Lerp(a.b, b.b, t)
  );
}

static uint32_t gw39Hash32(uint32_t x) {
  x = (uint32_t)((x ^ 0x9e3779b9u) * 1664525u + 1013904223u);
  x ^= x >> 16;
  return x;
}



static GW39Shape gw39Shape(
  uint8_t block,
  uint8_t tail,
  uint16_t total
) {
  float tt = max(1, (int)total);
  float bn = max(1, (int)block) / tt;
  float tn = tail / tt;

  GW39Shape sh;
  sh.head = max(1.0f / tt, bn * 0.35f);
  sh.headPing = max(1.0f / tt, bn * 0.30f);
  sh.back = max(1.0f / tt, (bn + tn) * 1.07f);
  sh.backPing = max(1.0f / tt, bn + tn);
  sh.broad = max(1.0f / tt, bn * 0.50f + tn * 0.50f);
  sh.edgeK = max(
    10.0f,
    min(80.0f, 1.2f / max(1.0f / tt, bn * 0.35f))
  );
  sh.freq = max(
    0.35f,
    min(3.5f, 11.2f / max(1.0f, (float)block + tail * 0.30f))
  );
  sh.tailMix = max(
    0.0f,
    min(
      0.35f,
      tail / max(1.0f, (float)block + tail) * 0.32f
    )
  );
  return sh;
}

// Exact subset of source motion1() used by W39:
// M_DOUBLE, M_COMET, M_CASCADE.
static float gw39Motion(
  uint8_t motion,
  float p,
  float t,
  float speed,
  int dir,
  uint8_t block,
  uint8_t tail,
  uint16_t totalLeds
) {
  GW39Shape sh = gw39Shape(block, tail, totalLeds);

  // M_COMET = 0
  if (motion == 0U) {
    float ce = gw3039f(t * speed * 0.27f) * 1.3f - 0.15f;
    if (dir < 0) ce = 1.0f - ce;
    float d = (p - ce) * dir;
    return gw3039gauss(p, ce, d > 0.0f ? sh.head : sh.back);
  }

  // M_DOUBLE = 7
  if (motion == 7U) {
    float a = 0.0f, b = 0.0f;

    for (int k = 0; k < 2; k++) {
      float o = k ? 0.48f : 0.0f;
      float ce = gw3039f(t * speed * 0.25f + o) * 1.3f - 0.15f;
      if (dir < 0) ce = 1.0f - ce;

      float d = (p - ce) * dir;
      float z = gw3039gauss(
        p,
        ce,
        d > 0.0f
          ? sh.headPing
          : max(sh.headPing, sh.backPing * 0.86f)
      ) * (k ? 0.85f : 1.0f);

      if (k) a = z;
      else b = z;
    }

    return max(a, b);
  }

  // M_CASCADE = 8
  float ph = gw3039f(t * speed * 0.22f);
  float pp = dir > 0 ? p : 1.0f - p;

  if (ph < 0.55f) {
    float lv = ph / 0.55f;
    return 1.0f / (1.0f + expf(-(lv - pp) * sh.edgeK));
  }

  float off = (ph - 0.55f) / 0.45f;
  return 1.0f / (1.0f + expf((off - pp) * sh.edgeK));
}

static CRGB gw39PhaseColor(
  uint8_t phaseIndex,
  uint8_t ch,
  float p,
  float t
) {
  // Source COLOR_STYLE=0, so normal phases directly use COLORS_[phase].
  // Only phase index 1 / CH2 is rainbow.
  if (phaseIndex == 1U && ch == 1U) {
    return gw3039hsv(
      p * 0.92f +
      t * 0.12f +
      34.0f * 0.031f +
      phaseIndex * 0.071f +
      0.18f,
      1.0f,
      1.0f
    );
  }

  if (ch == 0U) {
    if (phaseIndex == 0U) return CRGB(68, 47, 147);
    if (phaseIndex == 1U) return CRGB(255, 255, 255);
    return CRGB(13, 213, 217);
  }

  if (phaseIndex == 0U) return CRGB(255, 42, 42);
  if (phaseIndex == 1U) return CRGB(255, 115, 0);
  return CRGB(216, 231, 4);
}

static CRGB gw39Sen(
  uint8_t mode,
  uint16_t idx,
  uint16_t count,
  float localSec
) {
  const float SEN_DUR = 2.4f;

  // MASTER_SEN_MODE=0: each channel uses its own local p.
  float p =
    count <= 1U
      ? 0.5f
      : (float)idx / (float)(count - 1U);

  float u = gw3039c(localSec / SEN_DUR);

  // Exact source:
  // pass = fract1(u * 2 * SEN_REPEAT), repeat=1
  float pass = gw3039f(u * 2.0f);
  float grow =
    pass < 0.62f
      ? gw38Ease(pass / 0.62f)
      : 1.0f - gw38Ease((pass - 0.62f) / 0.38f);

  float br = 0.0f;

  // SEN_EFFECT_INTRO = 3
  if (mode == 3U) {
    float d = (0.5f - fabsf(p - 0.5f)) * 2.0f;
    float sig = 1.0f / (1.0f + expf(-(grow - d) * 42.0f));
    br = gw3039c(
      sig * 0.82f +
      gw3039gauss(d, grow, 0.035f) * 0.55f
    );
  }
  // SEN_EFFECT_OUTRO = 8
  else {
    float front =
      min(1.0f, floorf(grow * 8.0f) / 7.0f);

    float sig = 1.0f / (1.0f + expf(-(front - p) * 42.0f));
    br = gw3039c(
      sig * 0.80f +
      gw3039gauss(p, front, 0.028f) * 0.55f
    );
  }

  if (u > 0.90f) {
    br *= 1.0f - gw38Ease((u - 0.90f) / 0.10f);
  }

  return gw3039scale(CRGB(255, 50, 0), br);
}

static float gw39StrobeBlockBrightness(
  uint16_t ledIndex,
  int targetBlock,
  uint8_t blockLen,
  uint8_t tailLen,
  uint16_t ledCount
) {
  if (targetBlock < 0) return 0.0f;

  uint16_t st = targetBlock * blockLen;
  uint16_t en = min(
    (int)ledCount - 1,
    (int)st + blockLen - 1
  );

  if (ledIndex >= st && ledIndex <= en) return 1.0f;
  if (tailLen == 0U) return 0.0f;

  uint16_t d =
    ledIndex < st
      ? st - ledIndex
      : ledIndex - en;

  return d > tailLen
    ? 0.0f
    : gw3039c(1.0f - d / (tailLen + 1.0f));
}

static CRGB gw39StrobeColor(
  uint8_t ch,
  uint32_t step,
  float p,
  float t
) {
  // RAINBOW_STROBE = false,false and COLOR_STYLE=0.
  // Exact source picks phaseColors[step % 3].
  uint8_t ci = step % 3U;

  if (ch == 0U) {
    if (ci == 0U) return CRGB(68, 47, 147);
    if (ci == 1U) return CRGB(255, 255, 255);
    return CRGB(13, 213, 217);
  }

  if (ci == 0U) return CRGB(255, 42, 42);
  if (ci == 1U) return CRGB(255, 115, 0);
  return CRGB(216, 231, 4);
}

static CRGB gw39Strobe(
  uint8_t ch,
  uint16_t idx,
  uint16_t count,
  float localSec
) {
  // Source STROBE_MODE=2 -> internal mode=1.
  // mode1 exact: step=floor(local/.07), sub=step%6,
  // flash on even sub, target random block per channel.
  const uint8_t blockLen = 10U;
  const uint8_t tailLen = 4U;

  uint16_t blocks =
    max(1, (int)((count + blockLen - 1U) / blockLen));

  uint32_t step = (uint32_t)floorf(localSec / 0.07f);
  uint8_t sub = step % 6U;
  uint32_t cycle = step / 6U;

  uint16_t bA =
    gw38Hash32(34U * 149U + cycle * 23U + 7U) % blocks;
  uint16_t bB =
    gw38Hash32(34U * 163U + cycle * 31U + 13U) % blocks;

  bool flash = (sub % 2U) == 0U;
  int target = flash
    ? (ch == 0U ? bA : bB)
    : -1;

  float br = flash
    ? gw38StrobeBlockBrightness(
        idx,
        target,
        blockLen,
        tailLen,
        count
      )
    : 0.0f;

  float p =
    count <= 1U
      ? 0.5f
      : (float)idx / (float)(count - 1U);

  // Source passes step + mode*7 = step+7.
  CRGB col = gw39StrobeColor(
    ch,
    step + 7U,
    p,
    localSec
  );

  return gw3039scale(col, br);
}

static CRGB gw39CorePixel(
  uint8_t ch,
  uint16_t idx,
  uint16_t count,
  float coreSec
) {
  // Source targetDuration = WELCOME_DURATION = 15 sec.
  //
  // strobeDuration1(15) = min(4,max(2,3)) = 3 sec.
  // baseTarget = 12 sec.
  // source phase durations = 9 + 11 + 10 = 30 sec.
  // baseScale = 12/30 = 0.4.
  //
  // Display durations:
  // P1 = 9*.4  = 3.6 sec
  // P2 = 11*.4 = 4.4 sec
  // P3 = 10*.4 = 4.0 sec
  // ST = 3.0 sec

  const float MASTER_SPEED = 2.2f;
  const float BASE_SCALE = 0.4f;
  const float P1_DISP = 3.6f;
  const float P2_DISP = 4.4f;
  const float P3_DISP = 4.0f;
  const float STROBE_DISP = 3.0f;
  const float PHASE_X = 0.75f;

  float p =
    count <= 1U
      ? 0.5f
      : (float)idx / (float)(count - 1U);

  // ------------------------------------------------------------
  // PHASE 1: M_DOUBLE, dir=-1, speed=.947073, source duration=9
  // ------------------------------------------------------------
  if (coreSec < P1_DISP) {
    float lt = coreSec / BASE_SCALE;

    float br = gw39Motion(
      7U,
      p,
      lt,
      MASTER_SPEED * 0.947073f,
      -1,
      10U,
      4U,
      count
    );

    CRGB col = gw39PhaseColor(0U, ch, p, lt);
    return gw3039scale(col, br);
  }

  // ------------------------------------------------------------
  // PHASE 2: M_COMET, dir=+1, speed=1.137044, source duration=11
  // Crossfade from phase1 for source-local first .75 sec.
  // ------------------------------------------------------------
  float x = coreSec - P1_DISP;

  if (x < P2_DISP) {
    float lt = x / BASE_SCALE;

    float br = gw39Motion(
      0U,
      p,
      lt,
      MASTER_SPEED * 1.137044f,
      1,
      10U,
      4U,
      count
    );

    CRGB col = gw39PhaseColor(1U, ch, p, lt);

    if (lt < PHASE_X) {
      float prevT = 9.0f + lt;

      float prevBr = gw39Motion(
        7U,
        p,
        prevT,
        MASTER_SPEED * 0.947073f,
        -1,
        10U,
        4U,
        count
      );

      CRGB prevCol = gw39PhaseColor(0U, ch, p, prevT);
      float m = lt / PHASE_X;

      br = gw38Lerp(prevBr, br, m);
      col = gw38Mix(prevCol, col, m);
    }

    return gw3039scale(col, br);
  }

  // ------------------------------------------------------------
  // PHASE 3: M_CASCADE, dir=-1, speed=1.142795, source duration=10
  // Crossfade from phase2 for source-local first .75 sec.
  // ------------------------------------------------------------
  x -= P2_DISP;

  if (x < P3_DISP) {
    float lt = x / BASE_SCALE;

    float br = gw39Motion(
      8U,
      p,
      lt,
      MASTER_SPEED * 1.142795f,
      -1,
      10U,
      4U,
      count
    );

    CRGB col = gw39PhaseColor(2U, ch, p, lt);

    if (lt < PHASE_X) {
      float prevT = 11.0f + lt;

      float prevBr = gw39Motion(
        0U,
        p,
        prevT,
        MASTER_SPEED * 1.137044f,
        1,
        10U,
        4U,
        count
      );

      CRGB prevCol = gw39PhaseColor(1U, ch, p, prevT);
      float m = lt / PHASE_X;

      br = gw38Lerp(prevBr, br, m);
      col = gw38Mix(prevCol, col, m);
    }

    return gw3039scale(col, br);
  }

  // ------------------------------------------------------------
  // STROBE ORDER 4.
  // ------------------------------------------------------------
  x -= P3_DISP;

  if (x < STROBE_DISP) {
    return gw39Strobe(ch, idx, count, x);
  }

  return CRGB::Black;
}



// ---------------- W36 exact source arrays ----------------
static const uint16_t GW36_JML_CHANNEL = 170U;
static const uint8_t  GW36_BLOCK_SIZE = 10U;
static const uint8_t gw36ChSisi[GW36_JML_CHANNEL] = {
  1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  1,1,1,1,1,1,1,1,1,
  0,0,0,0,0,0,
  1,1,
  0,0,0,0,
  1,1,1,1,
  0,0,
  1,1,1,1,
  0,0,0,0,
  1,1,
  0,0,
  1,1
};

static const uint8_t gw36ChStart[GW36_JML_CHANNEL] = {
  65,65,63,63,63,58,58,58,52,44,44,44,37,37,37,31,31,31,25,25,25,19,19,13,13,6,6,1,1,0,0,
  0,0,0,1,1,1,6,6,11,11,17,17,23,23,29,29,36,36,42,42,50,50,50,56,56,56,65,65,65,
  0,0,0,0,4,4,9,9,16,16,16,23,23,23,28,28,28,35,35,43,43,50,50,57,57,57,60,60,65,65,65,
  65,65,65,65,61,61,58,58,53,53,47,47,41,41,34,34,28,28,22,22,17,17,13,13,7,7,10,10,5,5,0,0,0,0,12,12,19,19,38,38,
  29,29,20,20,14,14,8,51,51,
  39,39,0,0,41,41,
  28,28,
  17,17,11,11,
  65,65,44,44,
  18,18,
  0,0,14,14,
  0,0,
  12,12,
  65,65,65,65
};

static const uint32_t gw36ChWarna[GW36_JML_CHANNEL] = {
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF,0x00FF00,0xFF00FF,0xFFFF00,0x00FFFF,0xFFA500,0xFF1493,
  0xFF0000,0x0088FF
};

static inline CRGB gw36HexToCRGB(uint32_t c) {
  return CRGB(
    (uint8_t)((c >> 16) & 0xFF),
    (uint8_t)((c >> 8) & 0xFF),
    (uint8_t)(c & 0xFF)
  );
}
static void gw36DrawCore(uint16_t count, uint16_t pos) {
  if (pos >= GW36_JML_CHANNEL) return;
  uint8_t sisi = gw36ChSisi[pos];
  int start = (int)gw36ChStart[pos];
  CRGB warna = gw36HexToCRGB(gw36ChWarna[pos]);

  for (uint8_t i = 0; i < GW36_BLOCK_SIZE; i++) {
    int idx = start + (int)i;
    // Source positions tetap berbasis strip 75 LED.
    if (idx < 0 || idx >= 75 || idx >= (int)count) continue;
    if (sisi == 0U) leds1[idx] = warna;
    else leds2[idx] = warna;
  }
}
static void gw36Render(uint32_t elapsed, uint16_t count) {
  const uint32_t INTRO_MS = 2400UL;
  const uint32_t PER_POS_MS = 460UL; // source: 40/40 x4, gap100, ON40
  const uint32_t CORE_MS = (uint32_t)GW36_JML_CHANNEL * PER_POS_MS;
  const uint32_t OUTRO_MS = 2800UL;
  const uint32_t TOTAL_MS = INTRO_MS + CORE_MS + OUTRO_MS;

  fill_solid(leds1, count, CRGB::Black);
  fill_solid(leds2, count, CRGB::Black);

  if (elapsed >= TOTAL_MS) {
    gw3039Done = true;
    return;
  }

  if (elapsed < INTRO_MS) {
    float t = (float)elapsed * 0.001f;
    for (uint16_t i = 0; i < count; i++) {
      leds1[i] = gw38SenIntro(i, count, t);
      leds2[i] = gw38SenIntro(i, count, t);
    }
    return;
  }

  uint32_t coreT = elapsed - INTRO_MS;
  if (coreT < CORE_MS) {
    uint16_t pos = (uint16_t)(coreT / PER_POS_MS);
    uint32_t r = coreT % PER_POS_MS;

    // Persis event timing state source:
    // 40-80 ON1, 120-160 ON2, 200-240 ON3, 280-320 ON4,
    // 420-460 ON5. Selain itu OFF.
    bool on =
      (r >= 40UL  && r < 80UL)  ||
      (r >= 120UL && r < 160UL) ||
      (r >= 200UL && r < 240UL) ||
      (r >= 280UL && r < 320UL) ||
      (r >= 420UL && r < 460UL);

    if (on) gw36DrawCore(count, pos);
    return;
  }

  uint32_t outT = coreT - CORE_MS;
  float t = (float)outT * 0.001f;
  for (uint16_t i = 0; i < count; i++) {
    leds1[i] = gw4142Sen(4U, 0U, i, count, t);
    leds2[i] = gw4142Sen(4U, 1U, i, count, t);
  }
}

// ---------------- W37 exact source arrays ----------------
static const uint8_t GW37_JML_CHANNEL = 42U;
static const uint8_t GW37_BLOCK_SIZE = 10U;
static const uint8_t gw37ChSisi[GW37_JML_CHANNEL] = {
  0,0,1,1,1,0,0,1,1,1,0,0,1,1,1,0,0,1,0,1,0,1,0,1,1,0,0,1,0,0,0,0,1,1,0,0,1,0,0,1,1,0
};

static const uint8_t gw37ChStart[GW37_JML_CHANNEL] = {
  23,10,42,17,5,43,59,62,31,0,0,32,52,23,11,17,52,37,38,11,26,65,65,0,65,65,12,0,0,22,26,40,40,22,42,3,65,65,26,10,0,28
};

static void gw37DrawCore(uint16_t count, uint8_t statePos) {
  if (statePos >= GW37_JML_CHANNEL) return;

  // Source exact integer arithmetic:
  // hue = statePos * (255 / 42)
  uint8_t hue = statePos * (255 / GW37_JML_CHANNEL);
  CRGB warna = CHSV(hue, 255, 255);
  uint8_t sisi = gw37ChSisi[statePos];
  int start = (int)gw37ChStart[statePos];

  for (uint8_t i = 0; i < GW37_BLOCK_SIZE; i++) {
    int idx = start + (int)i;
    if (idx < 0 || idx >= (int)count) continue;
    if (sisi == 0U) leds1[idx] = warna;
    else leds2[idx] = warna;
  }
}
static void gw37Render(uint32_t elapsed, uint16_t count) {
  const uint32_t INTRO_MS = 2800UL;
  const uint32_t PER_POS_MS = 184UL; // source 16/16 x4, gap40, ON16
  const uint32_t CORE_MS = (uint32_t)GW37_JML_CHANNEL * PER_POS_MS;
  const uint32_t OUTRO_MS = 2400UL;
  const uint32_t TOTAL_MS = INTRO_MS + CORE_MS + OUTRO_MS;

  fill_solid(leds1, count, CRGB::Black);
  fill_solid(leds2, count, CRGB::Black);

  if (elapsed >= TOTAL_MS) {
    gw3039Done = true;
    return;
  }

  if (elapsed < INTRO_MS) {
    float t = (float)elapsed * 0.001f;
    for (uint16_t i = 0; i < count; i++) {
      leds1[i] = gw4142Sen(4U, 0U, i, count, t);
      leds2[i] = gw4142Sen(4U, 1U, i, count, t);
    }
    return;
  }

  uint32_t coreT = elapsed - INTRO_MS;
  if (coreT < CORE_MS) {
    uint8_t pos = (uint8_t)(coreT / PER_POS_MS);
    uint32_t r = coreT % PER_POS_MS;

    bool on =
      (r >= 16UL  && r < 32UL)  ||
      (r >= 48UL  && r < 64UL)  ||
      (r >= 80UL  && r < 96UL)  ||
      (r >= 112UL && r < 128UL) ||
      (r >= 168UL && r < 184UL);

    if (on) gw37DrawCore(count, pos);
    return;
  }

  uint32_t outT = coreT - CORE_MS;
  float t = (float)outT * 0.001f;
  for (uint16_t i = 0; i < count; i++) {
    leds1[i] = gw39Sen(8U, i, count, t);
    leds2[i] = gw39Sen(8U, i, count, t);
  }
}

// ---------------- W38 wrapper: exact 2.4s intro + 20s core ----------------
static void gw38Render(uint32_t elapsed, uint16_t count) {
  const uint32_t INTRO_MS = 2400UL;
  const uint32_t CORE_MS = 20000UL;
  const uint32_t TOTAL_MS = INTRO_MS + CORE_MS;

  fill_solid(leds1, count, CRGB::Black);
  fill_solid(leds2, count, CRGB::Black);

  if (elapsed >= TOTAL_MS) {
    gw3039Done = true;
    return;
  }

  if (elapsed < INTRO_MS) {
    float t = (float)elapsed * 0.001f;
    for (uint16_t i = 0; i < count; i++) {
      leds1[i] = gw38SenIntro(i, count, t);
      leds2[i] = gw38SenIntro(i, count, t);
    }
  } else {
    float t = (float)(elapsed - INTRO_MS) * 0.001f;
    for (uint16_t i = 0; i < count; i++) {
      leds1[i] = gw38CorePixel(0U, i, count, t);
      leds2[i] = gw38CorePixel(1U, i, count, t);
    }
  }
}

// ---------------- W39 wrapper: exact 2.4 + 15 + 2.4 = 19.8s ----------------
static void gw39Render(uint32_t elapsed, uint16_t count) {
  const uint32_t INTRO_MS = 2400UL;
  const uint32_t CORE_MS = 15000UL;
  const uint32_t OUTRO_MS = 2400UL;
  const uint32_t TOTAL_MS = INTRO_MS + CORE_MS + OUTRO_MS;

  fill_solid(leds1, count, CRGB::Black);
  fill_solid(leds2, count, CRGB::Black);

  if (elapsed >= TOTAL_MS) {
    gw3039Done = true;
    return;
  }

  if (elapsed < INTRO_MS) {
    float t = (float)elapsed * 0.001f;
    for (uint16_t i = 0; i < count; i++) {
      leds1[i] = gw39Sen(3U, i, count, t);
      leds2[i] = gw39Sen(3U, i, count, t);
    }
  } else if (elapsed < INTRO_MS + CORE_MS) {
    float t = (float)(elapsed - INTRO_MS) * 0.001f;
    for (uint16_t i = 0; i < count; i++) {
      leds1[i] = gw39CorePixel(0U, i, count, t);
      leds2[i] = gw39CorePixel(1U, i, count, t);
    }
  } else {
    float t = (float)(elapsed - INTRO_MS - CORE_MS) * 0.001f;
    for (uint16_t i = 0; i < count; i++) {
      leds1[i] = gw39Sen(8U, i, count, t);
      leds2[i] = gw39Sen(8U, i, count, t);
    }
  }
}

static bool gw3039DirectSourceActive() {
  if (selectedWelcome < 30U || selectedWelcome > 39U) return false;
  uint8_t m = mappedWelcome[selectedWelcome];
  return !(m >= 1U && m <= 210U);
}

static void gw3039ResetRuntime() {
  gw3039Done = false;
}

static void gw3039RenderSelected(uint8_t welcomeNo, uint32_t tMs, uint16_t count) {
  gw3039Done = false;

  switch (welcomeNo) {
    case 30U:
    case 31U:
    case 32U:
    case 33U:
    case 34U:
    case 35U:
      gw3035Render(welcomeNo, tMs, count);
      break;
    case 36U:
      gw36Render(tMs, count);
      break;
    case 37U:
      gw37Render(tMs, count);
      break;
    case 38U:
      gw38Render(tMs, count);
      break;
    case 39U:
      gw39Render(tMs, count);
      break;
    default:
      return;
  }

  // CH3/CH4 ikut Welcome source, mapping GLOBAL lurus.
  memcpy(leds3, leds1, sizeof(CRGB) * count);
  memcpy(leds4, leds2, sizeof(CRGB) * count);
}



// ============================================================================
// WELCOME 20-29 — SOURCE ORIGINAL RECOVERY
//
// W20-W23 = source generator user family (W23 file1 ... W20 file4)
//   SOURCE_NUM_LEDS=75, SPEED_MUL=2.15, TAIL_LEN=23,
//   SEG_MS=4600, BLEND_START=.78, SEN_DURATION=3.4s.
//   Implementasi pixel-formula equivalent, TANPA buffer float[75] tambahan.
//
// W24 = Hydraulic Hammer Gradient source user:
//   12s, hammer 10 LED, 5 hit, solid fill,
//   Purple -> Light Blue -> White, CH2 mirror.
//
// W25 = Dual Hammer 5 LED source:
//   merah -> biru -> amber -> amber full 650ms ->
//   amber running W42 5600ms.
//
// W26-W29 = source generator yang sama dengan W30-W35:
//   5 fase x 6000ms, 3 repeat/fase.
//
// Integrasi terbaru: semua timeline memakai welcomeAnimClockVirtual
// sehingga SPEED GLOBAL tetap live. Rumus/urutan/warna source tidak diubah.
// CH3=CH1 dan CH4=CH2.
// ============================================================================

static bool gw2029Done = false;

// ---------------- common source math W20-W23 ----------------
static inline float gw2023Clamp(float x) {
  return x < 0.0f ? 0.0f : (x > 1.0f ? 1.0f : x);
}
static inline float gw2023Sm(float x) {
  x = gw2023Clamp(x);
  return x * x * (3.0f - 2.0f * x);
}
static inline float gw2023Fract(float x) {
  return x - floorf(x);
}
static inline float gw2023Ease(float x) {
  x = gw2023Clamp(x);
  return -(cosf(PI * x) - 1.0f) * 0.5f;
}
static inline float gw2023Tri(float p) {
  return p < 0.5f ? p * 2.0f : 2.0f - p * 2.0f;
}
static inline float gw2023Gauss(float x, float c, float w) {
  float d = (x - c) / w;
  return expf(-0.5f * d * d);
}
static inline float gw2023PosMod(float x, float m) {
  float r = fmodf(x, m);
  return r < 0.0f ? r + m : r;
}
static inline float gw2023Max(float a, float b) { return a > b ? a : b; }
static inline float gw2023Min(float a, float b) { return a < b ? a : b; }


// FIX11: old expanded helper removed; shared W14..W23 engine is used.


// FIX11: old expanded helper removed; shared W14..W23 engine is used.


// FIX11: old expanded helper removed; shared W14..W23 engine is used.


// FIX11: old expanded helper removed; shared W14..W23 engine is used.


// FIX11: old expanded helper removed; shared W14..W23 engine is used.


// Direct per-pixel equivalent of source w1423_primitiveF() types 0..19.
// Source currentDir=0, jadi applyDirection() adalah no-op.

// FIX11: old expanded helper removed; shared W14..W23 engine is used.


static float gw2023SenValue(uint8_t effect, float p, float u) {
  u=gw2023Clamp(u);
  float pass=gw2023Fract(u*2.0f);
  float grow=pass<.62f
    ? gw2023Ease(pass/.62f)
    : 1.0f-gw2023Ease((pass-.62f)/.38f);

  float v=0.0f;
  float sigA, q, d, a, b, ce, front;

  switch(effect){
    case 0:
      sigA=1.0f/(1.0f+expf(-(grow-p)*42.0f));
      v=gw2023Clamp(sigA*.8f+gw2023Gauss(p,grow,.025f)*.6f);
      break;
    case 1:
      q=1.0f-p;
      sigA=1.0f/(1.0f+expf(-(grow-q)*42.0f));
      v=gw2023Clamp(sigA*.8f+gw2023Gauss(q,grow,.025f)*.6f);
      break;
    case 2:
      d=fabsf(p-.5f)*2.0f;
      sigA=1.0f/(1.0f+expf(-(grow-d)*42.0f));
      v=gw2023Clamp(sigA*.82f+gw2023Gauss(d,grow,.035f)*.55f);
      break;
    case 3:
      d=(.5f-fabsf(p-.5f))*2.0f;
      sigA=1.0f/(1.0f+expf(-(grow-d)*42.0f));
      v=gw2023Clamp(sigA*.82f+gw2023Gauss(d,grow,.035f)*.55f);
      break;
    case 4:
      a=grow*.5f; b=1.0f-grow*.5f;
      v=gw2023Max(gw2023Gauss(p,a,.055f),gw2023Gauss(p,b,.055f));
      break;
    case 5:
      a=.5f-grow*.5f; b=.5f+grow*.5f;
      v=gw2023Max(gw2023Gauss(p,a,.055f),gw2023Gauss(p,b,.055f));
      break;
    case 6:
      ce=pass*1.3f-.15f; d=p-ce;
      v=gw2023Gauss(p,ce,d>0.0f?.035f:.15f);
      break;
    case 7:
      ce=1.0f-(pass*1.3f-.15f); d=(p-ce)*-1.0f;
      v=gw2023Gauss(p,ce,d>0.0f?.035f:.15f);
      break;
    case 8:
      front=gw2023Min(1.0f,floorf(grow*8.0f)/7.0f);
      sigA=1.0f/(1.0f+expf(-(front-p)*42.0f));
      v=gw2023Clamp(sigA*.8f+gw2023Gauss(p,front,.028f)*.55f);
      break;
    case 9:
      ce=gw2023Ease(gw2023Tri(pass));
      d=pass<.5f?p-ce:ce-p;
      v=gw2023Gauss(p,ce,d>0.0f?.03f:.14f);
      break;
    default: {
      float ce1=gw2023Fract(pass)*1.3f-.15f;
      float d1=p-ce1;
      float aa=gw2023Gauss(p,ce1,d1>0.0f?.03f:.12f);
      float ce2=gw2023Fract(pass+.48f)*1.3f-.15f;
      float d2=p-ce2;
      float bb=gw2023Gauss(p,ce2,d2>0.0f?.03f:.12f)*.85f;
      v=gw2023Max(aa,bb);
    } break;
  }

  if(u>.9f)v*=1.0f-gw2023Ease((u-.9f)/.1f);
  return gw2023Clamp(v);
}


// ============================================================================
// FIX11 SAFE SIZE STAGE1 — WELCOME 14..23 SHARED ENGINE
//
// Versi 1722 KB memakai SATU engine array untuk Welcome 14..23.
// Firmware FIX10 saat ini memakai rumus pixel-equivalent yang jauh lebih panjang.
// Rumus sumber/warna/timing tetap sama; hanya cara menghitung frame disatukan kembali.
// Timeline tetap memakai "elapsed" dari welcomeAnimClockVirtual, jadi speed global LIVE
// milik firmware sekarang TIDAK diubah.
// ============================================================================
static const uint16_t GW1423_SHARED_MAX = 75U;
static const float GW1423_SHARED_TAIL = 23.0f;

struct GW1423SharedConfig {
  uint8_t modeBase;
  bool senIntro;
  bool senOutro;
  uint8_t senIntroFx;
  uint8_t senOutroFx;
  CRGB color1;
  CRGB color2;
};

static const GW1423SharedConfig GW1423_SHARED_CFG[10] = {
  { 0U, true,  false, 5U, 0U, CRGB(234,247,255), CRGB(255,42,42) }, // W23
  { 5U, false, true,  5U, 2U, CRGB(255,0,174),   CRGB(0,255,170) }, // W22
  {10U, true,  true,  5U, 2U, CRGB(241,233,239), CRGB(212,255,0) }, // W21
  {15U, true,  true,  1U, 3U, CRGB(187,7,7),     CRGB(31,69,224) }, // W20
  {20U, true,  false, 6U, 3U, CRGB(183,22,227),  CRGB(65,220,9) },  // W19
  {25U, true,  false, 6U, 3U, CRGB(0,245,216),   CRGB(237,2,116) }, // W18
  {30U, true,  true,  5U, 6U, CRGB(204,0,71),    CRGB(78,241,9) },  // W17
  {35U, true,  true,  5U, 6U, CRGB(252,252,252), CRGB(200,0,255) }, // W16
  {40U, true,  true,  1U, 3U, CRGB(252,252,252), CRGB(200,0,255) }, // W15
  {45U, true,  true,  9U, 3U, CRGB(252,252,252), CRGB(200,0,255) }  // W14
};

static uint16_t gw1423SharedN = GW1423_SHARED_MAX;
static float gw1423SharedA1[GW1423_SHARED_MAX];
static float gw1423SharedB1[GW1423_SHARED_MAX];
static float gw1423SharedA2[GW1423_SHARED_MAX];
static float gw1423SharedB2[GW1423_SHARED_MAX];

void gw1423SharedClear(float *a,float *b){
  for(int i=0;i<gw1423SharedN;i++){a[i]=0;b[i]=0;}
}

void gw1423SharedAdd(float *a,int i,float v){
  if(i<0||i>=gw1423SharedN)return;
  v=gw2023Clamp(v); if(v>a[i])a[i]=v;
}

void gw1423SharedSpot(float *a,float c,float w,float gain=1.0f){
  w=gw2023Max(.5f,w);
  for(int i=0;i<gw1423SharedN;i++){
    float d=(i-c)/w;
    gw1423SharedAdd(a,i,expf(-d*d*2.0f)*gain);
  }
}

void gw1423SharedComet(float *a,float head,float len,bool reverse=false,float gain=1.0f,float pw=2.0f){
  len=gw2023Max(.01f,len);
  for(int i=0;i<gw1423SharedN;i++){
    int p=reverse?(gw1423SharedN-1-i):i;
    float d=head-p;
    if(d>=0&&d<=len)gw1423SharedAdd(a,i,powf(1.0f-d/len,pw)*gain);
  }
}

void gw1423SharedBlock(float *a,float center,float width,float gain=1.0f){
  int aa=(int)floorf(center-width*.5f);
  int bb=(int)ceilf(center+width*.5f);
  for(int i=aa;i<=bb;i++)if(i>=0&&i<gw1423SharedN){
    float edge=gw2023Min((float)(i-aa),(float)(bb-i));
    float fade=gw2023Min(1.0f,(edge+1.0f)/gw2023Max(1.0f,width*.22f));
    gw1423SharedAdd(a,i,gain*fade);
  }
}

void gw1423SharedVirtualComet(float *a,float *b,float head,float len,bool rev=false,float gain=1.0f,float pw=2.0f){
  int total=gw1423SharedN*2;
  len=gw2023Max(.01f,len);
  for(int g=0;g<total;g++){
    int p=rev?(total-1-g):g;
    float d=head-p;
    if(d<0||d>len)continue;
    float v=powf(1.0f-d/len,pw)*gain;
    if(g<gw1423SharedN)gw1423SharedAdd(a,g,v);else gw1423SharedAdd(b,g-gw1423SharedN,v);
  }
}

void gw1423SharedVirtualBlock(float *a,float *b,float c,float w,float gain=1.0f){
  int total=gw1423SharedN*2;
  for(int g=0;g<total;g++){
    float d=fabsf(g-c);
    if(d<=w*.5f){
      float v=gain*gw2023Min(1.0f,(w*.5f-d+1.0f)/gw2023Max(1.0f,w*.18f));
      if(g<gw1423SharedN)gw1423SharedAdd(a,g,v);else gw1423SharedAdd(b,g-gw1423SharedN,v);
    }
  }
}

void gw1423SharedPrimitive(uint8_t type,float t,float *A,float *B){
  gw1423SharedClear(A,B);
  const float N=gw1423SharedN-1;
  const float L=GW1423_SHARED_TAIL;
  const float total=gw1423SharedN*2.0f;
  t=gw2023Clamp(t);

  if(type==0){float h=gw2023Sm(t)*(total-1+L);gw1423SharedVirtualComet(A,B,h,L,false,1,1.8f);}
  else if(type==1){float h=gw2023Sm(t)*(total-1+L);gw1423SharedVirtualComet(A,B,h,L*.72f,false,1,2.2f);gw1423SharedVirtualComet(A,B,h-gw1423SharedN*.40f,L*.58f,false,.70f,2);}
  else if(type==2){float q=t<.5f?gw2023Sm(t*2):gw2023Sm((1-t)*2);gw1423SharedVirtualComet(A,B,q*(total-1+L*1.2f),L*1.2f,false,1,1.8f);}
  else if(type==3){float q=t*3,f=gw2023Fract(q),tr=f<.5f?f*2:(1-f)*2;gw1423SharedComet(A,tr*(N+L),L,false);gw1423SharedComet(B,tr*(N+L),L,true);}
  else if(type==4){float base=gw2023Sm(t/.22f)*gw2023Sm((1-t)/.16f);for(int i=0;i<gw1423SharedN;i++){gw1423SharedAdd(A,i,base*.32f);gw1423SharedAdd(B,i,base*.32f);}gw1423SharedVirtualComet(A,B,gw2023Fract(t*2.2f)*(total+L),L*.85f,false,1,1.8f);}

  else if(type==5){gw1423SharedVirtualComet(A,B,gw2023Sm(t)*(total+L*1.55f),L*1.55f,false,1,2.2f);}
  else if(type==6){float h=gw2023Sm(t)*(total+L);for(int k=0;k<3;k++)gw1423SharedVirtualComet(A,B,h-k*gw1423SharedN*.28f,L*.66f,false,1-k*.16f,2.4f);}
  else if(type==7){float q=t*2,f=gw2023Fract(q),h=gw2023Sm(f)*(N+L);if((int)floorf(q)==0){gw1423SharedComet(A,h,L,false);gw1423SharedComet(B,h-N*.25f,L,false,.75f);}else{gw1423SharedComet(B,h,L,false);gw1423SharedComet(A,h-N*.25f,L,false,.75f);}}
  else if(type==8){gw1423SharedVirtualComet(A,B,gw2023Sm(t)*(total+L*1.15f),L*1.15f,true,1,2);}
  else if(type==9){float h=gw2023Sm(t)*(total+L);gw1423SharedVirtualComet(A,B,h,L,false,1,2);gw1423SharedVirtualComet(A,B,h-N*.48f,L*.75f,true,.72f,2);}

  else if(type==10){float p=gw2023Sm(t)*(N*.5f);gw1423SharedSpot(A,p,L*.26f);gw1423SharedSpot(A,N-p,L*.26f);gw1423SharedSpot(B,p,L*.26f);gw1423SharedSpot(B,N-p,L*.26f);}
  else if(type==11){float q=t<.52f?gw2023Sm(t/.52f):gw2023Sm((1-t)/.48f),p=q*(N*.5f);gw1423SharedSpot(A,N*.5f-p,L*.3f);gw1423SharedSpot(A,N*.5f+p,L*.3f);gw1423SharedSpot(B,N*.5f-p,L*.3f);gw1423SharedSpot(B,N*.5f+p,L*.3f);}
  else if(type==12){float p=gw2023Sm(t)*(N+L*.6f);gw1423SharedSpot(A,p,L*.26f);gw1423SharedSpot(B,N-p,L*.26f);gw1423SharedSpot(A,N-p,L*.20f,.72f);gw1423SharedSpot(B,p,L*.20f,.72f);}
  else if(type==13){float p=gw2023Sm(t)*(N*.5f);gw1423SharedSpot(A,N*.5f-p,L*.30f);gw1423SharedSpot(A,N*.5f+p,L*.30f);gw1423SharedSpot(B,N*.5f-p,L*.30f);gw1423SharedSpot(B,N*.5f+p,L*.30f);}
  else if(type==14){float q=t*2,f=gw2023Fract(q),p=gw2023Sm(f)*N;gw1423SharedSpot(A,p,L*.24f);gw1423SharedSpot(B,N-p,L*.24f);if(q>1){gw1423SharedSpot(A,N-p,L*.18f,.65f);gw1423SharedSpot(B,p,L*.18f,.65f);}}

  else if(type==15){gw1423SharedVirtualBlock(A,B,gw2023Sm(t)*(total+gw1423SharedN*.1f),gw2023Max(8.0f,L*.9f),1);}
  else if(type==16){float h=gw2023Sm(t)*(total+gw1423SharedN*.1f);gw1423SharedVirtualBlock(A,B,h,gw2023Max(7.0f,L*.7f),1);gw1423SharedVirtualBlock(A,B,h-gw1423SharedN*.45f,gw2023Max(6.0f,L*.55f),.72f);}
  else if(type==17){float q=t*2,f=gw2023Fract(q),c=gw2023Sm(f)*(N+L);if((int)floorf(q)==0){gw1423SharedBlock(A,c,L*.8f);gw1423SharedBlock(B,c-N*.30f,L*.65f,.7f);}else{gw1423SharedBlock(B,c,L*.8f);gw1423SharedBlock(A,c-N*.30f,L*.65f,.7f);}}
  else if(type==18){float q=t*3,f=gw2023Fract(q),tr=f<.5f?f*2:(1-f)*2;gw1423SharedBlock(A,tr*N,L*.82f);gw1423SharedBlock(B,(1-tr)*N,L*.82f);}
  else if(type==19){float width=gw2023Max(7.0f,L*.8f),shift=gw2023Sm(t)*(gw1423SharedN+width),per=width*2.6f;for(int i=0;i<gw1423SharedN;i++){float aa=gw2023PosMod(i-shift+width*8,per),bb=gw2023PosMod(N-i-shift+width*8,per);if(aa<width)gw1423SharedAdd(A,i,.9f);if(bb<width)gw1423SharedAdd(B,i,.9f);}}

  else if(type==20){float p=gw2023Sm(t)*(N*.5f);gw1423SharedSpot(A,p,L*.25f);gw1423SharedSpot(A,N-p,L*.25f);gw1423SharedSpot(B,p,L*.25f);gw1423SharedSpot(B,N-p,L*.25f);}
  else if(type==21){float p=gw2023Sm(t)*(N*.5f);gw1423SharedSpot(A,N*.5f-p,L*.28f);gw1423SharedSpot(A,N*.5f+p,L*.28f);gw1423SharedSpot(B,N*.5f-p,L*.28f);gw1423SharedSpot(B,N*.5f+p,L*.28f);}
  else if(type==22){float p=gw2023Sm(t)*(N*.5f);gw1423SharedSpot(A,N*.5f-p,L*.24f);gw1423SharedSpot(A,N*.5f+p,L*.24f);gw1423SharedSpot(B,N*.5f-p,L*.24f);gw1423SharedSpot(B,N*.5f+p,L*.24f);}
  else if(type==23){float p=gw2023Sm(t)*(N*.5f);gw1423SharedSpot(A,N*.5f+p,L*.25f);gw1423SharedSpot(A,N*.5f-p,L*.25f);gw1423SharedSpot(B,N*.5f+p,L*.25f);gw1423SharedSpot(B,N*.5f-p,L*.25f);}
  else if(type==24){float base=gw2023Sm(t/.28f)*gw2023Sm((1-t)/.18f);for(int i=0;i<gw1423SharedN;i++){float d=fabsf(i-N*.5f)/gw2023Max(.001f,N*.5f);gw1423SharedAdd(A,i,base*(1-d*.55f));gw1423SharedAdd(B,i,base*(1-d*.55f));}gw1423SharedSpot(A,N*.5f,L*.22f,.95f);gw1423SharedSpot(B,N*.5f,L*.22f,.95f);}

  else if(type==25){float q=t<.5f?gw2023Sm(t*2):gw2023Sm((1-t)*2);gw1423SharedVirtualComet(A,B,q*(total+L),L,false,1,2);}
  else if(type==26){float q=t<.5f?gw2023Sm(t*2):gw2023Sm((1-t)*2);gw1423SharedVirtualComet(A,B,q*(total+L),L,true,1,2);}
  else if(type==27){float q=t*2,f=gw2023Fract(q),tr=f<.5f?f*2:(1-f)*2;gw1423SharedVirtualComet(A,B,tr*(total+L),L*.72f,false,1,2.1f);gw1423SharedVirtualComet(A,B,tr*(total+L)-gw1423SharedN*.5f,L*.55f,false,.65f,2.1f);}
  else if(type==28){float micro=t*6,f=gw2023Fract(micro);int pair=(int)floorf(micro);float base=(pair/6.0f)*(total*.86f),move=(pair%2==0?f:-f)*gw1423SharedN*.12f;gw1423SharedVirtualComet(A,B,base+move+L,L*.9f,false,1,2);}
  else if(type==29){float q=t<.5f?gw2023Sm(t*2):gw2023Sm((1-t)*2);gw1423SharedVirtualComet(A,B,q*(total+L),L*1.1f,false,1,1.6f);gw1423SharedVirtualComet(A,B,q*(total+L)-gw1423SharedN*.58f,L*.55f,false,.62f,2.2f);}

  else if(type==30){float h=gw2023Sm(t)*(N+L);gw1423SharedComet(A,h,L,false);gw1423SharedComet(B,h,L,false);}
  else if(type==31){float h=gw2023Sm(t)*(N+L);gw1423SharedComet(A,h,L,false);gw1423SharedComet(B,h-N*.32f,L*.82f,false,.8f);}
  else if(type==32){float h=gw2023Sm(t)*(N+L);gw1423SharedComet(A,h,L,true);gw1423SharedComet(B,h,L,true);}
  else if(type==33){float q=t*4,f=gw2023Fract(q),h=gw2023Sm(f)*(N+L);if(((int)floorf(q))%2==0){gw1423SharedComet(A,h,L,false);gw1423SharedComet(B,h,L,true,.62f);}else{gw1423SharedComet(B,h,L,false);gw1423SharedComet(A,h,L,true,.62f);}}
  else if(type==34){float h=gw2023Sm(t)*(N+L);gw1423SharedComet(A,h,L,false);gw1423SharedComet(B,h,L,true);gw1423SharedComet(A,h-N*.42f,L*.52f,true,.55f);gw1423SharedComet(B,h-N*.42f,L*.52f,false,.55f);}

  else if(type==35){float p=gw2023Sm(t)*N;gw1423SharedSpot(A,p,L*.25f);gw1423SharedSpot(A,N-p,L*.25f);gw1423SharedSpot(B,p,L*.25f);gw1423SharedSpot(B,N-p,L*.25f);}
  else if(type==36){float q=t<.5f?gw2023Sm(t*2):gw2023Sm((1-t)*2),w=L*(.24f+.55f*(1-q));gw1423SharedSpot(A,N*.5f,w);gw1423SharedSpot(B,N*.5f,w);}
  else if(type==37){float p=gw2023Sm(t)*(N+L*.7f);gw1423SharedSpot(A,p,L*.22f);gw1423SharedSpot(A,N-p,L*.22f);gw1423SharedSpot(B,p,L*.22f);gw1423SharedSpot(B,N-p,L*.22f);}
  else if(type==38){float q=t<.5f?gw2023Sm(t*2):gw2023Sm((1-t)*2),p=q*N;gw1423SharedSpot(A,p,L*.26f);gw1423SharedSpot(B,N-p,L*.26f);}
  else if(type==39){float q=t*3,f=gw2023Fract(q),p=gw2023Sm(f)*N;gw1423SharedSpot(A,p,L*.21f);gw1423SharedSpot(A,N-p,L*.21f);gw1423SharedSpot(B,p,L*.21f);gw1423SharedSpot(B,N-p,L*.21f);}

  else if(type==40){gw1423SharedVirtualComet(A,B,gw2023Sm(t)*(total+L*1.8f),L*1.8f,false,1,1.55f);}
  else if(type==41){gw1423SharedVirtualComet(A,B,gw2023Sm(t)*(total+L*1.8f),L*1.8f,true,1,1.55f);}
  else if(type==42){float h=gw2023Sm(t)*(total+L*1.6f);gw1423SharedVirtualComet(A,B,h,L*1.45f,false,1,1.65f);gw1423SharedVirtualComet(A,B,h-gw1423SharedN*.55f,L*1.1f,false,.70f,1.65f);}
  else if(type==43){float q=t*2,f=gw2023Fract(q),h=gw2023Sm(f)*(N+L*1.5f);if((int)floorf(q)==0){gw1423SharedComet(A,h,L*1.4f,false);gw1423SharedComet(B,h-N*.3f,L,true,.7f);}else{gw1423SharedComet(B,h,L*1.4f,true);gw1423SharedComet(A,h-N*.3f,L,true,.7f);}}
  else if(type==44){float q=t<.5f?gw2023Sm(t*2):gw2023Sm((1-t)*2);gw1423SharedVirtualComet(A,B,q*(total+L*1.7f),L*1.7f,false,1,1.5f);}

  else if(type==45){float h=gw2023Sm(t)*(total+L);gw1423SharedVirtualComet(A,B,h,L,false,1,1.8f);gw1423SharedVirtualComet(A,B,h-N*.5f,L*.62f,false,.62f,2);}
  else if(type==46){float h=gw2023Sm(t)*(total+L);for(int k=0;k<4;k++)gw1423SharedVirtualComet(A,B,h-k*gw1423SharedN*.26f,L*.55f,false,1-k*.12f,2.3f);}
  else if(type==47){float p=gw2023Sm(t)*N;gw1423SharedSpot(A,p,L*.22f);gw1423SharedSpot(A,N-p,L*.22f);gw1423SharedSpot(B,N-p,L*.22f);gw1423SharedSpot(B,p,L*.22f);}
  else if(type==48){float q=t*4,f=gw2023Fract(q),tr=f<.5f?f*2:(1-f)*2;gw1423SharedComet(A,tr*(N+L),L,false);gw1423SharedComet(B,tr*(N+L),L,true);}
  else {float base=gw2023Sm(t/.20f)*gw2023Sm((1-t)/.14f);for(int i=0;i<gw1423SharedN;i++){gw1423SharedAdd(A,i,base*.42f);gw1423SharedAdd(B,i,base*.42f);}gw1423SharedVirtualComet(A,B,gw2023Fract(t*3)*(total+L),L*.95f,false,1,1.7f);}

}

static void gw1423SharedModeFrame(float sourceMs, const GW1423SharedConfig &cfg) {
  const float SEG_MS = 4600.0f;
  const float BLEND_START = 0.78f;

  float raw = sourceMs / SEG_MS;
  int seg = ((int)floorf(raw)) % 5;
  float local = raw - floorf(raw);

  if (local < BLEND_START) {
    gw1423SharedPrimitive(
      (uint8_t)(cfg.modeBase + (uint8_t)seg),
      local / BLEND_START,
      gw1423SharedA1, gw1423SharedB1
    );
  } else {
    float k = gw2023Sm((local - BLEND_START) / (1.0f - BLEND_START));

    gw1423SharedPrimitive(
      (uint8_t)(cfg.modeBase + (uint8_t)seg),
      1.0f,
      gw1423SharedA1, gw1423SharedB1
    );
    gw1423SharedPrimitive(
      (uint8_t)(cfg.modeBase + (uint8_t)((seg + 1) % 5)),
      0.0f,
      gw1423SharedA2, gw1423SharedB2
    );

    for (uint16_t i = 0; i < gw1423SharedN; i++) {
      gw1423SharedA1[i] =
        gw1423SharedA1[i] * (1.0f - k) + gw1423SharedA2[i] * k;
      gw1423SharedB1[i] =
        gw1423SharedB1[i] * (1.0f - k) + gw1423SharedB2[i] * k;
    }
  }

  for (uint16_t i = 0; i < gw1423SharedN; i++) {
    leds1[i] = cfg.color1;
    leds2[i] = cfg.color2;
    leds1[i].nscale8_video(
      (uint8_t)constrain(gw1423SharedA1[i] * 255.0f, 0.0f, 255.0f)
    );
    leds2[i].nscale8_video(
      (uint8_t)constrain(gw1423SharedB1[i] * 255.0f, 0.0f, 255.0f)
    );
  }
}

static void gw1423SharedSenFrame(uint8_t effect, float u) {
  const int total = (int)gw1423SharedN * 2;

  for (uint16_t i = 0; i < gw1423SharedN; i++) {
    float va = gw2023SenValue(
      effect, (float)i / (float)total, u
    );
    float vb = gw2023SenValue(
      effect, (float)(gw1423SharedN + i) / (float)total, u
    );

    leds1[i] = CRGB(255,50,0);
    leds2[i] = CRGB(255,50,0);

    leds1[i].nscale8_video(
      (uint8_t)constrain(va * 255.0f, 0.0f, 255.0f)
    );
    leds2[i].nscale8_video(
      (uint8_t)constrain(vb * 255.0f, 0.0f, 255.0f)
    );
  }
}

static void gw1423SharedRender(
  uint8_t welcomeNo, uint32_t elapsed, uint16_t count, bool &doneFlag
) {
  doneFlag = false;

  fill_solid(leds1, count, CRGB::Black);
  fill_solid(leds2, count, CRGB::Black);

  if (count < 1U || welcomeNo < 14U || welcomeNo > 23U) {
    doneFlag = true;
    return;
  }

  gw1423SharedN = count;
  if (gw1423SharedN > GW1423_SHARED_MAX) {
    gw1423SharedN = GW1423_SHARED_MAX;
  }

  const uint8_t cfgIndex = (uint8_t)(23U - welcomeNo);
  const GW1423SharedConfig &cfg = GW1423_SHARED_CFG[cfgIndex];

  const float SEN_MS = 3400.0f;
  const float MODE_REAL_MS = (4600.0f * 5.0f) / 2.1500f;
  const float introMs = cfg.senIntro ? SEN_MS : 0.0f;
  const float outroMs = cfg.senOutro ? SEN_MS : 0.0f;
  const float cycleMs = introMs + MODE_REAL_MS + outroMs;
  const float cyc = (float)elapsed;

  if (cyc >= cycleMs) {
    doneFlag = true;
    return;
  }

  if (cfg.senIntro && cyc < introMs) {
    gw1423SharedSenFrame(cfg.senIntroFx, cyc / introMs);
    return;
  }

  if (cyc < introMs + MODE_REAL_MS) {
    gw1423SharedModeFrame((cyc - introMs) * 2.1500f, cfg);
    return;
  }

  if (cfg.senOutro) {
    gw1423SharedSenFrame(
      cfg.senOutroFx,
      (cyc - introMs - MODE_REAL_MS) / outroMs
    );
  }
}




// FIX11: old expanded helper removed; shared W14..W23 engine is used.


static void gw2023Render(uint8_t welcomeNo, uint32_t elapsed, uint16_t count){
  gw1423SharedRender(welcomeNo, elapsed, count, gw2029Done);
}

// ---------------- W24 HYDRAULIC HAMMER GRADIENT ----------------
static CRGB gw24Gradient(uint16_t pos,uint16_t length){
  const CRGB PURPLE(154,88,255);
  const CRGB LIGHTBLUE(96,207,255);
  const CRGB WHITE(255,255,255);

  if(length<=1U)return WHITE;
  float t=(float)pos/(float)(length-1U);

  if(t<=.5f){
    uint8_t a=(uint8_t)((t/.5f)*255.0f);
    return blend(PURPLE,LIGHTBLUE,a);
  }
  uint8_t a=(uint8_t)(((t-.5f)/.5f)*255.0f);
  return blend(LIGHTBLUE,WHITE,a);
}
static uint16_t gw24FillCount(float pct,uint16_t count){
  if(pct<14.0f)return 0U;
  if(pct<31.0f)return (uint16_t)roundf(count*.28f);
  if(pct<48.0f)return (uint16_t)roundf(count*.46f);
  if(pct<65.0f)return (uint16_t)roundf(count*.64f);
  if(pct<82.0f)return (uint16_t)roundf(count*.82f);
  return count;
}
static float gw24Lerp(float a,float b,float t){
  if(t<0.0f)t=0.0f;
  if(t>1.0f)t=1.0f;
  return a+(b-a)*t;
}
static void gw24HammerFrame(
  float pct,bool &active,float &posPct,uint8_t &brightness
){
  static const float START[5]={0.0f,17.0f,34.0f,51.0f,68.0f};
  static const float ARRIVE[5]={9.0f,26.0f,43.0f,60.0f,77.0f};
  static const float BOUNCE[5]={11.0f,28.0f,45.0f,62.0f,79.0f};
  static const float REHIT[5]={14.0f,31.0f,48.0f,65.0f,82.0f};
  static const float FADEEND[5]={14.2f,31.2f,48.2f,65.2f,82.2f};

  active=false; posPct=0.0f; brightness=0U;

  for(uint8_t h=0;h<5U;h++){
    if(pct<START[h]||pct>FADEEND[h])continue;
    active=true;

    if(pct<=ARRIVE[h]){
      float t=(pct-START[h])/(ARRIVE[h]-START[h]);
      posPct=gw24Lerp(0.0f,52.0f,t); brightness=255U; return;
    }
    if(pct<=BOUNCE[h]){
      float t=(pct-ARRIVE[h])/(BOUNCE[h]-ARRIVE[h]);
      posPct=gw24Lerp(52.0f,41.0f,t); brightness=255U; return;
    }
    if(pct<=REHIT[h]){
      float t=(pct-BOUNCE[h])/(REHIT[h]-BOUNCE[h]);
      posPct=gw24Lerp(41.0f,52.0f,t); brightness=255U; return;
    }

    float t=(pct-REHIT[h])/(FADEEND[h]-REHIT[h]);
    posPct=gw24Lerp(52.0f,0.0f,t);
    int bri=(int)((1.0f-t)*255.0f);
    if(bri<0)bri=0;
    if(bri>255)bri=255;
    brightness=(uint8_t)bri;
    return;
  }
}
static void gw24RenderChannel(
  CRGB *out,bool mirror,uint16_t count,uint16_t fillCount,
  bool hammerActive,float hammerPosPct,uint8_t hammerBrightness
){
  fill_solid(out,count,CRGB::Black);
  if(fillCount>count)fillCount=count;

  for(uint16_t logical=0;logical<fillCount;logical++){
    uint16_t physical=mirror?(count-1U-logical):logical;
    out[physical]=gw24Gradient(logical,fillCount);
  }

  if(hammerActive&&hammerBrightness>0U){
    int hammerStart=(int)roundf((hammerPosPct/100.0f)*(float)count);
    if(hammerStart<0)hammerStart=0;
    if(hammerStart>(int)count-1)hammerStart=(int)count-1;

    for(uint8_t k=0;k<10U;k++){
      int logical=hammerStart+(int)k;
      if(logical<0||logical>=(int)count)continue;
      CRGB c=gw24Gradient(k,10U);
      if(hammerBrightness<255U)c.nscale8_video(hammerBrightness);
      uint16_t physical=mirror?(count-1U-(uint16_t)logical):(uint16_t)logical;
      out[physical]=c;
    }
  }
}
static void gw24Render(uint32_t elapsed,uint16_t count){
  if(count<1U){gw2029Done=true;return;}

  if(elapsed>=12000UL){
    gw24RenderChannel(leds1,false,count,count,false,0.0f,0U);
    gw24RenderChannel(leds2,true,count,count,false,0.0f,0U);
    gw2029Done=true;
    return;
  }

  float pct=((float)elapsed/12000.0f)*100.0f;
  uint16_t fillCount=gw24FillCount(pct,count);
  bool active;
  float posPct;
  uint8_t brightness;
  gw24HammerFrame(pct,active,posPct,brightness);

  gw24RenderChannel(leds1,false,count,fillCount,active,posPct,brightness);
  gw24RenderChannel(leds2,true,count,fillCount,active,posPct,brightness);
}

// ---------------- W25 DUAL HAMMER 5 LED ----------------
static inline float gw25Clamp(float v){
  return v<0.0f?0.0f:(v>1.0f?1.0f:v);
}
static inline float gw25Ease(float t){
  t=gw25Clamp(t);
  return t*t*(3.0f-2.0f*t);
}
static inline float gw25Gauss(float d,float w){
  if(w<.0001f)w=.0001f;
  float x=d/w;
  return expf(-.5f*x*x);
}
static void gw25BuildHammer(
  CRGB *out,uint16_t n,uint32_t globalHit,float q
){
  if(n==0U)return;

  const uint8_t BS=5U;
  const uint16_t blocks=(n+BS-1U)/BS;
  const int impact=(int)floorf((float)n*.43f);
  const int maxAge=(int)blocks+3;
  const CRGB palette[3]={
    CRGB(255,0,0),
    CRGB(47,143,255),
    CRGB(255,50,0)
  };

  fill_solid(out,n,CRGB::Black);

  for(int age=0;age<maxAge;age++){
    if((int32_t)globalHit-age<0)continue;

    uint32_t bornHit=globalHit-(uint32_t)age;
    uint8_t colorIndex=(uint8_t)((bornHit/blocks)%3U);
    float startLed=0.0f;

    if(age==0){
      int incomingTarget=impact-BS;
      if(incomingTarget<0)incomingTarget=0;

      float pos;
      if(q<.52f)pos=gw25Ease(q/.52f)*(float)incomingTarget;
      else if(q<.68f)pos=(float)incomingTarget-8.0f*gw25Ease((q-.52f)/.16f);
      else if(q<.82f)pos=(float)(incomingTarget-8)+8.0f*gw25Ease((q-.68f)/.14f);
      else pos=(float)incomingTarget+(float)BS*gw25Ease((q-.82f)/.18f);

      startLed=roundf(pos);
    } else {
      float shove=q>=.82f?(float)BS*gw25Ease((q-.82f)/.18f):0.0f;
      startLed=(float)impact+(float)(age-1)*(float)BS+shove;
    }

    if(startLed>=(float)n)continue;
    int base=(int)roundf(startLed);

    for(uint8_t k=0;k<BS;k++){
      int p=base+k;
      if(p<0||p>=(int)n)continue;
      out[p]=palette[colorIndex];
    }
  }
}
static void gw25BuildW42(
  CRGB *out1,CRGB *out2,uint16_t n,uint32_t runMs
){
  if(n==0U)return;

  const float RUN_CYCLE_MS=2800.0f;
  const CRGB AMBER(255,50,0);

  float u=fmodf((float)runMs,RUN_CYCLE_MS)/RUN_CYCLE_MS;
  float q=u<.5f?gw25Ease(u*2.0f):gw25Ease((1.0f-u)*2.0f);

  float leftPos=.02f+.48f*q;
  float rightPos=.98f-.48f*q;
  float impactBoost=fmaxf(0.0f,1.0f-fabsf(q-1.0f)*8.0f);
  float den=(float)((uint32_t)n*2UL-1UL);

  for(uint16_t i=0;i<n;i++){
    float p1=(float)i/den;
    float p2=(float)((uint32_t)n+(uint32_t)(n-1U-i))/den;

    float a1=gw25Gauss(p1-leftPos,.045f);
    float b1=gw25Gauss(p1-rightPos,.045f);
    float imp1=gw25Gauss(p1-.5f,.09f)*impactBoost*.75f;
    float br1=gw25Clamp(fmaxf(a1,b1)+imp1);

    float a2=gw25Gauss(p2-leftPos,.045f);
    float b2=gw25Gauss(p2-rightPos,.045f);
    float imp2=gw25Gauss(p2-.5f,.09f)*impactBoost*.75f;
    float br2=gw25Clamp(fmaxf(a2,b2)+imp2);

    if(br1<.02f)br1=0.0f;
    if(br2<.02f)br2=0.0f;

    CRGB c1=AMBER,c2=AMBER;
    c1.nscale8_video((uint8_t)roundf(br1*255.0f));
    c2.nscale8_video((uint8_t)roundf(br2*255.0f));
    out1[i]=c1;
    out2[i]=c2;
  }
}
static void gw25Render(uint32_t elapsed,uint16_t count){
  if(count==0U){gw2029Done=true;return;}

  const uint32_t HIT_MS=1150UL;
  const uint8_t BS=5U;
  const uint16_t blocks=(count+BS-1U)/BS;
  const uint32_t FILL_MS=HIT_MS*(uint32_t)blocks*3UL;
  const uint32_t HOLD_MS=650UL;
  const uint32_t RUN_MS=5600UL;
  const uint32_t TOTAL_MS=FILL_MS+HOLD_MS+RUN_MS;

  if(elapsed>=TOTAL_MS){
    fill_solid(leds1,count,CRGB::Black);
    fill_solid(leds2,count,CRGB::Black);
    gw2029Done=true;
    return;
  }

  if(elapsed<FILL_MS){
    uint32_t globalHit=elapsed/HIT_MS;
    float q=(float)(elapsed%HIT_MS)/(float)HIT_MS;
    gw25BuildHammer(leds1,count,globalHit,q);
    gw25BuildHammer(leds2,count,globalHit,q);
  }
  else if(elapsed<FILL_MS+HOLD_MS){
    fill_solid(leds1,count,CRGB(255,50,0));
    fill_solid(leds2,count,CRGB(255,50,0));
  }
  else{
    uint32_t runMs=elapsed-FILL_MS-HOLD_MS;
    gw25BuildW42(leds1,leds2,count,runMs);
  }
}

// ---------------- W26-W29: exact source 5x6s/3repeat ----------------
static void gw2629Render(uint8_t welcomeNo,uint32_t elapsed,uint16_t count){
  fill_solid(leds1,count,CRGB::Black);
  fill_solid(leds2,count,CRGB::Black);

  if(elapsed>=30000UL){
    gw2029Done=true;
    return;
  }

  uint8_t phase=(uint8_t)(elapsed/6000UL);
  float p=(float)(elapsed%6000UL)/6000.0f;
  float cyc=p*3.0f;
  uint8_t rep=(uint8_t)min(2,(int)cyc);
  float q=cyc-rep;

  // Source mapping: W30->06, W29->07, W28->08, W27->09, W26->10.
  uint8_t modeIndex=(uint8_t)(35U-welcomeNo);
  uint8_t fxId=(uint8_t)(modeIndex*5U+phase);

  static const CRGB palettes[10][3]={
    {CRGB(234,252,255),CRGB(56,216,255),CRGB(255,53,83)},
    {CRGB(255,178,47),CRGB(255,255,255),CRGB(255,102,41)},
    {CRGB(32,233,255),CRGB(138,92,255),CRGB(255,66,207)},
    {CRGB(255,255,255),CRGB(96,207,255),CRGB(53,108,255)},
    {CRGB(255,49,72),CRGB(255,255,255),CRGB(255,139,55)},
    {CRGB(36,255,211),CRGB(47,201,255),CRGB(122,93,255)},
    {CRGB(255,47,73),CRGB(255,117,135),CRGB(255,255,255)},
    {CRGB(255,255,255),CRGB(81,227,255),CRGB(255,72,96)},
    {CRGB(0,255,208),CRGB(0,191,255),CRGB(255,255,255)},
    {CRGB(255,255,255),CRGB(154,88,255),CRGB(53,223,255)}
  };

  uint32_t totalVirtual=(uint32_t)count*2U;
  float denom=totalVirtual>1U?(float)(totalVirtual-1U):1.0f;

  for(uint32_t vg=0;vg<totalVirtual;vg++){
    float sourceG=((float)vg*139.0f)/denom;
    float bri=gw3135FxValue(fxId,q,rep,sourceG);
    if(bri<=.01f)continue;

    CRGB c=(phase==2U)
      ? gw3135Rainbow(sourceG,p)
      : palettes[modeIndex][rep%3U];

    c.nscale8_video((uint8_t)(255.0f*gw3039c(bri)));

    if(vg<count)leds1[vg]+=c;
    else leds2[vg-count]+=c;
  }
}

static bool gw2029DirectSourceActive(){
  if(selectedWelcome<20U||selectedWelcome>29U)return false;
  uint8_t m=mappedWelcome[selectedWelcome];
  return !(m>=1U&&m<=210U);
}
static void gw2029ResetRuntime(){
  gw2029Done=false;
}
static void gw2029RenderSelected(
  uint8_t welcomeNo,uint32_t tMs,uint16_t count
){
  gw2029Done=false;

  if(welcomeNo>=20U&&welcomeNo<=23U)gw2023Render(welcomeNo,tMs,count);
  else if(welcomeNo==24U)gw24Render(tMs,count);
  else if(welcomeNo==25U)gw25Render(tMs,count);
  else if(welcomeNo>=26U&&welcomeNo<=29U)gw2629Render(welcomeNo,tMs,count);
  else return;

  memcpy(leds3,leds1,sizeof(CRGB)*count);
  memcpy(leds4,leds2,sizeof(CRGB)*count);
}



// ============================================================================
// WELCOME 10-19 — SOURCE ORIGINAL RECOVERY + GLOBAL SPEED
//
// W10-W13 source:
// - 5 fase x 3000 ms = 15 detik virtual.
// - arah utama RIGHT -> LEFT pada virtual CH2 -> CH1.
// - tepat satu fase strobo per blok di tiap Welcome.
//
// W14-W19 source user:
// - W19 types 20..24
// - W18 types 25..29
// - W17 types 30..34
// - W16 types 35..39
// - W15 types 40..44
// - W14 types 45..49
// - source SPEED_MUL=2.15, TAIL_LEN=23, SEG_MS=4600,
//   BLEND_START=.78, SEN_DURATION=3.4 detik.
//
// Semua timeline membaca welcomeAnimClockVirtual, jadi SPEED GLOBAL live.
// CH3=CH1, CH4=CH2.
// ============================================================================

static bool gw1019Done = false;

// ---------------- W10-W13 ----------------
static inline float gw1013Clamp(float x) {
  return x < 0.0f ? 0.0f : (x > 1.0f ? 1.0f : x);
}
static inline float gw1013Smooth(float x) {
  x = gw1013Clamp(x);
  return x * x * (3.0f - 2.0f * x);
}
static inline float gw1013Fract(float x) {
  return x - floorf(x);
}
static inline float gw1013Tri(float x) {
  float f = gw1013Fract(x);
  return f < 0.5f ? f * 2.0f : (1.0f - f) * 2.0f;
}
static inline uint32_t gw1013Hash(uint32_t x) {
  x ^= x >> 16;
  x *= 0x7feb352dUL;
  x ^= x >> 15;
  x *= 0x846ca68bUL;
  x ^= x >> 16;
  return x;
}
static CRGB gw1013Color(uint8_t welcomeMode, uint8_t phase) {
  switch (welcomeMode) {
    case 10: {
      static const CRGB p[5] = {
        CRGB(245,245,255), CRGB(40,150,255), CRGB(255,40,40),
        CRGB(255,255,255), CRGB(180,70,255)
      };
      return p[phase % 5U];
    }
    case 11: {
      static const CRGB p[5] = {
        CRGB(0,235,220), CRGB(255,70,180), CRGB(255,255,255),
        CRGB(80,130,255), CRGB(255,45,45)
      };
      return p[phase % 5U];
    }
    case 12: {
      static const CRGB p[5] = {
        CRGB(255,255,255), CRGB(190,40,255), CRGB(30,200,255),
        CRGB(255,55,55), CRGB(120,255,120)
      };
      return p[phase % 5U];
    }
    default: {
      static const CRGB p[5] = {
        CRGB(255,50,50), CRGB(80,170,255), CRGB(255,255,255),
        CRGB(220,50,255), CRGB(20,235,190)
      };
      return p[phase % 5U];
    }
  }
}
static uint8_t gw1013StrobePhase(uint8_t welcomeMode) {
  switch (welcomeMode) {
    case 10: return 2U;
    case 11: return 3U;
    case 12: return 1U;
    default: return 4U;
  }
}
static inline void gw1013SetVirtual(
  uint16_t count, int g, const CRGB &c, uint8_t level
) {
  const int total = (int)count * 2;
  if (g < 0 || g >= total || level == 0U) return;

  CRGB out = c;
  out.nscale8_video(level);

  // Source path RIGHT -> LEFT:
  // g 0..N-1 = CH2 outer kanan -> center
  // g N..2N-1 = CH1 center -> outer kiri
  if (g < (int)count) {
    int idx = (int)count - 1 - g;
    leds2[idx] = out;
  } else {
    int j = g - (int)count;
    int idx = (int)count - 1 - j;
    leds1[idx] = out;
  }
}
static void gw1013DrawBar(
  uint16_t count, float center, float width,
  const CRGB &color, bool softTail
) {
  const int total = (int)count * 2;
  int a = (int)floorf(center - width * 0.5f);
  int b = (int)ceilf(center + width * 0.5f);

  for (int g = a; g <= b; g++) {
    if (g < 0 || g >= total) continue;
    float d = fabsf((float)g - center);
    float half = width * 0.5f;
    float q = 1.0f - d / (half + 0.001f);
    q = gw1013Clamp(q);

    uint8_t level = softTail
      ? (uint8_t)(70.0f + 185.0f * powf(q, 0.45f))
      : 255U;

    gw1013SetVirtual(count, g, color, level);
  }
}
static void gw1013DrawTail(
  uint16_t count, float head, float bodyWidth,
  float tailLen, const CRGB &color
) {
  const int total = (int)count * 2;

  for (int g = (int)(head - bodyWidth + 1.0f); g <= (int)head; g++) {
    if (g >= 0 && g < total) gw1013SetVirtual(count, g, color, 255U);
  }

  for (int t = 1; t <= (int)tailLen; t++) {
    int g = (int)(head - bodyWidth - (float)t);
    if (g < 0 || g >= total) continue;
    float q = 1.0f - (float)t / (tailLen + 1.0f);
    uint8_t level = (uint8_t)(25.0f + 190.0f * q * q);
    gw1013SetVirtual(count, g, color, level);
  }
}
static void gw1013RenderStrobe(
  uint16_t count, uint8_t welcomeMode,
  float localT, const CRGB &color
) {
  const int total = (int)count * 2;
  const int blockLen = 8 + ((welcomeMode - 10U) * 2U);
  const int blocks = (total + blockLen - 1) / blockLen;

  const uint32_t tick = (uint32_t)floorf(localT * 36.0f);
  const bool flashOn = ((tick & 1U) == 0U);
  if (!flashOn) return;

  int lead = (int)((tick / 2U) % (uint32_t)max(1, blocks));

  for (int b = 0; b < blocks; b++) {
    uint32_t h = gw1013Hash(
      (uint32_t)b * 131U +
      tick * 977U +
      (uint32_t)welcomeMode * 7919U
    );
    bool randomHit = ((h % 100U) < 34U);
    bool leadHit =
      (b == lead) ||
      (b == ((lead + blocks - 1) % blocks));

    if (!(randomHit || leadHit)) continue;

    int start = b * blockLen;
    int end = min(total, start + blockLen);
    uint8_t level = leadHit ? 255U : 190U;

    for (int g = start; g < end; g++) {
      gw1013SetVirtual(count, g, color, level);
    }
  }
}
static void gw1013RenderNormal(
  uint16_t count, uint8_t welcomeMode,
  uint8_t phase, float localT,
  const CRGB &color
) {
  const float total = (float)count * 2.0f;
  const float N = (float)count;

  switch (phase) {
    case 0: {
      float q = gw1013Fract(
        localT * (3.0f + 0.25f * (welcomeMode - 10U))
      );
      float head = gw1013Smooth(q) * (total + 24.0f) - 4.0f;
      gw1013DrawTail(
        count, head,
        9.0f + (welcomeMode - 10U),
        18.0f, color
      );
      break;
    }

    case 1: {
      float q = gw1013Fract(
        localT * (3.6f + 0.2f * (welcomeMode - 10U))
      );
      float head = gw1013Smooth(q) * (total + 38.0f) - 8.0f;
      gw1013DrawTail(count, head, 10.0f, 14.0f, color);
      gw1013DrawTail(count, head - N * 0.55f, 8.0f, 11.0f, color);
      break;
    }

    case 2: {
      float cyc = localT * (2.8f + 0.15f * (welcomeMode - 10U));
      float tr = gw1013Tri(cyc);
      float head = tr * (total + 18.0f);
      gw1013DrawTail(count, head, 11.0f, 20.0f, color);
      break;
    }

    case 3: {
      float q = gw1013Fract(
        localT * (3.2f + 0.18f * (welcomeMode - 10U))
      );
      float head = gw1013Smooth(q) * (total + 55.0f) - 8.0f;

      for (int k = 0; k < 3; k++) {
        float c = head - k * (N * 0.42f);
        gw1013DrawBar(
          count, c,
          10.0f + k * 2.0f,
          color, true
        );
      }
      break;
    }

    default: {
      float q = gw1013Fract(
        localT * (2.9f + 0.2f * (welcomeMode - 10U))
      );
      float center = gw1013Smooth(q) * (total + 34.0f) - 10.0f;
      gw1013DrawBar(
        count, center,
        22.0f + (welcomeMode - 10U) * 2.0f,
        color, true
      );
      gw1013DrawBar(
        count, center - N * 0.62f,
        12.0f, color, true
      );
      break;
    }
  }
}
static void gw1013Render(
  uint8_t welcomeNo, uint32_t elapsed, uint16_t count
) {
  fill_solid(leds1, count, CRGB::Black);
  fill_solid(leds2, count, CRGB::Black);

  if (count < 1U) {
    gw1019Done = true;
    return;
  }

  if (elapsed >= 15000UL) {
    gw1019Done = true;
    return;
  }

  uint8_t phase = (uint8_t)(elapsed / 3000UL);
  if (phase >= 5U) phase = 4U;

  uint32_t inPhase = elapsed - (uint32_t)phase * 3000UL;
  float localT = (float)inPhase / 3000.0f;
  CRGB color = gw1013Color(welcomeNo, phase);

  if (phase == gw1013StrobePhase(welcomeNo)) {
    gw1013RenderStrobe(count, welcomeNo, localT, color);
  } else {
    gw1013RenderNormal(count, welcomeNo, phase, localT, color);
  }
}

// ---------------- W14-W19 pixel-equivalent source primitives 20..49 ----------------

// FIX11: old expanded helper removed; shared W14..W23 engine is used.



// FIX11: old expanded helper removed; shared W14..W23 engine is used.


static void gw1419Render(
  uint8_t welcomeNo, uint32_t elapsed, uint16_t count
){
  gw1423SharedRender(welcomeNo, elapsed, count, gw1019Done);
}

static bool gw1019DirectSourceActive(){
  if(selectedWelcome<10U||selectedWelcome>19U)return false;
  uint8_t m=mappedWelcome[selectedWelcome];
  return !(m>=1U&&m<=210U);
}
static void gw1019ResetRuntime(){
  gw1019Done=false;
}
static void gw1019RenderSelected(
  uint8_t welcomeNo,uint32_t tMs,uint16_t count
){
  gw1019Done=false;

  if(welcomeNo>=10U&&welcomeNo<=13U)
    gw1013Render(welcomeNo,tMs,count);
  else if(welcomeNo>=14U&&welcomeNo<=19U)
    gw1419Render(welcomeNo,tMs,count);
  else
    return;

  // GLOBAL 4CH lurus.
  memcpy(leds3,leds1,sizeof(CRGB)*count);
  memcpy(leds4,leds2,sizeof(CRGB)*count);
}




// ============================================================================
// WELCOME 3-9 — SOURCE RECOVERY + GLOBAL SPEED
//
// W3 source lama:
//   10 LED, 3x flash per posisi maju, lalu 10 random block events.
// W4 source lama:
//   5 LED dari dua sisi menuju tengah, lalu white full strobe 20 toggle.
// W5 source lama:
//   satu LED putih random CH1+CH2, ON/OFF, 80 kali.
// W6 source FIX67:
//   SEN intro 2.4s + core 15s + SEN outro 2.4s = 19.8s.
// W7 source Ceremony Alis Vario:
//   fase 1..8, termasuk strobe kiri/kanan, flow, stack 5 LED, hold.
// W8 source dual-color 14 fase:
//   setiap fase diulang 2x seperti FIX76.
// W9 source lama:
//   merah fill 5 LED bertambah/berkurang, tiap ukuran 5x flash.
//
// Semua timeline memakai welcomeAnimClockVirtual => SPEED GLOBAL.
// CH3=CH1 dan CH4=CH2.
// ============================================================================

static bool gw0309Done = false;

static inline float gw0309Clamp(float x) {
  return x < 0.0f ? 0.0f : (x > 1.0f ? 1.0f : x);
}
static inline float gw0309Smooth(float x) {
  x = gw0309Clamp(x);
  return x*x*(3.0f-2.0f*x);
}
static inline float gw0309Fract(float x) {
  return x-floorf(x);
}
static inline float gw0309Gauss(float x,float c,float w) {
  if(w<0.000001f)w=0.000001f;
  float d=(x-c)/w;
  return expf(-0.5f*d*d);
}
static inline float gw0309Ease(float x) {
  return -(cosf(PI*x)-1.0f)*0.5f;
}
static uint32_t gw0309Hash32(uint32_t x) {
  x ^= x >> 16;
  x *= 0x7feb352dUL;
  x ^= x >> 15;
  x *= 0x846ca68bUL;
  x ^= x >> 16;
  return x;
}
static CRGB gw0309HashColor(uint32_t seed) {
  return CHSV((uint8_t)gw0309Hash32(seed),255,255);
}

// ---------------- W3 ----------------
static void gw3Render(uint32_t tMs,uint16_t count) {
  fill_solid(leds1,count,CRGB::Black);
  fill_solid(leds2,count,CRGB::Black);
  if(count<1U){gw0309Done=true;return;}

  const uint16_t seg=(count<10U)?count:10U;
  const uint16_t jump=1U;
  const uint32_t perStep=1200UL; // 6 substep x 200ms
  uint16_t positions=0U;
  for(uint16_t p=0U;p<count;p=(uint16_t)(p+seg+jump))positions++;

  uint32_t phase0Ms=(uint32_t)positions*perStep;

  if(tMs<phase0Ms){
    uint32_t posIndex=tMs/perStep;
    uint32_t local=tMs%perStep;
    uint8_t sub=(uint8_t)(local/200UL);
    if((sub&1U)==0U){
      int start=(int)posIndex*(int)(seg+jump);
      CRGB c=gw0309HashColor(3000UL+posIndex*17UL+sub);
      for(uint16_t j=0;j<seg;j++){
        int idx=start+(int)j;
        if(idx>=0&&idx<(int)count){
          leds1[idx]=c;
          leds2[idx]=c;
        }
      }
    }
    return;
  }

  uint32_t phase1=tMs-phase0Ms;
  const uint32_t eventMs=400UL; // source ON 200 / OFF 200
  if(phase1>=10UL*eventMs){
    gw0309Done=true;
    return;
  }

  uint8_t event=(uint8_t)(phase1/eventMs);
  uint32_t local=phase1%eventMs;
  if(local<200UL){
    uint16_t blocks=count/seg; if(blocks<1U)blocks=1U;
    uint32_t h=gw0309Hash32(3300UL+event*97UL);
    uint8_t side=(uint8_t)(h&1U);
    uint16_t block=(uint16_t)((h>>8)%blocks);
    int start=(int)block*(int)seg;
    if(start+(int)seg>(int)count)start=(int)count-(int)seg;
    if(start<0)start=0;
    CRGB c=gw0309HashColor(h>>16);
    CRGB *dst=side==0U?leds1:leds2;
    for(uint16_t j=0;j<seg;j++){
      int idx=start+(int)j;
      if(idx>=0&&idx<(int)count)dst[idx]=c;
    }
  }
}

// ---------------- W4 ----------------
static void gw4Render(uint32_t tMs,uint16_t count) {
  fill_solid(leds1,count,CRGB::Black);
  fill_solid(leds2,count,CRGB::Black);
  if(count<1U){gw0309Done=true;return;}

  const uint16_t seg=(count<5U)?count:5U;
  uint16_t steps=0U;
  for(uint16_t pos=0U;pos<count/2U;pos=(uint16_t)(pos+3U))steps++;
  uint32_t phase0Ms=(uint32_t)steps*40UL;

  if(tMs<phase0Ms){
    uint16_t step=(uint16_t)(tMs/40UL);
    int pos=(int)step*3;
    CRGB c=gw0309HashColor(4000UL+step*43UL);
    int p1=pos;
    int p2=(int)count-pos-(int)seg;

    if(p1>=0&&p1+(int)seg<=(int)count){
      fill_solid(&leds1[p1],seg,c);
      fill_solid(&leds2[p1],seg,c);
    }

    // Persis source lama: p2 ditulis ke CH2.
    if(p2>=0&&p2+(int)seg<=(int)count){
      fill_solid(&leds2[p2],seg,c);
    }
    return;
  }

  uint32_t phase1=tMs-phase0Ms;
  if(phase1>=400UL){gw0309Done=true;return;}
  uint8_t toggle=(uint8_t)(phase1/20UL);
  if((toggle&1U)==0U){
    fill_solid(leds1,count,CRGB::White);
    fill_solid(leds2,count,CRGB::White);
  }
}

// ---------------- W5 ----------------
static void gw5Render(uint32_t tMs,uint16_t count) {
  fill_solid(leds1,count,CRGB::Black);
  fill_solid(leds2,count,CRGB::Black);
  if(count<1U){gw0309Done=true;return;}

  const uint32_t totalMs=80UL*20UL;
  if(tMs>=totalMs){gw0309Done=true;return;}

  uint32_t cycle=tMs/20UL;
  uint32_t local=tMs%20UL;
  if(local<10UL){
    uint16_t pos=(uint16_t)(gw0309Hash32(5000UL+cycle*101UL)%count);
    leds1[pos]=CRGB::White;
    leds2[pos]=CRGB::White;
  }
}

// ---------------- W6 exact FIX67 formulas ----------------
static const float GW6_PI = 3.14159265358979323846f;
static const float GW6_PHASE_X = 0.75f;
static const float GW6_MASTER_SPEED = 2.200000f;
static const float GW6_SEN_DURATION = 2.400000f;
static const float GW6_CORE_DURATION = 15.000000f;
static const float GW6_TOTAL_DURATION = 19.800000f;

static inline float gw6Clamp(float x) {
  return x<0.0f?0.0f:(x>1.0f?1.0f:x);
}
static inline float gw6Fract(float x) {
  return x-floorf(x);
}
static inline float gw6Lerp(float a,float b,float t) {
  return a+(b-a)*t;
}
static inline float gw6Gauss(float x,float c,float w) {
  if(w<0.000001f)w=0.000001f;
  float d=(x-c)/w;
  return expf(-0.5f*d*d);
}
static inline float gw6Ease(float x) {
  return -(cosf(GW6_PI*x)-1.0f)*0.5f;
}
static inline void gw6MixColor(
  float ar,float ag,float ab,
  float br,float bg,float bb,
  float t,
  float &r,float &g,float &b
){
  r=gw6Lerp(ar,br,t);
  g=gw6Lerp(ag,bg,t);
  b=gw6Lerp(ab,bb,t);
}
static GW6Shape gw6MotionShape(uint8_t block,uint8_t tail,uint16_t total) {
  float tt=total>0?(float)total:1.0f;
  float bn=(block>0?(float)block:1.0f)/tt;
  float tn=(float)tail/tt;
  GW6Shape s;
  s.head=fmaxf(1.0f/tt,bn*.35f);
  s.headPing=fmaxf(1.0f/tt,bn*.30f);
  s.back=fmaxf(1.0f/tt,(bn+tn)*1.07f);
  s.backPing=fmaxf(1.0f/tt,bn+tn);
  s.broad=fmaxf(1.0f/tt,bn*.50f+tn*.50f);
  float edgeDen=fmaxf(1.0f/tt,bn*.35f);
  s.edgeK=fmaxf(10.0f,fminf(80.0f,1.2f/edgeDen));
  float freqDen=fmaxf(1.0f,(float)block+(float)tail*.30f);
  s.freq=fmaxf(.35f,fminf(3.5f,11.2f/freqDen));
  float tailDen=fmaxf(1.0f,(float)block+(float)tail);
  s.tailMix=fmaxf(0.0f,fminf(.35f,((float)tail/tailDen)*.32f));
  return s;
}
static inline float gw6ShapedWave(float v,const GW6Shape &s) {
  float x=gw6Clamp(v);
  return gw6Clamp(gw6Lerp(x,sqrtf(x),s.tailMix));
}
static float gw6MotionBreath(float p,float t,uint16_t count) {
  GW6Shape s=gw6MotionShape(10,4,count);
  const float speed=GW6_MASTER_SPEED*1.260140f;
  float pp=1.0f-p;
  float v=(.5f+.5f*sinf(2.0f*GW6_PI*(pp*2.0f*s.freq-t*speed*.12f)))*
          (.55f+.45f*sinf(t*.33f));
  return gw6ShapedWave(v,s);
}
static float gw6MotionRibbon(float p,float t,uint16_t count) {
  GW6Shape s=gw6MotionShape(10,4,count);
  const float speed=GW6_MASTER_SPEED*1.084617f;
  float pp=1.0f-p;
  float ce=gw6Fract(t*speed*.13f);
  float wobAmp=fminf(.08f,s.broad*.55f);
  float wob=wobAmp*sinf(t*1.2f+pp*8.0f*s.freq);
  float center=gw6Clamp(ce+wob);
  float width=fmaxf(s.broad,.012f);
  return gw6Gauss(pp,center,width);
}
static float gw6StrobeBlockBrightness(
  uint16_t ledIndex,int targetBlock,uint8_t blockLen,uint8_t tailLen,uint16_t ledCount
){
  if(targetBlock<0||ledCount==0U)return 0.0f;
  uint16_t st=(uint16_t)(targetBlock*blockLen);
  int e=(int)st+(int)blockLen-1;
  if(e>(int)ledCount-1)e=(int)ledCount-1;
  uint16_t en=(uint16_t)e;
  if(ledIndex>=st&&ledIndex<=en)return 1.0f;
  if(tailLen==0U)return 0.0f;
  uint16_t d=ledIndex<st?(uint16_t)(st-ledIndex):(uint16_t)(ledIndex-en);
  if(d>tailLen)return 0.0f;
  return gw6Clamp(1.0f-(float)d/((float)tailLen+1.0f));
}
static void gw6GetPhaseColor(uint8_t ch,uint8_t index,float &r,float &g,float &b) {
  static const uint8_t colorsA[3][3]={
    {234,246,255},{90,214,255},{201,13,13}
  };
  static const uint8_t colorsB[3][3]={
    {255,42,42},{4,46,215},{24,219,10}
  };
  const uint8_t (*c)[3]=(ch==0U)?colorsA:colorsB;
  index%=3U;
  r=c[index][0];g=c[index][1];b=c[index][2];
}
static GW6Eval gw6EvalCore(
  float elapsed,float p,uint8_t ch,uint16_t ledIndex,uint16_t count
){
  GW6Eval z;z.brightness=0.0f;z.r=z.g=z.b=0.0f;
  const float baseScale=.6f;
  const float breathDisplayDuration=6.6f;
  const float ribbonDisplayDuration=5.4f;

  if(elapsed<breathDisplayDuration){
    float motionT=elapsed/baseScale;
    z.brightness=gw6MotionBreath(p,motionT,count);
    gw6GetPhaseColor(ch,1,z.r,z.g,z.b);
  }else if(elapsed<breathDisplayDuration+ribbonDisplayDuration){
    float localDisp=elapsed-breathDisplayDuration;
    float motionT=localDisp/baseScale;
    z.brightness=gw6MotionRibbon(p,motionT,count);
    gw6GetPhaseColor(ch,2,z.r,z.g,z.b);

    if(motionT<GW6_PHASE_X){
      float qr,qg,qb;
      float qBrightness=gw6MotionBreath(p,11.0f+motionT,count);
      gw6GetPhaseColor(ch,1,qr,qg,qb);
      float m=motionT/GW6_PHASE_X;
      z.brightness=gw6Lerp(qBrightness,z.brightness,m);
      gw6MixColor(qr,qg,qb,z.r,z.g,z.b,m,z.r,z.g,z.b);
    }
  }else{
    float local=elapsed-12.0f;
    if(local<0.0f)local=0.0f;
    if(local>3.0f)local=3.0f;
    const uint8_t blockLen=10U,tailLen=4U;
    uint16_t blocks=(uint16_t)(((uint32_t)count+blockLen-1U)/blockLen);
    if(blocks<1U)blocks=1U;
    uint32_t step=(uint32_t)floorf(local/.15f);
    int target=(int)(step%blocks);
    z.brightness=gw6StrobeBlockBrightness(ledIndex,target,blockLen,tailLen,count);
    gw6GetPhaseColor(ch,(uint8_t)(step%3U),z.r,z.g,z.b);
  }
  z.brightness=gw6Clamp(z.brightness);
  return z;
}
static GW6Eval gw6EvalSen(float p,float elapsed,bool outro) {
  GW6Eval z;
  float u=gw6Clamp(elapsed/GW6_SEN_DURATION);
  float pass=gw6Fract(u*2.0f);
  float grow=pass<.62f?gw6Ease(pass/.62f):1.0f-gw6Ease((pass-.62f)/.38f);
  float v=0.0f;

  if(!outro){
    float sig=1.0f/(1.0f+expf(-(grow-p)*42.0f));
    v=gw6Clamp(sig*.8f+gw6Gauss(p,grow,.025f)*.6f);
  }else{
    float ce1=gw6Fract(pass)*1.3f-.15f;
    float d1=p-ce1;
    float a=gw6Gauss(p,ce1,d1>0.0f?.03f:.12f);
    float ce2=gw6Fract(pass+.48f)*1.3f-.15f;
    float d2=p-ce2;
    float b=gw6Gauss(p,ce2,d2>0.0f?.03f:.12f)*.85f;
    v=fmaxf(a,b);
  }

  if(u>.9f)v*=1.0f-gw6Ease((u-.9f)/.1f);
  z.brightness=gw6Clamp(v);
  z.r=255.0f;z.g=50.0f;z.b=0.0f;
  return z;
}
static CRGB gw6ToLed(const GW6Eval &z) {
  float k=gw6Clamp(z.brightness);
  int rr=(int)(z.r*k),gg=(int)(z.g*k),bb=(int)(z.b*k);
  rr=constrain(rr,0,255);gg=constrain(gg,0,255);bb=constrain(bb,0,255);
  return CRGB((uint8_t)rr,(uint8_t)gg,(uint8_t)bb);
}
static void gw6Render(uint32_t tMs,uint16_t count) {
  float elapsed=(float)tMs*.001f;
  if(elapsed>=GW6_TOTAL_DURATION){
    fill_solid(leds1,count,CRGB::Black);
    fill_solid(leds2,count,CRGB::Black);
    gw0309Done=true;
    return;
  }

  bool intro=elapsed<GW6_SEN_DURATION;
  bool core=elapsed>=GW6_SEN_DURATION &&
            elapsed<(GW6_SEN_DURATION+GW6_CORE_DURATION);
  float coreElapsed=elapsed-GW6_SEN_DURATION;
  float outroElapsed=elapsed-(GW6_SEN_DURATION+GW6_CORE_DURATION);
  uint32_t pathCount=(uint32_t)count*2U;
  float pathDen=pathCount>1U?(float)(pathCount-1U):1.0f;

  for(uint16_t i=0;i<count;i++){
    GW6Eval a,b;
    if(intro){
      float pA=(float)i/pathDen;
      float pB=(float)((uint32_t)count+(uint32_t)(count-1U-i))/pathDen;
      a=gw6EvalSen(pA,elapsed,false);
      b=gw6EvalSen(pB,elapsed,false);
    }else if(core){
      float p=count<=1U?.5f:(float)i/(float)(count-1U);
      a=gw6EvalCore(coreElapsed,p,0U,i,count);
      b=gw6EvalCore(coreElapsed,p,1U,i,count);
    }else{
      float pA=(float)i/pathDen;
      float pB=(float)((uint32_t)count+(uint32_t)(count-1U-i))/pathDen;
      a=gw6EvalSen(pA,outroElapsed,true);
      b=gw6EvalSen(pB,outroElapsed,true);
    }
    leds1[i]=gw6ToLed(a);
    leds2[i]=gw6ToLed(b);
  }
}

// ---------------- W7 source Ceremony Alis Vario ----------------
static inline float gw7BlockDistance(float dist,float width) {
  if(dist>=width)return 0.0f;
  return cosf((dist/width)*(PI/2.0f));
}
static uint32_t gw7StackDurationTotal(uint16_t count,uint8_t blocks) {
  uint32_t total=0UL;
  if(blocks<1U)blocks=1U;
  for(uint8_t b=0;b<blocks;b++){
    float frac=blocks<=1U?1.0f:((float)b/(float)(blocks-1U));
    float dMs=50.0f-frac*45.0f;
    int steps=(int)count-((int)b+1)*5;
    uint32_t dur=steps>0?(uint32_t)((float)steps*dMs):120UL;
    if(dur<120UL)dur=120UL;
    total+=dur;
  }
  return total;
}
static void gw7Render(uint32_t tMs,uint16_t count) {
  if(count<1U)count=1U;
  const uint32_t DUR_F1=3500UL,DUR_F2=3500UL,DUR_F3=3500UL,DUR_F4=3500UL;
  const uint32_t DUR_F5=3500UL,DUR_F6=4000UL,DUR_HOLD=4000UL;
  const uint8_t BLOCK_SIZE=5U;
  uint8_t blocks=(uint8_t)((count+BLOCK_SIZE-1U)/BLOCK_SIZE);
  if(blocks<1U)blocks=1U;
  uint32_t stackTotal=gw7StackDurationTotal(count,blocks);
  uint32_t T1=DUR_F1,T2=T1+DUR_F2,T3=T2+DUR_F3,T4=T3+DUR_F4;
  uint32_t T5=T4+DUR_F5,T6=T5+DUR_F6,T7=T6+stackTotal,TOTAL=T7+DUR_HOLD;

  if(tMs>=TOTAL){
    fill_solid(leds1,count,CRGB::White);
    fill_solid(leds2,count,CRGB::White);
    gw0309Done=true;
    return;
  }
  uint32_t t=tMs;
  fill_solid(leds1,count,CRGB::Black);
  fill_solid(leds2,count,CRGB::Black);

  if(t<T2){
    uint32_t localT=t<T1?t:(t-T1);
    float tSec=(float)localT*.001f;
    float durSec=(float)DUR_F1*.001f;
    float speed=((float)count+25.0f)/durSec;
    float waveL=((float)count-1.0f)-(fmodf(tSec*speed,(float)count+25.0f)-10.0f);
    float waveR=((float)count-1.0f)-(fmodf(tSec*speed,(float)count+25.0f)-18.0f);
    for(uint16_t i=0;i<count;i++){
      float a=gw7BlockDistance(fabsf((float)i-waveL),16.0f);
      float b=gw7BlockDistance(fabsf((float)i-waveR),16.0f);
      leds1[i]=CRGB((uint8_t)(255.0f*a),(uint8_t)(255.0f*a),(uint8_t)(255.0f*a));
      leds2[i]=CRGB((uint8_t)(255.0f*b),(uint8_t)(255.0f*b),(uint8_t)(255.0f*b));
    }
  }else if(t<T3){
    uint32_t localT=t-T2;
    float tSec=(float)localT*.001f;
    float wipeSpeed=((float)count+15.0f)/(((float)DUR_F3*.001f)*.72f);
    float head=tSec*wipeSpeed;
    for(uint16_t i=0;i<count;i++){
      if(head>=(float)count||(float)i<=head){leds1[i]=CRGB::White;leds2[i]=CRGB::White;}
    }
  }else if(t<T4){
    uint32_t localT=t-T3;
    float tSec=(float)localT*.001f;
    float p1=(sinf(tSec*3.6f)*.5f+.5f)*((float)count*.44f);
    float p2=((float)count*.52f)+(cosf(tSec*4.2f)*.5f+.5f)*((float)count*.44f);
    for(uint16_t i=0;i<count;i++){
      float a=gw7BlockDistance(fabsf((float)i-p1),14.0f);
      float b=gw7BlockDistance(fabsf((float)i-p2),14.0f);
      uint8_t q=(uint8_t)(255.0f*fmaxf(a,b));
      leds1[i]=CRGB(q,q,q);leds2[i]=CRGB(q,q,q);
    }
  }else if(t<T5){
    uint32_t localT=t-T4;
    uint32_t cycleTime=localT%400UL;
    bool left=cycleTime<200UL;
    uint32_t sub=left?cycleTime:(cycleTime-200UL);
    bool on=(sub%66UL)<36UL;
    if(on){
      if(left)fill_solid(leds1,count,CRGB::White);
      else fill_solid(leds2,count,CRGB::White);
    }
  }else if(t<T6){
    uint32_t localT=t-T5;
    uint32_t half=DUR_F6/2UL;
    float routeLen=(float)count*2.0f;
    float posCombined=localT<half
      ? ((float)localT/(float)half)*routeLen
      : routeLen-(((float)(localT-half)/(float)half)*routeLen);
    bool onLeft=posCombined<(float)count;
    float beamIdx=onLeft?((float)count-1.0f-posCombined):(posCombined-(float)count);
    CRGB *dst=onLeft?leds1:leds2;
    for(uint16_t i=0;i<count;i++){
      float dist=fabsf((float)i-beamIdx);
      if(dist<12.0f){
        float v=cosf((dist/12.0f)*(PI/2.0f));
        uint8_t q=(uint8_t)(255.0f*v);
        dst[i]=CRGB(q,q,q);
      }
    }
  }else if(t<T7){
    uint32_t localT=t-T6;
    uint32_t curStart=0UL,curDur=120UL;
    uint8_t curBlock=0U;
    for(uint8_t b=0;b<blocks;b++){
      float fracD=blocks<=1U?1.0f:((float)b/(float)(blocks-1U));
      float dMs=50.0f-fracD*45.0f;
      int steps=(int)count-((int)b+1)*(int)BLOCK_SIZE;
      uint32_t dur=steps>0?(uint32_t)((float)steps*dMs):120UL;
      if(dur<120UL)dur=120UL;
      if(localT<curStart+dur||b==blocks-1U){curBlock=b;curDur=dur;break;}
      curStart+=dur;
    }
    uint32_t bTime=localT>=curStart?localT-curStart:0UL;
    float frac=curDur>0UL?(float)bTime/(float)curDur:1.0f;
    if(frac>1.0f)frac=1.0f;
    int targetPos=(int)count-((int)curBlock+1)*(int)BLOCK_SIZE;
    if(targetPos<0)targetPos=0;
    float movingPos=frac*(float)targetPos;
    int stackedStart=(int)count-(int)curBlock*(int)BLOCK_SIZE;
    if(stackedStart<0)stackedStart=0;
    for(int i=stackedStart;i<(int)count;i++){leds1[i]=CRGB::White;leds2[i]=CRGB::White;}
    for(uint16_t i=0;i<count;i++){
      if((int)i>=(int)movingPos&&(int)i<(int)movingPos+(int)BLOCK_SIZE){
        leds1[i]=CRGB::White;leds2[i]=CRGB::White;
      }else if((int)i<(int)movingPos&&(int)i>=(int)movingPos-4){
        float tail=1.0f-((movingPos-(float)i)/4.0f);
        if(tail<0.0f)tail=0.0f;
        uint8_t q=(uint8_t)(255.0f*tail*.85f);
        if(q>leds1[i].r){leds1[i]=CRGB(q,q,q);leds2[i]=CRGB(q,q,q);}
      }
    }
  }else{
    fill_solid(leds1,count,CRGB::White);
    fill_solid(leds2,count,CRGB::White);
  }
}

// ---------------- W8 exact FIX76 14-phase dual color ----------------
static const CRGB GW8_COL_L[14]={
  CRGB(0,210,255),CRGB(56,189,248),CRGB(0,240,255),CRGB(255,255,255),
  CRGB(0,210,255),CRGB(217,70,239),CRGB(0,85,255),CRGB(0,220,255),
  CRGB(0,240,255),CRGB(239,68,68),CRGB(0,210,255),CRGB(255,255,255),
  CRGB(220,38,38),CRGB(255,255,255)
};
static const CRGB GW8_COL_R[14]={
  CRGB(255,0,68),CRGB(251,113,133),CRGB(244,63,94),CRGB(255,0,68),
  CRGB(255,153,0),CRGB(59,130,246),CRGB(255,0,50),CRGB(255,119,0),
  CRGB(255,0,100),CRGB(245,158,11),CRGB(255,255,255),CRGB(255,255,255),
  CRGB(244,63,94),CRGB(255,255,255)
};
static const uint32_t GW8_DUR[14]={
  3500UL,3000UL,3500UL,3500UL,3500UL,3500UL,3500UL,
  4000UL,15000UL,4000UL,3500UL,3500UL,3000UL,4000UL
};
static inline float gw8BlockDistance(float dist,float width){
  if(dist>=width)return 0.0f;
  return cosf((dist/width)*(PI/2.0f));
}
static inline CRGB gw8Scale(const CRGB &c,float v){
  if(v<=0.0f)return CRGB::Black;
  if(v>1.0f)v=1.0f;
  CRGB out=c;out.nscale8_video((uint8_t)(v*255.0f));return out;
}
static uint32_t gw8BlockDur(uint16_t count,uint8_t blocks,uint8_t b){
  float frac=blocks<=1U?1.0f:((float)b/(float)(blocks-1U));
  float dMs=50.0f-frac*45.0f;
  int steps=(int)count-((int)b+1)*5;
  uint32_t dur=steps>0?(uint32_t)((float)steps*dMs):120UL;
  if(dur<120UL)dur=120UL;
  return dur;
}
static uint32_t gw8StackTotal(uint16_t count,uint8_t blocks){
  uint32_t total=0UL;
  for(uint8_t b=0;b<blocks;b++)total+=gw8BlockDur(count,blocks,b);
  return total;
}
static void gw8Render(uint32_t tMs,uint16_t count){
  if(count<1U)count=1U;
  const uint8_t BLOCK_SIZE=5U;
  uint8_t blocks=(uint8_t)((count+BLOCK_SIZE-1U)/BLOCK_SIZE);
  if(blocks<1U)blocks=1U;
  uint32_t stackTotal=gw8StackTotal(count,blocks);
  const uint8_t REPEAT=2U;
  uint32_t TF[15];TF[0]=0UL;
  for(uint8_t p=0;p<14U;p++){
    uint32_t baseDur=(p==8U)?stackTotal:GW8_DUR[p];
    TF[p+1U]=TF[p]+baseDur*(uint32_t)REPEAT;
  }
  uint32_t total=TF[14];
  if(tMs>=total){
    fill_solid(leds1,count,GW8_COL_L[13]);
    fill_solid(leds2,count,GW8_COL_R[13]);
    gw0309Done=true;
    return;
  }
  uint32_t tMod=tMs;
  uint8_t phase=13U;
  for(uint8_t p=0;p<14U;p++){
    if(tMod>=TF[p]&&tMod<TF[p+1U]){phase=p;break;}
  }
  uint32_t baseDur=(phase==8U)?stackTotal:GW8_DUR[phase];
  uint32_t phaseElapsed=tMod-TF[phase];
  uint32_t localT=baseDur>0UL?(phaseElapsed%baseDur):0UL;
  uint32_t dur=baseDur;
  CRGB colorL=GW8_COL_L[phase],colorR=GW8_COL_R[phase];

  fill_solid(leds1,count,CRGB::Black);
  fill_solid(leds2,count,CRGB::Black);

  switch(phase){
    case 0:{
      float p=dur>0UL?(float)localT/(float)dur:1.0f;
      if(p<.82f){
        float head=(1.0f-p/.82f)*((float)count-1.0f);
        for(uint16_t i=0;i<count;i++){
          float v=gw8BlockDistance(fabsf((float)i-head),14.0f);
          leds1[i]=gw8Scale(colorL,v);leds2[i]=gw8Scale(colorR,v);
        }
      }else{
        bool flash=sinf((p-.82f)*45.0f)>0.0f;
        for(uint16_t i=0;i<count;i++){
          float v=(i<12U&&flash)?1.0f:0.0f;
          leds1[i]=gw8Scale(colorL,v);leds2[i]=gw8Scale(colorR,v);
        }
      }
    }break;
    case 1:{
      float p=dur>0UL?(float)localT/(float)dur:1.0f;
      float waveFront=p*(float)count;
      for(uint16_t i=0;i<count;i++){
        float d=fabsf((float)i-waveFront);
        float v=gw8BlockDistance(d,12.0f)*(1.0f-p*.3f);
        leds1[i]=gw8Scale(colorL,v);leds2[i]=gw8Scale(colorR,v);
      }
    }break;
    case 2:
    case 3:{
      float tSec=(float)localT/1000.0f;
      float durSec=(float)dur/1000.0f;
      float speed=((float)count+25.0f)/durSec;
      float waveL=((float)count-1.0f)-(fmodf(tSec*speed,(float)count+25.0f)-10.0f);
      float waveR=((float)count-1.0f)-(fmodf(tSec*speed,(float)count+25.0f)-18.0f);
      for(uint16_t i=0;i<count;i++){
        float vL=gw8BlockDistance(fabsf((float)i-waveL),16.0f);
        float vR=gw8BlockDistance(fabsf((float)i-waveR),16.0f);
        leds1[i]=gw8Scale(colorL,vL);leds2[i]=gw8Scale(colorR,vR);
      }
    }break;
    case 4:{
      float tSec=(float)localT/1000.0f;
      float wipeSpeed=((float)count+15.0f)/(((float)dur/1000.0f)*.72f);
      float head=tSec*wipeSpeed;
      for(uint16_t i=0;i<count;i++){
        float v=(head>=(float)count||(float)i<=head)?1.0f:0.0f;
        leds1[i]=gw8Scale(colorL,v);leds2[i]=gw8Scale(colorR,v);
      }
    }break;
    case 5:{
      float tSec=(float)localT/1000.0f;
      float p1=(sinf(tSec*3.6f)*.5f+.5f)*((float)count*.44f);
      float p2=((float)count*.52f)+(cosf(tSec*4.2f)*.5f+.5f)*((float)count*.44f);
      for(uint16_t i=0;i<count;i++){
        float v=fmaxf(gw8BlockDistance(fabsf((float)i-p1),14.0f),
                       gw8BlockDistance(fabsf((float)i-p2),14.0f));
        leds1[i]=gw8Scale(colorL,v);leds2[i]=gw8Scale(colorR,v);
      }
    }break;
    case 6:{
      uint32_t cyc=localT%400UL;
      bool left=cyc<200UL;
      uint32_t sub=left?cyc:(cyc-200UL);
      bool on=(sub%66UL)<36UL;
      float briL=left&&on?1.0f:0.0f,briR=!left&&on?1.0f:0.0f;
      for(uint16_t i=0;i<count;i++){
        leds1[i]=gw8Scale(colorL,briL);leds2[i]=gw8Scale(colorR,briR);
      }
    }break;
    case 7:{
      uint32_t half=dur/2UL;
      float route=(float)count*2.0f;
      float posCombined=localT<half
        ? route-(((float)localT/(float)half)*route)
        : (((float)(localT-half)/(float)half)*route);
      uint8_t beamCh=posCombined<(float)count?0U:1U;
      float beamIdx=posCombined<(float)count
        ? ((float)count-1.0f-posCombined)
        : (posCombined-(float)count);
      CRGB *target=beamCh==0U?leds1:leds2;
      CRGB beamColor=beamCh==0U?colorL:colorR;
      for(uint16_t i=0;i<count;i++){
        float dist=fabsf((float)i-beamIdx);
        if(dist<12.0f)target[i]=gw8Scale(beamColor,cosf((dist/12.0f)*(PI/2.0f)));
      }
    }break;
    case 8:{
      uint32_t curStart=0UL,curDur=gw8BlockDur(count,blocks,0U);
      uint8_t curBlock=0U;
      for(uint8_t b=0;b<blocks;b++){
        uint32_t bd=gw8BlockDur(count,blocks,b);
        if(localT>=curStart){curBlock=b;curDur=bd;}
        if(localT<curStart+bd)break;
        curStart+=bd;
      }
      uint32_t bTime=localT>=curStart?localT-curStart:0UL;
      float frac=curDur>0UL?(float)bTime/(float)curDur:1.0f;
      if(frac>1.0f)frac=1.0f;
      int targetPos=(int)count-((int)curBlock+1)*(int)BLOCK_SIZE;
      if(targetPos<0)targetPos=0;
      float movingPos=frac*(float)targetPos;
      int stackedStart=(int)count-(int)curBlock*(int)BLOCK_SIZE;
      if(stackedStart<0)stackedStart=0;
      for(int i=stackedStart;i<(int)count;i++){leds1[i]=colorL;leds2[i]=colorR;}
      for(uint16_t i=0;i<count;i++){
        if((int)i>=(int)movingPos&&(int)i<(int)movingPos+(int)BLOCK_SIZE){
          leds1[i]=colorL;leds2[i]=colorR;
        }else if((int)i<(int)movingPos&&(int)i>=(int)movingPos-4){
          float tail=1.0f-((movingPos-(float)i)/4.0f);
          float v=tail*.85f;
          CRGB l=gw8Scale(colorL,v),r=gw8Scale(colorR,v);
          if(l.getAverageLight()>leds1[i].getAverageLight())leds1[i]=l;
          if(r.getAverageLight()>leds2[i].getAverageLight())leds2[i]=r;
        }
      }
    }break;
    case 9:{
      float p=dur>0UL?(float)localT/(float)dur:1.0f;
      int remaining=(int)((1.0f-p)*(float)count);
      for(uint16_t i=0;i<count;i++){
        float v=(int)i<remaining?1.0f:0.0f;
        leds1[i]=gw8Scale(colorL,v);leds2[i]=gw8Scale(colorR,v);
      }
    }break;
    case 10:{
      float p=((float)localT/(float)dur)*(float)count;
      for(uint16_t i=0;i<count;i++){
        bool even=(i&1U)==0U;
        float vL=((int)i<=(int)p&&even)?1.0f:(((int)i<=(int)(p*.6f))?.4f:0.0f);
        float vR=((int)i<=(int)p&&!even)?1.0f:(((int)i<=(int)(p*.6f))?.4f:0.0f);
        leds1[i]=gw8Scale(colorL,vL);leds2[i]=gw8Scale(colorR,vR);
      }
    }break;
    case 11:{
      float p=dur>0UL?(float)localT/(float)dur:1.0f;
      float v=p<.8f?.15f+(p/.8f)*.85f:(p<.9f?1.8f:0.0f);
      for(uint16_t i=0;i<count;i++){leds1[i]=gw8Scale(colorL,v);leds2[i]=gw8Scale(colorR,v);}
    }break;
    case 12:{
      float p=fmodf((float)localT/1000.0f,1.0f);
      float pulse=powf(sinf(p*PI*4.0f),6.0f);
      float v=.2f+.8f*pulse;
      for(uint16_t i=0;i<count;i++){leds1[i]=gw8Scale(colorL,v);leds2[i]=gw8Scale(colorR,v);}
    }break;
    case 13:
    default:
      fill_solid(leds1,count,colorL);
      fill_solid(leds2,count,colorR);
      break;
  }
}

// ---------------- W9 ----------------
static void gw9Render(uint32_t tMs,uint16_t count) {
  fill_solid(leds1,count,CRGB::Black);
  fill_solid(leds2,count,CRGB::Black);
  if(count<1U){gw0309Done=true;return;}

  // W9 BARU:
  // - blok TIDAK menyambung/menumpuk.
  // - hanya 5 LED per blok.
  // - CH1 dan CH2 bergerak SAMA/SEJAJAR.
  // - maju 5 LED setiap langkah: 0..4 -> 5..9 -> 10..14 -> dst.
  // - 5 kedipan cepat per blok, lalu lebih cepat pindah ke blok berikutnya.
  const uint16_t BLOCK_SIZE = 5U;
  const uint32_t FLASH_SLOT_MS = 40UL;   // 15ms OFF + 25ms ON
  const uint8_t FLASH_COUNT = 5U;
  const uint32_t FLASH_TOTAL_MS = FLASH_SLOT_MS * FLASH_COUNT; // 200ms
  const uint32_t BLOCK_CYCLE_MS = 600UL; // sebelumnya 1200ms, sekarang 2x lebih cepat

  uint16_t blockCount = (uint16_t)((count + BLOCK_SIZE - 1U) / BLOCK_SIZE);
  uint32_t totalMs = (uint32_t)blockCount * BLOCK_CYCLE_MS;
  if(tMs >= totalMs){gw0309Done=true;return;}

  uint16_t block = (uint16_t)(tMs / BLOCK_CYCLE_MS);
  uint32_t local = tMs % BLOCK_CYCLE_MS;

  uint16_t start = (uint16_t)(block * BLOCK_SIZE);
  uint16_t end = start + BLOCK_SIZE;
  if(end > count) end = count;

  if(local < FLASH_TOTAL_MS){
    uint32_t sub = local % FLASH_SLOT_MS;
    bool on = sub >= 15UL; // OFF 15ms -> ON 25ms
    if(on){
      for(uint16_t i=start;i<end;i++){
        leds1[i]=CRGB::Red;
        leds2[i]=CRGB::Red;
      }
    }
  }
}

static bool gw0309DirectSourceActive() {
  if(selectedWelcome<3U||selectedWelcome>9U)return false;
  uint8_t m=mappedWelcome[selectedWelcome];
  return !(m>=1U&&m<=210U);
}
static void gw0309ResetRuntime() {
  gw0309Done=false;
}
static void gw0309RenderSelected(uint8_t welcomeNo,uint32_t tMs,uint16_t count) {
  gw0309Done=false;

  switch(welcomeNo){
    case 3U:gw3Render(tMs,count);break;
    case 4U:gw4Render(tMs,count);break;
    case 5U:gw5Render(tMs,count);break;
    case 6U:gw6Render(tMs,count);break;
    case 7U:gw7Render(tMs,count);break;
    case 8U:gw8Render(tMs,count);break;
    case 9U:gw9Render(tMs,count);break;
    default:return;
  }

  memcpy(leds3,leds1,sizeof(CRGB)*count);
  memcpy(leds4,leds2,sizeof(CRGB)*count);
}



void finishWelcomeToMain() {
  uint8_t finishedWelcome = selectedWelcome;
  welcomeRunning = false; welcomeForceRender = false; welcomePlaylistPlaying = false; selectedWelcome = configuredWelcome;
  uint8_t mappedMode = 0xFF;
  // W50 sekarang source mandiri Cyber Neon, bukan alias ke Mode210 lama.
  if (finishedWelcome != 50U && finishedWelcome < 256) {
    uint8_t m = mappedWelcome[finishedWelcome]; if (m >= 1 && m <= 210) mappedMode = m;
  }
  if (mappedMode != 0xFF) {
    for (uint8_t ch = 0; ch < 4; ch++) { selectedMode[ch] = mappedMode; channelSource[ch] = MAIN_MODE; }
    mainSource = MAIN_MODE; welcomeReturnSource = MAIN_MODE;
    refreshBaseSourceFlags(); solidRgbForceRender = true; modeForceRender = true; resetCustomSuites(); resetAllChannelSuiteStates(); markSettingsUrgent();
    Serial.printf("[K1 FINISH] Welcome #%u selesai -> Mode #%u aktif\n", finishedWelcome, mappedMode); return;
  }
  uint8_t target = welcomeReturnSource;
  if (target != MAIN_RGB && target != MAIN_MODE) target = MAIN_MODE;
  mainSource = target;
  refreshBaseSourceFlags();
  solidRgbForceRender = solidRgbActive; modeForceRender = modeRunning;
  resetCustomSuites(); resetAllChannelSuiteStates();
  markSettingsUrgent();
}

static void startWelcome() {
  if (!(pendingK1DirectSave && selectedWelcome == pendingK1DirectWelcome)) {
    uint8_t directMode = 0xFF;
    if (loadK1DirectMapping(selectedWelcome, directMode)) { mappedWelcome[selectedWelcome] = directMode; }
  }
  if (TOTAL_CEREMONY == 0) initTiming();
  initWelcome1Timing();
  unsigned long now = millis(); welcomeLastClockAt = now; welcomeLastRenderAt = 0; welcomeAnimClockVirtual = 0.0f;
  gw4050ResetRuntime();
  gw3039ResetRuntime();
  gw2029ResetRuntime();
  gw1019ResetRuntime();
  gw0309ResetRuntime();
  welcomeRunning = true; welcomeForceRender = true;
}

static void renderWelcomeFrame() {
  if (!lampOn || !contactOn) return;
  uint16_t n = activeLedCount; if (n < 1) n = 1; if (n > STAGE0_LED_BUFFER) n = STAGE0_LED_BUFFER;
  uint8_t mappedMode = 0xFF;

  // W50 harus langsung ke source Cyber Neon baru.
  // Mapping Mode210 hanya berlaku untuk slot lain.
  if (selectedWelcome != 50U && selectedWelcome < 256) {
    uint8_t m = mappedWelcome[selectedWelcome]; if (m >= 1 && m <= 210) mappedMode = m;
  }

  if (selectedWelcome == 50U) {
    gw4050RenderSelected(50U, (uint32_t)welcomeAnimClockVirtual, n);
  } else if (mappedMode != 0xFF) {
    renderMode210Pattern(mappedMode, leds1, leds2, n);
    memcpy(leds3, leds1, sizeof(CRGB) * n);
    memcpy(leds4, leds2, sizeof(CRGB) * n);
  } else if (gw0309DirectSourceActive()) {
    gw0309RenderSelected(selectedWelcome, (uint32_t)welcomeAnimClockVirtual, n);
  } else if (gw1019DirectSourceActive()) {
    gw1019RenderSelected(selectedWelcome, (uint32_t)welcomeAnimClockVirtual, n);
  } else if (gw2029DirectSourceActive()) {
    gw2029RenderSelected(selectedWelcome, (uint32_t)welcomeAnimClockVirtual, n);
  } else if (gw3039DirectSourceActive()) {
    gw3039RenderSelected(selectedWelcome, (uint32_t)welcomeAnimClockVirtual, n);
  } else if (gw4050DirectSourceActive()) {
    gw4050RenderSelected(selectedWelcome, (uint32_t)welcomeAnimClockVirtual, n);
  } else if (selectedWelcome == 1) {
    if (W1_TOTAL_CEREMONY == 0) initWelcome1Timing();
    uint32_t tMod = (uint32_t)fmodf(welcomeAnimClockVirtual, (float)W1_TOTAL_CEREMONY);
    uint8_t curPhaseW1 = 13;
    for (uint8_t p = 0; p < W1_TOTAL_PHASES; p++) { if (tMod >= W1_T_F[p] && tMod < W1_T_F[p + 1]) { curPhaseW1 = p; break; } }
    CRGB phaseColor = W1_PHASE_COLORS[curPhaseW1];
    evaluateWelcome1(tMod, w1OutL, w1OutR, n);
    for (uint16_t i = 0; i < n; i++) {
      CRGB cL = phaseColor; cL.nscale8_video((uint8_t)(fminf(1.0f, w1OutL[i]) * 255.0f));
      CRGB cR = phaseColor; cR.nscale8_video((uint8_t)(fminf(1.0f, w1OutR[i]) * 255.0f));
      leds1[i] = cL; leds3[i] = cL; leds2[i] = cR; leds4[i] = cR;
    }
  } else {
    uint32_t tMod = (uint32_t)fmodf(welcomeAnimClockVirtual, (float)TOTAL_CEREMONY);
    uint8_t curPhase = getActivePhase(tMod);
    evaluateNewCeremony(tMod, curPhase, n, w1OutL, w1OutR);
    for (uint16_t i = 0; i < n; i++) {
      CRGB cL = colorDRL; cL.nscale8_video((uint8_t)(fminf(1.0f, w1OutL[i]) * 255.0f));
      CRGB cR = colorDRL; cR.nscale8_video((uint8_t)(fminf(1.0f, w1OutR[i]) * 255.0f));
      leds1[i] = cL; leds3[i] = cL; leds2[i] = cR; leds4[i] = cR;
    }
  }
  k3SafeShow();
}


static void completeWelcomePlaybackGlobal() {
  // CONTACT Welcome selesai sekali -> putih 4CH, TIDAK loop.
  if (specialWelcomeContext == 1U) {
    specialWelcomeContext = 0U;
    welcomeRunning = false;
    welcomeForceRender = false;
    welcomePlaylistPlaying = false;
    contactStandbyRedActive = true;
    selectedWelcome = contactWelcomeMode;
    showContactStandbyRedNow();
    return;
  }

  // SENJA Welcome selesai -> kembali ke Mode/RGB normal terakhir.
  if (specialWelcomeContext == 2U) {
    specialWelcomeContext = 0U;
    contactStandbyRedActive = false;
    welcomeRunning = false;
    welcomeForceRender = false;
    welcomePlaylistPlaying = false;
    finishWelcomeToMain();
    return;
  }

  if (welcomePlaylistPlaying && k2SetupState == 0) {
    for (uint8_t next = (uint8_t)(playingPlaylistIndex + 1U); next < 3; next++) {
      uint8_t w = welcomePlaylist[next];
      if (w != 0xFF && w <= 0x32) {
        playingPlaylistIndex = next;
        selectedWelcome = w;
        startWelcome();
        return;
      }
    }
  }

  welcomePlaylistPlaying = false;
  playingPlaylistIndex = 0;
  finishWelcomeToMain();
}


static void serviceWelcomeRealtime() {
  if (!welcomeRunning || !lampOn || !contactOn) return;

  unsigned long now = millis();
  if (welcomeLastClockAt == 0) welcomeLastClockAt = now;
  unsigned long dt = now - welcomeLastClockAt;
  welcomeLastClockAt = now;
  if (dt > 100UL) dt = 100UL;

  // GLOBAL SPEED satu-satunya pengali timing Welcome 40-50.
  // Source step/durasi di bawah membaca clock virtual ini.
  welcomeAnimClockVirtual += (float)dt * liveSpeedFactor;

  const bool source0309 = gw0309DirectSourceActive();
  const bool source1019 = gw1019DirectSourceActive();
  const bool source2029 = gw2029DirectSourceActive();
  const bool source3039 = gw3039DirectSourceActive();
  const bool source4050 = gw4050DirectSourceActive();

  if (source0309 || source1019 || source2029 || source3039 || source4050) {
    if (!welcomeForceRender && (now - welcomeLastRenderAt) < 15UL) return;
    welcomeForceRender = false;
    welcomeLastRenderAt = now;
    renderWelcomeFrame();

    // W3-50 source selesai pada boundary source masing-masing.
    // Tidak dipotong oleh TOTAL_CEREMONY umum.
    const bool sourceDone =
      source0309 ? gw0309Done :
      (source1019 ? gw1019Done :
      (source2029 ? gw2029Done :
      (source3039 ? gw3039Done : gw4050Done)));

    if (sourceDone) {
      completeWelcomePlaybackGlobal();
    }
    return;
  }

  uint32_t totalCeremonyMs =
    (selectedWelcome == 1) ? W1_TOTAL_CEREMONY : TOTAL_CEREMONY;

  if (totalCeremonyMs > 0 &&
      welcomeAnimClockVirtual >= (float)totalCeremonyMs) {
    completeWelcomePlaybackGlobal();
    return;
  }

  if (!welcomeForceRender && (now - welcomeLastRenderAt) < 15UL) return;
  welcomeForceRender = false;
  welcomeLastRenderAt = now;
  renderWelcomeFrame();
}

static void applyActiveLedCountToFastLED(uint16_t oldCount, uint16_t newCount) {
  if (oldCount < 1) oldCount = 1; if (oldCount > STAGE0_LED_BUFFER) oldCount = STAGE0_LED_BUFFER;
  if (newCount < 1) newCount = 1; if (newCount > STAGE0_LED_BUFFER) newCount = STAGE0_LED_BUFFER;
  // Resize buffer tambahan lebih dulu. Jika heap tidak cukup, jumlah LED lama tetap dipertahankan
  // sehingga efek tidak dipotong dan tidak ada akses buffer di luar batas.
  if (!resizeRuntimeAuxBuffers(newCount)) {
    pendingLedCount = oldCount;
    return;
  }
  if (newCount < oldCount) {
    for (uint16_t i = newCount; i < oldCount; i++) { leds1[i] = CRGB::Black; leds2[i] = CRGB::Black; leds3[i] = CRGB::Black; leds4[i] = CRGB::Black; }
    FastLED.show();
  }
  activeLedCount = newCount; initWelcome1Timing();
  if (ledController1) ledController1->setLeds(leds1, newCount); if (ledController2) ledController2->setLeds(leds2, newCount);
  if (ledController3) ledController3->setLeds(leds3, newCount); if (ledController4) ledController4->setLeds(leds4, newCount);
  welcomeForceRender = true; if (solidRgbActive) solidRgbForceRender = true; if (modeRunning) modeForceRender = true; markSettingsDirty();
}

static void clearAllActiveOutputNow() {
  uint16_t n = activeLedCount; if (n < 1) n = 1; if (n > STAGE0_LED_BUFFER) n = STAGE0_LED_BUFFER;
  fill_solid(leds1, n, CRGB::Black); fill_solid(leds2, n, CRGB::Black); fill_solid(leds3, n, CRGB::Black); fill_solid(leds4, n, CRGB::Black);
  k3SafeShow();
}

static void renderSolidRgbNow() {
  if (!lampOn || !contactOn || !solidRgbActive || mainSource == MAIN_WELCOME) return;
  uint16_t n = activeLedCount; if (n < 1) n = 1; if (n > STAGE0_LED_BUFFER) n = STAGE0_LED_BUFFER;
  if (channelSource[0] == MAIN_RGB) fill_solid(leds1, n, CRGB(rgbR[0], rgbG[0], rgbB[0]));
  if (channelSource[1] == MAIN_RGB) fill_solid(leds2, n, CRGB(rgbR[1], rgbG[1], rgbB[1]));
  if (channelSource[2] == MAIN_RGB) fill_solid(leds3, n, CRGB(rgbR[2], rgbG[2], rgbB[2]));
  if (channelSource[3] == MAIN_RGB) fill_solid(leds4, n, CRGB(rgbR[3], rgbG[3], rgbB[3]));
  k3SafeShow();
}

static void serviceSolidRgbRealtime() {
  if (!lampOn || !contactOn || !solidRgbActive || mainSource == MAIN_WELCOME) return;
  if (!solidRgbForceRender) return;
  solidRgbForceRender = false; solidRgbLastRenderAt = millis(); renderSolidRgbNow();
}

static bool lastPhysSenKiri = false;
static bool lastPhysSenKanan = false;
static bool lastPhysRem = false;
static bool lastPhysMundur = false;
static bool lastPhysSenja = false;

// FIX8 SEN FISIK: ritme flasher HANYA heartbeat, bukan timing animasi.
// Selama masih ada pulsa dalam window ini, engine SEN dianggap masih aktif.
// Kecepatan animasi tetap 100% dari senSpeed global aplikasi.
static unsigned long senPhysicalLastPulseAt = 0UL;
static constexpr unsigned long SEN_FLASHER_HEARTBEAT_HOLD_MS = 1500UL;

// SENJA: hitung murni 3x trigger SEN (rising edge), TANPA batas waktu.
// Setiap OFF -> ON dihitung 1. Counter reset saat SENJA OFF atau setelah mencapai 3.
// 3x pertama  = masuk PUTIH ALL sementara.
// 3x berikutnya = kembalikan persis state dasar sebelum PUTIH (MODE/RGB per channel).
static uint8_t senjaWhiteGestureCount = 0U;
static bool senjaWhiteOverrideActive = false;
static uint8_t senjaWhiteSavedChannelSource[4] = {MAIN_MODE, MAIN_MODE, MAIN_MODE, MAIN_MODE};
static uint8_t senjaWhiteSavedMode[4] = {1,1,1,1};
static uint8_t senjaWhiteSavedR[4] = {255,255,255,255};
static uint8_t senjaWhiteSavedG[4] = {255,255,255,255};
static uint8_t senjaWhiteSavedB[4] = {255,255,255,255};
static uint8_t senjaWhiteSavedMainSource = MAIN_MODE;
static uint8_t senjaWhiteSavedWelcomeReturnSource = MAIN_MODE;

static void captureSenjaWhiteReturnState() {
  for (uint8_t ch = 0; ch < 4U; ch++) {
    senjaWhiteSavedChannelSource[ch] = isValidBaseSource(channelSource[ch]) ? channelSource[ch] : MAIN_MODE;
    senjaWhiteSavedMode[ch] = selectedMode[ch];
    senjaWhiteSavedR[ch] = rgbR[ch];
    senjaWhiteSavedG[ch] = rgbG[ch];
    senjaWhiteSavedB[ch] = rgbB[ch];
  }

  uint8_t base = mainSource;
  if (base == MAIN_WELCOME) base = welcomeReturnSource;
  if (!isValidBaseSource(base)) base = MAIN_MODE;
  senjaWhiteSavedMainSource = base;

  uint8_t ret = welcomeReturnSource;
  if (!isValidBaseSource(ret)) ret = base;
  senjaWhiteSavedWelcomeReturnSource = ret;
}

static void enterSenjaWhiteOverride() {
  captureSenjaWhiteReturnState();
  senjaWhiteOverrideActive = true;

  for (uint8_t ch = 0; ch < 4U; ch++) {
    rgbR[ch] = 255U;
    rgbG[ch] = 255U;
    rgbB[ch] = 255U;
    channelSource[ch] = MAIN_RGB;
  }

  refreshBaseSourceFlags();
  welcomeRunning = false;
  pendingWelcomeRestart = false;
  welcomePlaylistPlaying = false;
  specialWelcomeContext = 0U;
  contactStandbyRedActive = false;
  welcomeReturnSource = MAIN_RGB;
  mainSource = MAIN_RGB;
  lampOn = true;
  solidRgbForceRender = true;
  modeForceRender = true;

  // PUTIH dari gesture SENJA bersifat sementara: JANGAN autosave agar state lama tidak hilang.
  Serial.println("[SENJA] SEN 3X -> TEMP RGB WHITE ALL; next 3x restores previous state");
}

static void restoreSenjaWhiteReturnState() {
  for (uint8_t ch = 0; ch < 4U; ch++) {
    selectedMode[ch] = senjaWhiteSavedMode[ch];
    rgbR[ch] = senjaWhiteSavedR[ch];
    rgbG[ch] = senjaWhiteSavedG[ch];
    rgbB[ch] = senjaWhiteSavedB[ch];
    channelSource[ch] = senjaWhiteSavedChannelSource[ch];
  }

  refreshBaseSourceFlags();
  welcomeRunning = false;
  pendingWelcomeRestart = false;
  welcomePlaylistPlaying = false;
  specialWelcomeContext = 0U;
  contactStandbyRedActive = false;
  welcomeReturnSource = senjaWhiteSavedWelcomeReturnSource;
  mainSource = senjaWhiteSavedMainSource;
  if (!isValidBaseSource(mainSource)) mainSource = MAIN_MODE;
  if (!isValidBaseSource(welcomeReturnSource)) welcomeReturnSource = mainSource;
  lampOn = true;
  senjaWhiteOverrideActive = false;

  // Restart state efek agar mode yang dipilih langsung dirender normal dari awal.
  resetCustomSuites();
  solidRgbForceRender = true;
  modeForceRender = true;
  welcomeForceRender = true;
  Serial.println("[SENJA] SEN 3X AGAIN -> RESTORE PREVIOUS MODE/RGB STATE");
}

static unsigned long lastAutoSwitchTime = 0;

// COMPILEFIX9: forward declaration untuk Arduino IDE 1.8.x.
// Hanya deklarasi; logika/fungsi tidak diubah.
static void abortPendingUiSetups(bool feedback);

void handlePhysicalPinsAndAutoMode() {
  unsigned long now = millis();
  if (lampOn && autoMode && mainSource == MAIN_MODE) {
    if (now - lastAutoSwitchTime >= 10000UL) {
      lastAutoSwitchTime = now; uint8_t nextM = selectedMode[0];
      if (nextM < 5 || nextM > 9) nextM = 5; else { nextM++; if (nextM > 9) nextM = 5; }
      for (uint8_t i = 0; i < 4; i++) selectedMode[i] = nextM;
      resetCustomSuites(); modeForceRender = true;
    }
  }
  static unsigned long lastPinRead = 0; if (now - lastPinRead < 20UL) return; lastPinRead = now;

  bool senKiri  = (digitalRead(PIN_SEN_KIRI) == LOW);
  bool senKanan = (digitalRead(PIN_SEN_KANAN) == LOW);
  bool rem      = (digitalRead(PIN_REM) == LOW);
  bool mundur   = (digitalRead(PIN_MUNDUR) == LOW);
  bool senja    = (digitalRead(PIN_SENJA) == HIGH);

  // Setiap level ON dari flasher hanya memperbarui heartbeat.
  // Tidak mengubah virtualTime dan tidak mengatur speed efek.
  if (!senMenuActive && (senKiri || senKanan) && lampOn && contactOn) {
    senPhysicalLastPulseAt = now;
  }

  if (senja != lastPhysSenja) {
    lastPhysSenja = senja;
    senjaPhysicalActive = senja;

    // CONTACT logical tetap ON selama modul hidup.
    // GPIO7 hanya menentukan konteks SENJA, bukan mematikan engine global.
    contactOn = true;
    lampOn = true;
    if (mundur && !mundurEngine.active) startMundur(selectedMundur, true);

    // Ganti konteks harus keluar dari sesi arah SEN/app preview.
    senMenuActive = false;
    senDirectionTriggerLatched = false;
    senDirectionBothOffSince = 0UL;
    abortPendingUiSetups(false);

    if (turnEngine.active && !turnEngine.isPhysical) {
      turnEngine.active = false;
      turnEngine.finishRequested = false;
    }
    if (brakeEngine.active && !brakeEngine.isPhysical) {
      brakeEngine.active = false;
    }

    if (senjaPhysicalActive) {
      // GPIO7 HIGH = SENJA.
      // Semua menu aplikasi kembali NORMAL dan Welcome SENJA sendiri dimainkan.
      senjaWhiteGestureCount = 0U;
      senjaWhiteOverrideActive = false;
      contactStandbyRedActive = false;
      startContextWelcome(2U, senjaWelcomeMode);
    } else {
      // GPIO7 LOW = KONTAK.
      // Saat SENJA dimatikan, wajib putar Welcome CONTACT terlebih dahulu.
      // Setelah Welcome CONTACT selesai, completeWelcomePlaybackGlobal() masuk putih 4CH.
      senjaWhiteGestureCount = 0U;
      senjaWhiteOverrideActive = false;
      contactStandbyRedActive = false;
      startContextWelcome(1U, contactWelcomeMode);
    }
  }
  if (rem != lastPhysRem) {
    lastPhysRem = rem;
    if (rem && lampOn && contactOn) { if (brake34Enabled) startBrake(selectedRem ? selectedRem : 1, true); }
    else if (!rem && brakeEngine.isPhysical) { finishBrake(); }
  }

  // GPIO10 = MUNDUR fisik, aktif LOW.
  // Mode yang dipakai adalah selectedMundur (1..10), semuanya putih.
  if (mundur != lastPhysMundur) {
    lastPhysMundur = mundur;
    if (mundur && lampOn && contactOn) {
      startMundur(selectedMundur, true);
      Serial.printf("[MUNDUR GPIO10] ON mode=%u\n", (unsigned)selectedMundur);
    } else if (!mundur && mundurEngine.active && mundurEngine.isPhysical) {
      finishMundur();
      Serial.println("[MUNDUR GPIO10] OFF");
    }
  }
  // Saat UI masih di MENU SEN:
  // satu aktivasi pin SEN KIRI ATAU KANAN = toggle arah GLOBAL semua SEN.
  // Input sein kendaraan bisa berkedip ON/OFF, jadi dilatch agar satu aktivasi
  // tidak membalik arah berkali-kali. Rearm setelah kedua pin OFF >=1.5 detik.
  if (!senKiri && !senKanan) {
    if (senDirectionBothOffSince == 0UL) senDirectionBothOffSince = now;
    if (senDirectionTriggerLatched &&
        (unsigned long)(now - senDirectionBothOffSince) >= SEN_DIRECTION_REARM_OFF_MS) {
      senDirectionTriggerLatched = false;
    }
  } else {
    senDirectionBothOffSince = 0UL;
  }

  if (senKiri != lastPhysSenKiri || senKanan != lastPhysSenKanan) {
    const bool senRising = (senKiri && !lastPhysSenKiri) || (senKanan && !lastPhysSenKanan);
    lastPhysSenKiri = senKiri;
    lastPhysSenKanan = senKanan;

    // SENJA + SEN 3x -> RGB PUTIH ALL 4CH.
    // TANPA timer/window/rearm: setiap trigger OFF->ON dihitung tepat 1 kali.
    // Berlaku di luar menu SEN supaya tidak bentrok dengan fungsi ubah arah SEN.
    if (senRising && senjaPhysicalActive && !senMenuActive && lampOn && contactOn) {
      if (senjaWhiteGestureCount < 3U) senjaWhiteGestureCount++;
      Serial.printf("[SENJA 3X] count=%u/3\n", (unsigned)senjaWhiteGestureCount);

      if (senjaWhiteGestureCount >= 3U) {
        senjaWhiteGestureCount = 0U;

        if (!senjaWhiteOverrideActive) {
          enterSenjaWhiteOverride();
        } else {
          restoreSenjaWhiteReturnState();
        }
      }
    }

    if (senRising && senMenuActive && !senDirectionTriggerLatched && lampOn && contactOn) {
      // Kiri atau kanan sama saja: toggle SEMUA arah SEN.
      // selectedSen dan varian A/B TIDAK berubah.
      senDirectionReverse = !senDirectionReverse;
      senDirectionTriggerLatched = true;
      senDirectionBothOffSince = 0UL;
      markSettingsUrgent();
      triggerBlink(CRGB::White, 3);
      welcomeForceRender = true;
      modeForceRender = true;
      solidRgbForceRender = true;
      Serial.printf("[SEN DIR] %s SAVED - UI SEN\n",
                    senDirectionReverse ? "REVERSE/KELUAR" : "NORMAL/LAWAN");
      return;
    }

    // Di luar menu SEN, pin kiri/kanan tetap berfungsi sebagai sein normal.
    // FIX8 SEN FISIK / FLASHER HEARTBEAT:
    // - Rising pertama memulai efek SEN.
    // - Pulsa flasher berikutnya hanya heartbeat; TIDAK restart virtualTime.
    // - OFF pendek di antara kedipan flasher DIABAIKAN TOTAL.
    // - Kecepatan animasi tetap murni dari senSpeed global aplikasi.
    // - Jika pulsa benar-benar berhenti, serviceSenAndBrakeRealtime() baru meminta
    //   finish; lalu efek tetap menyelesaikan siklus aktif sebelum OFF.
    if (!senMenuActive && (senKiri || senKanan) && lampOn && contactOn) {
      uint8_t side = (senKiri && senKanan) ? 2 : (senKiri ? 0 : 1);
      const uint8_t slot = selectedSen ? selectedSen : 1U;
      const uint8_t senMode = getSenInternalMode(slot);
      senPhysicalLastPulseAt = now;

      if (turnEngine.active && turnEngine.isPhysical) {
        // Jangan reset virtualTime. Pulsa baru hanya menjaga SEN tetap hidup.
        turnEngine.side = side;
        turnEngine.mode = senMode;
        if (turnEngine.finishRequested) {
          turnEngine.finishRequested = false;
          turnEngine.finishRequestedAt = 0UL;
        }
        modeForceRender = true;
        welcomeForceRender = true;
        solidRgbForceRender = true;
      } else {
        // Hanya aktivasi pertama yang benar-benar memulai engine SEN.
        startTurnSignal(senMode, side, true);
      }
    }
    // Sengaja TIDAK ada aksi saat level flasher OFF. OFF pendek bukan OFF SEN.
  }
}

void serviceSenAndBrakeRealtime() {
  if (!lampOn || !contactOn) return;
  unsigned long now = millis(); bool changed = false;
  if (turnEngine.active) {
    if (turnEngine.lastClock == 0) turnEngine.lastClock = now;
    unsigned long dt = now - turnEngine.lastClock; turnEngine.lastClock = now; if (dt > 100) dt = 100;

    // SATU-SATUNYA sumber kecepatan animasi SEN adalah senSpeed global aplikasi.
    // Frekuensi / duty-cycle flasher tidak ikut masuk perhitungan virtualTime.
    float spdFactor = calculateLiveSpeedFactor(senSpeed);
    turnEngine.virtualTime += ((float)dt * 0.001f) * spdFactor;
    changed = true;

    if (turnEngine.isPhysical) {
      // Jangan menganggap setiap OFF flasher sebagai OFF sein.
      // Baru minta selesai bila heartbeat benar-benar hilang cukup lama.
      if (!turnEngine.finishRequested &&
          senPhysicalLastPulseAt != 0UL &&
          (unsigned long)(now - senPhysicalLastPulseAt) >= SEN_FLASHER_HEARTBEAT_HOLD_MS) {
        turnEngine.finishRequested = true;
        turnEngine.finishRequestedAt = now;
      }

      if (turnEngine.finishRequested) {
        float cycleU = getTurnSignalProgress(turnEngine.virtualTime);
        // Tetap pertahankan permintaan user: saat SEN benar-benar OFF,
        // efek tidak dipotong; tunggu sampai siklus aktif selesai.
        if (cycleU >= 0.95f) {
          finishTurnSignal();
          senPhysicalLastPulseAt = 0UL;
        }
      }
    }
  }
  if (brakeEngine.active) changed = true;
  if (mundurEngine.active) changed = true;
  if (changed) { welcomeForceRender = true; modeForceRender = true; solidRgbForceRender = true; }
}

static void serviceRealtimeControl() {
  if (pendingChipUpdate) { uint16_t requested = pendingLedCount; pendingChipUpdate = false; uint16_t oldCount = activeLedCount; applyActiveLedCountToFastLED(oldCount, requested); }
  if (pendingWelcomeRestart) { pendingWelcomeRestart = false; if (lampOn && contactOn && mainSource == MAIN_WELCOME) startWelcome(); }
  if (pendingClearOutput) { pendingClearOutput = false; clearAllActiveOutputNow(); }
}

static uint8_t getChannelCodeClean(const uint8_t *p, size_t len) {
  if (len >= 8 && (p[7] >= 0x01 && p[7] <= 0x05)) return p[7];
  if (len >= 4 && (p[3] >= 0x01 && p[3] <= 0x05)) return p[3];
  return 0x03; // ALL
}

static std::string normalizeDmxPacket(const std::string &rx) {
  if (rx.size() < 4) return rx; const uint8_t *p = (const uint8_t*)rx.data();
  if (p[0] != 0x7B || p[1] != 0xFF) return rx; const uint8_t cmd = p[2];
  const bool shifted = (cmd == 0x01 || cmd == 0x02 || cmd == 0x03 || cmd == 0x04 || cmd == 0x05 || cmd == 0x07 || cmd == 0x11 || cmd == 0x14 || cmd == 0x16 || cmd == 0x18 || cmd == 0x19 || cmd == 0x1A);
  if (!shifted) return rx;
  std::string out; out.reserve(rx.size() - 1); out.push_back((char)p[0]);
  for (size_t i = 2; i < rx.size(); i++) out.push_back((char)p[i]); return out;
}

static void abortPendingUiSetups(bool feedback) {
  bool aborted = false;
  if (isMappingMode) { isMappingMode = false; mapTargetWelcome = 0xFF; mapTarget210 = 0xFF; k1PendingWelcome = 0xFF; k1DoubleClickWindowActive = false; k1FirstTapAt = 0; aborted = true; }
  if (k2SetupState > 0 || isWaitingToLockSelection) { k2SetupState = 0; isWaitingToLockSelection = false; pendingPlaylistSelection = 0xFF; aborted = true; }
  if (k3PauseActive || k3EditContext != 0 || k3EditStage != 0) { k3PauseActive = false; k3EditContext = 0; k3EditStage = 0; k3EditReceivedColor = false; k3TapCount = 0; k3ResetDecisionPending = false; pendingK3Show = false; aborted = true; }
  if (aborted && feedback) triggerBlink(CRGB::Red, 2);
}

static void serviceK1ClickArbiter() {
  if (!k1DoubleClickWindowActive) return;
  if (!isMappingMode || k1PendingWelcome != 0xFF) { k1DoubleClickWindowActive = false; k1FirstTapAt = 0; return; }
  if ((uint32_t)(millis() - k1FirstTapAt) >= K1_FACTORY_DOUBLE_CLICK_MS) {
    k1DoubleClickWindowActive = false; k1FirstTapAt = 0; triggerBlink(CRGB::Blue, 2);
    Serial.printf("[K1 SINGLE] Mode #%u terkunci -> pilih Welcome lalu tekan K1 lagi untuk save.\n", (unsigned)mapTarget210);
  }
}

static void serviceUiStateRecovery() {
  if (isMappingMode && (millis() - k1MappingLastActivityAt >= 35000UL)) {
    isMappingMode = false; mapTargetWelcome = 0xFF; mapTarget210 = 0xFF; k1PendingWelcome = 0xFF; k1DoubleClickWindowActive = false; k1FirstTapAt = 0;
  }
}

static void enterVehiclePreviewFromApp() {
  abortPendingUiSetups(false); cancelVisualFeedback();
  uint8_t target = mainSource; if (target == MAIN_WELCOME) target = welcomeReturnSource; if (target != MAIN_MODE && target != MAIN_RGB) target = MAIN_MODE;
  welcomePlaylistPlaying = false; welcomeRunning = false; welcomeForceRender = false; pendingWelcomeRestart = false; mainSource = target; welcomeReturnSource = target;
  refreshBaseSourceFlags();
  solidRgbForceRender = solidRgbActive; modeForceRender = modeRunning;
}

void finalizeK1Mapping(uint8_t welcomeId, uint8_t modeId) {
  if (modeId < 1 || modeId > 210) { isMappingMode = false; k1PendingWelcome = 0xFF; triggerBlink(CRGB::Red, 2); return; }
  mappedWelcome[welcomeId] = modeId; configuredWelcome = welcomeId; selectedWelcome = welcomeId; k2PlaylistConfigured = false; welcomePlaylistPlaying = false; mainSource = MAIN_WELCOME; isMappingMode = false; k1PendingWelcome = 0xFF; k1DoubleClickWindowActive = false; k1FirstTapAt = 0;
  pendingK1DirectWelcome = welcomeId; pendingK1DirectMode = modeId; pendingK1DirectSave = true; markSettingsUrgent();
  resetCustomSuites(); startWelcome();
}

static void processStage5Hex(const std::string &rxIn) {
  if (!rxIn.empty() && (uint8_t)rxIn[0] == 0x2A) return;
  std::string rx = normalizeDmxPacket(rxIn); const size_t len = rx.size(); if (len < 3) return;
  const uint8_t *p = (const uint8_t*)rx.data(); if (p[0] != 0x7B) return;
  const uint8_t cmd = p[1]; const uint8_t value = p[2];
  bleLastValidPacketAt = millis(); const uint8_t channel = getChannelCodeClean(p, len);

  // ================================================================
  // KONTAK ON = APP LOCK KE WELCOME, GLOBAL ON/OFF, DAN SETTING MUNDUR.
  // - Welcome 0x18 tetap normal.
  // - MUNDUR 0x1D diizinkan agar mode 1..10 dari LEDLAMP bawaan tersimpan.
  // - RGB/Mode210/SEN/REM/K1-K3 dan setting lain tetap mengikuti lock lama.
  // ================================================================
  if (!senjaPhysicalActive && cmd != 0x18 && cmd != 0x04 && cmd != 0x1D) {
    return;
  }

  // SISTEM LOCK PENGAMAN (ANTI-CHILD & ANTI-MALING)
  if (lockedState && cmd != 0x16 && cmd != 0x04 && cmd != 0x19 && cmd != 0x1A && cmd != 0x1D) {
    cancelVisualFeedback();
    triggerTargetBlink(CRGB::Red, 1, 0x0F); 
    return; 
  }

  switch (cmd) {
    case 0x01: {
      // Menu REM lama: target 0x04 = brightness REM.
      if (len >= 4 && p[3] == 0x04) {
        uint8_t v = value; if (v > 100U) v = 100U;
        remBrightness = v;
        modeForceRender = true; welcomeForceRender = true; solidRgbForceRender = true;
        markSettingsDirty();
        break;
      }

      uint8_t v = value; if (v < 1) v = 1; if (v > 100) v = 100;
      appBrightness = v; brightness255 = convertBrightness100To255(v);
      FastLED.setBrightness(brightness255); senBrightness = appBrightness; remBrightness = appBrightness;
      if (welcomeRunning) welcomeForceRender = true; if (solidRgbActive) solidRgbForceRender = true; if (modeRunning) modeForceRender = true; markSettingsDirty(); break;
    }
    case 0x02: {
      // Menu REM lama: target 0x04 = speed REM.
      if (len >= 4 && p[3] == 0x04) {
        uint8_t v = value; if (v < 1U) v = 1U; if (v > 100U) v = 100U;
        remSpeed = v;
        modeForceRender = true; welcomeForceRender = true; solidRgbForceRender = true;
        markSettingsDirty();
        break;
      }

      uint8_t v = value; if (v < 1) v = 1; if (v > 100) v = 100;
      appSpeed = v; liveSpeedFactor = calculateLiveSpeedFactor(v); senSpeed = appSpeed; remSpeed = appSpeed;
      if (welcomeRunning) welcomeForceRender = true; if (modeRunning) modeForceRender = true; markSettingsDirty(); break;
    }
    case 0x03: {
      senMenuActive = false;
      senDirectionTriggerLatched = false;
      senDirectionBothOffSince = 0UL;
      if (turnEngine.active && !turnEngine.isPhysical) { turnEngine.active = false; turnEngine.finishRequested = false; }
      if (brakeEngine.active && !brakeEngine.isPhysical) brakeEngine.active = false;
      cancelVisualFeedback(); lastRemAppRaw = 0; lastRemAppTapAt = 0;
      uint8_t mode = 0; if (value != 0xFF) { if (value >= 0x01 && value <= 0xD2) mode = value; else if (value >= 0xE0 && value <= 0xE9) mode = (uint8_t)(value - 0xDF); }
      if (isMappingMode) { k1MappingLastActivityAt = millis(); return; }
      abortPendingUiSetups(false);
      if (value == 0xFF) { autoMode = true; mainSource = MAIN_MODE; welcomeReturnSource = MAIN_MODE; welcomeRunning = false; setAllChannelSources(MAIN_MODE); resetCustomSuites(); resetAllChannelSuiteStates(); modeForceRender = true; }
      else if (mode) { autoMode = false; selectModeRealtime(mode, channel); }
      markSettingsUrgent(); break;
    }
    case 0x04: {
      const bool nextOn = (value == 0x01 || value == 0xFF);
      const int8_t targetChannel = channelCodeToIndex(channel);

      // Channel 0x01/0x02/0x04/0x05 = ON/OFF independen LED1..LED4.
      // Tidak mengganti source/mode dan tidak mengirim RGB hitam.
      if (targetChannel >= 0) {
        channelOutputEnabled[(uint8_t)targetChannel] = nextOn;
        if (nextOn && !lampOn) {
          lampOn = true;
          contactStandbyRedActive = false;
          startContextWelcome(senjaPhysicalActive ? 2U : 1U,
                              senjaPhysicalActive ? senjaWelcomeMode : contactWelcomeMode);
        }
        welcomeForceRender = true;
        modeForceRender = true;
        solidRgbForceRender = true;
        markSettingsDirty();
        break;
      }

      // Channel ALL (0x03) mempertahankan perilaku ON/OFF utama.
      lampOn = nextOn;
      for (uint8_t ch = 0; ch < 4U; ch++) channelOutputEnabled[ch] = nextOn;
      if (!lampOn) { senMenuActive = false; senDirectionTriggerLatched = false; senDirectionBothOffSince = 0UL; abortPendingUiSetups(false); cancelVisualFeedback(); welcomePlaylistPlaying = false; welcomeRunning = false; modeRunning = false; turnEngine.active = false; turnEngine.finishRequested = false; brakeEngine.active = false; mundurEngine.active = false; lastRemAppRaw = 0; pendingClearOutput = true; }
      else {
        contactStandbyRedActive = false;
        startContextWelcome(senjaPhysicalActive ? 2U : 1U,
                            senjaPhysicalActive ? senjaWelcomeMode : contactWelcomeMode);
        if (digitalRead(PIN_MUNDUR) == LOW) startMundur(selectedMundur, true);
      }
      markSettingsDirty(); break;
    }
    case 0x05: {
      if (len >= 5) {
        uint16_t cnt = ((uint16_t)p[3] << 8) | (uint16_t)p[4]; if (cnt < 1) cnt = 1; if (cnt > STAGE0_LED_BUFFER) cnt = STAGE0_LED_BUFFER;
        pendingLedCount = cnt; pendingChipUpdate = true; if (solidRgbActive) solidRgbForceRender = true; if (modeRunning) modeForceRender = true; markSettingsDirty();
      } break;
    }
    case 0x07: {
      senMenuActive = false;
      senDirectionTriggerLatched = false;
      senDirectionBothOffSince = 0UL;
      if (len >= 5) {
        const uint8_t r = p[2], g = p[3], b = p[4];
        if (k3PauseActive && k3EditContext != 0 && k3EditStage >= 1 && k3EditStage <= 4) {
          uint8_t idx = (uint8_t)(k3EditStage - 1U);
          if (k3EditContext == 1) {
            setEffectColorOverrideRAM(k3EditModeByChannel[idx], k3EditStage, r, g, b);
          } else if (k3EditContext == 2) {
            uint8_t wm = k3EditWelcomeByChannel[idx];
            setWelcomeColorOverrideRAM(wm, k3EditStage, r, g, b);
          } else if (k3EditContext == 3) {
            rgbR[idx] = r; rgbG[idx] = g; rgbB[idx] = b; solidRgbForceRender = true;
          }
          k3BuildPreviewFromBase(CRGB(r, g, b));
          k3EditReceivedColor = true; k3LastColorEditTime = millis(); pendingK3Show = true; return;
        }
        int8_t idx = channelCodeToIndex(channel);
        if (idx >= 0) {
          uint8_t ch = (uint8_t)idx; rgbR[ch] = r; rgbG[ch] = g; rgbB[ch] = b; channelSource[ch] = MAIN_RGB;
        } else {
          for (uint8_t ch = 0; ch < 4; ch++) { rgbR[ch] = r; rgbG[ch] = g; rgbB[ch] = b; channelSource[ch] = MAIN_RGB; }
        }
        if (turnEngine.active && !turnEngine.isPhysical) { turnEngine.active = false; turnEngine.finishRequested = false; }
        if (brakeEngine.active && !brakeEngine.isPhysical) brakeEngine.active = false;
        cancelVisualFeedback();
        welcomeRunning = false; pendingWelcomeRestart = false;
        welcomeReturnSource = MAIN_RGB; mainSource = MAIN_RGB; lampOn = true;
        refreshBaseSourceFlags();
        solidRgbForceRender = true; modeForceRender = true; markSettingsDirty();
      } break;
    }
    case 0x11: {
      selectedKButton = value; uint8_t btnId = value;
      if (btnId == 0x00) {
        unsigned long nowTap = millis();
        if (k1LastAcceptedTapAt != 0 && (uint32_t)(nowTap - k1LastAcceptedTapAt) < K1_BUTTON_DEBOUNCE_MS) { return; }
        k1LastAcceptedTapAt = nowTap;
        if (!isMappingMode) {
          abortPendingUiSetups(false);
          uint8_t currentMode = selectedMode[0]; if (currentMode < 1 || currentMode > 210) currentMode = 4;
          isMappingMode = true; mapTargetWelcome = 0xFF; mapTarget210 = currentMode; k1PendingWelcome = 0xFF;
          k1MappingLastActivityAt = nowTap; k1FirstTapAt = nowTap; k1DoubleClickWindowActive = true;
        } else {
          if (k1PendingWelcome != 0xFF) { k1DoubleClickWindowActive = false; k1FirstTapAt = 0; finalizeK1Mapping(k1PendingWelcome, mapTarget210); }
          else if (k1DoubleClickWindowActive && (uint32_t)(nowTap - k1FirstTapAt) <= K1_FACTORY_DOUBLE_CLICK_MS) {
            isMappingMode = false; mapTargetWelcome = 0xFF; mapTarget210 = 0xFF; k1PendingWelcome = 0xFF; k1DoubleClickWindowActive = false; k1FirstTapAt = 0; cancelVisualFeedback(); pendingK1FactoryReset = true;
          } else {
            isMappingMode = false; k1PendingWelcome = 0xFF; mapTargetWelcome = 0xFF; mapTarget210 = 0xFF; k1DoubleClickWindowActive = false; k1FirstTapAt = 0; triggerBlink(CRGB::Red, 2);
          }
        } return;
      }
      if (btnId == 0x01) {
        if (k2SetupState == 0) {
          abortPendingUiSetups(false); k2SetupState = 1; tempPlaylist[0] = welcomePlaylist[0]; tempPlaylist[1] = welcomePlaylist[1]; tempPlaylist[2] = welcomePlaylist[2]; isWaitingToLockSelection = false; triggerBlink(CRGB::Blue, 1);
        } else {
          k2SetupState = 0; isWaitingToLockSelection = false; if (tempPlaylist[0] == 0xFF) tempPlaylist[0] = 0x00; welcomePlaylist[0] = tempPlaylist[0]; welcomePlaylist[1] = tempPlaylist[1]; welcomePlaylist[2] = tempPlaylist[2]; k2PlaylistConfigured = true; pendingSaveWelcomePlaylist = true; triggerBlink(CRGB::Green, 3);
        } return;
      }
      if (btnId == 0x02) {
        unsigned long nowTap = millis();
        if (k3PauseActive) {
          if (k3TapCount > 0 && (nowTap - k3TapLastMs <= K3_DOUBLE_TAP_WINDOW)) {
            if (k3TapCount < 5) k3TapCount++; k3TapLastMs = nowTap; if (k3TapCount >= 2) k3ResetDecisionPending = true; return;
          }
          if (k3EditReceivedColor) { if (k3EditContext == 3) markSettingsUrgent(); else pendingPersistK3 = true; }
          k3PauseActive = false; k3EditContext = 0; k3EditStage = 0; k3EditReceivedColor = false; k3TapCount = 0; k3ResetDecisionPending = false; return;
        }
        abortPendingUiSetups(false);
        k3PauseActive = true; k3PauseStartedAt = nowTap; k3TapCount = 1; k3TapLastMs = nowTap; k3ResetDecisionPending = false; k3EditStage = 1; k3EditReceivedColor = false; k3EditStageStartedAt = nowTap;
        if (mainSource == MAIN_WELCOME) { k3EditContext = 2; for (uint8_t ch = 0; ch < 4; ch++) k3EditWelcomeByChannel[ch] = selectedWelcome; }
        else if (mainSource == MAIN_MODE) { k3EditContext = 1; for (uint8_t ch = 0; ch < 4; ch++) k3EditModeByChannel[ch] = selectedMode[ch]; }
        else if (mainSource == MAIN_RGB) { k3EditContext = 3; } else { k3EditContext = 0; }
        if (k3EditContext != 0) { k3CaptureEditFrame(1); signalK3EditStage(1); pendingK3Show = true; } return;
      } break;
    }
    case 0x14: { if (value <= 0x02) handleDmxSubarea(value); break; }
    case 0x16: { 
      lockedState = (value == 0x01 || value != 0x00); 
      cancelVisualFeedback();
      if (lockedState) {
        triggerTargetBlink(CRGB(255, 80, 0), 1, 0x0F);
      } else {
        triggerTargetBlink(CRGB(255, 80, 0), 2, 0x0F);
      }
      markSettingsUrgent(); 
      break; 
    }
    case 0x18: {
      senMenuActive = false;
      senDirectionTriggerLatched = false;
      senDirectionBothOffSince = 0UL;
      if (isMappingMode) {
        k1MappingLastActivityAt = millis();
        if (k1DoubleClickWindowActive) { k1DoubleClickWindowActive = false; k1FirstTapAt = 0; triggerBlink(CRGB::Blue, 2); }
        if (mapTarget210 < 1 || mapTarget210 > 210) { mapTarget210 = (selectedMode[0] >= 1 && selectedMode[0] <= 210) ? selectedMode[0] : 4; }
        k1PendingWelcome = value; selectedWelcome = value; resetCustomSuites(); startWelcome(); return;
      }
      if (k2SetupState > 0) {
        pendingPlaylistSelection = value; lastWelcomeSelectionTime = millis(); isWaitingToLockSelection = true; selectedWelcome = value; startWelcome(); return;
      }
      {
        if (turnEngine.active && !turnEngine.isPhysical) { turnEngine.active = false; turnEngine.finishRequested = false; }
        if (brakeEngine.active && !brakeEngine.isPhysical) brakeEngine.active = false;
        cancelVisualFeedback();
        welcomePlaylistPlaying = false;

        uint8_t w = value;
        if (w > 50U) w = 50U;

        if (!senjaPhysicalActive) {
          // KONTAK / PIN7 LOW:
          // scroll maupun klik Welcome hanya menyimpan CONTACT Welcome.
          contactWelcomeMode = w;
          contactStandbyRedActive = false;
          markSettingsUrgent();
          startContextWelcome(1U, contactWelcomeMode);
        } else {
          // SENJA / PIN7 HIGH:
          // Welcome SENJA tersimpan sendiri; menu lain tetap normal.
          senjaWelcomeMode = w;
          contactStandbyRedActive = false;
          markSettingsUrgent();
          startContextWelcome(2U, senjaWelcomeMode);
        }
      } break;
    }
    case 0x19: {
      senMenuActive = true;
      if (value == 0x00 || value == 0xFF) {
        cancelVisualFeedback();
        finishTurnSignal();
        markSettingsDirty(); // pilihan SEN terakhir tetap tersimpan
      } else if (value >= 0x01 && value <= 0x0A) {
        enterVehiclePreviewFromApp();
        registerSenAppSelection(value);
        startTurnSignal(getSenInternalMode(selectedSen ? selectedSen : value), 2, false);
        // registerSenAppSelection sudah autosave urgent untuk scroll maupun klik.
      }
      break;
    }
    case 0x1A: {
      senMenuActive = false;
      senDirectionTriggerLatched = false;
      senDirectionBothOffSince = 0UL;
      if (value == 0x00 || value == 0xFF) {
        cancelVisualFeedback();
        selectedRem = 0;
        finishBrake();
        lastRemAppRaw = 0;
      } else if (value >= 0x01 && value <= 0x0A) {
        // Tombol REM 1..10 = Mode REM 1..10.
        // Tidak ada remap/variant tersembunyi.
        lastRemAppRaw = value;
        lastRemAppTapAt = millis();
        enterVehiclePreviewFromApp();
        selectedRem = value;
        startBrake(value, false);
      }
      markSettingsDirty();
      break;
    }
    case 0x1D: {
      // Mapping terverifikasi dari aplikasi LEDLAMP bawaan:
      // 7B 1D 01..0A FF FF FF FF FF BF = MUNDUR Mode 1..10.
      senMenuActive = false;
      senDirectionTriggerLatched = false;
      senDirectionBothOffSince = 0UL;

      if (value == 0x00U || value == 0xFFU) {
        handleMundurBleValue(value);
      } else if (value >= 0x01U && value <= 0x0AU) {
        enterVehiclePreviewFromApp();
        handleMundurBleValue(value);
      }
      break;
    }
    default: break;
  }
}

// ============================================================================
// BLE CHARACTERISTIC CALLBACK — mapping MUNDUR 0x1D sudah final.
// ============================================================================
class Stage0CharacteristicCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *characteristic) override {
    std::string rx = characteristic->getValue();
    if (rx.empty()) return;
    processStage5Hex(rx);
  }
};

class Stage0ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *server) override {
    bleConnected = true;
    bleRestartRequested = false;
    bleLastValidPacketAt = millis();
    abortPendingUiSetups(false);
    Serial.printf("[BLE] CONNECT heap=%u\n", (unsigned)ESP.getFreeHeap());
    (void)server;
  }
  void onDisconnect(BLEServer *server) override {
    (void)server;
    Serial.printf("[BLE] DISCONNECT ota=%u rx=%u/%u heap=%u\n",
                  bleOtaActive ? 1U : 0U,
                  (unsigned)bleOtaReceivedSize,
                  (unsigned)bleOtaExpectedSize,
                  (unsigned)ESP.getFreeHeap());
    bleConnected = false; bleDisconnectedAt = millis(); bleRestartRequested = true;
    if (bleOtaActive) {
      Update.end(false);
      bleOtaActive = false;
      bleOtaExpectedSize = 0;
      bleOtaReceivedSize = 0;
      bleOtaLastNotifyBytes = 0;
    }
    senMenuActive = false; senDirectionTriggerLatched = false; senDirectionBothOffSince = 0UL;
    abortPendingUiSetups(false);
  }
};

void setupSingleLedcarAdvertising() {
  BLEAdvertising *adv = BLEDevice::getAdvertising(); if (!adv) return;
  adv->stop();

  // Advertisement utama dipertahankan persis untuk kompatibilitas LEDLAMP/LEDCAR.
  BLEAdvertisementData data;
  data.addData(std::string((const char*)ledcarAdvData, sizeof(ledcarAdvData)));
  adv->setAdvertisementData(data);

  // OTA FIX V2:
  // Web Bluetooth Windows/Android lebih stabil bila OTA service terlihat
  // pada hasil scan, bukan hanya tersedia setelah GATT discovery.
  BLEAdvertisementData scanData;
  scanData.addData(std::string((const char*)ledcarOtaScanData, sizeof(ledcarOtaScanData)));
  adv->setScanResponseData(scanData);
  adv->setScanResponse(true);

  // 100..150 ms: cukup responsif tanpa membanjiri radio.
  adv->setMinInterval(0xA0);
  adv->setMaxInterval(0xF0);
  adv->start();

  Serial.println("[BLE OTA] advertising FFE0 + OTA scan-response aktif");
}

void serviceBleRestart() {
  if (bleConnected || !bleRestartRequested) return;
  if (millis() - bleDisconnectedAt < 500UL) return;
  BLEAdvertising *adv = BLEDevice::getAdvertising(); if (adv) { adv->stop(); adv->start(); }
  bleRestartRequested = false;
}



class BleOtaControlCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *characteristic) override {
    std::string raw = characteristic->getValue();
    if (raw.empty()) return;
    String cmd(raw.c_str());
    cmd.trim();

    if (cmd.startsWith("START:")) {
      if (bleOtaActive) {
        bleOtaStatus("ERR:BUSY");
        return;
      }

      size_t imageSize = (size_t)strtoull(cmd.substring(6).c_str(), nullptr, 10);
      if (imageSize < 1024) {
        bleOtaStatus("ERR:BAD_SIZE");
        return;
      }

      bleOtaExpectedSize = imageSize;
      bleOtaReceivedSize = 0;
      bleOtaLastNotifyBytes = 0;

      if (!Update.begin(imageSize, U_FLASH)) {
        String err = "ERR:BEGIN:" + String((unsigned)Update.getError()) + ":SPACE:" + String((unsigned)ESP.getFreeSketchSpace());
        bleOtaStatus(err);
        bleOtaExpectedSize = 0;
        return;
      }

      bleOtaActive = true;
      bleOtaStatus("START_OK:" + String((unsigned)imageSize) + ":SPACE:" + String((unsigned)ESP.getFreeSketchSpace()));
      return;
    }

    if (cmd == "INFO") {
      bleOtaStatus("INFO:SPACE:" + String((unsigned)ESP.getFreeSketchSpace()) + ":HEAP:" + String((unsigned)ESP.getFreeHeap()));
      return;
    }

    if (cmd == "ABORT") {
      if (bleOtaActive) Update.end(false);
      bleOtaActive = false;
      bleOtaExpectedSize = 0;
      bleOtaReceivedSize = 0;
      bleOtaLastNotifyBytes = 0;
      bleOtaStatus("ABORTED");
      return;
    }

    if (cmd == "END") {
      if (!bleOtaActive) {
        bleOtaStatus("ERR:NOT_STARTED");
        return;
      }
      if (bleOtaReceivedSize != bleOtaExpectedSize) {
        String err = "ERR:SIZE:" + String((unsigned)bleOtaReceivedSize) + ":" + String((unsigned)bleOtaExpectedSize);
        Update.end(false);
        bleOtaActive = false;
        bleOtaStatus(err);
        return;
      }

      bool ok = Update.end();
      bleOtaActive = false;
      if (!ok) {
        bleOtaStatus("ERR:END:" + String((unsigned)Update.getError()));
        return;
      }

      bleOtaStatus("DONE:" + String((unsigned)bleOtaReceivedSize));
      bleOtaRestartPending = true;
      bleOtaRestartRequestedAt = millis();
      return;
    }

    bleOtaStatus("ERR:CMD");
  }
};

class BleOtaDataCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *characteristic) override {
    if (!bleOtaActive) return;
    std::string chunk = characteristic->getValue();
    if (chunk.empty()) return;

    size_t remaining = (bleOtaExpectedSize > bleOtaReceivedSize) ? (bleOtaExpectedSize - bleOtaReceivedSize) : 0;
    if (remaining == 0 || chunk.size() > remaining) {
      Update.end(false);
      bleOtaActive = false;
      bleOtaStatus("ERR:OVERFLOW");
      return;
    }

    size_t written = Update.write((uint8_t*)chunk.data(), chunk.size());
    if (written != chunk.size()) {
      Update.end(false);
      bleOtaActive = false;
      bleOtaStatus("ERR:WRITE:" + String((unsigned)Update.getError()));
      return;
    }

    bleOtaReceivedSize += written;
    if ((bleOtaReceivedSize - bleOtaLastNotifyBytes) >= 32768 || bleOtaReceivedSize == bleOtaExpectedSize) {
      bleOtaLastNotifyBytes = bleOtaReceivedSize;
      bleOtaStatus("PROGRESS:" + String((unsigned)bleOtaReceivedSize) + ":" + String((unsigned)bleOtaExpectedSize));
    }
  }
};

static void setupBleOtaService(BLEServer *server) {
  BLEService *otaService = server->createService(BLE_OTA_SERVICE_UUID);

  BLECharacteristic *dataCharacteristic = otaService->createCharacteristic(
    BLE_OTA_DATA_UUID,
    BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR
  );
  dataCharacteristic->setCallbacks(new BleOtaDataCallbacks());

  BLECharacteristic *ctrlCharacteristic = otaService->createCharacteristic(
    BLE_OTA_CTRL_UUID,
    BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_READ
  );
  ctrlCharacteristic->setCallbacks(new BleOtaControlCallbacks());
  ctrlCharacteristic->setValue("READY");

  bleOtaStatusCharacteristic = otaService->createCharacteristic(
    BLE_OTA_STATUS_UUID,
    BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY
  );
  bleOtaStatusCharacteristic->addDescriptor(new BLE2902());
  bleOtaStatusCharacteristic->setValue("READY");

  otaService->start();
}

void setupBleLedcar() {
  BLEDevice::init(BLE_NAME_CAR);

  // BLE OTA:
  // MTU 185 agar transfer lebih cepat; Worker tetap punya fallback 20 byte
  // jika peer hanya menyediakan MTU kecil.
  BLEDevice::setMTU(185);

  BLEServer *server = BLEDevice::createServer();
  server->setCallbacks(new Stage0ServerCallbacks());

  // Service LEDCAR asli FFE0/FFE1 tetap dipertahankan.
  BLEService *service = server->createService(SERVICE_UUID);
  BLECharacteristic *characteristic = service->createCharacteristic(
    CHARACTERISTIC_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR | BLECharacteristic::PROPERTY_NOTIFY
  );
  characteristic->setCallbacks(new Stage0CharacteristicCallbacks());
  characteristic->addDescriptor(new BLE2902());
  characteristic->setValue("MODE_5_10_WORK");
  service->start();

  // Service OTA terpisah untuk browser/Web Bluetooth.
  setupBleOtaService(server);
  setupSingleLedcarAdvertising();
}

void setupHardwareMapping() {
  pinMode(PIN_SEN_KIRI, INPUT_PULLUP); pinMode(PIN_SEN_KANAN, INPUT_PULLUP);
  pinMode(PIN_REM, INPUT_PULLUP); pinMode(PIN_MUNDUR, INPUT_PULLUP); pinMode(PIN_SENJA, INPUT_PULLDOWN);
  lastPhysSenKiri = (digitalRead(PIN_SEN_KIRI) == LOW); lastPhysSenKanan = (digitalRead(PIN_SEN_KANAN) == LOW);
  lastPhysRem = (digitalRead(PIN_REM) == LOW);
  lastPhysMundur = (digitalRead(PIN_MUNDUR) == LOW);
  senjaPhysicalActive = (digitalRead(PIN_SENJA) == HIGH);
  lastPhysSenja = senjaPhysicalActive;
  contactOn = true;
  ledController1 = &FastLED.addLeds<WS2812B, LED_PIN_1, GRB>(leds1, activeLedCount);
  ledController2 = &FastLED.addLeds<WS2812B, LED_PIN_2, GRB>(leds2, activeLedCount);
  ledController3 = &FastLED.addLeds<WS2812B, LED_PIN_3, GRB>(leds3, activeLedCount);
  ledController4 = &FastLED.addLeds<WS2812B, LED_PIN_4, GRB>(leds4, activeLedCount);
  FastLED.setBrightness(brightness255); FastLED.clear(true);
}

void setup() {
  Serial.begin(115200); delay(100);

  // =========================================================================
  // EKSEKUSI FORMAT NVS (JIKA DIAKTIFKAN)
  // =========================================================================
  if (WIPE_NVS_ON_BOOT) {
    nvs_flash_erase();
    nvs_flash_init();
    Serial.println("!!! NVS MEMORY WIPED - FORMAT BERHASIL !!!");
    delay(2000);
  }

  initTiming(); loadSavedSettings();
  if (!resizeRuntimeAuxBuffers(activeLedCount)) {
    Serial.println("[RAM] FATAL: buffer runtime tidak dapat dialokasikan");
    delay(1000);
    ESP.restart();
  }
  initWelcome1Timing(); setupHardwareMapping();

  // OTA Bluetooth only: tidak ada SoftAP, Wi-Fi STA, HTTP, atau TLS.
  setupBleLedcar();
  Serial.printf("[BLE OTA] READY name=%s space=%u heap=%u\n",
                BLE_NAME_CAR,
                (unsigned)ESP.getFreeSketchSpace(),
                (unsigned)ESP.getFreeHeap());
  FastLED.setBrightness(brightness255);
  contactOn = true;
  lampOn = true;
  contactStandbyRedActive = false;

  // Boot dibedakan total:
  // PIN7 LOW  -> Welcome CONTACT sendiri, selesai ke putih 4CH.
  // PIN7 HIGH -> Welcome SENJA sendiri, selesai kembali ke Mode/RGB normal.
  if (senjaPhysicalActive) {
    startContextWelcome(2U, senjaWelcomeMode);
  } else {
    startContextWelcome(1U, contactWelcomeMode);
  }

  // Bila kendaraan sudah berada pada posisi mundur saat modul boot,
  // GPIO10 tetap langsung mengaktifkan overlay putih terpilih.
  if (lastPhysMundur) startMundur(selectedMundur, true);
}

void loop() {
  // Saat flash OTA Bluetooth ditulis, hentikan renderer/Preferences sementara.
  if (bleOtaActive) { delay(1); return; }
  if (bleOtaRestartPending && (millis() - bleOtaRestartRequestedAt >= 2500UL)) { ESP.restart(); }
  handleNonBlockingBlink();
  serviceLegacyModePairPicker();

  if (k3ResetDecisionPending && k3TapCount >= 2 && (millis() - k3TapLastMs > K3_DOUBLE_TAP_WINDOW)) {
    uint8_t taps = k3TapCount; k3TapCount = 0; k3ResetDecisionPending = false;
    if (taps >= 5) performFactoryResetFromK3(); else performCurrentColorResetFromK3();
  }

  if (k3PauseActive && !k3EditReceivedColor && k3EditStage != 0 && (millis() - k3EditStageStartedAt >= K3_NO_COLOR_TIMEOUT_MS)) {
    k3PauseActive = false; k3EditContext = 0; k3EditStage = 0; k3EditReceivedColor = false; k3TapCount = 0; k3ResetDecisionPending = false;
    k3SafeShow();
  }

  if (k3PauseActive && k3EditReceivedColor && (millis() - k3LastColorEditTime >= K3_COLOR_SETTLE_MS)) {
    if (k3EditStage >= 1 && k3EditStage < 4) {
      if (k3EditContext == 1) saveK3RecordVerified(1, k3EditModeByChannel[k3EditStage - 1]);
      if (k3EditContext == 2) saveK3RecordVerified(2, k3EditWelcomeByChannel[k3EditStage - 1]);
            
      k3EditStage++; k3EditReceivedColor = false; k3EditStageStartedAt = millis();
      k3CaptureEditFrame(k3EditStage); signalK3EditStage(k3EditStage); k3SafeShow();
    } else if (k3EditStage == 4) {
      if (k3EditContext == 3) {
        saveSettingsNow(); solidRgbForceRender = true;
      } else {
        if (k3EditContext == 1) saveK3RecordVerified(1, k3EditModeByChannel[3]);
        if (k3EditContext == 2) saveK3RecordVerified(2, k3EditWelcomeByChannel[3]);
        persistK3ColorOverridesVerified();
      }
      k3PauseActive = false; k3EditContext = 0; k3EditStage = 0; k3EditReceivedColor = false; k3TapCount = 0; k3ResetDecisionPending = false;
      triggerBlink(CRGB::Blue, 1);
    }
  }

  if (k2SetupState > 0 && isWaitingToLockSelection) {
    if (millis() - lastWelcomeSelectionTime >= 5000) {
      isWaitingToLockSelection = false;
      if (k2SetupState == 1) { tempPlaylist[0] = pendingPlaylistSelection; k2SetupState = 2; triggerBlink(CRGB::White, 1); }
      else if (k2SetupState == 2) { tempPlaylist[1] = pendingPlaylistSelection; k2SetupState = 3; triggerBlink(CRGB::White, 2); }
      else if (k2SetupState >= 3) { tempPlaylist[2] = pendingPlaylistSelection; k2SetupState = 4; triggerBlink(CRGB::White, 3); }
    }
  }

  serviceDmxBoxSingleTap(); handlePhysicalPinsAndAutoMode(); serviceK1ClickArbiter(); serviceUiStateRecovery();

  if (pendingK1FactoryReset) {
    pendingK1FactoryReset = false; bool ok = resetK1MappingsFactoryVerified();
    if (ok) { triggerBlink(CRGB::Green, 5); } else { triggerBlink(CRGB::Red, 5); }
    if (mainSource == MAIN_WELCOME && lampOn && contactOn) { resetCustomSuites(); startWelcome(); }
    modeForceRender = true; welcomeForceRender = true;
  }

  if (pendingK1DirectSave) {
    uint8_t w = pendingK1DirectWelcome; uint8_t m = pendingK1DirectMode; pendingK1DirectSave = false;
    bool ok = saveK1DirectMappingVerified(w, m);
    if (!ok) { ok = saveK1DirectMappingVerified(w, m); }
    pendingK1DirectWelcome = 0xFF; pendingK1DirectMode = 0xFF;
    if (ok) { k1LastSavedWelcome = w; k1LastSavedMode = m; triggerBlink(CRGB::Green, 3); } 
    else { triggerBlink(CRGB::Red, 5); }
  }

  if (pendingSaveWelcomeMap || pendingSaveConfiguredWelcome) { pendingSaveWelcomeMap = false; pendingSaveConfiguredWelcome = false; saveSettingsNow(); }
  if (pendingSaveWelcomePlaylist) { pendingSaveWelcomePlaylist = false; prefs.begin("ledcar4ch", false); prefs.putBytes("welPlay", welcomePlaylist, 3); prefs.putBool("k2cfg", k2PlaylistConfigured); prefs.end(); }

  if (pendingPersistK3) {
    pendingPersistK3 = false;
    for (uint8_t i = 0; i < 4; i++) {
      if (k3EditContext == 1) saveK3RecordVerified(1, k3EditModeByChannel[i]);
      if (k3EditContext == 2) saveK3RecordVerified(2, k3EditWelcomeByChannel[i]);
    }
    persistK3ColorOverridesVerified();
  }

  if (pendingK3Show) { pendingK3Show = false; k3SafeShow(); }

  serviceBleRestart(); serviceRealtimeControl(); serviceSenAndBrakeRealtime();

  if (contactStandbyRedActive && !senjaPhysicalActive) {
    // CONTACT selesai Welcome -> putih 4CH sambil SEN/REM fisik tetap bisa overlay.
    serviceContactStandbyRed();
  } else if (mainSource == MAIN_WELCOME) {
    serviceWelcomeRealtime();
  } else {
    // RGB dan MODE boleh aktif bersamaan pada channel berbeda.
    if (solidRgbActive) serviceSolidRgbRealtime();
    if (modeRunning) serviceModeRealtime();
  }

  serviceDeferredAutoSave();

  yield();
}
