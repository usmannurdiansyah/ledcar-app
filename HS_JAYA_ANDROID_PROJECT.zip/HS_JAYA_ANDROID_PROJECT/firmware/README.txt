CUSTOM FIRMWARE STATUS

Firmware custom tidak perlu diubah untuk fitur multi-device di APK.
Versi yang disertakan sudah mempunyai:
- FFE0 / FFE1
- Mode 1..210 via 0x03
- MUNDUR 1..10 via opcode 0x1D
- LED1..LED4 independent via channel code custom
- OTA service 7e400001-b5a3-f393-e0a9-e50e24dcca9e pada scan response

OTA service tersebut dipakai APK HS JAYA untuk membedakan custom firmware dari stock
walaupun nama BLE custom masih LEDCAR-02-9931.

AUTO/COLLECT sekarang sengaja dijalankan di sisi APK sebagai playlist command Mode 1..210.
Karena itu Collect dapat berjalan pada stock LEDCAR/LEDDMX dan custom firmware tanpa opcode
Collect khusus pada firmware.
