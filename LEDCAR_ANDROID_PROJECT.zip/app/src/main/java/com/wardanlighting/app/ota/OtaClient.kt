package com.wardanlighting.app.ota

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.util.Log
import com.wardanlighting.app.ble.BleManager
import com.wardanlighting.app.model.OtaStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

@SuppressLint("MissingPermission")
class OtaClient(private val bleManager: BleManager) {

    companion object {
        private const val TAG = "OtaClient"
        private const val CHUNK_SIZE = 180
    }

    private val _status = MutableStateFlow(OtaStatus.IDLE)
    val status: StateFlow<OtaStatus> = _status.asStateFlow()

    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress.asStateFlow()

    private val _statusMessage = MutableStateFlow("Siap untuk update")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    suspend fun startOta(binBytes: ByteArray): Boolean {
        val gatt = bleManager.getGatt()
        val ctrlChar = bleManager.otaCtrlChar
        val dataChar = bleManager.otaDataChar

        if (gatt == null || ctrlChar == null || dataChar == null) {
            _status.value = OtaStatus.ERROR
            _statusMessage.value = "BLE OTA tidak terhubung atau perangkat belum siap"
            return false
        }

        try {
            _status.value = OtaStatus.PREPARING
            _statusMessage.value = "Menginisialisasi OTA..."
            _progress.value = 0f

            // 1. Send START:<size>
            val startCommand = "START:${binBytes.size}"
            ctrlChar.value = startCommand.toByteArray(Charsets.UTF_8)
            ctrlChar.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            val startWrote = gatt.writeCharacteristic(ctrlChar)
            if (!startWrote) {
                _status.value = OtaStatus.ERROR
                _statusMessage.value = "Gagal memulai sesi OTA"
                return false
            }

            delay(600)

            // 2. Stream Data Chunks
            _status.value = OtaStatus.UPLOADING
            val totalBytes = binBytes.size
            var bytesSent = 0

            while (bytesSent < totalBytes) {
                val chunkSize = (totalBytes - bytesSent).coerceAtMost(CHUNK_SIZE)
                val chunk = binBytes.copyOfRange(bytesSent, bytesSent + chunkSize)

                dataChar.value = chunk
                dataChar.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                gatt.writeCharacteristic(dataChar)

                bytesSent += chunkSize
                val currentProgress = bytesSent.toFloat() / totalBytes.toFloat()
                _progress.value = currentProgress
                val kbSent = bytesSent / 1024
                val kbTotal = totalBytes / 1024
                _statusMessage.value = "Mengirim firmware: $kbSent KB / $kbTotal KB (${(currentProgress * 100).toInt()}%)"

                delay(12) // Throttle to prevent packet loss
            }

            // 3. Send END
            _status.value = OtaStatus.COMPLETING
            _statusMessage.value = "Memverifikasi firmware..."
            delay(500)

            val endCommand = "END"
            ctrlChar.value = endCommand.toByteArray(Charsets.UTF_8)
            ctrlChar.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            gatt.writeCharacteristic(ctrlChar)

            delay(1500)
            _status.value = OtaStatus.SUCCESS
            _statusMessage.value = "Update OTA Berhasil! Perangkat sedang merestart..."
            return true

        } catch (e: Exception) {
            Log.e(TAG, "Error during OTA: ${e.message}", e)
            _status.value = OtaStatus.ERROR
            _statusMessage.value = "Kesalahan OTA: ${e.localizedMessage}"
            return false
        }
    }

    fun reset() {
        _status.value = OtaStatus.IDLE
        _progress.value = 0f
        _statusMessage.value = "Siap untuk update"
    }
}
