package com.wardanlighting.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wardanlighting.app.ble.BleManager
import com.wardanlighting.app.model.ChannelSelection
import com.wardanlighting.app.model.ConnectionStatus
import com.wardanlighting.app.ui.components.ColorWheel
import com.wardanlighting.app.ui.components.NeonBrightnessSlider
import com.wardanlighting.app.ui.components.WlLogoHeader
import com.wardanlighting.app.ui.theme.*

@Composable
fun HomeControlScreen(
    bleManager: BleManager,
    onNavigateToSettings: () -> Unit,
    onNavigateToOta: () -> Unit,
    onNavigateToCollect: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedChannel by remember { mutableStateOf(ChannelSelection.ALL) }
    var isPowerOn by remember { mutableStateOf(true) }
    var brightness by remember { mutableStateOf(50) }

    var showWelcomeDialog by remember { mutableStateOf(false) }
    var showRemDialog by remember { mutableStateOf(false) }
    var showSenDialog by remember { mutableStateOf(false) }
    var showBleScanDialog by remember { mutableStateOf(false) }

    var selectedWelcome by remember { mutableStateOf(0) }
    var selectedRem by remember { mutableStateOf(1) }
    var selectedSen by remember { mutableStateOf(1) }

    val connectionStatus by bleManager.connectionStatus.collectAsState()
    val scannedDevices by bleManager.scannedDevices.collectAsState()

    val presetColors = listOf(
        Color(0xFFFF0000),
        Color(0xFFFF7A00),
        Color(0xFFFFD600),
        Color(0xFF00E676),
        Color(0xFF00E5FF),
        Color(0xFF2979FF),
        Color(0xFFFFFFFF)
    )

    if (showWelcomeDialog) {
        WelcomeSelectionDialog(
            currentWelcome = selectedWelcome,
            onDismiss = { showWelcomeDialog = false },
            onSelect = { wId ->
                selectedWelcome = wId
                bleManager.sendWelcome(wId)
            }
        )
    }

    if (showRemDialog) {
        RemSelectionDialog(
            currentRem = selectedRem,
            onDismiss = { showRemDialog = false },
            onSelect = { rId ->
                selectedRem = rId
                bleManager.sendRem(rId)
            }
        )
    }

    if (showSenDialog) {
        SenSelectionDialog(
            currentSen = selectedSen,
            onDismiss = { showSenDialog = false },
            onSelect = { sId ->
                selectedSen = sId
                bleManager.sendSen(sId)
            }
        )
    }

    if (showBleScanDialog) {
        BleScanDialog(
            devices = scannedDevices,
            isScanning = connectionStatus == ConnectionStatus.SCANNING,
            onDismiss = {
                bleManager.stopScan()
                showBleScanDialog = false
            },
            onScan = { bleManager.startScan() },
            onSelectDevice = { addr ->
                bleManager.connect(addr)
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepBackground)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNavigateToSettings) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Menu",
                    tint = TextPrimary
                )
            }

            WlLogoHeader()

            IconButton(onClick = {
                bleManager.startScan()
                showBleScanDialog = true
            }) {
                Icon(
                    imageVector = if (connectionStatus == ConnectionStatus.CONNECTED) Icons.Default.BluetoothConnected else Icons.Default.Bluetooth,
                    contentDescription = "Bluetooth",
                    tint = if (connectionStatus == ConnectionStatus.CONNECTED) NeonCyan else TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Channel Selection Tabs (LED1 | ALL | LED2 | Collect)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(CardBackground)
                .border(1.dp, CardBorder, RoundedCornerShape(24.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            ChannelSelection.values().forEach { ch ->
                val isSelected = ch == selectedChannel
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) ActiveBlue else Color.Transparent)
                        .clickable {
                            if (ch == ChannelSelection.COLLECT) {
                                onNavigateToCollect()
                            } else {
                                selectedChannel = ch
                            }
                        }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = ch.label,
                        color = if (isSelected) TextPrimary else TextMuted,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Circular Color Wheel with Center Power Toggle
        ColorWheel(
            modifier = Modifier.padding(vertical = 6.dp),
            isPowerOn = isPowerOn,
            onPowerToggle = {
                isPowerOn = !isPowerOn
                bleManager.sendPower(isPowerOn)
            },
            onColorSelected = { r, g, b ->
                bleManager.sendColorRgb(r, g, b, selectedChannel.code)
            }
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Preset Colors Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            presetColors.forEach { color ->
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(color)
                        .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                        .clickable {
                            val r = (color.red * 255).toInt()
                            val g = (color.green * 255).toInt()
                            val b = (color.blue * 255).toInt()
                            bleManager.sendColorRgb(r, g, b, selectedChannel.code)
                        }
                )
            }
            // Plus Button
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(CardSurface)
                    .border(1.dp, CardBorder, CircleShape)
                    .clickable {
                        // Default white pulse or custom
                        bleManager.sendColorRgb(255, 255, 255, selectedChannel.code)
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Color",
                    tint = TextPrimary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Brightness Slider
        NeonBrightnessSlider(
            value = brightness,
            onValueChange = {
                brightness = it
                bleManager.sendBrightness(it)
            }
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Quick Action Buttons (2x2 Grid: WELCOME, REM, SET 1-3, Update OTA)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ActionCardButton(
                icon = Icons.Default.Star,
                iconTint = AccentAmber,
                label = "WELCOME >",
                modifier = Modifier.weight(1f),
                onClick = { showWelcomeDialog = true }
            )
            ActionCardButton(
                icon = Icons.Default.Warning,
                iconTint = AccentRed,
                label = "REM >",
                modifier = Modifier.weight(1f),
                onClick = { showRemDialog = true }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ActionCardButton(
                icon = Icons.Default.Tune,
                iconTint = NeonCyan,
                label = "SET 1-3 >",
                modifier = Modifier.weight(1f),
                onClick = { showSenDialog = true }
            )
            ActionCardButton(
                icon = Icons.Default.CloudUpload,
                iconTint = ElectricBlue,
                label = "Update OTA",
                modifier = Modifier.weight(1f),
                onClick = onNavigateToOta
            )
        }
    }
}

@Composable
fun ActionCardButton(
    icon: ImageVector,
    iconTint: Color,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(48.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
