package com.wardanlighting.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wardanlighting.app.ble.BleManager
import com.wardanlighting.app.ui.components.ModeDrumColumn
import com.wardanlighting.app.ui.components.NeonBrightnessSlider
import com.wardanlighting.app.ui.components.NeonSpeedSlider
import com.wardanlighting.app.ui.theme.*

@Composable
fun ModeScreen(
    bleManager: BleManager,
    onBack: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedChannelTab by remember { mutableStateOf(0) } // 0 = LED1, 1 = LED2
    var modeLed1 by remember { mutableStateOf(1) }
    var modeLed2 by remember { mutableStateOf(1) }
    var speed by remember { mutableStateOf(50) }
    var brightness by remember { mutableStateOf(50) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepBackground)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Text(
                text = "Mode (210 Efek)",
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = onNavigateToSettings) {
                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = TextMuted)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // LED1 / LED2 Channel Selector Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(CardBackground)
                .border(1.dp, CardBorder, RoundedCornerShape(24.dp))
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (selectedChannelTab == 0) ActiveBlue else Color.Transparent)
                    .clickable { selectedChannelTab = 0 }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "LED1",
                    color = if (selectedChannelTab == 0) TextPrimary else TextMuted,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (selectedChannelTab == 1) ActiveBlue else Color.Transparent)
                    .clickable { selectedChannelTab = 1 }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "LED2",
                    color = if (selectedChannelTab == 1) TextPrimary else TextMuted,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Dual Scroll Drum Picker (LED1 and LED2 side by side)
        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ModeDrumColumn(
                title = "LED1",
                selectedMode = modeLed1,
                onModeSelect = { m ->
                    modeLed1 = m
                    bleManager.sendMode(m, 0x01.toByte())
                },
                modifier = Modifier.weight(1f)
            )

            ModeDrumColumn(
                title = "LED2",
                selectedMode = modeLed2,
                onModeSelect = { m ->
                    modeLed2 = m
                    bleManager.sendMode(m, 0x02.toByte())
                },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Auto Mode Toggle Button
        Button(
            onClick = { bleManager.sendMode(0xFF) },
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CardSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("Auto Mode (Ganti Otomatis)", color = NeonCyan, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Sliders
        NeonSpeedSlider(
            value = speed,
            onValueChange = {
                speed = it
                bleManager.sendSpeed(it)
            }
        )

        NeonBrightnessSlider(
            value = brightness,
            onValueChange = {
                brightness = it
                bleManager.sendBrightness(it)
            }
        )
    }
}
