package com.wardanlighting.app.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.wardanlighting.app.model.BleDeviceItem
import com.wardanlighting.app.model.ConnectionStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

@SuppressLint("MissingPermission")
class BleManager(private val context: Context) {

    companion object {
        private const val TAG = "BleManager"

        val SERVICE_UUID: UUID = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb")
        val CHARACTERISTIC_UUID: UUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb")

        val BLE_OTA_SERVICE_UUID: UUID = UUID.fromString("7e400001-b5a3-f393-e0a9-e50e24dcca9e")
        val BLE_OTA_DATA_UUID: UUID = UUID.fromString("7e400002-b5a3-f393-e0a9-e50e24dcca9e")
        val BLE_OTA_CTRL_UUID: UUID = UUID.fromString("7e400003-b5a3-f393-e0a9-e50e24dcca9e")
        val BLE_OTA_STATUS_UUID: UUID = UUID.fromString("7e400004-b5a3-f393-e0a9-e50e24dcca9e")
    }

    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter = bluetoothManager?.adapter
    private var bluetoothGatt: BluetoothGatt? = null

    private var txCharacteristic: BluetoothGattCharacteristic? = null

    // OTA characteristics
    var otaDataChar: BluetoothGattCharacteristic? = null
        private set
    var otaCtrlChar: BluetoothGattCharacteristic? = null
        private set
    var otaStatusChar: BluetoothGattCharacteristic? = null
        private set

    private val _connectionStatus = MutableStateFlow(ConnectionStatus.DISCONNECTED)
    val connectionStatus: StateFlow<ConnectionStatus> = _connectionStatus.asStateFlow()

    private val _connectedDeviceName = MutableStateFlow<String?>(null)
    val connectedDeviceName: StateFlow<String?> = _connectedDeviceName.asStateFlow()

    private val _scannedDevices = MutableStateFlow<List<BleDeviceItem>>(emptyList())
    val scannedDevices: StateFlow<List<BleDeviceItem>> = _scannedDevices.asStateFlow()

    private val handler = Handler(Looper.getMainLooper())
    private var isScanning = false

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device ?: return
            val name = result.scanRecord?.deviceName ?: device.name ?: "Unknown LED Device"
            val address = device.address ?: return
            val rssi = result.rssi

            val currentList = _scannedDevices.value.toMutableList()
            val existingIndex = currentList.indexOfFirst { it.address == address }
            if (existingIndex >= 0) {
                currentList[existingIndex] = BleDeviceItem(name, address, rssi)
            } else {
                currentList.add(BleDeviceItem(name, address, rssi))
            }
            _scannedDevices.value = currentList.sortedByDescending { it.rssi }

            // Auto connect if device name contains LEDCAR or LEDLAMP
            if (_connectionStatus.value == ConnectionStatus.SCANNING &&
                (name.contains("LEDCAR", ignoreCase = true) || name.contains("LEDLAMP", ignoreCase = true))) {
                stopScan()
                connect(address)
            }
        }

        override fun onScanFailed(errorCode: Int) {
            Log.e(TAG, "BLE Scan failed: $errorCode")
            _connectionStatus.value = ConnectionStatus.DISCONNECTED
            isScanning = false
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    Log.i(TAG, "Connected to GATT server.")
                    _connectionStatus.value = ConnectionStatus.CONNECTING
                    _connectedDeviceName.value = gatt.device?.name ?: "LEDCAR Device"
                    gatt.requestMtu(185)
                    gatt.discoverServices()
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    Log.i(TAG, "Disconnected from GATT server.")
                    _connectionStatus.value = ConnectionStatus.DISCONNECTED
                    _connectedDeviceName.value = null
                    txCharacteristic = null
                    otaDataChar = null
                    otaCtrlChar = null
                    otaStatusChar = null
                    bluetoothGatt?.close()
                    bluetoothGatt = null
                }
            }
        }

        override fun onMtuChanged(gatt: BluetoothGatt?, mtu: Int, status: Int) {
            Log.i(TAG, "MTU changed to $mtu, status: $status")
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                val ledService = gatt.getService(SERVICE_UUID)
                txCharacteristic = ledService?.getCharacteristic(CHARACTERISTIC_UUID)

                val otaService = gatt.getService(BLE_OTA_SERVICE_UUID)
                otaDataChar = otaService?.getCharacteristic(BLE_OTA_DATA_UUID)
                otaCtrlChar = otaService?.getCharacteristic(BLE_OTA_CTRL_UUID)
                otaStatusChar = otaService?.getCharacteristic(BLE_OTA_STATUS_UUID)

                // Enable notifications on FFE1 if present
                txCharacteristic?.let { char ->
                    gatt.setCharacteristicNotification(char, true)
                }

                // Enable notifications on OTA status
                otaStatusChar?.let { char ->
                    gatt.setCharacteristicNotification(char, true)
                    val descriptor = char.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
                    descriptor?.let {
                        it.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        gatt.writeDescriptor(it)
                    }
                }

                _connectionStatus.value = ConnectionStatus.CONNECTED
                Log.i(TAG, "Services discovered. Connected & Ready.")
            } else {
                Log.w(TAG, "onServicesDiscovered received: $status")
            }
        }
    }

    fun startScan() {
        if (isScanning || bluetoothAdapter == null || !bluetoothAdapter.isEnabled) return
        _scannedDevices.value = emptyList()
        _connectionStatus.value = ConnectionStatus.SCANNING
        isScanning = true

        bluetoothAdapter.bluetoothLeScanner?.startScan(scanCallback)

        handler.postDelayed({
            if (isScanning) {
                stopScan()
            }
        }, 12000)
    }

    fun stopScan() {
        if (!isScanning) return
        isScanning = false
        bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback)
        if (_connectionStatus.value == ConnectionStatus.SCANNING) {
            _connectionStatus.value = ConnectionStatus.DISCONNECTED
        }
    }

    fun connect(address: String) {
        val device = bluetoothAdapter?.getRemoteDevice(address) ?: return
        disconnect()
        _connectionStatus.value = ConnectionStatus.CONNECTING
        bluetoothGatt = device.connectGatt(context, false, gattCallback)
    }

    fun disconnect() {
        bluetoothGatt?.disconnect()
        bluetoothGatt?.close()
        bluetoothGatt = null
        txCharacteristic = null
        otaDataChar = null
        otaCtrlChar = null
        otaStatusChar = null
        _connectionStatus.value = ConnectionStatus.DISCONNECTED
        _connectedDeviceName.value = null
    }

    fun sendRawPacket(data: ByteArray): Boolean {
        val gatt = bluetoothGatt ?: return false
        val char = txCharacteristic ?: return false

        char.value = data
        char.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        return gatt.writeCharacteristic(char)
    }

    // 0x01: Brightness
    fun sendBrightness(value: Int, isRem: Boolean = false) {
        val clamped = value.coerceIn(1, 100).toByte()
        val packet = if (isRem) {
            byteArrayOf(0x7B.toByte(), 0x01.toByte(), clamped, 0x04.toByte())
        } else {
            byteArrayOf(0x7B.toByte(), 0x01.toByte(), clamped)
        }
        sendRawPacket(packet)
    }

    // 0x02: Speed
    fun sendSpeed(value: Int, isRem: Boolean = false) {
        val clamped = value.coerceIn(1, 100).toByte()
        val packet = if (isRem) {
            byteArrayOf(0x7B.toByte(), 0x02.toByte(), clamped, 0x04.toByte())
        } else {
            byteArrayOf(0x7B.toByte(), 0x02.toByte(), clamped)
        }
        sendRawPacket(packet)
    }

    // 0x03: Mode (1..210, 0xFF = Auto)
    fun sendMode(mode: Int, channelCode: Byte = 0x03.toByte()) {
        val packet = if (mode == 0xFF || mode > 210) {
            byteArrayOf(0x7B.toByte(), 0x03.toByte(), 0xFF.toByte())
        } else {
            byteArrayOf(0x7B.toByte(), 0x03.toByte(), mode.toByte(), channelCode)
        }
        sendRawPacket(packet)
    }

    // 0x04: Power Lamp (1 = ON, 0 = OFF)
    fun sendPower(on: Boolean) {
        val packet = byteArrayOf(0x7B.toByte(), 0x04.toByte(), if (on) 0x01.toByte() else 0x00.toByte())
        sendRawPacket(packet)
    }

    // 0x05: Chip Settings (LED Count)
    fun sendChipSettings(ledCount: Int) {
        val clamped = ledCount.coerceIn(1, 1000)
        val high = ((clamped shr 8) and 0xFF).toByte()
        val low = (clamped and 0xFF).toByte()
        val packet = byteArrayOf(0x7B.toByte(), 0x05.toByte(), 0x00.toByte(), high, low)
        sendRawPacket(packet)
    }

    // 0x07: Color RGB
    fun sendColorRgb(r: Int, g: Int, b: Int, channelCode: Byte = 0x03.toByte()) {
        val packet = byteArrayOf(
            0x7B.toByte(),
            0x07.toByte(),
            r.coerceIn(0, 255).toByte(),
            g.coerceIn(0, 255).toByte(),
            b.coerceIn(0, 255).toByte(),
            0x00.toByte(),
            0x00.toByte(),
            channelCode
        )
        sendRawPacket(packet)
    }

    // 0x11: Button K (0=K1, 1=K2, 2=K3)
    fun sendButtonK(buttonId: Int) {
        val packet = byteArrayOf(0x7B.toByte(), 0x11.toByte(), buttonId.toByte())
        sendRawPacket(packet)
    }

    // 0x14: Subarea (0x02 = Left, 0x00 = Box/Center, 0x01 = Right)
    fun sendSubarea(area: Byte) {
        val packet = byteArrayOf(0x7B.toByte(), 0x14.toByte(), area)
        sendRawPacket(packet)
    }

    // 0x16: Lock (1 = Lock, 0 = Unlock)
    fun sendLock(locked: Boolean) {
        val packet = byteArrayOf(0x7B.toByte(), 0x16.toByte(), if (locked) 0x01.toByte() else 0x00.toByte())
        sendRawPacket(packet)
    }

    // 0x18: Welcome (0..50)
    fun sendWelcome(welcomeId: Int) {
        val packet = byteArrayOf(0x7B.toByte(), 0x18.toByte(), welcomeId.coerceIn(0, 50).toByte())
        sendRawPacket(packet)
    }

    // 0x19: Sen (Turn Signal: 1..10, 0 = OFF)
    fun sendSen(senId: Int) {
        val packet = byteArrayOf(0x7B.toByte(), 0x19.toByte(), senId.coerceIn(0, 10).toByte())
        sendRawPacket(packet)
    }

    // 0x1A: Rem (Brake: 1..10, 0 = OFF)
    fun sendRem(remId: Int) {
        val packet = byteArrayOf(0x7B.toByte(), 0x1A.toByte(), remId.coerceIn(0, 10).toByte())
        sendRawPacket(packet)
    }

    fun getGatt(): BluetoothGatt? = bluetoothGatt
}
