package com.wardanlighting.app.model

enum class ChannelSelection(val code: Byte, val label: String) {
    LED1(0x01, "LED1"),
    ALL(0x03, "ALL"),
    LED2(0x02, "LED2"),
    COLLECT(0x00, "Collect")
}

data class CollectItem(
    val id: String,
    val modeNumber: Int,
    val name: String,
    val speed: Int = 50,
    val brightness: Int = 50
)

data class BleDeviceItem(
    val name: String,
    val address: String,
    val rssi: Int
)

enum class ConnectionStatus {
    DISCONNECTED,
    SCANNING,
    CONNECTING,
    CONNECTED
}

enum class OtaStatus {
    IDLE,
    PREPARING,
    UPLOADING,
    COMPLETING,
    SUCCESS,
    ERROR
}
