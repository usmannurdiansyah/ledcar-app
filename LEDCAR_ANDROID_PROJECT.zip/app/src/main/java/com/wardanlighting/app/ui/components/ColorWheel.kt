package com.wardanlighting.app.ui.components

import android.graphics.Color as AndroidColor
import android.graphics.Paint as AndroidPaint
import android.graphics.SweepGradient
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.wardanlighting.app.ui.theme.CardBackground
import com.wardanlighting.app.ui.theme.CardBorder
import com.wardanlighting.app.ui.theme.NeonCyan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

@Composable
fun ColorWheel(
    modifier: Modifier = Modifier,
    isPowerOn: Boolean,
    onPowerToggle: () -> Unit,
    onColorSelected: (Int, Int, Int) -> Unit
) {
    var touchX by remember { mutableStateOf(0f) }
    var touchY by remember { mutableStateOf(0f) }

    Box(
        modifier = modifier
            .size(240.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val centerX = size.width / 2f
                        val centerY = size.height / 2f
                        val dx = offset.x - centerX
                        val dy = offset.y - centerY
                        val distance = sqrt(dx * dx + dy * dy)
                        val outerRadius = size.width / 2f
                        val innerRadius = outerRadius * 0.45f

                        if (distance in innerRadius..outerRadius) {
                            touchX = offset.x
                            touchY = offset.y
                            var angle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                            if (angle < 0) angle += 360f

                            val hsv = floatArrayOf(angle, 1.0f, 1.0f)
                            val rgb = AndroidColor.HSVToColor(hsv)
                            val r = AndroidColor.red(rgb)
                            val g = AndroidColor.green(rgb)
                            val b = AndroidColor.blue(rgb)
                            onColorSelected(r, g, b)
                        }
                    }
                }
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        val centerX = size.width / 2f
                        val centerY = size.height / 2f
                        val dx = change.position.x - centerX
                        val dy = change.position.y - centerY
                        val distance = sqrt(dx * dx + dy * dy)
                        val outerRadius = size.width / 2f
                        val innerRadius = outerRadius * 0.45f

                        if (distance in innerRadius..outerRadius) {
                            touchX = change.position.x
                            touchY = change.position.y
                            var angle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                            if (angle < 0) angle += 360f

                            val hsv = floatArrayOf(angle, 1.0f, 1.0f)
                            val rgb = AndroidColor.HSVToColor(hsv)
                            val r = AndroidColor.red(rgb)
                            val g = AndroidColor.green(rgb)
                            val b = AndroidColor.blue(rgb)
                            onColorSelected(r, g, b)
                        }
                    }
                }
        ) {
            val width = size.width
            val height = size.height
            val centerX = width / 2f
            val centerY = height / 2f
            val radius = width / 2f
            val strokeWidth = radius * 0.50f

            drawIntoCanvas { canvas ->
                val colors = intArrayOf(
                    AndroidColor.RED,
                    AndroidColor.YELLOW,
                    AndroidColor.GREEN,
                    AndroidColor.CYAN,
                    AndroidColor.BLUE,
                    AndroidColor.MAGENTA,
                    AndroidColor.RED
                )
                val shader = SweepGradient(centerX, centerY, colors, null)
                val paint = AndroidPaint().apply {
                    this.isAntiAlias = true
                    this.style = AndroidPaint.Style.STROKE
                    this.strokeWidth = strokeWidth
                    this.shader = shader
                }
                canvas.nativeCanvas.drawCircle(centerX, centerY, radius - strokeWidth / 2f, paint)
            }
        }

        // Center Power Button
        Box(
            modifier = Modifier
                .size(76.dp)
                .shadow(8.dp, CircleShape)
                .clip(CircleShape)
                .background(CardBackground)
                .padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            IconButton(
                onClick = onPowerToggle,
                modifier = Modifier.fillMaxSize()
            ) {
                Icon(
                    imageVector = Icons.Default.PowerSettingsNew,
                    contentDescription = "Power",
                    tint = if (isPowerOn) NeonCyan else Color(0xFF64748B),
                    modifier = Modifier.size(38.dp)
                )
            }
        }
    }
}
