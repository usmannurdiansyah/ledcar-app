package com.wardanlighting.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.wardanlighting.app.ble.BleManager
import com.wardanlighting.app.ota.OtaClient
import com.wardanlighting.app.ui.components.BottomNavBar
import com.wardanlighting.app.ui.components.BottomNavTab
import com.wardanlighting.app.ui.screens.*
import com.wardanlighting.app.ui.theme.DeepBackground
import com.wardanlighting.app.ui.theme.WardanLightingTheme

class MainActivity : ComponentActivity() {

    private lateinit var bleManager: BleManager
    private lateinit var otaClient: OtaClient

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        if (allGranted) {
            bleManager.startScan()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bleManager = BleManager(this)
        otaClient = OtaClient(bleManager)

        checkAndRequestPermissions()

        setContent {
            WardanLightingTheme {
                var currentTab by remember { mutableStateOf(BottomNavTab.RGB) }
                var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = DeepBackground,
                    bottomBar = {
                        BottomNavBar(
                            selectedTab = currentTab,
                            onTabSelected = { tab ->
                                currentTab = tab
                                currentScreen = when (tab) {
                                    BottomNavTab.RGB -> Screen.Home
                                    BottomNavTab.MODE -> Screen.Mode
                                    BottomNavTab.COLLECT -> Screen.Collect
                                    BottomNavTab.SET -> Screen.Settings
                                }
                            }
                        )
                    }
                ) { innerPadding ->
                    val screenModifier = Modifier.padding(innerPadding)

                    when (currentScreen) {
                        is Screen.Home -> {
                            HomeControlScreen(
                                bleManager = bleManager,
                                onNavigateToSettings = {
                                    currentTab = BottomNavTab.SET
                                    currentScreen = Screen.Settings
                                },
                                onNavigateToOta = {
                                    currentScreen = Screen.Ota
                                },
                                onNavigateToCollect = {
                                    currentTab = BottomNavTab.COLLECT
                                    currentScreen = Screen.Collect
                                },
                                modifier = screenModifier
                            )
                        }
                        is Screen.Mode -> {
                            ModeScreen(
                                bleManager = bleManager,
                                onBack = {
                                    currentTab = BottomNavTab.RGB
                                    currentScreen = Screen.Home
                                },
                                onNavigateToSettings = {
                                    currentTab = BottomNavTab.SET
                                    currentScreen = Screen.Settings
                                },
                                modifier = screenModifier
                            )
                        }
                        is Screen.Collect -> {
                            CollectScreen(
                                bleManager = bleManager,
                                onBack = {
                                    currentTab = BottomNavTab.RGB
                                    currentScreen = Screen.Home
                                },
                                modifier = screenModifier
                            )
                        }
                        is Screen.Settings -> {
                            SettingsScreen(
                                bleManager = bleManager,
                                onBack = {
                                    currentTab = BottomNavTab.RGB
                                    currentScreen = Screen.Home
                                },
                                onNavigateToOta = {
                                    currentScreen = Screen.Ota
                                },
                                modifier = screenModifier
                            )
                        }
                        is Screen.Ota -> {
                            OtaUpdateScreen(
                                bleManager = bleManager,
                                otaClient = otaClient,
                                onBack = {
                                    currentScreen = when (currentTab) {
                                        BottomNavTab.RGB -> Screen.Home
                                        BottomNavTab.MODE -> Screen.Mode
                                        BottomNavTab.COLLECT -> Screen.Collect
                                        BottomNavTab.SET -> Screen.Settings
                                    }
                                },
                                modifier = screenModifier
                            )
                        }
                    }
                }
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_SCAN)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }

        if (permissions.isNotEmpty()) {
            permissionLauncher.launch(permissions.toTypedArray())
        } else {
            bleManager.startScan()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        bleManager.disconnect()
    }
}
