package com.wardanlighting.app

sealed class Screen {
    object Home : Screen()
    object Mode : Screen()
    object Collect : Screen()
    object Settings : Screen()
    object Ota : Screen()
}
