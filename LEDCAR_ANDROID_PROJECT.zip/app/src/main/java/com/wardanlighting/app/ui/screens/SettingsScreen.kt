package com.wardanlighting.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wardanlighting.app.ble.BleManager
import com.wardanlighting.app.ui.theme.*

@Composable
fun SettingsScreen(
    bleManager: BleManager,
    onBack: () -> Unit,
    onNavigateToOta: () -> Unit,
    modifier: Modifier = Modifier
) {
    var passwordEnabled by remember { mutableStateOf(false) }
    var showChipDialog by remember { mutableStateOf(false) }
    var ledCount by remember { mutableStateOf(75) }

    if (showChipDialog) {
        ChipSettingsDialog(
            currentCount = ledCount,
            onDismiss = { showChipDialog = false },
            onSave = { count ->
                ledCount = count
                bleManager.sendChipSettings(count)
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepBackground)
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "WL ",
                color = NeonCyan,
                fontWeight = FontWeight.Black,
                fontSize = 20.sp
            )
            Text(
                text = "Wardan Lighting",
                color = TextPrimary,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 18.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 1. Chip settings
        SettingsItemRow(
            icon = Icons.Default.Memory,
            title = "Chip settings",
            onClick = { showChipDialog = true }
        )

        // 2. Timer
        SettingsItemRow(
            icon = Icons.Default.Timer,
            title = "Timer",
            onClick = {
                // Auto mode timer toggle
                bleManager.sendMode(0xFF)
            }
        )

        // 3. Button K1, K2, K3
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.TouchApp, contentDescription = null, tint = TextMuted, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Text("Button", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("K1" to 0, "K2" to 1, "K3" to 2).forEach { (label, id) ->
                        Button(
                            onClick = { bleManager.sendButtonK(id) },
                            colors = ButtonDefaults.buttonColors(containerColor = ActiveBlue),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // 4. Subarea (<, ■, >)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CropFree, contentDescription = null, tint = TextMuted, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Text("Subarea", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    IconButton(
                        onClick = { bleManager.sendSubarea(0x02.toByte()) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Left", tint = TextPrimary)
                    }
                    IconButton(
                        onClick = { bleManager.sendSubarea(0x00.toByte()) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.CropSquare, contentDescription = "Center", tint = TextPrimary)
                    }
                    IconButton(
                        onClick = { bleManager.sendSubarea(0x01.toByte()) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "Right", tint = TextPrimary)
                    }
                }
            }
        }

        // 5. Password / Lock
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = TextMuted, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Text("Password", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
                Switch(
                    checked = passwordEnabled,
                    onCheckedChange = {
                        passwordEnabled = it
                        bleManager.sendLock(it)
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = AccentGreen,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = CardSurface
                    )
                )
            }
        }

        // 6. Update OTA
        SettingsItemRow(
            icon = Icons.Default.CloudUpload,
            title = "Update OTA",
            onClick = onNavigateToOta
        )

        // 7. Skin restoration
        SettingsItemRow(
            icon = Icons.Default.Palette,
            title = "Skin restoration",
            onClick = { /* Restore default skin */ }
        )

        // 8. Change skin
        SettingsItemRow(
            icon = Icons.Default.Image,
            title = "Change skin",
            onClick = { /* Change skin theme */ }
        )

        // 9. Reset
        SettingsItemRow(
            icon = Icons.Default.Refresh,
            title = "Reset",
            onClick = {
                // Sends factory reset (K1 double tap simulation or full restore)
                bleManager.sendButtonK(0)
            }
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Branding Card v4.3.7
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("WL", color = NeonCyan, fontWeight = FontWeight.Black, fontSize = 24.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("Wardan Lighting", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("v4.3.7", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "SIMPLE  •  FAST  •  RELIABLE",
                    color = TextMuted,
                    fontSize = 11.sp,
                    letterSpacing = 2.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SettingsItemRow(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = TextMuted, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(14.dp))
                Text(title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted)
        }
    }
}
