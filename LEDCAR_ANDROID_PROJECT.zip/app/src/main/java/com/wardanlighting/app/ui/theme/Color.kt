package com.wardanlighting.app.ui.theme

import androidx.compose.ui.graphics.Color

val DeepBackground = Color(0xFF0B111E)
val DarkNavy = Color(0xFF0F172A)
val CardBackground = Color(0xFF131C2E)
val CardSurface = Color(0xFF162238)
val CardBorder = Color(0xFF1E2D4A)

val NeonCyan = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF2979FF)
val ActiveBlue = Color(0xFF0284C7)
val AccentPurple = Color(0xFFD946EF)
val AccentAmber = Color(0xFFFF9900)
val AccentRed = Color(0xFFEF4444)
val AccentGreen = Color(0xFF10B981)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val SliderTrackDark = Color(0xFF1E293B)
