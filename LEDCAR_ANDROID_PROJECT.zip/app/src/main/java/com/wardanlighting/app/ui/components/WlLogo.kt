package com.wardanlighting.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wardanlighting.app.ui.theme.ElectricBlue
import com.wardanlighting.app.ui.theme.NeonCyan
import com.wardanlighting.app.ui.theme.TextMuted
import com.wardanlighting.app.ui.theme.TextPrimary

@Composable
fun WlLogoHeader(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "WL ",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.SansSerif,
                color = NeonCyan
            )
            Text(
                text = "WARDAN LIGHTING",
                fontSize = 17.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.SansSerif,
                color = TextPrimary,
                letterSpacing = 1.2.sp
            )
        }
        Text(
            text = "LIGHT UP YOUR RIDE",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = NeonCyan,
            letterSpacing = 2.5.sp
        )
    }
}
