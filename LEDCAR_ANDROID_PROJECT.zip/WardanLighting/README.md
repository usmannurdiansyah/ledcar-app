# Wardan Lighting (Android, Kotlin + Jetpack Compose)

Skeleton app dengan 5 layar: Home/Control, Mode (1-210), Collect,
Settings, dan Update OTA. Tampilan sengaja **tidak** meniru persis
mockup — cukup fungsional dan gampang dikembangkan.

## Yang sudah fungsional

- **Update OTA** (`OtaUpdateScreen.kt`) — 100% nyambung ke:
  - Worker Cloudflare kamu (`ledcar-ota.usmannurdiansyah.workers.dev`):
    `/api/test-token`, `/api/job/start`, `/api/job` (polling), lewat
    `OtaClient.kt`.
  - BLE karakteristik `FFE0/FFE1` di ESP32-C3, protokol ASCII persis
    `mayarota.ino`: `WINFO → WSCLR/WSADD → WPCLR/WPADD → WTCLR/WTADD →
    WJCLR/WJADD → WGO`, lewat `BleManager.kt`.
  - Kalau kamu sudah matikan `TEST_BYPASS` di worker, ganti pemanggilan
    `otaClient.getTestToken()` di `OtaUpdateScreen.kt` jadi
    `otaClient.verifyLicense(kodeLisensi)`.

## Yang masih placeholder (`TODO`)

- **Home/Control** (RGB, brightness, power), **Mode** (pilih 1-210),
  dan **Collect** (urutan efek) belum mengirim apa pun ke LEDCAR,
  karena protokol byte untuk kontrol warna/mode/K1-K2-K3/Subarea ada
  di bagian firmware `.ino` yang belum saya lihat (file aslinya jauh
  lebih panjang dari potongan yang di-share). Begitu kamu kasih
  command yang dipakai firmware untuk itu, tinggal tambahkan fungsi
  serupa `startWifiOta()` di `BleManager.kt` dan panggil dari layar
  terkait.

## Build lokal (Android Studio)

1. Buka folder ini sebagai project di Android Studio (Giraffe/Koala ke
   atas). Kalau diminta generate Gradle wrapper, klik "OK" / "Sync
   Now" — `gradle/wrapper/gradle-wrapper.properties` sudah menunjuk ke
   Gradle 8.7.
2. Run ke device fisik (emulator tidak punya Bluetooth asli).

## Build dari command line

Butuh Gradle terpasang secara lokal (`gradle` di PATH), lalu:

```bash
gradle wrapper          # sekali saja, untuk generate gradlew.jar
./gradlew assembleDebug
```

APK hasil build ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Build otomatis via GitHub Actions

Begitu repo ini di-push ke GitHub (branch `main`), workflow
`.github/workflows/android-build.yml` otomatis jalan dan meng-compile
`app-debug.apk`, lalu upload sebagai **artifact** — bisa diunduh dari
tab **Actions** di repo kamu, tanpa perlu compile manual.

## Izin yang dipakai

- `BLUETOOTH_SCAN` / `BLUETOOTH_CONNECT` (Android 12+) atau
  `ACCESS_FINE_LOCATION` (Android ≤ 11) — wajib untuk BLE scan.
- `INTERNET` — untuk polling status job OTA ke Cloudflare Worker.

Semua permintaan izin runtime sudah dihandle di `MainActivity.kt`.
