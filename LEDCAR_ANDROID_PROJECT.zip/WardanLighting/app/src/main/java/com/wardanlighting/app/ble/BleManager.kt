package com.wardanlighting.app.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID

/**
 * Talks to the LEDCAR-xx-xxxx ESP32-C3 over the same FFE0/FFE1 GATT
 * service used by mayarota.ino. Only the Wi-Fi OTA ASCII protocol
 * (WINFO, WSCLR/WSADD, WPCLR/WPADD, WTCLR/WTADD, WJCLR/WJADD, WGO) is
 * implemented here, since that's the only protocol we have the exact
 * byte-for-byte spec for.
 *
 * TODO: the RGB / Mode(1-210) / Collect / K1-K2-K3 / Subarea control
 * protocol lives in a different part of the firmware that wasn't
 * available when this app was generated. Wire those up the same way
 * once you have the exact command strings/bytes the firmware expects
 * on this same characteristic (or a different one, if it uses one).
 */
class BleManager(private val context: Context) {

    companion object {
        val SERVICE_UUID: UUID = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb")
        val CHAR_UUID: UUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb")
        val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        const val DEVICE_NAME_PREFIX = "LEDCAR-"
    }

    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter get() = bluetoothManager.adapter

    private var gatt: BluetoothGatt? = null
    private var mainChar: BluetoothGattCharacteristic? = null

    private val _connectionState = MutableStateFlow("disconnected")
    val connectionState: StateFlow<String> = _connectionState

    private val _lastStatus = MutableStateFlow("")
    val lastStatus: StateFlow<String> = _lastStatus

    // Incoming BLE notifications land here so cmd()/waitBle() can await them.
    private val notifyChannel = Channel<String>(capacity = Channel.CONFLATED)

    @SuppressLint("MissingPermission")
    fun scanAndConnect(onDeviceFound: (BluetoothDevice) -> Unit) {
        val scanner = adapter.bluetoothLeScanner ?: return
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val name = result.device.name ?: return
                if (name.startsWith(DEVICE_NAME_PREFIX)) {
                    scanner.stopScan(this)
                    onDeviceFound(result.device)
                }
            }
        }
        scanner.startScan(callback)
    }

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice) {
        _connectionState.value = "connecting"
        gatt = device.connectGatt(context, false, object : BluetoothGattCallback() {

            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    _connectionState.value = "connected"
                    g.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    // A disconnect right after WGO is normal (ESP hands off to Wi-Fi).
                    _connectionState.value = "disconnected"
                }
            }

            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                val service = g.getService(SERVICE_UUID) ?: return
                val char = service.getCharacteristic(CHAR_UUID) ?: return
                mainChar = char
                g.setCharacteristicNotification(char, true)
                val cccd = char.getDescriptor(CCCD_UUID)
                if (cccd != null) {
                    cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    g.writeDescriptor(cccd)
                }
                _connectionState.value = "ready"
            }

            @Suppress("DEPRECATION")
            override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
                val value = characteristic.value?.toString(Charsets.UTF_8) ?: return
                _lastStatus.value = value
                notifyChannel.trySend(value)
            }
        })
    }

    /** Scans for LEDCAR-*, connects, and waits until services/notify are ready. */
    @SuppressLint("MissingPermission")
    suspend fun connectToLedcar(timeoutMs: Long = 15000): Boolean {
        return withTimeoutOrNull(timeoutMs) {
            scanAndConnect { device -> connect(device) }
            connectionState.first { it == "ready" }
            true
        } ?: false
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        gatt?.disconnect()
        gatt?.close()
        gatt = null
    }

    @SuppressLint("MissingPermission")
    private suspend fun write(payload: String) {
        val char = mainChar ?: error("BLE not connected")
        val g = gatt ?: error("BLE not connected")
        @Suppress("DEPRECATION")
        char.value = payload.toByteArray(Charsets.UTF_8)
        @Suppress("DEPRECATION")
        g.writeCharacteristic(char)
    }

    private suspend fun waitFor(prefixes: List<String>, timeoutMs: Long = 6000): String? {
        return withTimeoutOrNull(timeoutMs) {
            while (true) {
                val v = notifyChannel.receive()
                if (prefixes.any { v.startsWith(it) }) return@withTimeoutOrNull v
            }
            @Suppress("UNREACHABLE_CODE")
            null
        }
    }

    /** Mirrors cmd() in the customer web page: write, wait for an OK/err prefix. */
    private suspend fun cmd(payload: String, okPrefixes: List<String>, timeoutMs: Long = 6000): String {
        write(payload)
        val result = waitFor(okPrefixes + listOf("WIFI_ERR:"), timeoutMs)
            ?: error("ESP tidak menjawab ${payload.substringBefore(":")}")
        if (result.startsWith("WIFI_ERR:")) error(result)
        return result
    }

    private suspend fun sendChunked(clearCmd: String, addPrefix: String, value: String, label: String) {
        cmd(clearCmd, listOf("${label}_CLEAR"))
        val chunkSize = 12
        var i = 0
        while (i < value.length) {
            val chunk = value.substring(i, minOf(i + chunkSize, value.length))
            cmd(addPrefix + chunk, listOf("${label}_OK:"))
            i += chunkSize
        }
    }

    /** Full WGO handoff sequence, identical to run() in the customer web page. */
    suspend fun startWifiOta(ssid: String, pass: String, token: String, jobId: String) {
        cmd("WINFO", listOf("WIFI_INFO:READY"))
        sendChunked("WSCLR", "WSADD:", ssid, "WIFI_SSID")
        sendChunked("WPCLR", "WPADD:", pass, "WIFI_PASS")
        sendChunked("WTCLR", "WTADD:", token, "WIFI_TOKEN")
        sendChunked("WJCLR", "WJADD:", jobId, "WIFI_JOB")
        cmd("WGO", listOf("WIFI_QUEUED"))
        // From here on BLE may legitimately drop — the ESP is moving to Wi-Fi.
        // Poll job status over HTTPS instead (see OtaClient.pollJob).
    }
}
