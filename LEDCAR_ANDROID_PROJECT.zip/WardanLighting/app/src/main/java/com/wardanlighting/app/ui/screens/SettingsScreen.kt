package com.wardanlighting.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(onOpenOta: () -> Unit) {
    var passwordProtected by remember { mutableStateOf(true) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))

        ListItem(
            headlineContent = { Text("Password") },
            trailingContent = {
                Switch(checked = passwordProtected, onCheckedChange = { passwordProtected = it })
            }
        )
        HorizontalDivider()

        ListItem(
            headlineContent = { Text("Update OTA") },
            supportingContent = { Text("Update firmware lewat Wi-Fi") },
            modifier = Modifier.clickable(onClick = onOpenOta)
        )
        HorizontalDivider()

        Spacer(Modifier.height(16.dp))
        Text("Wardan Lighting — v0.1.0 (skeleton)", style = MaterialTheme.typography.bodySmall)
    }
}

private fun Modifier.clickable(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))
