package com.wardanlighting.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Simplified control screen: power, RGB sliders, brightness.
 * Sending these values to the LEDCAR is a TODO — see BleManager.kt
 * for why (protocol not available yet).
 */
@Composable
fun HomeControlScreen(connectionState: String) {
    var lampOn by remember { mutableStateOf(true) }
    var red by remember { mutableFloatStateOf(255f) }
    var green by remember { mutableFloatStateOf(255f) }
    var blue by remember { mutableFloatStateOf(255f) }
    var brightness by remember { mutableFloatStateOf(50f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Home / Control", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(4.dp))
        AssistChip(onClick = {}, label = { Text("BLE: $connectionState") })
        Spacer(Modifier.height(24.dp))

        FilledIconToggleButton(
            checked = lampOn,
            onCheckedChange = { lampOn = it },
            modifier = Modifier.size(72.dp)
        ) {
            Icon(Icons.Filled.PowerSettingsNew, contentDescription = "Power")
        }

        Spacer(Modifier.height(24.dp))

        ColorSlider("Red", red) { red = it }
        ColorSlider("Green", green) { green = it }
        ColorSlider("Blue", blue) { blue = it }

        Spacer(Modifier.height(12.dp))
        Text("Brightness: ${brightness.toInt()}")
        Slider(value = brightness, onValueChange = { brightness = it }, valueRange = 0f..100f)

        Spacer(Modifier.height(16.dp))
        Text(
            "TODO: kirim lampOn/R/G/B/brightness ke LEDCAR lewat BleManager " +
                "begitu protokol byte-nya diketahui.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun ColorSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text("$label: ${value.toInt()}")
        Slider(value = value, onValueChange = onChange, valueRange = 0f..255f)
    }
}
