package com.wardanlighting.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val WardanColors = darkColorScheme(
    primary = Color(0xFF3EA6FF),
    secondary = Color(0xFF7C4DFF),
    background = Color(0xFF0B1420),
    surface = Color(0xFF121B27),
)

@Composable
fun WardanLightingTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = WardanColors,
        content = content
    )
}
