package com.wardanlighting.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ModeScreen() {
    var selected by remember { mutableIntStateOf(1) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Mode (1-210)", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f)) {
            items((1..210).toList()) { modeNumber ->
                ListItem(
                    headlineContent = { Text("Mode $modeNumber") },
                    trailingContent = {
                        if (selected == modeNumber) Text("● aktif")
                    },
                    modifier = Modifier.clickable { selected = modeNumber }
                )
                HorizontalDivider()
            }
        }
        Text(
            "TODO: kirim pilihan mode ke LEDCAR (byte command belum tersedia).",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}
