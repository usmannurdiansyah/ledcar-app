package com.wardanlighting.app

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.wardanlighting.app.ble.BleManager
import com.wardanlighting.app.ota.OtaClient
import com.wardanlighting.app.ui.screens.*

private sealed class Dest(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Home : Dest("home", "Home", Icons.Filled.Lightbulb)
    object Mode : Dest("mode", "Mode", Icons.Filled.List)
    object Collect : Dest("collect", "Collect", Icons.Filled.Star)
    object Settings : Dest("settings", "Set", Icons.Filled.Settings)
    object Ota : Dest("ota", "OTA", Icons.Filled.CloudUpload)
}

private val bottomItems = listOf(Dest.Home, Dest.Mode, Dest.Collect, Dest.Settings)

@Composable
fun WardanLightingApp(bleManager: BleManager, otaClient: OtaClient) {
    val navController = rememberNavController()
    val connectionState by bleManager.connectionState.collectAsStateSafe("disconnected")

    Scaffold(
        bottomBar = {
            NavigationBar {
                val backStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = backStackEntry?.destination
                bottomItems.forEach { dest ->
                    NavigationBarItem(
                        selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                        label = { Text(dest.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Dest.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Dest.Home.route) { HomeControlScreen(connectionState) }
            composable(Dest.Mode.route) { ModeScreen() }
            composable(Dest.Collect.route) { CollectScreen() }
            composable(Dest.Settings.route) {
                SettingsScreen(onOpenOta = { navController.navigate(Dest.Ota.route) })
            }
            composable(Dest.Ota.route) { OtaUpdateScreen(bleManager, otaClient) }
        }
    }
}

// small wrapper kept local so this file has no extra dependency surprises
@Composable
private fun kotlinx.coroutines.flow.StateFlow<String>.collectAsStateSafe(initial: String) =
    androidx.compose.runtime.produceState(initialValue = initial, this) {
        this@collectAsStateSafe.collect { value = it }
    }
