package com.wardanlighting.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class CollectEntry(val id: Int, val effectNumber: Int)

@Composable
fun CollectScreen() {
    var entries by remember {
        mutableStateOf(listOf(CollectEntry(0, 1), CollectEntry(1, 5), CollectEntry(2, 12)))
    }
    var nextId by remember { mutableIntStateOf(entries.size) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Collect (pilih efek)", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))

        LazyColumn(Modifier.weight(1f)) {
            items(entries, key = { it.id }) { entry ->
                ListItem(
                    headlineContent = { Text("Efek #${entry.effectNumber}") },
                    trailingContent = {
                        IconButton(onClick = {
                            entries = entries.filterNot { it.id == entry.id }
                        }) { Icon(Icons.Filled.Delete, contentDescription = "Hapus") }
                    }
                )
                HorizontalDivider()
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { entries = entries + CollectEntry(nextId++, 1) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Tambah Efek")
        }
    }
}
