package com.wardanlighting.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.wardanlighting.app.ble.BleManager
import com.wardanlighting.app.ota.OtaClient
import kotlinx.coroutines.launch

/**
 * Reproduces the flow from the customer web page (CUSTOMER_HTML in the
 * Worker): get/verify a token, scan+connect BLE, WINFO -> SSID -> PASS
 * -> TOKEN -> JOB -> WGO, then poll the job over HTTPS.
 */
@Composable
fun OtaUpdateScreen(bleManager: BleManager, otaClient: OtaClient) {
    val scope = rememberCoroutineScope()

    var ssid by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var progress by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("Belum mulai.") }
    var running by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Update OTA", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(4.dp))
        Text(
            "Bluetooth hanya mengirim SSID/password/token. Setelah WGO diterima, " +
                "ESP mengambil firmware lewat Wi-Fi. BLE putus setelah itu = normal.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = ssid, onValueChange = { ssid = it },
            label = { Text("SSID Wi-Fi 2.4 GHz") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = password, onValueChange = { password = it },
            label = { Text("Password Wi-Fi") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))

        Button(
            enabled = !running && ssid.isNotBlank(),
            onClick = {
                running = true
                progress = 0
                status = "Menyiapkan..."
                scope.launch {
                    try {
                        // 1. token — swap getTestToken() for verifyLicense(code)
                        //    once the worker's TEST_BYPASS is turned off.
                        status = "Meminta token..."
                        val token = otaClient.getTestToken()

                        // 2. job id
                        status = "Membuat job..."
                        val jobId = otaClient.startJob(token)

                        // 3. BLE: scan + connect to LEDCAR-xx-xxxx, then handoff sequence
                        status = "Mencari & menyambung ke LEDCAR..."
                        val connected = bleManager.connectToLedcar()
                        if (!connected) error("Tidak bisa menyambung ke LEDCAR lewat Bluetooth.")

                        status = "Mengirim SSID/password/token via BLE..."
                        bleManager.startWifiOta(ssid, password, token, jobId)

                        // 4. poll status over HTTPS, same as the web page
                        status = "Perintah diterima. Menunggu ESP masuk Wi-Fi..."
                        otaClient.pollJob(token, jobId) { update ->
                            when (update) {
                                is OtaClient.JobStatus.Progress -> {
                                    progress = update.percent
                                    status = when (update.status) {
                                        "connected" -> "Wi-Fi tersambung ke ESP. Mengambil firmware..."
                                        "downloading" -> "ESP download firmware ${update.percent}%..."
                                        else -> update.status
                                    }
                                }
                                is OtaClient.JobStatus.Done -> {
                                    progress = 100
                                    status = "BERHASIL. Firmware selesai ditulis, ESP restart."
                                    running = false
                                }
                                is OtaClient.JobStatus.Error -> {
                                    status = "GAGAL: ${update.message}"
                                    running = false
                                }
                            }
                        }
                    } catch (e: Exception) {
                        status = "GAGAL: ${e.message}"
                        running = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (running) "Sedang update..." else "Update via Wi-Fi") }

        Spacer(Modifier.height(20.dp))
        LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
        Text("$progress%", modifier = Modifier.padding(top = 4.dp))

        Spacer(Modifier.height(12.dp))
        Text(status)
    }
}
