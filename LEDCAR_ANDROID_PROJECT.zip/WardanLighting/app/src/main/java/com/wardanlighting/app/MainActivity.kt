package com.wardanlighting.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import com.wardanlighting.app.ble.BleManager
import com.wardanlighting.app.ota.OtaClient
import com.wardanlighting.app.ui.theme.WardanLightingTheme

class MainActivity : ComponentActivity() {

    private lateinit var bleManager: BleManager
    private val otaClient = OtaClient()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { /* no-op */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bleManager = BleManager(applicationContext)
        requestBlePermissions()

        setContent {
            WardanLightingTheme {
                WardanLightingApp(bleManager = bleManager, otaClient = otaClient)
            }
        }
    }

    private fun requestBlePermissions() {
        val needed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        permissionLauncher.launch(needed)
    }

    override fun onDestroy() {
        super.onDestroy()
        bleManager.disconnect()
    }
}
