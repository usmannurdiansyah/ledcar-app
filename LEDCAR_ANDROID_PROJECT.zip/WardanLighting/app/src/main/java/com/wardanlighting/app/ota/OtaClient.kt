package com.wardanlighting.app.ota

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Talks to the same Worker used by the customer web page
 * (ledcar-ota.usmannurdiansyah.workers.dev). Endpoints and payload
 * shapes match index.js exactly: /api/test-token, /api/verify,
 * /api/job/start, /api/job.
 */
class OtaClient(
    private val baseUrl: String = "https://ledcar-ota.usmannurdiansyah.workers.dev"
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    sealed class JobStatus {
        data class Progress(val status: String, val percent: Int) : JobStatus()
        object Done : JobStatus()
        data class Error(val message: String) : JobStatus()
    }

    /** Mirrors enableTest() in the web page. Only works while the worker's TEST_BYPASS = true. */
    suspend fun getTestToken(): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("$baseUrl/api/test-token").build()
        client.newCall(req).execute().use { resp ->
            val body = JSONObject(resp.body?.string() ?: "{}")
            if (!resp.isSuccessful || !body.has("token")) {
                error(body.optString("message", "TEST token gagal"))
            }
            body.getString("token")
        }
    }

    /** Mirrors verify() in the web page. Used once TEST_BYPASS is turned off in the worker. */
    suspend fun verifyLicense(licenseCode: String): String = withContext(Dispatchers.IO) {
        val payload = JSONObject().put("licenseCode", licenseCode).toString()
        val req = Request.Builder()
            .url("$baseUrl/api/verify")
            .post(payload.toRequestBody(jsonMedia))
            .build()
        client.newCall(req).execute().use { resp ->
            val body = JSONObject(resp.body?.string() ?: "{}")
            if (!resp.isSuccessful || !body.has("token")) {
                error(body.optString("message", "Verifikasi gagal"))
            }
            body.getString("token")
        }
    }

    /** Mirrors postJson('/api/job/start', {}) in the web page. */
    suspend fun startJob(token: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("$baseUrl/api/job/start")
            .addHeader("authorization", "Bearer $token")
            .post("{}".toRequestBody(jsonMedia))
            .build()
        client.newCall(req).execute().use { resp ->
            val body = JSONObject(resp.body?.string() ?: "{}")
            if (!resp.isSuccessful || !body.has("jobId")) {
                error(body.optString("message", "Gagal membuat job"))
            }
            body.getString("jobId")
        }
    }

    /**
     * Mirrors pollJob() in the web page: polls /api/job every second for up
     * to 150s, and gives up early (35s) if the ESP never reported "connected".
     * [onUpdate] is called for every status transition.
     */
    suspend fun pollJob(token: String, jobId: String, onUpdate: (JobStatus) -> Unit) {
        val startedAt = System.currentTimeMillis()
        var everOnline = false

        while (System.currentTimeMillis() - startedAt < 150_000) {
            val json = withContext(Dispatchers.IO) {
                val req = Request.Builder()
                    .url("$baseUrl/api/job?id=$jobId")
                    .addHeader("authorization", "Bearer $token")
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) null else JSONObject(resp.body?.string() ?: "{}")
                }
            }

            if (json != null) {
                val status = json.optString("status", "queued")
                val progress = json.optInt("progress", 0)

                when (status) {
                    "connected" -> { everOnline = true; onUpdate(JobStatus.Progress(status, 0)) }
                    "downloading" -> { everOnline = true; onUpdate(JobStatus.Progress(status, progress)) }
                    "done" -> { onUpdate(JobStatus.Done); return }
                    "error" -> {
                        onUpdate(JobStatus.Error(json.optString("message", "ESP melaporkan kegagalan Wi-Fi OTA")))
                        return
                    }
                }
            }

            if (!everOnline && System.currentTimeMillis() - startedAt > 35_000) {
                onUpdate(JobStatus.Error("ESP belum berhasil masuk Wi-Fi. Periksa SSID 2.4 GHz dan password."))
                return
            }

            delay(1000)
        }
        onUpdate(JobStatus.Error("Timeout menunggu OTA Wi-Fi selesai."))
    }
}
