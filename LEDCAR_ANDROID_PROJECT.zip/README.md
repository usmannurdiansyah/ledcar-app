# Wardan Lighting (v4.3.7)

**LIGHT UP YOUR RIDE — ONE APP. ENDLESS POSSIBILITIES**  
Aplikasi Android Smart Control untuk LED DMX + LED CAR (ESP32-C3 4-Channel WS2812B) dengan kontrol real-time BLE dan OTA Bluetooth Update.

---

## Fitur Utama

1. **Home / Control (RGB)**
   - Circular Color Wheel dengan tombol Power Switch (On/Off).
   - Pemilihan Channel: `LED1`, `ALL`, `LED2`, `Collect`.
   - Palet warna instan (Merah, Oranye, Kuning, Hijau, Cyan, Biru, Putih) + Custom Color.
   - Slider Brightness (1 - 100%).
   - Tombol Akses Cepat:
     - `WELCOME >` (Mode Welcome 0 - 50)
     - `REM >` (Mode REM 1 - 10)
     - `SET 1-3 >` (Mode SEIN 1 - 10)
     - `Update OTA` (Langsung ke layar OTA Firmware Update)

2. **Mode (210 Efek)**
   - Dual-drum wheel scroll picker untuk memilih 1 sampai 210 efek.
   - Pilihan Channel independen (`LED1`, `LED2`).
   - Tombol Auto Mode (Ganti efek otomatis).
   - Slider Speed & Brightness real-time.

3. **Collect Screen**
   - Daftar efek favorit / custom run.
   - Tombol `+ Tambah Efek` berdasarkan nomor mode.
   - Kontrol Speed & Brightness terdedikasi.

4. **Settings / Drawer**
   - **Chip Settings**: Atur jumlah LED per strip (default: 75 LED).
   - **Button**: K1, K2, K3 (Penyimpanan memori, playlist, dan color override).
   - **Subarea**: Kontrol navigasi area (`<`, `■`, `>`).
   - **Password**: Fitur pengunci (Lock mode).
   - **Update OTA**: Akses firmware flashing over BLE.
   - **Reset**: Reset factory settings.

5. **Update OTA (Bluetooth Low Energy)**
   - File picker file binary firmware (`.bin`).
   - Indikator progres upload real-time (persentase & byte streamed).
   - Layanan resmi: `ledcar-ota.usmannurdiansyah.workers.dev`.
   - Aman dan kompatibel penuh dengan firmware ESP32-C3 (`mayarota.ino`).

---

## Panduan Upload ke GitHub & Build Otomatis (GitHub Actions)

Repository ini telah dilengkapi dengan file workflow GitHub Actions di `.github/workflows/android-build.yml`.

### Cara Mengunggah ke GitHub:
1. Ekstrak file zip ini langsung ke direktori repositori git Anda:
   ```bash
   git clone https://github.com/usmannurdiansyah/ledcar-app.git
   cd ledcar-app
   # Salin/ekstrak seluruh isi file zip ke dalam folder ini
   ```
2. Pastikan file terdeteksi:
   ```bash
   git add .
   git commit -m "feat: complete Wardan Lighting Android app with GitHub Actions"
   git push origin main
   ```
3. Buka tab **Actions** di GitHub:
   `https://github.com/usmannurdiansyah/ledcar-app/actions`
4. Workflow **Build Android APK** akan berjalan secara otomatis dan menghasilkan artifact file APK (`WardanLighting-v4.3.7-debug.apk`) yang siap di-download dan di-install di smartphone Anda!
