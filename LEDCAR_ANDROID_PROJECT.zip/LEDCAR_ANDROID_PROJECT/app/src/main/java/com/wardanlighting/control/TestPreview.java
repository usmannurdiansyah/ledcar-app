package com.wardanlighting.control;
import java.util.*;
public class TestPreview {
 static long hash(FirmwarePreview120.Frame4 f){long h=1469598103934665603L;for(int k=0;k<4;k++)for(int c:f.ch[k]){h^=c;h*=1099511628211L;}return h;}
 public static void main(String[]a){
  Map<Long,List<Integer>> first=new HashMap<>();
  for(int m=1;m<=120;m++){
    Set<Long>s=new HashSet<>();for(int t=0;t<20;t++)s.add(hash(FirmwarePreview120.render(m,t*250L,70)));
    long h=hash(FirmwarePreview120.render(m,1000,70)); first.computeIfAbsent(h,x->new ArrayList<>()).add(m);
    System.out.printf("%d frames=%d%n",m,s.size());
  }
  System.out.println("dupes at 1s");for(var e:first.entrySet())if(e.getValue().size()>1)System.out.println(e.getValue());
 }
}
