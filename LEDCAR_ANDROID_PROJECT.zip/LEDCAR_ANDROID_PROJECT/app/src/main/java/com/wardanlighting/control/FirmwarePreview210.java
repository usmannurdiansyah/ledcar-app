package com.wardanlighting.control;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * Firmware-faithful preview frames for Mode 121..210 generated directly from
 * mayarota(3).ino math/render functions. Frames are RGB565 to keep APK size
 * reasonable. Timing uses the same global speed factor as firmware.
 */
final class FirmwarePreview210 {
    private static final int START = 121;
    private static final int END = 210;
    private static final int FRAMES = 160;
    private static final int N = 75;
    private static final int DT_MS_T = 80; // 0.08 firmware-time seconds per frame
    private static final int HEADER = 14;
    private static final int PIXELS_PER_FRAME = 4 * N;
    private static final int BYTES_PER_FRAME = PIXELS_PER_FRAME * 2;
    private static volatile byte[] data;
    private static volatile boolean loadTried;

    private FirmwarePreview210() {}

    static void init(Context context) {
        if (data != null || loadTried) return;
        synchronized (FirmwarePreview210.class) {
            if (data != null || loadTried) return;
            loadTried = true;
            try (InputStream in = context.getResources().openRawResource(R.raw.fw_preview_121_210);
                 ByteArrayOutputStream out = new ByteArrayOutputStream(9_000_000)) {
                byte[] buf = new byte[32768];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                byte[] tmp = out.toByteArray();
                if (valid(tmp)) data = tmp;
            } catch (Throwable ignored) {
                data = null;
            }
        }
    }

    private static boolean valid(byte[] b) {
        if (b == null || b.length < HEADER) return false;
        if (b[0] != 'F' || b[1] != 'W' || b[2] != 'P' || b[3] != '1') return false;
        int s = u16(b,4), e=u16(b,6), f=u16(b,8), n=u16(b,10), dt=u16(b,12);
        long expected = HEADER + (long)(e-s+1) * f * 4L * n * 2L;
        return s==START && e==END && f==FRAMES && n==N && dt==DT_MS_T && expected==b.length;
    }

    private static int u16(byte[] b,int o){ return (b[o]&255) | ((b[o+1]&255)<<8); }

    private static float speedFactor(int speed) {
        int v = Math.max(1, Math.min(100, speed));
        float delayMs = 50f - ((v - 1) * 45f / 99f);
        if (delayMs < 5f) delayMs = 5f;
        if (delayMs > 50f) delayMs = 50f;
        return 25f / delayMs;
    }

    static FirmwarePreview120.Frame4 render(int mode, long elapsedMs, int speed) {
        FirmwarePreview120.Frame4 out = new FirmwarePreview120.Frame4();
        if (mode < START || mode > END) return out;
        byte[] b = data;
        if (b == null) {
            // Fail-safe animation: never permanently freezes even if the raw asset
            // somehow cannot be loaded. Normally this path is never used.
            renderFallback(out, mode, elapsedMs, speed);
            return out;
        }
        double t = Math.max(0L, elapsedMs) * 0.001 * speedFactor(speed);
        int frame = (int)Math.floor((t * 1000.0) / DT_MS_T);
        frame = Math.floorMod(frame, FRAMES);
        long frameIndex = (long)(mode - START) * FRAMES + frame;
        int off = HEADER + (int)(frameIndex * BYTES_PER_FRAME);
        for (int ch=0; ch<4; ch++) {
            for (int i=0; i<N; i++) {
                int v = (b[off]&255) | ((b[off+1]&255)<<8); off += 2;
                int r = ((v >> 11) & 31) * 255 / 31;
                int g = ((v >> 5) & 63) * 255 / 63;
                int bl = (v & 31) * 255 / 31;
                out.ch[ch][i] = 0xFF000000 | (r<<16) | (g<<8) | bl;
            }
        }
        return out;
    }

    private static void renderFallback(FirmwarePreview120.Frame4 f,int mode,long ms,int speed){
        float sf=speedFactor(speed);
        float p=(float)((ms*0.001*sf*(0.45 + (mode%11)*0.035))%1.0);
        int head=Math.min(N-1,Math.max(0,Math.round(p*(N-1))));
        int hue=(int)((mode*37L + ms/18L)%360L);
        int c=hsv(hue);
        for(int ch=0;ch<4;ch++){
            int h=((mode+ch)&1)==0?head:(N-1-head);
            for(int i=0;i<N;i++){
                int d=Math.abs(i-h);
                if(d<=8){float q=1f-d/9f;f.ch[ch][i]=scale(c,q*q);}
            }
        }
    }
    private static int hsv(float h){
        h%=360f;if(h<0)h+=360f;float x=1f-Math.abs((h/60f)%2f-1f);float r=0,g=0,b=0;
        if(h<60){r=1;g=x;}else if(h<120){r=x;g=1;}else if(h<180){g=1;b=x;}else if(h<240){g=x;b=1;}else if(h<300){r=x;b=1;}else{r=1;b=x;}
        return 0xFF000000|(Math.round(r*255)<<16)|(Math.round(g*255)<<8)|Math.round(b*255);
    }
    private static int scale(int c,float q){q=Math.max(0,Math.min(1,q));return 0xFF000000|(Math.round(((c>>16)&255)*q)<<16)|(Math.round(((c>>8)&255)*q)<<8)|Math.round((c&255)*q);}
}
