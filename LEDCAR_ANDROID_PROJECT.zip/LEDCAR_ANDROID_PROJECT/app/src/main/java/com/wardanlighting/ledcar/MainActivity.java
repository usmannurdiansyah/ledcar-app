package com.wardanlighting.ledcar;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {

    private static final UUID SERVICE_FFE0 =
            UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    private static final UUID CHAR_FFE1 =
            UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");

    private static final String OTA_URL =
            "https://ledcar-ota.usmannurdiansyah.workers.dev";

    private static final int REQ_BT = 1001;

    private final Handler main = new Handler(Looper.getMainLooper());

    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic ffe1;
    private boolean scanning = false;

    // Firmware mapping:
    // 0x01=CH1, 0x02=CH2, 0x03=ALL, 0x04=CH3, 0x05=CH4
    private int selectedChannel = 0x03;

    private TextView statusText;
    private TextView channelText;
    private TextView brightnessLabel;
    private TextView speedLabel;
    private TextView modeLabel;
    private TextView rgbLabel;

    private int red = 0;
    private int green = 200;
    private int blue = 255;

    private final int bg = Color.rgb(7, 19, 31);
    private final int panel = Color.rgb(12, 31, 47);
    private final int panel2 = Color.rgb(15, 40, 61);
    private final int cyan = Color.rgb(39, 201, 255);
    private final int text = Color.rgb(239, 249, 255);
    private final int muted = Color.rgb(145, 174, 193);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        BluetoothManager manager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager != null ? manager.getAdapter() : null;

        setContentView(buildUi());
        updateStatus("Belum terhubung");
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(36));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = tv("LEDCAR", 30, Typeface.BOLD, text);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = tv("WARDAN LIGHTING • BLE CONTROLLER", 12, Typeface.BOLD, cyan);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub, lpMatchWrap(0, 0, 0, 14));

        LinearLayout connection = card();
        statusText = tv("Belum terhubung", 14, Typeface.BOLD, text);
        connection.addView(statusText, lpMatchWrap(0, 0, 0, 10));

        Button connect = actionButton("HUBUNGKAN LEDCAR");
        connect.setOnClickListener(v -> connectLedcar());
        connection.addView(connect);
        root.addView(connection, lpMatchWrap(0, 0, 0, 12));

        LinearLayout channels = card();
        channels.addView(sectionTitle("PILIH CHANNEL"));
        channelText = tv("Aktif: ALL", 13, Typeface.BOLD, cyan);
        channels.addView(channelText, lpMatchWrap(0, 4, 0, 8));

        LinearLayout row1 = horizontal();
        row1.addView(channelButton("ALL", 0x03), weightButton());
        row1.addView(channelButton("LED 1", 0x01), weightButton());
        row1.addView(channelButton("LED 2", 0x02), weightButton());
        channels.addView(row1);

        LinearLayout row2 = horizontal();
        row2.addView(channelButton("LED 3", 0x04), weightButton());
        row2.addView(channelButton("LED 4", 0x05), weightButton());
        channels.addView(row2, lpMatchWrap(0, 6, 0, 0));
        root.addView(channels, lpMatchWrap(0, 0, 0, 12));

        LinearLayout live = card();
        live.addView(sectionTitle("KONTROL UTAMA"));

        brightnessLabel = tv("Brightness: 100", 13, Typeface.BOLD, text);
        live.addView(brightnessLabel);
        SeekBar brightness = new SeekBar(this);
        brightness.setMax(99);
        brightness.setProgress(99);
        brightness.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int v = progress + 1;
                brightnessLabel.setText("Brightness: " + v);
                if (fromUser) sendSimple(0x01, v);
            }
        });
        live.addView(brightness);

        speedLabel = tv("Speed: 70", 13, Typeface.BOLD, text);
        live.addView(speedLabel, lpMatchWrap(0, 8, 0, 0));
        SeekBar speed = new SeekBar(this);
        speed.setMax(99);
        speed.setProgress(69);
        speed.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int v = progress + 1;
                speedLabel.setText("Speed: " + v);
                if (fromUser) sendSimple(0x02, v);
            }
        });
        live.addView(speed);

        modeLabel = tv("Mode: 1", 13, Typeface.BOLD, text);
        live.addView(modeLabel, lpMatchWrap(0, 8, 0, 0));
        SeekBar mode = new SeekBar(this);
        mode.setMax(209);
        mode.setProgress(0);
        mode.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int v = progress + 1;
                modeLabel.setText("Mode: " + v);
                if (fromUser) sendPacket(0x03, v, 0, 0, selectedChannel);
            }
        });
        live.addView(mode);

        LinearLayout powerRow = horizontal();
        Button on = smallButton("POWER ON");
        on.setOnClickListener(v -> sendSimple(0x04, 0x01));
        Button off = smallButton("POWER OFF");
        off.setOnClickListener(v -> sendSimple(0x04, 0x00));
        powerRow.addView(on, weightButton());
        powerRow.addView(off, weightButton());
        live.addView(powerRow, lpMatchWrap(0, 10, 0, 0));

        root.addView(live, lpMatchWrap(0, 0, 0, 12));

        LinearLayout rgbCard = card();
        rgbCard.addView(sectionTitle("WARNA RGB"));
        rgbLabel = tv("", 13, Typeface.BOLD, text);
        rgbCard.addView(rgbLabel, lpMatchWrap(0, 2, 0, 8));

        rgbCard.addView(colorSlider("R", 255, 0, value -> { red = value; updateRgbLabel(); }));
        rgbCard.addView(colorSlider("G", 255, 200, value -> { green = value; updateRgbLabel(); }));
        rgbCard.addView(colorSlider("B", 255, 255, value -> { blue = value; updateRgbLabel(); }));

        LinearLayout presets1 = horizontal();
        presets1.addView(colorButton("CYAN", 0, 200, 255), weightButton());
        presets1.addView(colorButton("MERAH", 255, 0, 0), weightButton());
        presets1.addView(colorButton("HIJAU", 0, 255, 0), weightButton());
        rgbCard.addView(presets1, lpMatchWrap(0, 8, 0, 0));

        LinearLayout presets2 = horizontal();
        presets2.addView(colorButton("BIRU", 0, 0, 255), weightButton());
        presets2.addView(colorButton("PUTIH", 255, 255, 255), weightButton());
        presets2.addView(colorButton("ORANGE", 255, 50, 0), weightButton());
        rgbCard.addView(presets2, lpMatchWrap(0, 6, 0, 0));

        Button applyRgb = actionButton("TERAPKAN RGB");
        applyRgb.setOnClickListener(v ->
                sendPacket(0x07, red, green, blue, selectedChannel));
        rgbCard.addView(applyRgb, lpMatchWrap(0, 10, 0, 0));
        root.addView(rgbCard, lpMatchWrap(0, 0, 0, 12));
        updateRgbLabel();

        LinearLayout vehicle = card();
        vehicle.addView(sectionTitle("WELCOME • SEN • REM"));

        Spinner welcome = spinnerRange(0, 50, "Welcome ");
        vehicle.addView(labeled("Welcome", welcome));
        Button applyWelcome = smallButton("JALANKAN WELCOME");
        applyWelcome.setOnClickListener(v -> sendSimple(0x18, welcome.getSelectedItemPosition()));
        vehicle.addView(applyWelcome, lpMatchWrap(0, 5, 0, 8));

        Spinner sen = spinnerRange(0, 10, "SEN ");
        vehicle.addView(labeled("SEN", sen));
        Button applySen = smallButton("JALANKAN SEN");
        applySen.setOnClickListener(v -> sendSimple(0x19, sen.getSelectedItemPosition()));
        vehicle.addView(applySen, lpMatchWrap(0, 5, 0, 8));

        Spinner rem = spinnerRange(0, 10, "REM ");
        vehicle.addView(labeled("REM", rem));
        Button applyRem = smallButton("JALANKAN REM");
        applyRem.setOnClickListener(v -> sendSimple(0x1A, rem.getSelectedItemPosition()));
        vehicle.addView(applyRem, lpMatchWrap(0, 5, 0, 0));

        root.addView(vehicle, lpMatchWrap(0, 0, 0, 12));

        LinearLayout sets = card();
        sets.addView(sectionTitle("SET 1–3"));
        TextView setInfo = tv("SET 1 = K1 • SET 2 = K2 • SET 3 = K3", 12, Typeface.NORMAL, muted);
        sets.addView(setInfo, lpMatchWrap(0, 2, 0, 8));

        LinearLayout setRow = horizontal();
        Button set1 = smallButton("SET 1");
        set1.setOnClickListener(v -> sendSimple(0x11, 0x00));
        Button set2 = smallButton("SET 2");
        set2.setOnClickListener(v -> sendSimple(0x11, 0x01));
        Button set3 = smallButton("SET 3");
        set3.setOnClickListener(v -> sendSimple(0x11, 0x02));
        setRow.addView(set1, weightButton());
        setRow.addView(set2, weightButton());
        setRow.addView(set3, weightButton());
        sets.addView(setRow);
        root.addView(sets, lpMatchWrap(0, 0, 0, 12));

        LinearLayout ota = card();
        ota.addView(sectionTitle("UPDATE FIRMWARE"));
        TextView otaInfo = tv(
                "Update firmware lewat halaman OTA LEDCAR. Internet dipakai oleh HP; kontrol lampu tetap BLE.",
                12, Typeface.NORMAL, muted);
        ota.addView(otaInfo, lpMatchWrap(0, 2, 0, 10));

        Button otaButton = actionButton("UPDATE OTA");
        otaButton.setTextSize(18);
        otaButton.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(OTA_URL)));
            } catch (Exception e) {
                toast("Browser tidak tersedia");
            }
        });
        ota.addView(otaButton);
        root.addView(ota);

        TextView footer = tv("LEDCAR v1.0 • Wardan Lighting", 11, Typeface.NORMAL, muted);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, lpMatchWrap(0, 16, 0, 0));

        return scroll;
    }

    private void connectLedcar() {
        if (adapter == null) {
            toast("Bluetooth tidak tersedia di HP ini");
            return;
        }

        if (!hasBluetoothPermissions()) {
            requestBluetoothPermissions();
            return;
        }

        if (!adapter.isEnabled()) {
            toast("Aktifkan Bluetooth terlebih dahulu");
            try {
                startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            } catch (Exception ignored) {}
            return;
        }

        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            toast("BLE scanner tidak tersedia");
            return;
        }

        if (scanning) {
            stopScan();
            return;
        }

        updateStatus("Mencari LEDCAR...");
        scanning = true;

        try {
            scanner.startScan(scanCallback);
        } catch (SecurityException e) {
            requestBluetoothPermissions();
            return;
        }

        main.postDelayed(() -> {
            if (scanning) {
                stopScan();
                updateStatus("LEDCAR belum ditemukan");
            }
        }, 12000);
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice device = result.getDevice();
            String name = null;

            try {
                if (hasBluetoothPermissions()) name = device.getName();
            } catch (SecurityException ignored) {}

            boolean nameMatch = name != null &&
                    (name.toUpperCase(Locale.ROOT).contains("LEDCAR") ||
                     name.toUpperCase(Locale.ROOT).contains("LEDLAMP"));

            boolean serviceMatch = false;
            if (result.getScanRecord() != null &&
                result.getScanRecord().getServiceUuids() != null) {
                for (ParcelUuid u : result.getScanRecord().getServiceUuids()) {
                    if (SERVICE_FFE0.equals(u.getUuid())) {
                        serviceMatch = true;
                        break;
                    }
                }
            }

            if (nameMatch || serviceMatch) {
                stopScan();
                final String shownName = name != null ? name : "LEDCAR";
                main.post(() -> updateStatus("Menghubungkan " + shownName + "..."));
                connectGatt(device);
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            scanning = false;
            main.post(() -> updateStatus("Scan BLE gagal: " + errorCode));
        }
    };

    private void connectGatt(BluetoothDevice device) {
        if (!hasBluetoothPermissions()) {
            requestBluetoothPermissions();
            return;
        }

        try {
            if (gatt != null) {
                gatt.close();
                gatt = null;
            }
            ffe1 = null;
            gatt = device.connectGatt(this, false, gattCallback,
                    BluetoothDevice.TRANSPORT_LE);
        } catch (SecurityException e) {
            requestBluetoothPermissions();
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                main.post(() -> updateStatus("Terhubung • membaca service..."));
                try {
                    g.discoverServices();
                } catch (SecurityException e) {
                    main.post(() -> updateStatus("Izin Bluetooth diperlukan"));
                }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                ffe1 = null;
                main.post(() -> updateStatus("Terputus"));
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                main.post(() -> updateStatus("Gagal membaca service"));
                return;
            }

            BluetoothGattService service = g.getService(SERVICE_FFE0);
            if (service == null) {
                main.post(() -> updateStatus("FFE0 tidak ditemukan"));
                return;
            }

            ffe1 = service.getCharacteristic(CHAR_FFE1);
            if (ffe1 == null) {
                main.post(() -> updateStatus("FFE1 tidak ditemukan"));
                return;
            }

            main.post(() -> updateStatus("TERHUBUNG • LEDCAR SIAP"));
        }
    };

    private void stopScan() {
        scanning = false;
        if (scanner != null && hasBluetoothPermissions()) {
            try {
                scanner.stopScan(scanCallback);
            } catch (SecurityException ignored) {}
        }
    }

    private boolean hasBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(new String[] {
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
            }, REQ_BT);
        } else {
            requestPermissions(new String[] {
                    Manifest.permission.ACCESS_FINE_LOCATION
            }, REQ_BT);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT) {
            if (hasBluetoothPermissions()) {
                connectLedcar();
            } else {
                toast("Izin Bluetooth diperlukan untuk terhubung ke LEDCAR");
            }
        }
    }

    private void sendSimple(int cmd, int value) {
        sendPacket(cmd, value, 0, 0, selectedChannel);
    }

    private void sendPacket(int cmd, int v1, int v2, int v3, int channel) {
        if (gatt == null || ffe1 == null) {
            toast("Hubungkan LEDCAR dulu");
            return;
        }

        byte[] p = new byte[9];
        p[0] = 0x7B;
        p[1] = (byte) (cmd & 0xFF);
        p[2] = (byte) (v1 & 0xFF);
        p[3] = (byte) (v2 & 0xFF);
        p[4] = (byte) (v3 & 0xFF);
        p[5] = 0x00;
        p[6] = 0x00;
        p[7] = (byte) (channel & 0xFF);
        p[8] = (byte) 0xBF;

        try {
            int props = ffe1.getProperties();
            int writeType =
                    (props & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                            ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                            : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;

            if (Build.VERSION.SDK_INT >= 33) {
                int rc = gatt.writeCharacteristic(ffe1, p, writeType);
                if (rc != 0) toast("BLE write gagal: " + rc);
            } else {
                ffe1.setWriteType(writeType);
                ffe1.setValue(p);
                boolean ok = gatt.writeCharacteristic(ffe1);
                if (!ok) toast("BLE write gagal");
            }
        } catch (SecurityException e) {
            requestBluetoothPermissions();
        } catch (Exception e) {
            toast("Gagal kirim BLE");
        }
    }

    private Button channelButton(String label, int code) {
        Button b = smallButton(label);
        b.setOnClickListener(v -> {
            selectedChannel = code;
            channelText.setText("Aktif: " + label);
        });
        return b;
    }

    private Button colorButton(String label, int r, int g, int b) {
        Button btn = smallButton(label);
        btn.setOnClickListener(v -> {
            red = r; green = g; blue = b;
            updateRgbLabel();
            sendPacket(0x07, red, green, blue, selectedChannel);
        });
        return btn;
    }

    private interface IntValue {
        void onValue(int value);
    }

    private View colorSlider(String label, int max, int initial, IntValue cb) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        TextView t = tv(label + ": " + initial, 12, Typeface.BOLD, muted);
        box.addView(t);

        SeekBar s = new SeekBar(this);
        s.setMax(max);
        s.setProgress(initial);
        s.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                t.setText(label + ": " + progress);
                cb.onValue(progress);
            }
        });
        box.addView(s);
        return box;
    }

    private void updateRgbLabel() {
        if (rgbLabel != null) {
            rgbLabel.setText(String.format(Locale.US,
                    "RGB: %d, %d, %d", red, green, blue));
        }
    }

    private Spinner spinnerRange(int min, int max, String prefix) {
        Spinner s = new Spinner(this);
        List<String> values = new ArrayList<>();
        for (int i = min; i <= max; i++) values.add(prefix + i);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, values) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(text);
                v.setTextSize(14);
                return v;
            }
            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView v = (TextView) super.getDropDownView(position, convertView, parent);
                v.setTextColor(Color.BLACK);
                v.setTextSize(14);
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);
        return s;
    }

    private View labeled(String label, View control) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView t = tv(label, 12, Typeface.BOLD, muted);
        box.addView(t);
        box.addView(control);
        return box;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.setBackground(roundRect(panel, 18, Color.rgb(28, 74, 99), 1));
        return box;
    }

    private TextView sectionTitle(String s) {
        TextView t = tv(s, 15, Typeface.BOLD, cyan);
        t.setLetterSpacing(0.08f);
        return t;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private Button actionButton(String s) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(s);
        b.setTextColor(Color.BLACK);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(dp(12), dp(10), dp(12), dp(10));
        b.setBackground(roundRect(cyan, 14, cyan, 0));
        return b;
    }

    private Button smallButton(String s) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(s);
        b.setTextColor(text);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(7), dp(9), dp(7), dp(9));
        b.setBackground(roundRect(panel2, 12, Color.rgb(34, 99, 129), 1));
        return b;
    }

    private TextView tv(String s, int sp, int style, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, style);
        return t;
    }

    private GradientDrawable roundRect(int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), stroke);
        return d;
    }

    private LinearLayout.LayoutParams lpMatchWrap(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private LinearLayout.LayoutParams weightButton() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(3), 0, dp(3), 0);
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void updateStatus(String s) {
        statusText.setText(s);
        statusText.setTextColor(s.startsWith("TERHUBUNG") ? cyan : text);
    }

    private void toast(String s) {
        main.post(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show());
    }

    @Override
    protected void onDestroy() {
        stopScan();
        if (gatt != null) {
            try {
                if (hasBluetoothPermissions()) gatt.disconnect();
            } catch (SecurityException ignored) {}
            gatt.close();
            gatt = null;
        }
        super.onDestroy();
    }

    private static abstract class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar seekBar) {}
        @Override public void onStopTrackingTouch(SeekBar seekBar) {}
    }
}
