package com.wardanlighting.control;

final class Protocol {
    static final int ALL = 0x03;

    enum Profile {
        CUSTOM,
        B_COMPACT,   // LEDCAR-02, LEDDMX-02, LEDDMX-04
        B_CLASSIC,   // LEDCAR-01 / classic LEDDMX
        A_GENERIC,   // LEDCAR-00 / LEDBLE
        UNKNOWN
    }

    private Protocol(){}

    static Profile classify(String name,boolean custom){
        if(custom)return Profile.CUSTOM;
        String u=name==null?"":name.toUpperCase(java.util.Locale.ROOT);
        if(u.startsWith("LEDCAR-02")||u.startsWith("LEDDMX-02")||u.startsWith("LEDDMX-04"))
            return Profile.B_COMPACT;
        if(u.startsWith("LEDDMX")||u.startsWith("LEDCAR-01"))
            return Profile.B_CLASSIC;
        if(u.startsWith("LEDCAR-00")||u.startsWith("LEDBLE"))
            return Profile.A_GENERIC;
        if(u.startsWith("LEDCAR"))
            return Profile.B_COMPACT;
        return Profile.UNKNOWN;
    }

    static byte[] simple(Profile profile,int command,int value,int channel){
        if(profile==Profile.CUSTOM)return customSimple(command,value,channel);

        // Pada stock, pilihan LED1-4 Wardan tidak dijadikan independent.
        // Command standard tetap dikirim sebagai kontrol global.
        switch(profile){
            case B_COMPACT:return compactSimple(command,value);
            case B_CLASSIC:return classicSimple(command,value);
            case A_GENERIC:return dialectASimple(command,value);
            default:return null;
        }
    }

    static byte[] rgb(Profile profile,int r,int g,int b,int channel){
        r=u8(r);g=u8(g);b=u8(b);

        if(profile==Profile.CUSTOM){
            byte[] p=customBase(0x07,channel);
            p[2]=(byte)r;p[3]=(byte)g;p[4]=(byte)b;
            return p;
        }

        if(profile==Profile.B_COMPACT)
            return frameB(0x07,r,g,b,0x00,0xFF,0xFF);

        if(profile==Profile.B_CLASSIC)
            return frameB(0xFF,0x07,r,g,b,0x00,0xFF);

        if(profile==Profile.A_GENERIC)
            return frameA(0xFF,0x05,0x03,r,g,b,0xFF);

        return null;
    }

    static byte[] ledCount(Profile profile,int count){
        count=Math.max(1,Math.min(1024,count));
        int hi=(count>>8)&0xFF,lo=count&0xFF;

        if(profile==Profile.CUSTOM){
            byte[] p=customBase(0x05,ALL);
            p[3]=(byte)hi;p[4]=(byte)lo;
            return p;
        }

        if(profile==Profile.B_COMPACT)
            return frameB(0x05,0x01,hi,lo,0xFF,0xFF,0xFF);

        if(profile==Profile.B_CLASSIC)
            return frameB(0xFF,0x05,0x04,hi,lo,0x01,0xFF);

        return null;
    }

    static byte[] remSetting(Profile profile,int command,int value){
        if(profile!=Profile.CUSTOM)return null;
        byte[] p=customSimple(command,value,ALL);
        p[3]=0x04;
        return p;
    }

    private static byte[] customSimple(int command,int value,int channel){
        byte[] p=customBase(command,channel);
        p[2]=(byte)value;
        return p;
    }

    private static byte[] customBase(int command,int channel){
        byte[] p=new byte[9];
        p[0]=0x7B;
        p[1]=(byte)command;
        p[7]=(byte)channel;
        p[8]=(byte)0xBF;
        return p;
    }

    private static byte[] compactSimple(int command,int value){
        value=u8(value);
        switch(command&0xFF){
            case 0x01:return frameB(0x01,value,0x00,0xFF,0xFF,0xFF,0xFF);
            case 0x02:return frameB(0x02,value,0x00,0xFF,0xFF,0xFF,0xFF);
            case 0x03:return frameB(0x03,value,0xFF,0xFF,0xFF,0xFF,0xFF);
            case 0x04:return frameB(0x04,value,0xFF,0xFF,0xFF,0xFF,0xFF);
            case 0x0D:return frameB(0x0D,value,0xFF,0xFF,0xFF,0xFF,0xFF);
            case 0x18:
            case 0x19:
            case 0x1A:
            case 0x1D:return frameB(command,value,0xFF,0xFF,0xFF,0xFF,0xFF);
            default:return null;
        }
    }

    private static byte[] classicSimple(int command,int value){
        value=u8(value);
        switch(command&0xFF){
            case 0x01:{
                int fine=(value*32)/100;
                return frameB(0xFF,0x01,fine,value,0x01,0xFF,0xFF);
            }
            case 0x02:return frameB(0xFF,0x02,value,0x00,0xFF,0xFF,0xFF);
            case 0x03:return frameB(0xFF,0x03,value,0xFF,0xFF,0xFF,0xFF);
            case 0x04:return frameB(0xFF,0x04,value,0xFF,0xFF,0xFF,0xFF);
            case 0x0D:return frameB(0xFF,0x0D,value,0xFF,0xFF,0xFF,0xFF);
            case 0x18:
            case 0x19:
            case 0x1A:
            case 0x1D:return frameB(0xFF,command,value,0xFF,0xFF,0xFF,0xFF);
            default:return null;
        }
    }

    private static byte[] dialectASimple(int command,int value){
        value=u8(value);
        switch(command&0xFF){
            case 0x01:return frameA(0xFF,0x01,value,0x00,0xFF,0xFF,0xFF);
            case 0x02:return frameA(0xFF,0x02,value,0x00,0xFF,0xFF,0xFF);
            case 0x03:return frameA(0xFF,0x03,value,0x03,0xFF,0xFF,0xFF);
            case 0x04:return frameA(0xFF,0x04,value,0xFF,0xFF,0xFF,0xFF);
            default:return null;
        }
    }

    private static byte[] frameA(int a,int b,int c,int d,int e,int f,int g){
        return new byte[]{
                0x7E,(byte)a,(byte)b,(byte)c,(byte)d,(byte)e,(byte)f,(byte)g,(byte)0xEF
        };
    }

    private static byte[] frameB(int a,int b,int c,int d,int e,int f,int g){
        return new byte[]{
                0x7B,(byte)a,(byte)b,(byte)c,(byte)d,(byte)e,(byte)f,(byte)g,(byte)0xBF
        };
    }

    private static int u8(int value){
        return Math.max(0,Math.min(255,value));
    }
}
