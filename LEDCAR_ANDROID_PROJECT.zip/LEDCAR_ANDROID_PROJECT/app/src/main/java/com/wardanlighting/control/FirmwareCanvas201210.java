package com.wardanlighting.control;

/** Mode 201–210: procedural Canvas preview. No firmware image or frame bank in the APK.
 * The eight phases for each mode are calculated from the supplied lighting effect
 * equations; channels follow the physical CH1 -> CH3 -> CH4 -> CH2 route.
 */
final class FirmwareCanvas201210 {
    private static final float M201210_PI = (float)Math.PI;
    private static final float PHASE_LEN = 1.45f;
    private static final float CYCLE_LEN = PHASE_LEN * 8f;
    private static final int N = FirmwarePreview120.N;
    private static final class Color3 {
        final float r,g,b;
        Color3(float r,float g,float b){this.r=r;this.g=g;this.b=b;}
    }
    private static final class Sample {float v; Color3 c;}
    private static final Color3[] PAL={
        new Color3(255,255,255),new Color3(255,40,40),new Color3(30,120,255),
        new Color3(190,30,255),new Color3(0,230,150),new Color3(255,45,165),
        new Color3(0,225,255),new Color3(255,170,0),new Color3(140,255,20),
        new Color3(255,80,25),new Color3(80,110,255),new Color3(255,235,80)
    };
    private FirmwareCanvas201210() {}

    static FirmwarePreview120.Frame4 render(int mode,long elapsedMs,int speed){
        FirmwarePreview120.Frame4 frame=new FirmwarePreview120.Frame4();
        if(mode<201||mode>210)return frame;
        int boundedSpeed=Math.max(1,Math.min(100,speed));
        float delay=50f-(boundedSpeed-1)*45f/99f;
        float t=(elapsedMs*.001f)*(25f/Math.max(5f,delay));
        // Bound phase clock before float loses precision on long-running screens.
        t%=CYCLE_LEN*256f;
        int st=Math.min(7,(int)Math.floor((t%CYCLE_LEN)/PHASE_LEN));
        float q=(t%CYCLE_LEN-st*PHASE_LEN)/PHASE_LEN;
        int cyc=(int)Math.floor(t/CYCLE_LEN);
        int id=mode-201;
        Color3 c1=m201210RC(cyc+st,id*11.13f+1f);
        Color3 c2=m201210RC(cyc+st+1,id*17.71f+3f);
        Color3 c3=m201210RC(cyc+st+2,id*23.29f+7f);
        Sample sm=new Sample();
        // Source position increases along CH1, CH3, CH4, CH2.
        int[] order={0,2,3,1};
        float L=N*4f-1f;
        for(int side=0;side<4;side++){
            int[] colors=frame.ch[order[side]];
            for(int i=0;i<N;i++){
                sample(id,t,side*N+i,L,N,st,q,c1,c2,c3,sm);
                float v=sm.v;
                colors[i]=0xFF000000
                        | (m201210Byte(Math.min(255f,sm.c.r*v*1.55f+18f*v))<<16)
                        | (m201210Byte(Math.min(255f,sm.c.g*v*1.55f+18f*v))<<8)
                        | m201210Byte(Math.min(255f,sm.c.b*v*1.55f+18f*v));
            }
        }
        return frame;
    }

    private static int m201210Byte(float v){return Math.max(0,Math.min(255,(int)Math.floor(v+.5f)));}
    private static float m201210Clamp(float v){return m201210Clamp(v,0f,1f);}
    private static float m201210Clamp(float v,float a,float b){return v<a?a:Math.min(v,b);}
    private static float m201210Smooth(float q){q=m201210Clamp(q);return q*q*(3f-2f*q);}
    private static float m201210Ping(float x,float L){
        if(L<=0f)return 0f;
        float p=fmodf(fmodf(x,2f*L)+2f*L,2f*L);
        return p<L?p:2f*L-p;
    }
    private static float m201210Hash(float n){float x=sinf(n*12.9898f+78.233f)*43758.5453f;return x-floorf(x);}
    private static float m201210Gauss(float d,float w){w=Math.max(.001f,w);return expf(-(d*d)/(2f*w*w));}
    private static float m201210Bar(float x,float c,float w){return m201210Clamp(1f-fabsf(x-c)/Math.max(.001f,w));}
    private static float m201210Comet(float x,float head,int dir,float headW,float tail){
        float d=(x-head)*dir;
        if(fabsf(d)<=headW)return 1f;
        float back=-d-headW;
        if(back>0f&&back<=tail){float q=1f-back/tail;return q*q*.94f;}
        return 0f;
    }
    private static float m201210Ring(float x,float c,float radius,float width){return m201210Gauss(fabsf(x-c)-radius,width);}
    private static Color3 m201210RC(float c,float s){
        int idx=(int)floorf(m201210Hash(c*7.17f+s)*12f);
        return PAL[Math.max(0,Math.min(11,idx))];
    }
    private static Color3 m201210Mix(Color3 a,Color3 b,float q){
        q=m201210Clamp(q);
        return new Color3(a.r+(b.r-a.r)*q,a.g+(b.g-a.g)*q,a.b+(b.b-a.b)*q);
    }
    private static float fmodf(float a,float b){return a%b;}
    private static float floorf(float a){return (float)Math.floor(a);}
    private static float sinf(float a){return (float)Math.sin(a);}
    private static float cosf(float a){return (float)Math.cos(a);}
    private static float expf(float a){return (float)Math.exp(a);}
    private static float powf(float a,float b){return (float)Math.pow(a,b);}
    private static float fabsf(float a){return Math.abs(a);}
    private static int abs(int a){return Math.abs(a);}
    private static float fmaxf(float a,float b){return Math.max(a,b);}

private static void sample(int id,float t,float x,float L,float N,
                           int st,float q,Color3 c1,Color3 c2,Color3 c3,Sample out){
  Color3 c=m201210Mix(c1,c2,q);
  float v=0.0f, p=0.0f, a1=0.0f, a2=0.0f;

  switch(id){
    case 0:{ // 201 SILK RELAY
      switch(st){
        case 0:{ // single silk relay
          p=m201210Smooth(q)*L;
          v=m201210Comet(x,p,1,2.2f,N*.23f); c=c1;
        }break;
        case 1:{ // breathing ribbon
          p=q*L; float w=2.5f+5.5f*(.5f-.5f*cosf(q*M201210_PI*2.0f));
          v=m201210Comet(x,p,1,w,N*.42f);
          float back=p-x;
          if(back>0.0f&&back<N*.42f)v*=.62f+.38f*(.5f+.5f*sinf(back*.16f+q*M201210_PI*6.0f));
          c=m201210Mix(c1,c2,m201210Clamp(back/(N*.42f)));
        }break;
        case 2:{ // twin overtake
          p=q*L; float sep=N*(.34f-.24f*(.5f-.5f*cosf(q*M201210_PI*2.0f)));
          v=fmaxf(m201210Comet(x,p,1,2.0f,N*.14f),
                 m201210Comet(x,p-sep,1,3.0f,N*.11f)*.78f);
          c=q<.5f?c1:c2;
        }break;
        case 3:{ // ribbon with wave-cut tail
          p=q*L; float base=m201210Comet(x,p,1,3.0f,N*.52f);
          float back=p-x;
          if(back>0.0f)base*=.55f+.45f*(.5f+.5f*sinf(back*.23f+t*5.0f));
          v=base; c=m201210Mix(c2,c3,m201210Clamp(back/(N*.5f)));
        }break;
        case 4:{ // hard reverse return
          p=L-q*L;
          v=m201210Comet(x,p,-1,2.4f,N*.18f); c=c3;
        }break;
        case 5:{ // echo return
          p=L-q*L;
          v=m201210Comet(x,p,-1,2.0f,N*.12f);
          for(int k=1;k<=4;k++)v=fmaxf(v,m201210Gauss(x-(p+N*.10f*k),2.0f+.4f*k)*(.75f-.12f*k));
          c=m201210Mix(c3,c1,q);
        }break;
        case 6:{ // center split
          float l=L*.5f-q*L*.5f, r=L*.5f+q*L*.5f;
          v=fmaxf(m201210Comet(x,l,-1,2.6f,N*.14f),
                 m201210Comet(x,r, 1,2.6f,N*.14f));
          c=m201210Mix(c1,c2,m201210Clamp(fabsf(x-L*.5f)/(L*.5f)));
        }break;
        default:{ // edge merge + center bloom
          float l=q*L*.5f, r=L-q*L*.5f;
          v=fmaxf(m201210Comet(x,l,1,2.6f,N*.15f),
                 m201210Comet(x,r,-1,2.6f,N*.15f));
          v=fmaxf(v,m201210Gauss(x-L*.5f,3.8f)*powf(q,3.0f));
          c=m201210Mix(c2,c3,q);
        }break;
      }
    }break;

    case 1:{ // 202 CROSS CEREMONY
      switch(st){
        case 0:{ // edge collision
          float l=q*L*.5f, r=L-q*L*.5f;
          v=fmaxf(m201210Comet(x,l,1,3.0f,N*.18f),m201210Comet(x,r,-1,3.0f,N*.18f));
          c=c1;
        }break;
        case 1:{ // collision explosion
          float rad=q*L*.5f;
          v=m201210Ring(x,L*.5f,rad,3.2f);
          v=fmaxf(v,m201210Ring(x,L*.5f,rad*.62f,2.2f)*.55f); c=c2;
        }break;
        case 2:{ // pendulum shuttle
          p=m201210Ping(q*2.0f*L,L);
          int dir=q<.5f?1:-1;
          v=m201210Comet(x,p,dir,2.2f,N*.21f); c=m201210Mix(c1,c3,q);
        }break;
        case 3:{ // dual counterflow pass
          float p1=q*L,p2=L-q*L;
          v=fmaxf(m201210Comet(x,p1,1,1.9f,N*.11f),
                 m201210Comet(x,p2,-1,3.3f,N*.24f)*.88f);
          c=m201210Mix(c2,c3,x/L);
        }break;
        case 4:{ // four-head fanout
          float[] centers={L*.20f,L*.40f,L*.60f,L*.80f};
          for(int k=0;k<4;k++){
            float dir=(k<2)?-1.0f:1.0f;
            float pp=centers[k]+dir*q*L*.20f;
            v=fmaxf(v,m201210Comet(x,pp,dir>0?1:-1,1.8f+.35f*k,N*.085f)*(1.0f-.12f*k));
          } c=c1;
        }break;
        case 5:{ // liquid zipper — alternating small gates, not static blocks
          float front=q*L;
          float cell=fmodf(floorf(x/fmaxf(3.0f,N*.055f)),2.0f);
          float d=front-x;
          float wave=(cell<.5f)?m201210Gauss(d,5.0f):m201210Gauss(d-N*.10f,5.0f);
          v=fmaxf(wave,m201210Comet(x,front,1,1.5f,N*.08f)*.55f); c=c2;
        }break;
        case 6:{ // center halo + orbiting runners
          float rad=(.08f+.34f*q)*L*.5f;
          v=m201210Ring(x,L*.5f,rad,2.7f)*.72f;
          float p1=L*.5f+sinf(q*M201210_PI*4.0f)*rad;
          float p2=L*.5f-sinf(q*M201210_PI*4.0f)*rad;
          v=fmaxf(v,m201210Gauss(x-p1,2.0f)); v=fmaxf(v,m201210Gauss(x-p2,2.0f)*.8f); c=c3;
        }break;
        default:{ // accelerating crossing finale
          float qe=powf(q,.58f);
          float p1=qe*L,p2=L-powf(q,1.55f)*L;
          v=fmaxf(m201210Comet(x,p1,1,2.0f,N*.12f),
                 m201210Comet(x,p2,-1,2.8f,N*.17f));
          c=m201210Mix(c1,c3,q);
        }break;
      }
    }break;

    case 2:{ // 203 ELASTIC STAIRFLOW
      switch(st){
        case 0:{ // six step jumps
          float[] pts={.02f,.14f,.28f,.43f,.60f,.78f,.96f};
          float pos=q*6.999f; int n=(int)floorf(pos); if(n>6)n=6;
          p=pts[n]*L;
          v=m201210Comet(x,p,1,3.0f,N*.10f); c=c1;
        }break;
        case 1:{ // steps dissolve into smooth catch-up
          float qe=m201210Smooth(q); p=(.08f+.92f*qe)*L;
          v=m201210Comet(x,p,1,2.0f,N*(.10f+.20f*q));
          for(int k=1;k<=3;k++)v=fmaxf(v,m201210Gauss(x-(p-N*.11f*k),2.2f)*(.65f-.12f*k)); c=c2;
        }break;
        case 2:{ // elastic overshoot / recoil
          float s=q<.72f?powf(q/.72f,.68f):(1.0f-(q-.72f)/.28f*.22f);
          p=s*L;
          int dir=q<.72f?1:-1;
          v=m201210Comet(x,p,dir,3.4f,N*.19f); c=c3;
        }break;
        case 3:{ // domino checkpoints with crossfade
          float[] pts={.06f,.22f,.40f,.58f,.77f,.95f};
          float pos=q*5.0f; int n=(int)floorf(pos); if(n>4)n=4; float f=pos-n;
          v=fmaxf(m201210Gauss(x-pts[n]*L,3.1f)*(1-f),
                 m201210Gauss(x-pts[n+1]*L,3.1f)*f);
          if(f>.5f)v=fmaxf(v,m201210Comet(x,pts[n+1]*L,1,1.5f,N*.06f)*.55f);
          c=((n&1)!=0)?c1:c2;
        }break;
        case 4:{ // three-head train changing spacing
          float base=q*L, sep=N*(.12f+.18f*sinf(q*M201210_PI));
          for(int k=0;k<3;k++)v=fmaxf(v,m201210Comet(x,base-k*sep,1,2.0f+.3f*k,N*(.07f+.025f*k))*(1.0f-.16f*k));
          c=c1;
        }break;
        case 5:{ // compression tunnel
          p=q*L;
          float w=6.0f-4.2f*q, tail=N*(.48f-.32f*q);
          v=m201210Comet(x,p,1,w,tail);
          float ring=m201210Ring(x,p,N*(.04f+.09f*q),2.3f)*.55f;
          v=fmaxf(v,ring); c=m201210Mix(c2,c3,q);
        }break;
        case 6:{ // reverse staircase
          float[] pts={.98f,.84f,.70f,.55f,.39f,.21f,.03f};
          float pos=q*6.999f; int n=(int)floorf(pos); if(n>6)n=6;
          p=pts[n]*L; v=m201210Comet(x,p,-1,3.0f,N*.10f); c=c3;
        }break;
        default:{ // long accelerating sprint
          float qe=powf(q,.52f); p=qe*L;
          v=m201210Comet(x,p,1,1.7f,N*(.10f+.42f*qe)); c=m201210Mix(c1,c3,qe);
        }break;
      }
    }break;

    case 3:{ // 204 SPLIT-MERGE RIVER
      switch(st){
        case 0:{ // one becomes two
          float center=q*L;
          float sep=N*.28f*q;
          v=fmaxf(m201210Comet(x,center-sep,1,2.3f,N*.12f),
                 m201210Comet(x,center+sep,1,2.3f,N*.12f)); c=c1;
        }break;
        case 1:{ // two become one while moving
          float center=q*L,sep=N*.32f*(1-q);
          v=fmaxf(m201210Comet(x,center-sep,1,2.0f,N*.10f),
                 m201210Comet(x,center+sep,1,2.0f,N*.10f));
          v=fmaxf(v,m201210Gauss(x-center,2.8f)*powf(q,2.0f)); c=c2;
        }break;
        case 2:{ // triple fan split from center
          float base=L*.5f;
          for(int k=-1;k<=1;k++){
            float pp=base+q*(float)k*L*.45f;
            int dir=k<0?-1:(k>0?1:1);
            v=fmaxf(v,m201210Comet(x,pp,dir,2.2f,N*.11f)*(k==0?.72f:1.0f));
          } c=c3;
        }break;
        case 3:{ // three weave forward
          float base=q*L;
          for(int k=0;k<3;k++){
            float pp=base+sinf(q*M201210_PI*4.0f+k*2.094f)*N*.16f;
            v=fmaxf(v,m201210Comet(x,pp,1,1.8f,N*.08f)*(1.0f-.12f*k));
          } c=m201210Mix(c1,c2,q);
        }break;
        case 4:{ // opposite rivers merge
          float p1=q*L*.5f,p2=L-q*L*.5f;
          v=fmaxf(m201210Comet(x,p1,1,2.5f,N*.20f),
                 m201210Comet(x,p2,-1,2.5f,N*.20f)); c=c2;
        }break;
        case 5:{ // swirl around center
          float rad=(.08f+.32f*(.5f-.5f*cosf(q*M201210_PI*2.0f)))*L*.5f;
          float p1=L*.5f+sinf(q*M201210_PI*6)*rad;
          float p2=L*.5f-sinf(q*M201210_PI*6)*rad;
          v=fmaxf(m201210Gauss(x-p1,3.0f),m201210Gauss(x-p2,3.0f)*.85f); c=c3;
        }break;
        case 6:{ // edge suction into center
          float p1=q*L*.5f,p2=L-q*L*.5f;
          float w=2.0f+5.0f*q;
          v=fmaxf(m201210Comet(x,p1,1,w,N*.16f),
                 m201210Comet(x,p2,-1,w,N*.16f));
          c=m201210Mix(c1,c3,q);
        }break;
        default:{ // four-way center blast
          float d=q*L*.48f;
          float[] ps={L*.5f-d,L*.5f-d*.45f,L*.5f+d*.45f,L*.5f+d};
          for(int k=0;k<4;k++)v=fmaxf(v,m201210Gauss(x-ps[k],2.4f)*(1.0f-.10f*fabsf(k-1.5f)));
          c=c1;
        }break;
      }
    }break;

    case 4:{ // 205 COMET CEREMONY
      switch(st){
        case 0:{ p=m201210Smooth(q)*L; v=m201210Comet(x,p,1,5.5f,N*.28f); c=c1; }break;
        case 1:{ p=powf(q,.55f)*L; v=m201210Comet(x,p,1,1.6f,N*.08f); c=c2; }break;
        case 2:{ // comet plus pulse echoes
          p=q*L; v=m201210Comet(x,p,1,2.6f,N*.17f);
          for(int k=1;k<=5;k++){
            float pp=p-N*.10f*k;
            float pulse=.35f+.65f*(.5f+.5f*sinf(q*M201210_PI*8.0f-k));
            v=fmaxf(v,m201210Gauss(x-pp,2.2f)*pulse*(1.0f-.12f*k));
          } c=c3;
        }break;
        case 3:{ // orbit companions
          p=q*L;
          v=m201210Comet(x,p,1,2.5f,N*.12f);
          float orb=N*.15f*sinf(q*M201210_PI*6);
          v=fmaxf(v,m201210Gauss(x-(p+orb),2.0f)*.72f);
          v=fmaxf(v,m201210Gauss(x-(p-orb-N*.08f),2.0f)*.58f); c=c1;
        }break;
        case 4:{ // stop-go ceremony
          float[] pts={.08f,.30f,.50f,.72f,.94f};
          float pos=q*5.0f; int n=(int)floorf(pos); if(n>4)n=4; float f=pos-n;
          p=pts[n]*L; float breathe=.55f+.45f*(.5f+.5f*cosf(f*M201210_PI*4.0f));
          v=m201210Comet(x,p,1,4.0f,N*.14f)*breathe; c=((n&1)!=0)?c2:c3;
        }break;
        case 5:{ p=L-m201210Smooth(q)*L; v=m201210Comet(x,p,-1,3.0f,N*.55f); c=c3; }break;
        case 6:{ // opposite comets
          float p1=q*L,p2=L-q*L;
          v=fmaxf(m201210Comet(x,p1,1,2.2f,N*.12f),
                 m201210Comet(x,p2,-1,2.2f,N*.12f)); c=m201210Mix(c1,c2,x/L);
        }break;
        default:{ // five streamlet finale
          float base=q*L;
          for(int k=-2;k<=2;k++){
            float pp=base+(float)k*N*.075f*(1-q);
            v=fmaxf(v,m201210Comet(x,pp,1,1.5f+.15f*abs(k),N*.07f)*(1.0f-.12f*abs(k)));
          } c=m201210Mix(c2,c3,q);
        }break;
      }
    }break;

    case 5:{ // 206 WAVE GATE FLOW
      switch(st){
        case 0:{ // traveling sine ridge
          float ph=(x/L)*M201210_PI*8.0f-q*M201210_PI*10.0f;
          float w=.5f+.5f*sinf(ph); v=powf(m201210Clamp(w),4.0f); c=c1;
        }break;
        case 1:{ // moving aperture
          float center=q*L, width=N*(.10f+.28f*(.5f-.5f*cosf(q*M201210_PI*2)));
          float d=fabsf(x-center);
          v=(d<width)?(.35f+.65f*cosf((d/width)*(M201210_PI/2.0f))):0.0f; c=c2;
        }break;
        case 2:{ // wave packet
          p=q*L;
          float env=m201210Gauss(x-p,N*.18f);
          float wave=.5f+.5f*sinf((x-p)*.23f-q*M201210_PI*8);
          v=env*(.25f+.75f*wave); c=c3;
        }break;
        case 3:{ // interference
          float a=.5f+.5f*sinf(x*.18f-q*M201210_PI*7);
          float b=.5f+.5f*sinf(x*.27f+q*M201210_PI*9);
          v=powf(m201210Clamp(a*b),1.6f); c=m201210Mix(c1,c3,x/L);
        }break;
        case 4:{ // breathing corridor with traveling dark notch
          float breathe=.24f+.76f*(.5f-.5f*cosf(q*M201210_PI*2));
          float notch=m201210Gauss(x-q*L,N*.08f);
          v=m201210Clamp(breathe-notch*.95f); c=c2;
        }break;
        case 5:{ // diagonal zipper wave
          float cell=floorf(x/fmaxf(3.0f,N*.07f));
          float shift=fmodf(cell*0.13f+q,1.0f);
          v=m201210Gauss(shift-.5f,.13f); c=(fmodf(cell,2.0f)<1.0f)?c1:c3;
        }break;
        case 6:{ // reverse ripple train
          float center=L-q*L;
          for(int k=0;k<4;k++){
            float rad=(q+k*.23f)*N*.32f;
            v=fmaxf(v,m201210Ring(x,center,rad,2.0f)*(.88f-.14f*k));
          } c=c3;
        }break;
        default:{ // wave collapse into comet
          float center=(1-q)*L*.5f+q*L;
          float wave=m201210Gauss(x-center,N*(.25f-.17f*q))*(.5f+.5f*sinf((x-center)*(.10f+.25f*q)));
          v=fmaxf(wave,m201210Comet(x,q*L,1,2.0f,N*.11f)*powf(q,2.0f)); c=m201210Mix(c2,c1,q);
        }break;
      }
    }break;

    case 6:{ // 207 ORBIT SHUTTLE
      switch(st){
        case 0:{ p=m201210Ping(q*2.0f*L,L); v=m201210Comet(x,p,q<.5f?1:-1,2.2f,N*.15f); c=c1; }break;
        case 1:{ // orbit pair around moving center
          float center=q*L, d=N*.16f*sinf(q*M201210_PI*6);
          v=fmaxf(m201210Gauss(x-(center+d),2.5f),m201210Gauss(x-(center-d),2.5f)*.8f); c=c2;
        }break;
        case 2:{ // triple orbit
          float center=q*L;
          for(int k=0;k<3;k++){
            float pp=center+sinf(q*M201210_PI*6+k*2.094f)*N*.18f;
            v=fmaxf(v,m201210Gauss(x-pp,2.0f)*(1.0f-.14f*k));
          } c=c3;
        }break;
        case 3:{ // boomerang
          float qq=q<.62f?q/.62f:1.0f-(q-.62f)/.38f;
          p=m201210Clamp(qq)*L;
          v=m201210Comet(x,p,q<.62f?1:-1,3.0f,N*.20f); c=m201210Mix(c1,c2,q);
        }break;
        case 4:{ // edge bounce with widening head
          p=m201210Ping(q*3.0f*L,L);
          int dir=((int)floorf(q*3.0f)%2)==0?1:-1;
          v=m201210Comet(x,p,dir,2.0f+4.0f*q,N*.13f); c=c2;
        }break;
        case 5:{ // center crossing pair
          float p1=q*L,p2=L-q*L;
          float pulse=.65f+.35f*(.5f+.5f*sinf(q*M201210_PI*4));
          v=fmaxf(m201210Comet(x,p1,1,2.1f,N*.11f),
                 m201210Comet(x,p2,-1,2.1f,N*.11f))*pulse; c=c3;
        }break;
        case 6:{ // accelerating ping-pong
          float qq=powf(q,.48f);
          p=m201210Ping(qq*2.0f*L,L);
          int dir=qq<.5f?1:-1;
          v=m201210Comet(x,p,dir,1.7f,N*(.08f+.22f*q)); c=c1;
        }break;
        default:{ // orbit collapse
          float rad=(1-q)*L*.42f;
          float p1=L*.5f+sinf(q*M201210_PI*8)*rad;
          float p2=L*.5f-sinf(q*M201210_PI*8)*rad;
          v=fmaxf(m201210Gauss(x-p1,2.6f),m201210Gauss(x-p2,2.6f));
          v=fmaxf(v,m201210Gauss(x-L*.5f,4.0f)*powf(q,3.0f)); c=m201210Mix(c2,c3,q);
        }break;
      }
    }break;

    case 7:{ // 208 CASCADE BLOOM
      switch(st){
        case 0:{ // sequential cascade
          float base=q*L;
          for(int k=0;k<5;k++)v=fmaxf(v,m201210Comet(x,base-k*N*.13f,1,1.8f,N*.07f)*(1.0f-.13f*k));
          c=c1;
        }break;
        case 1:{ // checkpoint blooms
          float[] pts={.10f,.30f,.50f,.70f,.90f};
          float pos=q*5.0f; int n=(int)floorf(pos); if(n>4)n=4; float f=pos-n;
          float rad=f*N*.18f;
          v=m201210Ring(x,pts[n]*L,rad,2.2f); v=fmaxf(v,m201210Gauss(x-pts[n]*L,2.4f)*(1-f)); c=c2;
        }break;
        case 2:{ // forward fountain
          float origin=q*L;
          for(int k=0;k<4;k++){
            float pp=origin+(k-1.5f)*N*.08f*sinf(q*M201210_PI);
            v=fmaxf(v,m201210Comet(x,pp,1,1.7f,N*.09f)*(1.0f-.12f*k));
          } c=c3;
        }break;
        case 3:{ // reverse waterfall
          float base=L-q*L;
          for(int k=0;k<6;k++)v=fmaxf(v,m201210Gauss(x-(base+k*N*.095f),2.1f)*(.95f-.11f*k));
          c=c1;
        }break;
        case 4:{ // center fanout
          for(int k=-2;k<=2;k++){
            float pp=L*.5f+q*(float)k*L*.18f;
            v=fmaxf(v,m201210Gauss(x-pp,2.5f)*(1.0f-.12f*abs(k)));
          } c=c2;
        }break;
        case 5:{ // fanin from distributed points
          for(int k=0;k<4;k++){
            float s=(.12f+.25f*k)*L;
            float pp=s+(L*.5f-s)*q;
            v=fmaxf(v,m201210Comet(x,pp,(pp<L*.5f)?1:-1,2.0f,N*.08f));
          } c=c3;
        }break;
        case 6:{ // four segment relay
          float seg=L/4.0f;
          int active=(int)floorf(q*4.0f); if(active>3)active=3;
          float local=fmodf(q*4.0f,1.0f);
          float pp=(active+local)*seg;
          v=m201210Comet(x,pp,1,2.5f,N*.10f);
          for(int k=0;k<active;k++)v=fmaxf(v,m201210Bar(x,(k+.5f)*seg,seg*.28f)*.28f); c=c1;
        }break;
        default:{ // grand cascade
          float base=q*L;
          for(int k=0;k<7;k++){
            float pp=base-k*N*.10f*(.6f+.4f*sinf(q*M201210_PI));
            v=fmaxf(v,m201210Comet(x,pp,1,1.4f+.18f*k,N*.055f)*(1.0f-.09f*k));
          } c=m201210Mix(c2,c3,q);
        }break;
      }
    }break;

    case 8:{ // 209 ZIPPER AURORA
      switch(st){
        case 0:{ // forward liquid zipper
          float front=q*L;
          float cell=floorf(x/fmaxf(3.0f,N*.05f));
          float offset=(fmodf(cell,2.0f)<1.0f)?0.0f:N*.065f;
          v=m201210Gauss(x-(front-offset),3.0f); c=c1;
        }break;
        case 1:{ // reverse zipper
          float front=L-q*L;
          float cell=floorf(x/fmaxf(3.0f,N*.055f));
          float offset=(fmodf(cell,2.0f)<1.0f)?0.0f:N*.07f;
          v=m201210Gauss(x-(front+offset),3.0f); c=c2;
        }break;
        case 2:{ // center dual zipper
          float l=L*.5f-q*L*.5f,r=L*.5f+q*L*.5f;
          float pattern=.55f+.45f*(.5f+.5f*sinf(x*.45f));
          v=fmaxf(m201210Gauss(x-l,3.2f),m201210Gauss(x-r,3.2f))*pattern; c=c3;
        }break;
        case 3:{ // zipper collapse to edges
          float l=q*L*.5f,r=L-q*L*.5f;
          float mask=.5f+.5f*cosf(x*.38f+q*M201210_PI*6);
          v=fmaxf(m201210Gauss(x-l,3.0f),m201210Gauss(x-r,3.0f))*(.35f+.65f*mask); c=c1;
        }break;
        case 4:{ // broad aurora ribbon
          p=q*L; float env=m201210Gauss(x-p,N*.30f);
          float w=.55f+.45f*sinf(x*.10f+t*4.5f);
          v=env*(.55f+.45f*w); c=m201210Mix(c1,c3,m201210Clamp((x-p)/(N*.6f)+.5f));
        }break;
        case 5:{ // two aurora bands opposite
          float p1=q*L,p2=L-q*L;
          a1=m201210Gauss(x-p1,N*.16f)*(.6f+.4f*sinf(x*.12f+t*5));
          a2=m201210Gauss(x-p2,N*.20f)*(.6f+.4f*cosf(x*.09f-t*4));
          v=fmaxf(a1,a2); c=m201210Mix(c2,c3,x/L);
        }break;
        case 6:{ // soft segmented pulse chase
          float cell=floorf(x/fmaxf(5.0f,N*.12f));
          float local=fmodf(q*7.0f-cell*.22f,1.0f); if(local<0)local+=1.0f;
          v=powf(.5f+.5f*cosf((local-.5f)*M201210_PI*2),5.0f);
          v*=.50f+.50f*m201210Gauss(x-q*L,N*.35f); c=c2;
        }break;
        default:{ // zipper -> aurora finale
          p=q*L;
          float zip=m201210Gauss(x-p,3.0f)*(.55f+.45f*(.5f+.5f*sinf(x*.42f)));
          float aur=m201210Gauss(x-p,N*(.08f+.34f*q))*(.45f+.55f*(.5f+.5f*sinf(x*.10f+t*5.5f)));
          v=fmaxf(zip,aur); c=m201210Mix(c1,c3,q);
        }break;
      }
    }break;

    default:{ // 210 GRAND CEREMONY X
      switch(st){
        case 0:{ // full route relay
          p=m201210Smooth(q)*L; v=m201210Comet(x,p,1,2.4f,N*.24f); c=c1;
        }break;
        case 1:{ // exact reverse relay
          p=L-m201210Smooth(q)*L; v=m201210Comet(x,p,-1,2.4f,N*.24f); c=c2;
        }break;
        case 2:{ // center split
          float l=L*.5f-q*L*.5f,r=L*.5f+q*L*.5f;
          v=fmaxf(m201210Comet(x,l,-1,2.3f,N*.13f),m201210Comet(x,r,1,2.3f,N*.13f)); c=c3;
        }break;
        case 3:{ // edge merge
          float l=q*L*.5f,r=L-q*L*.5f;
          v=fmaxf(m201210Comet(x,l,1,2.6f,N*.16f),m201210Comet(x,r,-1,2.6f,N*.16f));
          v=fmaxf(v,m201210Gauss(x-L*.5f,4.0f)*powf(q,3)); c=c1;
        }break;
        case 4:{ // triple weave
          float base=q*L;
          for(int k=0;k<3;k++){
            float pp=base+sinf(q*M201210_PI*6+k*2.094f)*N*.17f;
            v=fmaxf(v,m201210Comet(x,pp,1,1.8f,N*.08f)*(1.0f-.12f*k));
          } c=c2;
        }break;
        case 5:{ // wave gate
          float center=q*L, env=m201210Gauss(x-center,N*.22f);
          float wave=.5f+.5f*sinf((x-center)*.20f-q*M201210_PI*8);
          v=env*(.25f+.75f*wave); c=c3;
        }break;
        case 6:{ // step pulse then chase
          float[] pts={.05f,.20f,.38f,.57f,.76f,.94f};
          float pos=q*5.999f; int n=(int)floorf(pos); if(n>5)n=5;
          p=pts[n]*L;
          v=m201210Comet(x,p,1,3.4f,N*.10f);
          v=fmaxf(v,m201210Gauss(x-p,N*.055f)*(.55f+.45f*sinf(q*M201210_PI*12))); c=((n&1)!=0)?c1:c2;
        }break;
        default:{ // four-head grand finale, converging spacing
          float base=q*L, sep=N*.22f*(1-q)+N*.055f;
          for(int k=-2;k<=1;k++){
            float pp=base+k*sep;
            v=fmaxf(v,m201210Comet(x,pp,1,1.6f+.25f*abs(k),N*.07f)*(1.0f-.11f*abs(k)));
          }
          float bloom=m201210Gauss(x-base,N*(.04f+.18f*q))*.48f;
          v=fmaxf(v,bloom); c=m201210Mix(c1,c3,q);
        }break;
      }
    }break;
  }

  out.v=m201210Clamp(v);
  out.c=c;
}
}
