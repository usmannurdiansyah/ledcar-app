package com.wardanlighting.control;

/**
 * Procedural preview renderer derived from mayarota(3).ino.
 * Virtual LED count is fixed at 75 (firmware default) and MainActivity renders
 * adjacent samples as continuous solid segments, not LED dots.
 */
final class FirmwarePreview120 {
    static final int N = 75;
    static final int BLACK = 0xFF000000;
    static final int WHITE = 0xFFFFFFFF;
    static final float PI = (float)Math.PI;

    static final class Frame4 {
        final int[][] ch = new int[4][N];
        Frame4(){ clearAll(); }
        void clearAll(){ for(int k=0;k<4;k++) java.util.Arrays.fill(ch[k], BLACK); }
    }
    static final class Pair {
        final int[] a = new int[N];
        final int[] b = new int[N];
        Pair(){ java.util.Arrays.fill(a,BLACK); java.util.Arrays.fill(b,BLACK); }
    }
    static final class Sample { float v; int c; Sample(float v,int c){this.v=v;this.c=c;} }

    static Frame4 render(int mode,long elapsedMs,int speed){
        Frame4 f=new Frame4();
        if(mode<1||mode>120) return f;
        float sf=speedFactor(speed);
        Pair p=new Pair();
        if(mode<=4) render1to4(mode,elapsedMs,speed,p);
        else if(mode==5) render5(elapsedMs,speed,p);
        else if(mode==6) render6(elapsedMs,speed,p);
        else if(mode==7) render7(elapsedMs,speed,p);
        else if(mode==8) render8(elapsedMs,speed,p);
        else if(mode==9) render9(elapsedMs,speed,p);
        else if(mode==10) render10(elapsedMs,speed,p);
        else if(mode==11) render11(elapsedMs,speed,p);
        else if(mode==12) render12(elapsedMs,speed,p);
        else if(mode==13) render13(elapsedMs,speed,p);
        else if(mode==14) render14(elapsedMs,speed,p);
        else if(mode<=20) render15to20(mode,elapsedMs,speed,p);
        else if(mode<=30) render21to30(mode,elapsedMs,speed,p);
        else if(mode<=50) render31to50(mode,elapsedMs,speed,p);
        else if(mode<=60) render51to60(mode,elapsedMs,speed,p);
        else if(mode<=70) render61to70(mode,elapsedMs,speed,p);
        else if(mode<=92) render71to92(mode,elapsedMs,speed,p);
        else if(mode<=100) render93to100(mode,elapsedMs,speed,p);
        else render101to120(mode,elapsedMs,speed,p);

        // Physical 4CH mapping in mayarota(3).ino.
        if(mode==31){
            render31Four(elapsedMs,speed,f);
        } else if(mode==51){
            render51Four(elapsedMs,speed,f);
        } else if(mode>=101 && mode<=120){
            copy(p.a,f.ch[0]); copy(p.b,f.ch[1]); copy(p.b,f.ch[2]); copy(p.a,f.ch[3]);
        } else if(mode>=31 && mode<=100){
            copy(p.a,f.ch[0]); copy(p.b,f.ch[1]); copy(p.a,f.ch[2]); copy(p.b,f.ch[3]);
        } else if(mode>=21 && mode<=30){
            copy(p.a,f.ch[0]); copy(p.a,f.ch[1]); copy(p.b,f.ch[2]); copy(p.b,f.ch[3]);
        } else {
            copy(p.a,f.ch[0]); copy(p.b,f.ch[1]); copy(p.a,f.ch[2]); copy(p.b,f.ch[3]);
        }
        return f;
    }

    private static void copy(int[] s,int[] d){ System.arraycopy(s,0,d,0,Math.min(s.length,d.length)); }
    private static float speedFactor(int speed){
        int v=Math.max(1,Math.min(100,speed));
        float delay=50f-((v-1)*45f/99f); delay=clamp(delay,5f,50f); return 25f/delay;
    }
    private static long dly(long base,int speed){ if(base<=1)return 1; return Math.max(2L,Math.round(base/speedFactor(speed))); }
    private static float clamp(float v){return clamp(v,0f,1f);} private static float clamp(float v,float a,float b){return v<a?a:(v>b?b:v);}    
    private static float mod(float a,float b){ if(b==0)return 0; float r=a%b; return r<0?r+b:r; }
    private static float wrap01(float v){ return mod(v,1f); }
    private static float gauss(float d,float w){ if(w<=1e-7f)return 0; return (float)Math.exp(-(d*d)/(2f*w*w)); }
    private static float block(float d,float w){ return w<=1e-7f?0:clamp(1f-d/w); }
    private static int rgb(int r,int g,int b){ return 0xFF000000 | ((clampi(r,0,255))<<16) | ((clampi(g,0,255))<<8) | clampi(b,0,255); }
    private static int clampi(int v,int a,int b){return v<a?a:(v>b?b:v);}    
    private static int r(int c){return (c>>16)&255;} private static int g(int c){return (c>>8)&255;} private static int b(int c){return c&255;}
    private static int scale(int c,float v){ v=clamp(v); if(v<=.001f)return BLACK; return rgb(Math.round(r(c)*v),Math.round(g(c)*v),Math.round(b(c)*v)); }
    private static int add(int a,int bb){ return rgb(Math.min(255,r(a)+r(bb)),Math.min(255,g(a)+g(bb)),Math.min(255,b(a)+b(bb))); }
    private static int blend(int a,int bb,float k){ k=clamp(k); return rgb(Math.round(r(a)*(1-k)+r(bb)*k),Math.round(g(a)*(1-k)+g(bb)*k),Math.round(b(a)*(1-k)+b(bb)*k)); }
    private static int hsv(float h,float s,float v){
        h=mod(h,360f); s=clamp(s); v=clamp(v); float cc=v*s, hp=h/60f, x=cc*(1f-Math.abs(mod(hp,2f)-1f)), m=v-cc; float rr=0,gg=0,bb=0;
        if(h<60){rr=cc;gg=x;} else if(h<120){rr=x;gg=cc;} else if(h<180){gg=cc;bb=x;} else if(h<240){gg=x;bb=cc;} else if(h<300){rr=x;bb=cc;} else {rr=cc;bb=x;}
        return rgb(Math.round((rr+m)*255),Math.round((gg+m)*255),Math.round((bb+m)*255));
    }
    private static int hsv255(float hue){ return hsv(mod(hue,255f)*360f/255f,1f,1f); }
    private static int hashInt(int mode,int cycle,int salt){ int x=mode*0x45d9f3b + cycle*0x119de1f3 + salt*0x27d4eb2d; x^=(x>>>16); x*=0x45d9f3b; x^=(x>>>16); return x&0x7fffffff; }
    private static int rnd(int bound,int mode,int cycle,int salt){return bound<=1?0:hashInt(mode,cycle,salt)%bound;}
    private static float hashf(float n){ float x=(float)Math.sin(n*12.9898f+78.233f)*43758.5453f; return x-(float)Math.floor(x); }
    private static void fill(int[] a,int c){java.util.Arrays.fill(a,c);}    
    private static void setRange(int[] a,int start,int len,int c){ for(int i=Math.max(0,start);i<Math.min(a.length,start+len);i++)a[i]=c; }
    private static void maxSet(int[] a,int i,int c){ if(i<0||i>=a.length)return; if(bright(c)>bright(a[i]))a[i]=c; }
    private static int bright(int c){return r(c)+g(c)+b(c);}    

    // ------------------------------------------------------------------
    // MODE 1-4: source state emulated from elapsed time. Random choices are
    // deterministic in the app; firmware itself uses random(), so geometry is
    // source-faithful but random positions are not phase-synchronized.
    // ------------------------------------------------------------------
    private static int suiteEffect(int mode,int cycle){ return cycle<=0?1:1+rnd(8,mode,cycle,991); }
    private static long activeDur123(int mode,int effect,int speed){
        int blocks=8;
        if(mode==1){ switch(effect){case 1:return 4L*8*dly(80,speed);case 2:return 3L*6*dly(70,speed);case 3:return 3L*blocks*dly(150,speed);case 4:return 20L*dly(100,speed);case 5:return 20L*dly(150,speed);case 6:return 30L*dly(80,speed);case 7:return 10L*(dly(50,speed)+dly(200,speed));default:return 50L*dly(60,speed);} }
        if(mode==2){ switch(effect){case 1:return 4L*8*dly(150,speed);case 2:return 3L*6*dly(100,speed);case 3:return 3L*blocks*dly(150,speed);case 4:return 10L*dly(100,speed);case 5:return 12L*dly(150,speed);case 6:return 16L*dly(120,speed);case 7:return 6L*(dly(80,speed)+dly(250,speed));default:return 30L*dly(100,speed);} }
        // Mode 3 source timings/repeats.
        switch(effect){case 1:return 6L*8*dly(200,speed);case 2:return 5L*6*dly(200,speed);case 3:return 5L*blocks*dly(200,speed);case 4:return 30L*dly(200,speed);case 5:return 20L*dly(200,speed);case 6:return 30L*dly(200,speed);case 7:return 12L*(dly(100,speed)+dly(300,speed));default:return 50L*dly(150,speed);}
    }
    private static long[] cursor123(int mode,long ms,int speed){ long rem=Math.max(0,ms), pause=dly(500,speed); for(int cyc=0;cyc<512;cyc++){int e=suiteEffect(mode,cyc);long a=activeDur123(mode,e,speed);if(rem<a+pause)return new long[]{e,rem,cyc,a};rem-=a+pause;}return new long[]{1,0,0,activeDur123(mode,1,speed)}; }
    private static void render1to4(int mode,long ms,int speed,Pair p){
        if(mode==4){ render4(ms,speed,p); return; }
        long[] cur=cursor123(mode,ms,speed); int effect=(int)cur[0],cyc=(int)cur[2];long local=cur[1],active=cur[3]; if(local>=active)return;
        int blocks=8; int lc=WHITE,rc=WHITE;
        if(mode==2){ int palette=(cyc%6)-1; if(palette>=0){int[] pal={rgb(255,0,0),rgb(0,0,255),rgb(0,255,0),rgb(255,255,0),rgb(180,0,255)};lc=pal[palette];rc=pal[(palette+2)%5];} }
        int salt=cyc*31+effect*7;
        long dd; int sub,rep,bk,side;
        switch(effect){
            case 1:
                dd=dly(mode==1?80:(mode==2?150:200),speed); sub=(int)(local/dd)%8;rep=(int)(local/(dd*8));
                if(sub==0||sub==2){bk=rnd(blocks,mode,cyc,salt+rep*2);setRange(p.a,bk*10,10,lc);} else if(sub==4||sub==6){bk=rnd(blocks,mode,cyc,salt+rep*2+1);setRange(p.b,bk*10,10,rc);} break;
            case 2:
                dd=dly(mode==1?70:(mode==2?100:200),speed);sub=(int)(local/dd)%6;rep=(int)(local/(dd*6)); if((sub&1)==0){setRange(p.a,rnd(blocks,mode,cyc,salt+rep*2)*10,10,lc);setRange(p.b,rnd(blocks,mode,cyc,salt+rep*2+1)*10,10,rc);}break;
            case 3:
                dd=dly(mode==3?200:150,speed);bk=(int)(local/dd)%blocks;setRange(p.a,bk*10,10,lc);setRange(p.b,bk*10,10,rc);break;
            case 4:
                dd=dly(mode==3?200:100,speed);int st=(int)(local/dd);bk=rnd(blocks,mode,cyc,salt+st*2);side=rnd(2,mode,cyc,salt+st*2+1);setRange(side==0?p.a:p.b,bk*10,10,side==0?lc:rc);break;
            case 5:
                dd=dly(mode==3?200:150,speed);sub=(int)(local/dd)&1;fill(sub==0?p.a:p.b,sub==0?lc:rc);break;
            case 6:
                dd=dly(mode==1?80:(mode==2?120:200),speed);sub=(int)(local/dd)&1;if(sub==0){fill(p.a,lc);fill(p.b,rc);}break;
            case 7:
                long on=dly(mode==1?50:(mode==2?80:100),speed),off=dly(mode==1?200:(mode==2?250:300),speed),cc=on+off;int stp=(int)(local/cc);if(local%cc<on){side=mode==1?rnd(2,mode,cyc,salt+stp):0;bk=rnd(blocks,mode,cyc,salt+stp+77);setRange(side==0?p.a:p.b,bk*10,10,side==0?lc:rc);}break;
            default:
                dd=dly(mode==1?60:(mode==2?100:150),speed);int q=(int)(local/dd);int i1=rnd(N,mode,cyc,salt+q),i2=rnd(N,mode,cyc,salt+q+99);setRange(p.a,Math.max(0,i1-2),5,lc);setRange(p.b,Math.max(0,i2-2),5,rc);break;
        }
    }
    private static void render4(long ms,int speed,Pair p){
        long on=dly(250,speed),off=dly(50,speed),cy=on+off; long st=ms/cy; if(ms%cy>=on)return; int blocks=8; int ci=(int)(st/31)%10;
        int[] hue={213,140,192,0,64,96,32,160,110,240}; int rc=hsv255(hue[ci]),lc=hsv255(hue[(ci+1)%10]); setRange(p.b,rnd(blocks,4,(int)st,1)*10,10,rc);setRange(p.a,rnd(blocks,4,(int)st,2)*10,10,lc);
    }

    private static void render5(long ms,int speed,Pair p){
        float sf=speedFactor(speed); float t=ms*.001f*sf; int phase=((int)Math.floor(t/6f))&1; int step=(int)Math.floor(t/(.025f/sf)); // only hue/meteor pace matters visually
        float stepF=ms/(float)dly(25,speed); int pos=((int)stepF)%N; int sweep=((int)stepF)/N; boolean dir=(sweep&1)==0; float hue=mod(stepF*3f,255f);
        int meteor=hsv255(160 + (hashInt(5,sweep,77)%255));
        if(phase==0){for(int i=0;i<N;i++)p.b[i]=hsv255(hue+i*15);int idx=dir?(N-1-pos):pos;if(idx>=0&&idx<N)p.a[idx]=meteor;}
        else {for(int i=0;i<N;i++)p.a[N-1-i]=hsv255(hue+i*15);int idx=dir?pos:(N-1-pos);if(idx>=0&&idx<N)p.b[idx]=meteor;}
    }
    private static void render6(long ms,int speed,Pair p){ long step=ms/dly(20,speed);int center=N/2;long one=center,rep=one*2,sideBlock=rep*3;int side=(int)((step/sideBlock)&1);long q=step%sideBlock,within=q%rep;int i=within<one?(int)within:(int)(rep-1-within);int mi=N-1-i;int col=hsv255((step*5)%255);setRange(side==0?p.a:p.b,Math.max(0,i-1),3,col);setRange(side==0?p.a:p.b,Math.max(0,mi-1),3,col);}
    private static void render7(long ms,int speed,Pair p){long fadeStep=dly(40,speed),fade=80*fadeStep,hold=dly(100,speed),on=dly(30,speed),off=dly(60,speed),blitz=3*(on+off),black=dly(1500,speed),total=fade+hold+blitz+black,q=ms%total;if(q<fade){float v=Math.min(79,(int)(q/fadeStep))/255f;fill(p.a,scale(WHITE,v));fill(p.b,scale(WHITE,v));return;}q-=fade;if(q<hold){fill(p.a,scale(WHITE,79/255f));fill(p.b,scale(WHITE,79/255f));return;}q-=hold;if(q<blitz && q%(on+off)<on){fill(p.a,WHITE);fill(p.b,WHITE);}}
    private static void render8(long ms,int speed,Pair p){long q=ms,fadeStep=dly(40,speed),hold=dly(100,speed),on=dly(35,speed),off=dly(65,speed),gap=dly(400,speed);for(int lim=5;lim<=75;lim+=5){long fade=80*fadeStep,sec=fade+hold+2*(on+off)+gap;if(q<sec){int color=BLACK;if(q<fade)color=scale(WHITE,Math.min(79,(int)(q/fadeStep))/255f);else if((q-=fade)<hold)color=scale(WHITE,79/255f);else if((q-=hold)<2*(on+off)&&q%(on+off)<on)color=WHITE;if(color!=BLACK){setRange(p.a,0,lim,color);setRange(p.b,N-lim,lim,color);}return;}q-=sec;}long tail=dly(1500,speed);if(q>=tail)render8(q-tail,speed,p);}
    private static void render9(long ms,int speed,Pair p){long md=dly(25,speed),meteor=5L*(N*2)*md;if(ms<meteor){long st=ms/md;int pos=(int)(st%(N*2));int col=hsv255((st*8)%255);if(pos<N)setRange(p.b,Math.max(0,pos-2),5,col);else{int li=(N*2-1)-pos;setRange(p.a,Math.max(0,li-2),5,col);}return;}long q=ms-meteor,on=dly(200,speed),off=dly(80,speed),cy=on+off,stro=30*cy;if(q>=stro){render9(q-stro,speed,p);return;}int n=(int)(q/cy);if(q%cy<on){int start=(n%15)*10,col=hsv255((n*30)%255);if(start<N)setRange(p.b,start,10,col);else setRange(p.a,start-N,10,col);}}

    // ------------------------------------------------------------------
    // MODE 10-30 — formulas ported from mayarota(3).ino.
    // ------------------------------------------------------------------
    private static float legacySpeed(int speed){ int v=clampi(speed,0,100); int mapped=2+(v*33/100); return mapped*.1f; }
    private static float blockHw(float d,float W){ float h=W*.5f; if(d<=h*.7f)return 1f; if(d<=h)return 1f-(d-h*.7f)/(h*.3f)*.35f; return 0f; }
    private static float blockHw(float d,float W,int tail){ float h=W*.5f; if(d<=h*.7f)return 1f; if(d<=h)return 1f-(d-h*.7f)/(h*.3f)*.35f; if(tail>0&&d<=h+tail)return .65f*(1f-(d-h)/tail); return 0f; }
    private static int hw(float val,int base,int core,int tail,float whiteRatio){
        if(val<=.001f)return BLACK; float th=1f-whiteRatio*.5f;
        if(val>=th && whiteRatio>.01f){float k=(val-th)/(1f-th);return blend(base,core,k);} float f=val/th;int c=blend(tail,base,(float)Math.pow(clamp(f),.7));return scale(c,f);
    }
    private static int hw(float val,int base,int tail){return hw(val,base,WHITE,tail,.5f);}

    private static void render10(long ms,int speed,Pair p){
        long d200=dly(200,speed),d100=dly(100,speed),d5000=dly(5000,speed); int seg=10,segCount=N/seg; if(segCount<1)segCount=1;
        long scanOne=6L*2L*d200; // 3 flashes per segment
        long scanAll=segCount*scanOne;
        if(ms<scanAll){int si=(int)(ms/scanOne);long q=ms%scanOne;int blink=(int)(q/d200);if((blink&1)==0){int col=hsv255(hashInt(10,si,blink)%255);setRange(p.a,si*10,10,col);setRange(p.b,si*10,10,col);}return;}
        long q=ms-scanAll; int maxI=N/2-5; int collisionFrames=maxI>=0?(maxI/2+1):0; long coll=collisionFrames*d200;
        if(q<coll){int st=(int)(q/d200);int ii=st*2;int rs=N-ii-10;int col=hsv255(hashInt(10,1000+st,2)%255);setRange(p.a,ii,10,col);setRange(p.b,ii,10,col);setRange(p.a,Math.max(0,rs),10,col);setRange(p.b,Math.max(0,rs),10,col);return;}
        q-=coll; long explode=10L*d100; if(q<explode){if(((q/d100)&1)==0){fill(p.a,WHITE);fill(p.b,WHITE);}return;} q-=explode;
        long jumpStep=d200, jumpTotal=5L*4L*jumpStep; if(q<jumpTotal){int ev=(int)(q/(4L*jumpStep));long loc=q%(4L*jumpStep);int flash=(int)(loc/jumpStep);if((flash&1)==0){int side=rnd(2,10,ev,77);int start=rnd(N-9,10,ev,79);int col=hsv255(hashInt(10,ev,83)%255);setRange(side==0?p.a:p.b,start,10,col);}return;} q-=jumpTotal;
        if(q<d5000)return; render10(q-d5000,speed,p);
    }

    private static void render11(long ms,int speed,Pair p){
        long dur=dly(2500,speed); int eff=1+(int)((ms/dur)%8); long local=ms%dur; float hue=(ms/(float)dly(20,speed))%255f;int col=hsv255(hue);int blocks=8;
        switch(eff){
            case 1:{long d=dly(60,speed);int sub=(int)(local/d)%4;if((sub&1)==0)setRange(p.a,rnd(blocks,11,(int)(ms/dur),(int)(local/(d*4)))*10,10,col);break;}
            case 2:{long d=dly(50,speed);int sub=(int)(local/d)%6;int rep=(int)(local/(d*6));if((sub&1)==0){setRange(p.a,rnd(blocks,11,rep,1)*10,10,col);setRange(p.b,rnd(blocks,11,rep,2)*10,10,col);}break;}
            case 3:{long d=dly(100,speed);int b=(int)(local/d)%blocks;setRange(p.a,b*10,10,col);setRange(p.b,b*10,10,col);break;}
            case 4:{long d=dly(80,speed);int st=(int)(local/d);int b=rnd(blocks,11,st,3),side=rnd(2,11,st,4);setRange(side==0?p.a:p.b,b*10,10,col);break;}
            case 5:{long d=dly(120,speed);if(((local/d)&1)==0)fill(p.a,col);else fill(p.b,col);break;}
            case 6:{long d=dly(60,speed);if(((local/d)&1)==0){fill(p.a,col);fill(p.b,col);}break;}
            case 7:{long on=dly(30,speed),off=dly(150,speed),cy=on+off;int st=(int)(local/cy);if(local%cy<on)setRange(p.a,rnd(blocks,11,st,7)*10,10,col);break;}
            default:for(int i=0;i<N;i++){p.a[i]=hsv255(hue+i*7);p.b[i]=hsv255(hue+i*7);}break;
        }
    }

    private static void render12(long ms,int speed,Pair p){
        int bs=N/5-1;if(bs<1)bs=1;if(bs>N)bs=N;int max=N-bs;int bc=max/bs+1+((max%bs)!=0?1:0);long off=dly(45,speed),on=dly(90,speed),gap=dly(85,speed);long blink=5L*(off+on),slot=blink+gap;long st=ms/slot;int period=bc<=1?1:(bc*2-2);int k=period<=1?0:(int)(st%period);int pos=k<bc?k:period-k;long q=ms%slot;if(q<blink){long z=q%(off+on);if(z>=off){int start=Math.min(max,pos*bs);setRange(p.a,start,bs,rgb(105,225,255));setRange(p.b,start,bs,rgb(105,225,255));}}}

    private static long stage13Duration(int speed){return 80L*dly(40,speed)+dly(100,speed)+2L*(dly(35,speed)+dly(65,speed))+dly(400,speed);}
    private static void render13(long ms,int speed,Pair p){
        long sec=stage13Duration(speed),finalGap=dly(1500,speed),cycle=6*sec+finalGap,q=ms%cycle;int li=(int)Math.min(5,q/sec);if(q>=6*sec)return;long z=q%sec;int lim=Math.max(1,N*(li+1)/6);float hue=(ms/(float)dly(15,speed))%255f;int col=hsv255(hue);long fade=80L*dly(40,speed),hold=dly(100,speed),on=dly(35,speed),off=dly(65,speed);int c=BLACK;if(z<fade)c=scale(col,Math.min(79,(int)(z/dly(40,speed)))/79f);else if((z-=fade)<hold)c=col;else{z-=hold;if(z<2*(on+off)&&z%(on+off)<on)c=col;}if(c!=BLACK){setRange(p.a,0,lim,c);setRange(p.b,N-lim,lim,c);}
    }
    private static void render14(long ms,int speed,Pair p){
        long sec=stage13Duration(speed),finalGap=dly(1500,speed),whole=6*sec+finalGap;long cyc=ms/whole,q=ms%whole;if(q>=6*sec)return;int li=(int)(q/sec),lim=Math.max(1,N*(li+1)/6);long z=q%sec;long fade=80L*dly(40,speed),hold=dly(100,speed),on=dly(35,speed),off=dly(65,speed);int c=BLACK;if(z<fade)c=scale(WHITE,Math.min(79,(int)(z/dly(40,speed)))/79f);else if((z-=fade)<hold)c=WHITE;else{z-=hold;if(z<2*(on+off)&&z%(on+off)<on)c=WHITE;}if(c!=BLACK){boolean rev=(cyc&1)==1;if(!rev){setRange(p.a,0,lim,c);setRange(p.b,N-lim,lim,c);}else{setRange(p.a,N-lim,lim,c);setRange(p.b,0,lim,c);}}
    }

    private static void render15to20(int mode,long ms,int speed,Pair p){
        float t=ms*.001f*legacySpeed(speed); float W=10f;
        if(mode==15||mode==16){float cy=mod(t*2f,2f),h=Math.abs((float)Math.sin(cy*PI*.5f))*(N-1);for(int i=0;i<N;i++){float v=blockHw(Math.abs(i-h),W);int c=mode==15?hsv255(i/(float)N*255f+t*50f):WHITE;p.a[i]=scale(c,v);p.b[i]=scale(c,v);}return;}
        if(mode==17){int Ne=N*2;float cy=mod(t*2f,2f),h=Math.abs((float)Math.sin(cy*PI*.5f))*(Ne-1);for(int i=0;i<N;i++){float v1=blockHw(Math.abs((N+i)-h),W),v2=blockHw(Math.abs(i-h),W);p.a[i]=hw(v1,rgb(0,85,255),WHITE);p.b[i]=scale(hsv255(i/(float)N*255f+t*50f),v2);}return;}
        if(mode==18){float mid=(N-1)*.5f,pos=mid+(float)Math.exp(-mod(t*2f,3f))*(float)Math.cos(t*14f)*(mid*.95f);for(int i=0;i<N;i++){float v=blockHw(Math.abs(i-pos),7f);p.a[i]=scale(hsv255(t*40f+i*4f),v);p.b[i]=scale(WHITE,v);}return;}
        if(mode==19){t=ms*.001f*1.2f;for(int i=0;i<N;i++){float norm=i/(float)(N-1);float p1=mod(t*22,N),p2=N-1-mod(t*22,N);float v1=(float)Math.sin(norm*PI*3-t*4)*.4f+.3f+Math.max(blockHw(Math.abs(i-p1),14),blockHw(Math.abs(i-p2),14))*.6f+((int)mod((float)Math.floor(t*8),8)==0?.4f:0);v1=Math.min(1,v1);float pp=mod(t*22,N+7)-3.5f;float v2=blockHw(Math.abs(i-pp),7);p.a[i]=scale(hsv255(t*40+i*4),v1);p.b[i]=hw(v2,WHITE,rgb(255,0,0),WHITE,1f);}return;}
        // 20 connected comet CH1 -> CH2
        int total=N*2;for(int i=0;i<N;i++){float v1=comet20(t,i,total,14),v2=comet20(t,i+N,total,14);p.a[i]=hw(v1,rgb(0,242,254),rgb(255,187,0),rgb(0,0,255),1f);p.b[i]=hw(v2,rgb(255,0,128),rgb(255,0,0),rgb(0,0,255),1f);}
    }
    private static float comet20(float t,int i,int total,int W){float head=mod(t*26,total+35)-10,d=head-i;if(d>=-2&&d<=W)return 1;if(d>W&&d<W+25)return (float)Math.exp(-(d-W)/8f);return 0;}

    private static void render21to30(int mode,long ms,int speed,Pair p){
        if(mode==27){render27(ms,speed,p);return;} if(mode==28){render28(ms,speed,p);return;} if(mode==29||mode==30){render2930(mode,ms,speed,p);return;}
        float wall=ms*.001f*speedFactor(speed); float t=(mode==24||mode==25)?wall*3f:wall*1.2f; int total=N*2;
        for(int i=0;i<N;i++){
            if(mode==21){float sweep=mod(t*20,total),v1=blockHw(Math.abs(i-sweep),20),vb=blockHw(Math.abs((i+N)-sweep),20),v2=1-vb;p.a[i]=scale(hsv255(t*40+i*4),v1);p.b[i]=hw(v2,rgb(8,158,181),rgb(15,189,189),rgb(9,170,108),1f);}
            else if(mode==22){float mid=(N-1)*.5f,pos=mid+(float)Math.exp(-mod(t*2,3))*(float)Math.cos(t*14)*(mid*.95f),v1=blockHw(Math.abs(i-pos),8,3);float h1=mod(t*22,N+30)-10,h2=N-1-(mod(t*22,N+30)-10),v2=Math.min(1,blockHw(Math.abs(i-h1),8)+blockHw(Math.abs(i-h2),8));p.a[i]=scale(hsv255(t*40+i*4),v1);p.b[i]=hw(v2,rgb(143,75,175),rgb(173,118,219),rgb(178,108,198),1f);}
            else if(mode==23){float n1=i/(float)(total-1),n2=(i+N)/(float)(total-1),v1=(float)Math.sin(n1*2-t*2)*.5f+.5f,v2=(float)Math.sin(n2*2-t*2)*.5f+.5f;p.a[i]=hw(v1,rgb(31,101,65),WHITE,rgb(220,9,9),1f);p.b[i]=hw(v2,rgb(0,120,255),WHITE,rgb(220,9,9),1f);}
            else if(mode==24||mode==25){boolean swapped=mode==25&&(((int)Math.floor(t/((total+30)/20f)))&1)==1;float local=mode==25?mod(t,(total+30)/20f):t;for(int ch=0;ch<2;ch++){int vi=i+ch*N;boolean use3=mode==24?(ch==0):((!swapped&&ch==0)||(swapped&&ch==1));float val;int base,core;if(use3){float pp=mod(local*22,total+8)-4;val=blockHw(Math.abs(vi-pp),8);base=rgb(227,116,13);core=rgb(216,0,245);}else{float pp=mod(local*20,total+30)-15,dd=Math.abs(vi-pp);val=dd<14?1:(dd<22?(float)Math.cos(((dd-14)/8)*(PI/2)):0);base=rgb(0,120,255);core=rgb(117,138,40);}if(ch==0)p.a[i]=hw(val,base,core,rgb(220,9,9),1f);else p.b[i]=hw(val,base,core,rgb(220,9,9),1f);}}
            else {float p1=((float)Math.sin(t*3.2)*.5f+.5f)*(N-1),p2=((float)Math.sin(t*2.4)*.5f+.5f)*(N-1),v1=blockHw(Math.abs(i-p1),7),v2=blockHw(Math.abs(i-p2),7);p.a[i]=hw(v1,rgb(96,18,161),rgb(90,21,193),rgb(21,193,87),.5f);p.b[i]=hw(v2,rgb(21,193,87),rgb(21,193,87),rgb(21,193,87),.5f);}
        }
    }
    private static void render27(long ms,int speed,Pair p){
        int[] sizes={5,8,10,12};long t=ms;int modeIdx=(int)((t/dly(6500,speed))%4);int bs=sizes[modeIdx],rows=(N+bs-1)/bs;long slot=dly(50+50+50+50+50+50+100,speed);int blockNo=(int)((t/slot)%(rows*2));long q=t%slot;if(q<dly(50,speed)|| (q>=dly(100,speed)&&q<dly(150,speed)) || (q>=dly(200,speed)&&q<dly(250,speed))){int side=blockNo&1,row=rnd(rows,27,modeIdx,blockNo+3);boolean rainbow=rnd(100,27,modeIdx,blockNo+11)<25;int start=row*bs;if(rainbow)for(int i=0;i<bs&&start+i<N;i++)(side==0?p.a:p.b)[start+i]=hsv255((hashInt(27,blockNo,17)+i*(255/Math.max(1,bs)))%255);else setRange(side==0?p.a:p.b,start,bs,hsv255(hashInt(27,blockNo,19)%255));}}
    private static void render28(long ms,int speed,Pair p){float rate=.0484f+speed*.00396f,prog=ms*.001f*rate;for(int ch=0;ch<2;ch++){int cycle=(int)Math.floor(prog);float local=prog-cycle;boolean rev=((cycle/3)&1)!=0;float ph=local+(ch==1?.5f:0);if(ph>=1)ph-=1;float pos=rev?1-ph:ph;int[][] cs={{rgb(255,40,145),rgb(0,210,255),rgb(255,180,0)},{WHITE,rgb(70,120,255),rgb(80,255,80)}};int base=cs[ch][cycle%3];float visual=prog/.22f;float gate=(((int)Math.floor(visual*10))%4)<2?1:.1f;int[] out=ch==0?p.a:p.b;for(int i=0;i<N;i++){float x=i/(float)(N-1),dd=Math.abs(x-pos);if(dd>.5f)dd=1-dd;float scan=dd<.1f?1-dd/.1f:0;int block=(int)Math.floor(x*10);if(block>9)block=9;int active=(int)Math.floor(pos*10);if(active>9)active=9;float val=Math.max(scan*.8f,block==active?gate:0);out[i]=scale(base,val);}}}
    private static void render2930(int mode,long ms,int speed,Pair p){float rate=.22f+speed*.018f,t=ms*.001f*rate;for(int ch=0;ch<2;ch++){int[] out=ch==0?p.a:p.b;if(mode==29){float center=(float)Math.sin(t*1.5+(ch==1?PI:0))*.5f+.5f,width=.08f+.22f*((float)Math.sin(t*.7)*.5f+.5f),blitz=((int)Math.floor(mod(t,1.8f)*12)<3)?1:.35f;for(int i=0;i<N;i++){float x=i/(float)(N-1),body=clamp(1-Math.abs(x-center)/width),val=body*blitz;out[i]=scale(hsv((x*.9f+t*.08f+(ch==1?.16f:0))*360,1,1),val);}}else{float pos=(float)Math.sin(t*1.6+(ch==1?.8f:0))*.5f+.5f;for(int i=0;i<N;i++){float x=i/(float)(N-1),dd=Math.abs(x-pos),core=(float)Math.exp(-dd*45);out[i]=scale(ch==1?rgb(255,0,120):hsv((x+t*.08f)*360,1,1),core);}}}}

    // ------------------------------------------------------------------
    // MODE 31-60 — approved-source formulas in mayarota(3).ino.
    // ------------------------------------------------------------------
    private static void render31to50(int mode,long ms,int speed,Pair p){
        if(mode==31)return; float t=ms*.001f*speedFactor(speed),NN=N,W=Math.max(4f,NN/10f),C=(NN-1)*.5f;
        for(int ch=0;ch<2;ch++)for(int i=0;i<N;i++){
            float x=N>1?i/(float)(N-1):0,v=0;int color=BLACK;
            switch(mode){
                case 32:{float A=wrap01(t*.52f+(ch==1?.25f:0)),B=4*A*(1-A),cc=ch==1?1-B:B,ball=(float)Math.exp(-Math.abs(x-cc)*35),ghost=(float)Math.exp(-Math.abs(x-(1-cc))*30)*.30f;int pc=hsv((t*.12f+x*.5f+(ch==1?.20f:0))*360,1,1);color=add(scale(pc,ball),scale(WHITE,ghost));v=1;break;}
                case 33:{float[] widths={.05f,.08f,.10f,.12f};boolean swap=(((int)Math.floor(t/2.2))&1)!=0,rev=(ch==1)!=swap;float dir=rev?-1:1,A=wrap01(t*.32f*dir),B=widths[((int)Math.floor(t/1.2))&3],cc=wrap01((float)Math.floor(t*2.4)*.173f+(ch==1?.41f:0));boolean flag=((int)Math.floor(t*12)%6)<3;float run=(float)Math.exp(-cyclicDist(x,A)*32),blk=(cyclicDist(x,cc)<B*.5f&&flag)?1:0;color=scale(ch==1?rgb(255,80,20):rgb(40,180,255),Math.max(run,blk));v=1;break;}
                case 34:{float dir=(((int)Math.floor(t/2.4))&1)!=0?1:-1,A=wrap01(t*.28f*dir);boolean flag=((int)Math.floor(t*8)%8)<2;float flow=(float)Math.exp(-cyclicDist(x,A)*20),burst=(flag&&Math.abs(x-.5f)<.20f)?1:0;color=scale(WHITE,Math.max(flow*.8f,burst));v=1;break;}
                case 35:{float A=(float)Math.sin(t*1.25)*.38f+.5f,B=1-A,ta=ch==1?B:A,tb=ch==1?A:B,a=(float)Math.exp(-Math.abs(x-ta)*20),bb=(float)Math.exp(-Math.abs(x-tb)*20)*.55f;int c1=hsv((x+t*.10f+(ch==1?.18f:0))*360,1,1),c2=hsv((1-x+t*.07f+.5f)*360,1,1);color=add(scale(c1,a),scale(c2,bb));v=1;break;}
                case 36:{float A=wrap01(t*.25f),B=A<.5f?A*2:2-A*2,u=((ch==1?1:0)+x)*.5f,d=Math.abs(u-B),core=(float)Math.exp(-d*60),tail=(float)Math.exp(-Math.max(0,u-B)*18)*.5f;int pc=hsv((u+t*.08f)*360,1,1);color=add(scale(pc,core),scale(rgb(255,150,20),tail));v=1;break;}
                case 37:{int kk=(int)Math.floor(t*3)%6;float pp=mod(kk*W*1.35f+(ch==1?W*.6f:0),NN);boolean flash=((int)Math.floor(t*12)%6)<3&&mod(t*6,1)>.68f;float breath=.35f+.65f*((float)Math.sin(t*2.4)*.5f+.5f),vv=block(Math.abs(i-pp),W*.7f);v=clamp(Math.max(vv,flash?.9f:0)*breath);color=hsv(45+i*3+t*20,1,1);break;}
                case 38:{float pp=mod(t*18,NN+W)-W*.5f,qq=NN-1-pp,ss=Math.max(0,(float)Math.sin(t*3.5)),meteor=Math.max(gauss(i-pp,W*.55f),gauss(i-qq,W*.55f)),collision=gauss(i-C,W*1.2f)*(float)Math.pow(ss,8);v=clamp(meteor+collision);color=hsv(i*5+t*80+(ch==1?90:0),1,1);break;}
                case 39:{float rad=((float)Math.sin(t*2.2)*.5f+.5f)*C;boolean flash=((int)Math.floor(t*8)%8)<2;v=Math.max(block(Math.abs(Math.abs(i-C)-rad),W*.45f),flash?.8f:0);color=hsv(35+(ch==1?190:0)+t*30,1,1);break;}
                case 40:case 41:{boolean pulse=((int)Math.floor(t*10)%20)==0;float vv=0;for(int k=0;k<4;k++){float pp=mod(t*20-k*NN/4f+(ch==1?k*4f:0)+NN*8,NN);vv=Math.max(vv,gauss(i-pp,W*.42f));}if(pulse)vv+=.8f;v=clamp(vv);color=hsv(t*70+i*2+(ch==1?120:0),.95f,1);break;}
                case 42:{float pp=C+(float)Math.sin(t*2.5)*(float)Math.cos(t*.72)*C*.95f,ph=mod(t*1.5f,4),e=C+(float)Math.exp(-ph)*(float)Math.cos(t*13)*C*.8f;v=Math.max(block(Math.abs(i-pp),W),block(Math.abs(i-e),W*.7f));color=hsv(195+(float)Math.sin(t)*90+(ch==1?60:0),.95f,1);break;}
                case 43:{float rad=mod(t*16,C+W);if((((int)Math.floor(t*.65))&1)!=0)rad=C-mod(rad,Math.max(C,1));float head=mod(t*22,NN);int frame=(int)Math.floor(t*60);float ring=block(Math.abs(Math.abs(i-C)-rad),W*.6f),sp=(Math.abs(i-head)<W*2&&hashInt(43,frame,i+ch*997)%256>224)?.9f:0;v=Math.max(ring,sp);color=hsv(20+i*4+t*55,.95f,1);break;}
                case 44:{float size=W+((float)Math.sin(t*2.6)*.5f+.5f)*(C-W),sw=C+(float)Math.sin(t*3.1)*C*.9f,ed=Math.abs(i-C),ap=ed<size?1:gauss(ed-size,W*.6f);v=clamp(ap*.6f+block(Math.abs(i-sw),W*1.1f)*.6f);color=hsv(275+(float)Math.sin(t*1.5)*80+(ch==1?55:0),.95f,1);break;}
                case 45:{float pp,qq;if(ch==0){pp=((float)Math.sin(t*3.2)*.5f+.5f)*(NN-1);qq=mod(t*13,NN);}else{pp=((float)Math.sin(t*2.35+1.2)*.5f+.5f)*(NN-1);qq=NN-1-mod(t*17,NN);}v=Math.max(block(Math.abs(i-pp),W*.7f),gauss(i-qq,W*.55f));color=hsv(ch==1?130:275,.95f,1);break;}
                case 46:{int[] segs={5,8,10,12};int seg=segs[((int)Math.floor(t*.8))&3],ep=(int)Math.floor(t*4);boolean st=((int)Math.floor(t*12)%3)<2;int start=Math.floorMod(ep*37+ch*71,N);start-=start%seg;v=(i>=start&&i<Math.min(N,start+seg)&&st)?1:0;color=hsv((float)Math.floor(t*4)*47+(ch==1?90:0),.95f,1);break;}
                case 47:{int[] segs={5,8,10,12};int stage=(int)Math.floor(t/2.8)%4,frame=(int)Math.floor(t*60);if(stage==0){float pp=mod(t*22,NN);v=Math.max(gauss(i-pp,W*.5f),gauss(i-(NN-1-pp),W*.5f));}else if(stage==1){float pp=mod(t*18,NN+W)-W*.5f,qq=NN-1-pp;v=clamp(Math.max(block(Math.abs(i-pp),W),block(Math.abs(i-qq),W))+gauss(i-C,W)*.5f);}else if(stage==2){float pp=mod(t*20,NN);float sp=(Math.abs(i-pp)<W*2&&hashInt(47,frame,i+ch*541)%256>214)?.8f:0;v=clamp(block(Math.abs(i-pp),W*.8f)+sp);}else{int seg=segs[((int)Math.floor(t*1.2))&3],ep=(int)Math.floor(t*5),start=Math.floorMod(ep*29+ch*41,N);start-=start%seg;v=(i>=start&&i<start+seg&&((int)Math.floor(t*14)%3)<2)?1:0;}color=hsv(t*90+i*3+(ch==1?80:0),.95f,1);break;}
                case 48:{int ph=(int)Math.floor(t*2.4)%4;boolean flash=(ph==1||ph==3)&&(((int)Math.floor(t*12)%2)==0),left=i<C,red=ph<2?left:!left;color=scale(red?rgb(255,0,0):rgb(0,70,255),flash?1:.85f);v=1;break;}
                case 49:{int step=(int)Math.floor(t*13),cy=step%18,grp=step/18;float base=grp*W*2,off=cy<12?cy:24-cy,pp=mod(base+off*W/3,NN);v=block(Math.abs(i-pp),W*.7f);color=WHITE;break;}
                case 50:{int st=(int)Math.floor(t/1.8)%4;if(st==0){v=((int)Math.floor(t*12)%2)==0?1:0;color=rgb(255,0,0);}else if(st==1){v=((int)Math.floor(t*12)%2)==0?1:0;color=rgb(0,70,255);}else if(st==2){float pp=mod(t*20,NN);v=block(Math.abs(i-pp),W*.8f);color=WHITE;}break;}
            }
            int out=(v==1&&color!=BLACK&&(mode>=32&&mode<=36||mode==48))?color:scale(color,v); if(ch==0)p.a[i]=out;else p.b[i]=out;
        }
    }
    private static float cyclicDist(float a,float bb){float d=Math.abs(a-bb);d=mod(d,1);if(d>.5f)d=1-d;return d;}

    private static void render31Four(long ms,int speed,Frame4 f){
        long fd=dly(5,speed),frame=ms/fd,phaseBlock=161;int phase=4+(int)(frame/phaseBlock);phase=((phase-1)%8)+1;int local=(int)(frame%phaseBlock),total=N*2;int pos=0;int dir=1;long gs=local;
        if(phase==1||phase==2||phase==4||phase==7)pos=local%Math.max(1,total); else if(phase==3){int period=Math.max(1,2*(total-1));int q=local*2%period;pos=q<total?q:period-q;dir=(q<total)?1:-1;}else if(phase==6)pos=local%(Math.max(1,total/2));
        int[][] leftPair={f.ch[0],f.ch[2]}, rightPair={f.ch[1],f.ch[3]};
        for(int vp=0;vp<total;vp++){
            float vl=0,vr=0;int cl=m31Color(vp,total,gs),cr=m31Color(vp,total,gs+15);
            if(phase==1){int dd=Math.floorMod(pos-vp,total);if(dd<40)vl=vr=1-dd/40f;}
            else if(phase==2){for(int k=0;k<2;k++){int head=(pos+k*(total/2))%total,dd=Math.floorMod(head-vp,total);if(dd<50)vl=vr=Math.max(vl,1-dd/50f);}}
            else if(phase==3){int dd=dir==1?Math.floorMod(pos-vp,total):Math.floorMod(vp-pos,total);if(dd<35)vl=vr=(float)Math.sin(dd/(float)35*PI);}
            else if(phase==4){int head=local%(total+50),dd=head-vp;if(dd>=0&&dd<50)vl=vr=(float)Math.sin(dd/(float)50*PI);}
            else if(phase==5){vl=vr=(float)((Math.sin((gs*6+vp*4)*2*PI/256)+1)*.5);}
            else if(phase==6){int center=total/2,idx1=(center+pos)%total,idx2=Math.floorMod(center-pos,total),d1=Math.floorMod(idx1-vp,total),d2=Math.floorMod(vp-idx2,total);if(d1<20||d2<20)vl=vr=1-Math.min(d1,d2)/20f;cr=cl;}
            else if(phase==7){int p1=pos%total,p2=(pos*2)%total,d1=Math.floorMod(p1-vp,total),d2=Math.floorMod(p2-vp,total);if(d1<25)vl=1-d1/25f;if(d2<25)vr=1-d2/25f;}
            else {float breath=(float)((Math.sin(gs*4*2*PI/256)+1)*.5);vl=vr=.18f+.82f*breath;}
            int seg=vp/N,idx=vp%N;leftPair[seg][idx]=scale(cl,vl);rightPair[seg][idx]=scale(cr,vr);
        }
    }
    private static int m31Color(int i,int total,long step){float hue=mod((i*255f/Math.max(1,total))*2+step*3,256)*360f/255f;return hsv(hue,1,.5f);}

    private static void render51to60(int mode,long ms,int speed,Pair p){float t=ms*.001f*speedFactor(speed),NN=N,W=Math.max(4f,NN/12f),C=(NN-1)*.5f;int[] p3={WHITE,rgb(255,0,0),rgb(0,80,255)};int[] pal={rgb(255,0,0),rgb(0,90,255),WHITE,rgb(170,0,255),rgb(0,255,120),rgb(255,40,140),rgb(0,220,255),rgb(255,220,0),rgb(120,255,0),rgb(255,100,40)};for(int ch=0;ch<2;ch++)for(int i=0;i<N;i++){float v=0;int color=BLACK;if(mode==51){float len=2.6f;int rep=((int)Math.floor(t/len))%5;float u=mod(t,len)/len;boolean forward=(rep&1)==0;int total=N*2;float head=forward?u*(total-1):(1-u)*(total-1);int bl=Math.max(5,Math.round(N*.085f)),tail=Math.max(4,Math.round(N*.06f)),virt=ch==0?i:N+i,dir=forward?1:-1;for(int j=0;j<bl+tail;j++){int vp=Math.round(head)-dir*j;if(vp==virt){v=j<bl?1:1-(j-bl+1)/(float)(tail+1);break;}}int[] cc={rgb(255,40,40),rgb(0,170,255),rgb(0,255,110),rgb(185,60,255),rgb(255,150,0)};color=cc[rep];}
            else if(mode==52){float len=4,u=mod(t,len)/len;int cyc=(int)Math.floor(t/len);float spread=(.12f+.25f*(.5f-.5f*(float)Math.cos(u*PI*2)))*NN,dr=(float)Math.sin(u*PI*2)*NN*.11f;float[] centers={C-spread+dr*.65f,C-spread*.35f-dr*.65f,C+spread*.35f+dr*.65f,C+spread-dr*.65f};for(float cc:centers){float gate=1-Math.abs(Math.abs(i-cc)-W*.75f)/(W*.28f);v=Math.max(v,clamp(gate));}v=clamp(v*(.72f+.28f*(float)Math.sin(u*PI*4)));color=p3[Math.floorMod(cyc,3)];}
            else if(mode==53){float len=1.55f;int ph=Math.floorMod((int)Math.floor(t/len),8);float u=mod(t,len)/len;int a=ch==0?rgb(0,190,255):rgb(255,45,120),bb=ch==0?rgb(255,220,0):rgb(80,255,120);if(ph==0){float half=u*NN*.5f,d=Math.abs(i-C);v=d<=half?1:gauss(d-half,W*.22f);color=a;}else if(ph==1){float edge=Math.min(i,NN-1-i),lim=u*NN*.5f;v=edge>=lim?1:gauss(edge-lim,W*.2f);color=bb;}else if(ph==2){int seg=Math.max(4,Math.round(NN/10)),idx=i/seg,pulse=(int)Math.floor(u*8)%2;v=((idx+pulse)&1)==0?1:.08f;color=ch==0?WHITE:rgb(0,100,255);}else if(ph==3){float aa=u*(NN-1),b=(1-u)*(NN-1);v=Math.max(gauss(i-aa,W*.34f),gauss(i-b,W*.34f));color=ch==0?rgb(180,50,255):rgb(255,130,0);}else if(ph==4){float reach=u*NN*.5f;v=(i<reach||i>NN-1-reach)?1:0;color=ch==0?rgb(0,255,130):rgb(255,40,40);}else if(ph==5){float h=u*(NN-1),hole=gauss(i-h,W*.55f);v=1-hole;color=ch==0?WHITE:rgb(255,0,160);}else if(ph==6){float aa=u*C,b=(NN-1)-u*C;v=Math.max(gauss(i-aa,W*.36f),gauss(i-b,W*.36f));if(u>.82f)v=Math.max(v,gauss(i-C,W*(.25f+(u-.82f)*4)));color=ch==0?rgb(0,170,255):rgb(255,210,0);}else{int pulse=(int)Math.floor(u*6);v=(pulse&1)==0?1:0;color=pal[((int)Math.floor(u*3)+ch*2)%10];}}
            else if(mode==54){int seg=Math.max(4,Math.round(NN/12)),sc=(int)Math.ceil(NN/seg),idx=i/seg;float cy=mod(t,5.2f);if(cy<2.6f){int on=(int)Math.floor(cy/2.6f*(sc+1));v=idx<on?1:0;}else{float q=(cy-2.6f)/2.6f,den=Math.max(.5f,sc*.5f),dist=Math.abs(idx+.5f-sc*.5f)/den;v=dist>q?1:0;}v*=((i%seg)<2?.35f:1);color=rgb(235,245,255);}
            else if(mode==55){int seg=Math.max(5,Math.round(NN/8)),sc=(int)Math.ceil(NN/seg),cyc=(int)Math.floor(t/5),phase=(int)Math.floor(mod(t,5)/5*sc*2),idx=i/seg;v=phase<sc?(idx<=phase?1:0):(idx<=sc*2-1-phase?1:0);color=p3[Math.floorMod(cyc,3)];}
            else if(mode==56){float u=mod(t,5)/5,p1=NN*(.22f+.18f*(float)Math.sin(t*.8)),p2=NN*(.78f+.14f*(float)Math.cos(t*.7)),rad=(.5f-.5f*(float)Math.cos(u*PI*2))*NN*.18f,r1=Math.abs(Math.abs(i-p1)-rad),r2=Math.abs(Math.abs(i-p2)-rad*.8f);v=Math.max(gauss(r1,W*.22f),gauss(r2,W*.22f));v=clamp(v*(.72f+.28f*(float)Math.sin(t*9+i*.05f)));color=ch==0?rgb(180,235,255):WHITE;}
            else if(mode==57){float rate=11+5*(float)Math.sin(t*.8),pp=mod(t*rate,NN),q=mod(pp+NN*.32f,NN);v=Math.max(gauss(i-pp,W*.5f),gauss(i-q,W*.5f));color=WHITE;}
            else if(mode==58){int seg=Math.max(4,Math.round(NN/16)),idx=i/seg,shift=(int)Math.floor(t*5),local=i%seg,pattern=Math.floorMod(idx+shift,6);boolean on=pattern==0||pattern==1||pattern==4;float pulse=.55f+.45f*((float)Math.sin(t*5+idx*.8)*.5f+.5f),edge=(local==0||local==seg-1)?.35f:1;v=on?pulse*edge:0;color=rgb(245,245,255);}
            else if(mode==59){int cyc=(int)Math.floor(t/4),pair=Math.floorMod(cyc,3),sw=Math.floorMod(cyc,2),side=(ch+sw)%2;int[][] pairs={{WHITE,rgb(255,0,0)},{rgb(0,90,255),WHITE},{rgb(255,0,0),rgb(0,90,255)}};color=pairs[pair][side];float[] cs={NN*.16f,NN*.38f,NN*.62f,NN*.84f};float u=mod(t,4)/4;for(int k=0;k<4;k++){float pulse=.15f+.85f*((float)Math.sin(u*PI*2+k*1.35+ch*.8)*.5f+.5f);v=Math.max(v,gauss(i-cs[k],W*.72f)*pulse);}}
            else{float u=(float)Math.sin(t*1.25)*.5f+.5f,center=NN*(.25f+.5f*((float)Math.sin(t*.37)*.5f+.5f));float[] starts={NN*.08f,NN*.27f,NN*.48f,NN*.69f,NN*.91f};for(int k=0;k<5;k++){float repel=(k-2)*NN*.045f*(float)Math.sin(t*2.1),pp=starts[k]*(1-u)+center*u+repel;v=Math.max(v,gauss(i-pp,W*.42f));}color=ch==0?WHITE:rgb(120,190,255);}
            (ch==0?p.a:p.b)[i]=scale(color,v);
        }}
    private static void render51Four(long ms,int speed,Frame4 f){float t=ms*.001f*speedFactor(speed),len=2.6f;int rep=Math.floorMod((int)Math.floor(t/len),5);float u=mod(t,len)/len;boolean forward=(rep&1)==0;int total=N*4;float head=forward?u*(total-1):(1-u)*(total-1);int bl=Math.max(5,Math.round(N*.085f)),tail=Math.max(4,Math.round(N*.06f)),dir=forward?1:-1;int[] cols={rgb(255,40,40),rgb(0,170,255),rgb(0,255,110),rgb(185,60,255),rgb(255,150,0)};int[][] order={f.ch[0],f.ch[2],f.ch[3],f.ch[1]};for(int j=0;j<bl+tail;j++){int vp=Math.round(head)-dir*j;if(vp<0||vp>=total)continue;int seg=vp/N,idx=vp%N;float val=j<bl?1:1-(j-bl+1)/(float)(tail+1);order[seg][idx]=scale(cols[rep],val);}}

    // MODE 61-70 — source formulas.
    private static int fiveColor(int n){int k=Math.floorMod(n,5);return k==0?WHITE:k==1?rgb(255,0,0):k==2?rgb(0,90,255):k==3?rgb(0,255,90):rgb(255,0,170);}
    private static void render61to70(int mode,long ms,int speed,Pair p){float t=ms*.001f*speedFactor(speed),NN=N,W=Math.max(3f,NN/14f),C=(NN-1)*.5f;for(int ch=0;ch<2;ch++)for(int i=0;i<N;i++){float v=0;int color=BLACK;
        if(mode==61){float L=5.2f,u=mod(t,L)/L;if(u<.22f){float q=u/.22f;v=gauss(i-C,W*(.45f+q*.25f));}else if(u<.52f){float q=(u-.22f)/.30f,pp=q*C;v=Math.max(gauss(i-(C-pp),W*.48f),gauss(i-(C+pp),W*.48f));}else if(u<.68f)v=Math.max(gauss(i-1,W*.65f),gauss(i-(NN-2),W*.65f));else if(u<.94f){float q=(u-.68f)/.26f,pp=(1-q)*C;v=Math.max(gauss(i-(C-pp),W*.52f),gauss(i-(C+pp),W*.52f));}else v=(((int)Math.floor(t*18))%2==0)?gauss(i-C,W*1.25f):0;color=WHITE;}
        else if(mode==62){float L=6,u=mod(t,L)/L;int red=rgb(255,0,0),blue=rgb(0,70,255);if(u<.25f){int swap=((int)Math.floor(t/L))%2;boolean left=i<C,isRed=swap!=0?!left:left;v=.9f;color=isRed?red:blue;}else if(u<.48f){float q=(u-.25f)/.23f,pp=q*C,vl=gauss(i-pp,W*.55f),vr=gauss(i-(NN-1-pp),W*.55f);v=Math.max(vl,vr);color=vl>vr?red:blue;}else if(u<.58f){boolean fl=((int)Math.floor(t*20))%2==0;v=gauss(i-C,W*1.3f)*(fl?1:.1f);color=WHITE;}else{float q=(u-.58f)/.42f,pp=q*C,vl=gauss(i-(C-pp),W*.5f),vr=gauss(i-(C+pp),W*.5f);v=Math.max(vl,vr);color=vl>vr?blue:red;}}
        else if(mode==63){float L=5.6f,u=mod(t,L)/L;int blocks=6;float seg=NN/blocks,shift=u<.5f?0:seg*.5f,local=mod(i-shift,NN);int idx=clampi((int)Math.floor(local/seg),0,blocks-1);float pos=local-idx*seg,width=u<.25f?.42f:u<.5f?.42f-((u-.25f)/.25f)*.25f:u<.75f?.17f+((u-.5f)/.25f)*.25f:.42f;v=block(Math.abs(pos-seg*.5f),seg*width);if(u>.75f)v*=.55f+.45f*((float)Math.sin(t*8+idx)*.5f+.5f);color=(idx%2==0)?WHITE:rgb(0,150,255);}
        else if(mode==64){float L=6.4f,u=mod(t,L)/L,p1,p2,tail=.55f;if(u<.36f){float q=u/.36f;p1=q*(NN-1);p2=(NN-1)-q*(NN-1);}else if(u<.58f){float q=(u-.36f)/.22f;p1=C+q*C;p2=C-q*C;}else{float q=(u-.58f)/.42f;p1=(NN-1)-q*(NN-1);p2=q*(NN-1);tail=.95f;}float v1=gauss(i-p1,W*.38f)+gauss(i-(p1-tail*W*2),W*.8f)*.45f,v2=gauss(i-p2,W*.38f)+gauss(i-(p2+tail*W*2),W*.8f)*.45f;v=clamp(Math.max(v1,v2));color=v1>v2?WHITE:rgb(0,100,255);}
        else if(mode==65){float L=6.2f,u=mod(t,L)/L;int zones=8;float seg=NN/zones;int idx=clampi((int)Math.floor(i/seg),0,zones-1);if(u<.28f){int k=(int)Math.floor((u/.28f)*(zones+1));v=idx<k?1:0;}else if(u<.48f)v=(idx%2)==(((int)Math.floor(t*6))%2)?1:.12f;else if(u<.70f){float q=(u-.48f)/.22f,dist=Math.abs(idx+.5f-zones*.5f)/(zones*.5f);v=dist>q?1:0;}else{int k=(int)Math.floor(((u-.70f)/.30f)*(zones+1));v=idx>=zones-k?1:0;}color=WHITE;}
        else if(mode==66){float L=6.8f,u=mod(t,L)/L;int zones=5;float seg=NN/zones;int idx=clampi((int)Math.floor(i/seg),0,zones-1);float local=(i-idx*seg)/seg,shape=(float)Math.sin(PI*local);v=.05f;if(u<.30f){int a=((int)Math.floor((u/.30f)*zones))%zones;v=idx==a?shape:0;}else if(u<.60f){int a=zones-1-(((int)Math.floor(((u-.30f)/.30f)*zones))%zones);v=idx==a?shape:0;}else if(u<.86f){int k=((int)Math.floor(((u-.60f)/.26f)*zones))%zones;v=(idx==k||idx==zones-1-k)?shape:0;}else v=.18f*shape;color=ch==0?WHITE:rgb(0,140,255);}
        else if(mode==67){float L=6,u=mod(t,L)/L;int cyc=(int)Math.floor(t/L),zones=10;float seg=NN/zones;int idx=clampi((int)Math.floor(i/seg),0,zones-1),rainbowSide=cyc%2;float dd=Math.abs(i-C);if(u<.22f){float q=u/.22f;v=dd<C*q?1:0;}else if(u<.42f){float q=(u-.22f)/.20f;v=dd<C*(1-q)?1:0;}else if(u<.60f)v=(idx%2==0)?1:.05f;else if(u<.78f)v=(idx%2==1)?1:.05f;else{float q=(u-.78f)/.22f,pp=q*(NN-1);v=gauss(i-pp,W*.42f);}color=ch==rainbowSide?hsv(t*1.15f*85+i/(NN-1)*360+cyc*37,1,1):fiveColor(cyc);}
        else if(mode==68){float L=6.4f,u=mod(t,L)/L;int flip=((int)Math.floor(t/L))%2,dir1=flip!=0?1:-1,dir2=-dir1;float p1=C,p2=C,v1=0,v2=0;if(u<.42f){float q=u/.42f;p1=dir1<0?(NN-1)*(1-q):(NN-1)*q;p2=dir2<0?(NN-1)*(1-q):(NN-1)*q;v1=gauss(i-p1,W*.48f);v2=gauss(i-p2,W*.48f);}else if(u<.56f){int bs=(int)Math.floor(((u-.42f)/.14f)*6);boolean fl=bs%2==0;v=fl?gauss(i-C,W*.95f):0;color=WHITE;(ch==0?p.a:p.b)[i]=scale(color,v);continue;}else{float q=(u-.56f)/.44f;p1=C+(dir1<0?-1:1)*q*C;p2=C+(dir2<0?-1:1)*q*C;v1=gauss(i-p1,W*.5f);v2=gauss(i-p2,W*.5f);}float own=ch==0?v1:v2,other=ch==0?v2:v1;v=clamp(Math.max(own,other*.35f));color=ch==0?rgb(255,30,120):rgb(0,140,255);}
        else if(mode==69){float L=7,u=mod(t,L)/L;float[] starts={NN*.12f,NN*.50f,NN*.88f},targets={NN*.36f,NN*.50f,NN*.64f},dest={NN*.10f,NN*.50f,NN*.90f};int best=0;for(int k=0;k<3;k++){float pp;if(u<.34f){float q=u/.34f;pp=starts[k]*(1-q)+C*q;}else if(u<.48f)pp=C;else if(u<.78f){float q=(u-.48f)/.30f;pp=C*(1-q)+dest[k]*q;}else{float q=(u-.78f)/.22f;pp=dest[k];if(q>.65f)pp=targets[k];}float qv=gauss(i-pp,W*(k==1?.55f:.45f));if(qv>v){v=qv;best=k;}}float fade=u>.78f?1-((u-.78f)/.22f)*.55f:1;v=clamp(v*fade);color=best==0?WHITE:best==1?rgb(0,150,255):rgb(255,40,130);}
        else {float L=7.2f,u=mod(t,L)/L;int cyc=(int)Math.floor(t/L),zones=12;float seg=NN/zones;int idx=clampi((int)Math.floor(i/seg),0,zones-1),reverse=cyc%2;if(u<.32f){int k=(int)Math.floor((u/.32f)*(zones*.5f+1));v=(idx<k||idx>=zones-k)?1:0;}else if(u<.54f){float q=(u-.32f)/.22f,dist=Math.abs(idx+.5f-zones*.5f)/(zones*.5f);v=dist<1-q?1:0;}else if(u<.80f){int bi=((int)Math.floor(((u-.54f)/.26f)*3))%3,third=clampi(idx*3/zones,0,2);v=third==bi?1:.08f;}else{float q=(u-.80f)/.20f;int k=(int)Math.floor(q*(zones+1));v=reverse!=0?(idx>=zones-k?1:0):(idx<k?1:0);}int rs=(cyc+1)%2;color=ch==rs?hsv(t*1.15f*85+i/(NN-1)*360+cyc*53,1,1):fiveColor(cyc+2);}
        (ch==0?p.a:p.b)[i]=scale(color,v);
    }}

    private static float smoothstep(float a,float bb,float x){if(Math.abs(bb-a)<1e-6)return x>=bb?1:0;float q=clamp((x-a)/(bb-a));return q*q*(3-2*q);}
    private static float softBar(float g,float p,float w){return w<=1e-6?0:clamp(1-smoothstep(w*.68f,w,Math.abs(g-p)));}
    private static int randColor(int id,int cyc,int ph){float h=hashf(id*101f+cyc*47f+ph*29f)*360,s=.78f+hashf(id*19f+cyc*83f+ph*11f)*.22f;return hsv(h,s,1);}
    private static final int[] P7380={WHITE,rgb(255,0,0),rgb(0,90,255),rgb(180,0,255),rgb(0,220,120),rgb(255,40,150),rgb(0,220,255),rgb(255,220,0),rgb(120,255,0),rgb(255,90,40)};
    private static int rc7380(float c,float s){int idx=((int)Math.floor(hashf(c*7.17f+s)*10))%10;return P7380[Math.floorMod(idx,10)];}
    private static float ping(float u,float L){float q=mod(u,2*L);return q<L?q:2*L-q;}

    private static void render71to92(int mode,long ms,int speed,Pair p){float t=ms*.001f*speedFactor(speed);if(mode<=72){float NN=N,M=NN*2,W=Math.max(9f,M/13f);for(int ch=0;ch<2;ch++)for(int i=0;i<N;i++){float G=(ch==0?0:NN)+i,v;int color;if(mode==71){float L=8.6f,u=mod(t,L)/L;int cyc=(int)Math.floor(t/L);float q=u<.5f?u*2:2-u*2;int dir=u<.5f?1:-1;float pp=q*(M-1),pulse=.5f+.5f*(float)Math.sin(q*PI*6);if(dir<0)pulse=1-pulse;float w=W*(.7f+1.65f*pulse);v=softBar(G,pp,w);int cp=(int)Math.floor(q*3)+(dir<0?3:0);color=randColor(15,cyc,cp);}else{float L=11,u=mod(t,L)/L;int cyc=(int)Math.floor(t/L);if(u<.20f){float pp=u/.20f*(M-1);v=softBar(G,pp,W);color=randColor(19,cyc,0);}else if(u<.36f){float q=(u-.20f)/.16f,pp=M-1;v=softBar(G,pp,W*(1+3*q));color=randColor(19,cyc,1);}else if(u<.52f){float q=(u-.36f)/.16f,sep=q*W*2.4f,pp=M-1;v=Math.max(softBar(G,pp-sep,W*.85f),softBar(G,pp+sep,W*.85f));color=randColor(19,cyc,2);}else if(u<.60f){int st=(int)Math.floor(((u-.52f)/.08f)*6);v=st%2==0?1:0;color=WHITE;}else{float q=(u-.60f)/.40f,pp=(1-q)*(M-1),w=W*(1.3f+.9f*(float)Math.sin(q*PI));v=softBar(G,pp,w);color=randColor(19,cyc,3);}}(ch==0?p.a:p.b)[i]=scale(color,v);}return;}
        int id=mode-73;float NN=N;for(int ch=0;ch<2;ch++)for(int i=0;i<N;i++){float G=(ch==0?i:NN+i);Sample s=sample7380(id,t,G,NN);(ch==0?p.a:p.b)[i]=scale(s.c,s.v);}}

    private static Sample sample7380(int id,float t,float g,float NN){float L=NN*2,W=Math.max(4,NN/10),u=mod(t,6)/6,v=0,pp=0;int cyc=(int)Math.floor(t/6),col=rc7380(cyc,id*3.1f),col2=rc7380(cyc+1,id*5.7f),c=col;switch(id){
        case 0:pp=u*L;if(u<.28f)v=block(Math.abs(g-pp),W*.55f);else if(u<.52f)v=block(Math.abs(g-pp),W*(.55f+(u-.28f)*4));else if(u<.78f)for(int k=-1;k<=1;k++)v=Math.max(v,gauss(g-(pp+k*W*1.8f),W*.35f));else{pp=L-(u-.78f)/.22f*L;v=gauss(g-pp,W*.28f);}break;
        case 1:pp=u*L;v=gauss(Math.abs(Math.abs(g-pp)-W*(.3f+2*(float)Math.sin(u*PI))),W*.22f);if(u>.65f&&u<.82f)v=Math.max(v,gauss(g-L*.82f,W*1.2f));if(u>.82f)v=gauss(g-L*.82f,W*(1.2f-(u-.82f)*5));c=blend(col,col2,u);break;
        case 2:pp=u*L;if(u<.42f)v=gauss(g-pp,W*.55f);else if(u<.70f)v=Math.max(gauss(g-pp,W*.25f),gauss(g-(pp-W*1.5f),W*.25f));else{pp=L-(u-.70f)/.30f*L;v=gauss(g-pp,W*.65f);}c=u<.42f?col:col2;break;
        case 3:if(u<.35f)pp=u/.35f*L*.45f;else if(u<.55f)pp=L*(.45f+(float)Math.floor((u-.35f)*10)*.08f);else if(u<.70f)pp=L*.78f;else pp=L*.78f+(u-.70f)/.30f*L*.22f;v=gauss(g-pp,W*.38f);break;
        case 4:pp=u<.62f?u/.62f*L:L-(u-.62f)/.38f*L;v=(.5f+.5f*(float)Math.sin((g-pp)*.22f))*gauss(g-pp,W*2.4f);c=u<.62f?col:col2;break;
        case 5:{int cnt=u<.33f?5:u<.66f?8:3;float seg=L/cnt,x=mod(g-mod(t*18,L)+L,L);int idx=(int)Math.floor(x/seg);float local=x-idx*seg;v=local>seg*.15f&&local<seg*.85f?1:.08f;c=rc7380(cyc+idx,id);break;}
        case 6:{float p1=u*L,p2=L-u*L;if(u<.42f)v=Math.max(gauss(g-p1,W*.4f),gauss(g-p2,W*.4f));else if(u<.58f)v=gauss(g-L/2,W*(.4f+(u-.42f)*5));else{float q=(u-.58f)/.42f*L*.5f;v=Math.max(gauss(g-(L/2-q),W*.35f),gauss(g-(L/2+q),W*.35f));}break;}
        case 7:pp=u*L;v=gauss(g-pp,W*(.25f+1.6f*(.5f-.5f*(float)Math.cos(u*PI*4))))*clamp(.55f+.45f*(float)Math.cos((g-pp)*.35f));break;
        case 8:pp=u*L;c=rc7380(cyc+(int)Math.floor(pp/(L/4)),id);v=Math.max(gauss(g-pp,W*.38f),gauss(g-(pp-W*1.4f),W*.25f)*.65f);break;
        case 9:if(u<.35f)for(int k=0;k<5;k++)v=Math.max(v,gauss(g-(u/.35f*L-k*W*1.2f),W*.2f));else if(u<.65f)for(int k=0;k<5;k++)v=Math.max(v,gauss(g-(L-(u-.35f)/.30f*L-k*W*.9f),W*.2f));else for(int k=0;k<6;k++)v=Math.max(v,gauss(g-((u-.65f)/.35f*L-k*W*.6f),W*.18f));break;
        case 10:pp=u*L;v=gauss(g-pp,W*.7f);if(u>.45f&&u<.72f){v=0;for(int k=-2;k<=2;k++)v=Math.max(v,gauss(g-(pp+k*W*.9f),W*.22f));}if(u>.72f)v=gauss(g-pp,W*(.2f+(u-.72f)*2.2f));break;
        case 11:pp=ping(t*22,L);int st=((int)Math.floor(t/1.4))%4;float[] ws={.35f,.75f,.22f,1.1f};v=gauss(g-pp,ws[st]*W);c=rc7380(cyc+st,id);break;
        case 12:for(int k=0;k<4;k++){float sp=W*(1.1f+.8f*(float)Math.sin(u*PI*2+k)),x=mod(u*L+k*sp,L);v=Math.max(v,gauss(g-x,W*.28f));}if(u>.72f)v=Math.max(v,gauss(g-L*.78f,W*1.5f));break;
        case 13:if(u<.38f){float q=u/.38f;pp=q*q*L*.52f;v=gauss(g-pp,W*.42f);}else if(u<.58f){float q=(u-.38f)/.20f;pp=L*(.52f+q*.10f);v=gauss(g-pp,W*(.42f+.28f*(float)Math.sin(q*PI)));}else if(u<.82f){float q=(u-.58f)/.24f,center=L*(.62f+q*.25f),sep=W*(.35f+q*1.7f);v=Math.max(gauss(g-(center-sep),W*.34f),gauss(g-(center+sep),W*.34f));}else{float q=(u-.82f)/.18f,center=L*(.87f+q*.11f),sep=W*2.05f*(1-q);v=Math.max(Math.max(gauss(g-(center-sep),W*.34f),gauss(g-(center+sep),W*.34f)),gauss(g-center,W*.42f)*q);}c=rc7380(cyc,id+13);break;
        case 14:{float[] j={.05f,.24f,.47f,.36f,.72f,.58f,.92f};int n=Math.min(6,(int)Math.floor(u*7));float f=u*7-n;int n2=Math.min(6,n+1);pp=(j[n]*(1-f)+j[n2]*f)*L;v=gauss(g-pp,W*.42f);break;}
        case 15:pp=u<.5f?u/.5f*L:L-(u-.5f)/.5f*L;v=gauss(g-pp,u<.5f?W*.5f:W*(.25f+.65f*(float)Math.sin((u-.5f)*PI)));c=u<.5f?col:col2;break;
        case 16:{float seg=L/8;int idx=(int)Math.floor(g/seg),step=(int)Math.floor(u*10);v=idx<=step%9?1:.05f;if(u>.55f){pp=(u-.55f)/.45f*L;v=Math.max(v*.25f,gauss(g-pp,W*.2f));c=col2;}break;}
        case 17:{float[] sp={10,15,21};for(int k=0;k<3;k++){float x=mod(t*sp[k]+k*L/3,L);v=Math.max(v,gauss(g-x,W*(.28f+.08f*k)));}if(u>.70f)v=Math.max(v,gauss(g-L*.68f,W*1.3f));c=rc7380(cyc+(int)Math.floor(u*4),id);break;}
        case 18:pp=u*L;v=gauss(Math.abs(Math.abs(g-pp)-W*(.3f+1.7f*Math.abs((float)Math.sin(u*PI*3)))),W*.18f);if(u>.72f){float local=mod(g-pp+L,L);if(((int)Math.floor(local/(W*.7f))%2)==0)v=Math.max(v,gauss(g-pp,W*1.7f));}break;
        default:{float uu=mod(t,7.2f)/7.2f;int s=(int)Math.floor(uu*6);float lo=mod(uu*6,1);c=rc7380(cyc+s,id);if(s==0){pp=lo*L;v=gauss(g-pp,W*.42f);}else if(s==1){pp=lo*L;v=Math.max(Math.max(gauss(g-pp,W*.3f),gauss(g-(pp-W*1.4f),W*.3f)),gauss(g-(pp+W*1.4f),W*.3f));}else if(s==2){pp=lo*L;v=gauss(g-pp,W*(.25f+1.1f*(float)Math.sin(lo*PI)));}else if(s==3){pp=lo*L;float local=g-pp+L;v=((int)Math.floor(local/(W*.7f))%3)==0?gauss(g-pp,W*2.2f):0;}else if(s==4){pp=L-lo*L;v=gauss(g-pp,W*.5f);}else v=0;break;}
    }return new Sample(clamp(v),c);}

    private static final int[] P93100={WHITE,rgb(255,0,0),rgb(0,90,255),rgb(190,0,255),rgb(0,220,130),rgb(255,30,150),rgb(0,220,255),rgb(255,220,0),rgb(120,255,0),rgb(255,80,40)};
    private static int rc93100(float seed){int idx=((int)Math.floor(hashf(seed)*10))%10;return P93100[Math.floorMod(idx,10)];}
    private static void render93to100(int mode,long ms,int speed,Pair p){float t=ms*.001f*speedFactor(speed),NN=N;int id=mode-93;for(int ch=0;ch<2;ch++)for(int i=0;i<N;i++){float G=ch==0?i:NN+i;Sample s=sample93100(id,t,G,NN); // approximate HTML trail with previous samples
        float best=s.v;int col=s.c;for(int k=1;k<=3;k++){Sample old=sample93100(id,Math.max(0,t-k*.016667f),G,NN);float vv=old.v*(float)Math.pow(.58,k);if(vv>best){best=vv;col=old.c;}}(ch==0?p.a:p.b)[i]=scale(col,best);}}
    private static Sample sample93100(int id,float t,float g,float NN){float L=NN*2,W=Math.max(4,NN/10),u=mod(t,6)/6,v=0;int cyc=(int)Math.floor(t/6),c=rc93100(cyc+id*7f);switch(id){
        case 0:if(u<.22f){float pp=u/.22f*L*.38f;v=gauss(g-pp,W*.3f);c=rc93100(cyc);}else if(u<.42f){float q=(u-.22f)/.20f,pp=L*(.38f+q*.16f);v=gauss(g-pp,W*(.3f+q*.9f));c=rc93100(cyc+1);}else if(u<.68f){float q=(u-.42f)/.26f,pp=L*(.54f+q*.28f);for(int k=-2;k<=1;k++)v=Math.max(v,gauss(g-(pp+k*W*.9f),W*.24f));c=rc93100(cyc+2);}else if(u<.86f){float q=(u-.68f)/.18f,pp=L*(.82f+q*.12f);v=Math.max(gauss(g-pp,W*.3f),gauss(g-(pp-W),W*.2f));c=rc93100(cyc+3);}else{float q=(u-.86f)/.14f,pp=L*(.94f+q*.05f);v=gauss(g-pp,W*(.8f-.45f*q));c=rc93100(cyc+4);}break;
        case 1:{float[] pts={.08f,.22f,.39f,.57f,.74f,.91f};if(u<.30f){for(float pt:pts)v=Math.max(v,gauss(g-L*pt,W*.2f));c=rc93100(cyc);}else if(u<.56f){float q=(u-.30f)/.26f,center=L*(.48f+.12f*(float)Math.sin(t));for(float pt:pts){float pp=L*pt*(1-q)+center*q;v=Math.max(v,gauss(g-pp,W*.25f));}c=rc93100(cyc+1);}else if(u<.78f){float q=(u-.56f)/.22f,center=L*.55f;for(float pt:pts){float pp=center+(pt-.5f)*L*q*1.3f;v=Math.max(v,gauss(g-pp,W*.22f));}c=rc93100(cyc+2);}else{float q=(u-.78f)/.22f,pp=q*L;v=gauss(g-pp,W*.45f);c=rc93100(cyc+3);}break;}
        case 2:if(u<.32f){float pp=u/.32f*L*.52f;v=gauss(g-pp,W*.85f)*(.55f+.45f*(float)Math.sin((g-pp)*.25f));c=rc93100(cyc);}else if(u<.58f){float q=(u-.32f)/.26f,center=L*.56f,sep=W*(.4f+q*2.3f);v=Math.max(gauss(g-(center-sep),W*.45f),gauss(g-(center+sep),W*.45f));c=rc93100(cyc+1);}else if(u<.80f){float q=(u-.58f)/.22f,pp=L*(.56f-q*.28f);v=gauss(g-pp,W*.5f);c=rc93100(cyc+2);}else{float q=(u-.80f)/.20f,pp=L*(.28f+q*.68f);v=gauss(g-pp,W*.72f);c=rc93100(cyc+3);}break;
        case 3:{float seg=L/10;int idx=(int)Math.floor(g/seg);if(u<.30f){int st=(int)Math.floor((u/.30f)*11);v=idx<=st?1:.03f;c=rc93100(cyc);}else if(u<.55f){float q=(u-.30f)/.25f;int parity=((int)Math.floor(q*8))%2;v=(idx%2)==parity?1:.08f;c=rc93100(cyc+1);}else if(u<.78f){float pp=(u-.55f)/.23f*L;v=Math.max(gauss(g-pp,W*.25f),Math.max(gauss(g-(pp-W),W*.2f),gauss(g-(pp+W),W*.2f)));c=rc93100(cyc+2);}else{int blink=((int)Math.floor((u-.78f)*30))%2;v=blink!=0?1:0;c=rc93100(cyc+3);}break;}
        case 4:if(u<.34f){float p1=u/.34f*L*.45f,p2=L*.18f+u/.34f*L*.30f;v=Math.max(gauss(g-p1,W*.32f),gauss(g-p2,W*.32f));c=rc93100(cyc);}else if(u<.62f){float q=(u-.34f)/.28f,center=L*(.5f+q*.25f),sep=W*(.4f+q*2);for(int k=-1;k<=1;k++)v=Math.max(v,gauss(g-(center+k*sep),W*.25f));c=rc93100(cyc+1);}else if(u<.82f){float q=(u-.62f)/.20f,pp=L*(.75f+q*.18f);v=Math.max(gauss(g-pp,W*.35f),gauss(g-(pp-W*.9f),W*.28f));c=rc93100(cyc+2);}else{float q=(u-.82f)/.18f,pp=L*(.93f+q*.05f);v=gauss(g-pp,W*(.9f-.5f*q));c=rc93100(cyc+3);}break;
        case 5:if(u<.28f){float pp=u/.28f*L*.42f;for(int k=0;k<3;k++)v=Math.max(v,gauss(g-(pp-k*W*.8f),W*.28f));c=rc93100(cyc);}else if(u<.44f){float pp=L*.42f;v=gauss(g-pp,W*.6f);c=rc93100(cyc+1);}else if(u<.62f){float q=(u-.44f)/.18f,pp=L*(.42f-q*.14f);v=gauss(g-pp,W*.35f);c=rc93100(cyc+2);}else if(u<.84f){float q=(u-.62f)/.22f,pp=L*(.28f+q*.57f);v=gauss(g-pp,W*.28f);c=rc93100(cyc+3);}else{float q=(u-.84f)/.16f,pp=L*(.85f+q*.12f);v=Math.max(gauss(g-pp,W*.25f),gauss(g-(pp-W*.7f),W*.18f));c=rc93100(cyc+4);}break;
        case 6:if(u<.28f){float pp=u/.28f*L*.45f,rad=W*(.4f+u/.28f*1.8f);v=gauss(Math.abs(Math.abs(g-pp)-rad),W*.2f);c=rc93100(cyc);}else if(u<.56f){float q=(u-.28f)/.28f,pp=L*(.45f+q*.25f),seg=W*.7f;int idx=(int)Math.floor((g-pp+L)/seg);v=(idx%3)==0?gauss(g-pp,W*2.5f):0;c=rc93100(cyc+idx);}else if(u<.82f){float q=(u-.56f)/.26f,pp=L*(.70f+q*.23f);for(int k=0;k<5;k++)v=Math.max(v,gauss(g-(pp-k*W*.7f),W*.18f));c=rc93100(cyc+2);}else{float q=(u-.82f)/.18f,pp=L*(.93f+q*.05f);v=gauss(g-pp,W*.4f);c=rc93100(cyc+3);}break;
        default:{int stage=(int)Math.floor(u*6);float q=mod(u*6,1);if(stage==0){float pp=q*L*.4f;v=gauss(g-pp,W*.3f);c=rc93100(cyc);}else if(stage==1){float pp=L*.4f;v=q<.6f?gauss(g-pp,W*.45f):0;c=rc93100(cyc+1);}else if(stage==2){float center=L*(.4f+q*.2f),sep=W*(.3f+q*1.8f);v=Math.max(gauss(g-(center-sep),W*.25f),gauss(g-(center+sep),W*.25f));c=rc93100(cyc+2);}else if(stage==3){float pp=L*(.6f-q*.18f);v=gauss(g-pp,W*.3f);c=rc93100(cyc+3);}else if(stage==4){float pp=L*(.42f+q*.5f);v=gauss(g-pp,W*(.5f-.2f*q));c=rc93100(cyc+4);}else{int blink=((int)Math.floor(q*8))%2;v=blink!=0?1:0;c=rc93100(cyc+5);}break;}
    }return new Sample(clamp(v),c);}

    private static final int[] P101120={WHITE,rgb(255,0,0),rgb(0,90,255),rgb(180,0,255),rgb(0,220,120),rgb(255,40,150),rgb(0,220,255),rgb(120,255,0)};
    private static int rc101120(int n,float s){int i=(int)Math.floor(hashf(n*7.17f+s)*8);return P101120[clampi(i,0,7)];}
    private static void render101to120(int mode,long ms,int speed,Pair p){float t=ms*.001f*speedFactor(speed),NN=N;int id=mode-101;for(int ch=0;ch<2;ch++)for(int i=0;i<N;i++){float G=ch==0?i:NN+i;Sample s=sample101120(id,t,G,NN);(ch==0?p.a:p.b)[i]=scale(s.c,s.v);}}
    private static Sample sample101120(int id,float t,float g,float NN){float L=NN*2,W=Math.max(4,NN/10);int cyc=(int)Math.floor(t/5.6f);int col=rc101120(cyc,id*2.71f),col2=rc101120(cyc+1,id*4.13f),col3=rc101120(cyc+2,id*5.91f),c=col;float u=mod(t,5.6f)/5.6f,v=0,pp=0;switch(id){
        case 0:{float ph;if(u<.22f){ph=u/.22f;for(int k=0;k<3;k++){float x=L*(.08f+k*.11f),on=clamp(ph*3-k);v=Math.max(v,block(Math.abs(g-x),W*.48f)*on);}c=col;}else if(u<.46f){ph=(u-.22f)/.24f;float p1=L*.08f+(L*.30f-L*.08f)*ph,p2=L*.19f+(L*.30f-L*.19f)*ph,p3=L*.30f;v=Math.max(block(Math.abs(g-p1),W*.48f),Math.max(block(Math.abs(g-p2),W*.48f),block(Math.abs(g-p3),W*.48f)));c=col2;}else if(u<.68f){ph=(u-.46f)/.22f;pp=L*.30f+ph*L*.25f;v=block(Math.abs(g-pp),W*(.75f+ph*.9f));c=col2;}else{ph=(u-.68f)/.32f;pp=L*.55f+ph*L*.45f;for(int k=-1;k<=1;k++){float x=pp+k*W*(1.2f+ph*.8f);v=Math.max(v,gauss(g-x,W*.26f));}c=col3;}break;}
        case 1:{float q=u*L;if(u<.25f)v=gauss(g-q,W*.4f);else if(u<.72f){float sp=(u-.25f)/.47f*W*2.4f;v=Math.max(gauss(g-(q-sp),W*.24f),gauss(g-(q+sp),W*.24f));}else{float m=L-(u-.72f)/.28f*L*.22f;v=gauss(g-m,W*(.7f-(u-.72f)*1.4f));}c=u<.5f?col:col2;break;}
        case 2:{float seg=L/9;int st=(int)Math.floor(u*11),idx=(int)Math.floor(g/seg);if(u<.42f)v=idx<=st?1:.04f;else if(u<.68f){pp=(u-.42f)/.26f*L;v=Math.max(.12f,gauss(g-pp,W*.7f));}else{float cut=(u-.68f)/.32f*L;v=g>cut?.8f:.03f;}c=u<.42f?col:u<.68f?col2:col3;break;}
        case 3:pp=u*L;if(u<.35f)v=Math.max(gauss(g-(pp-W*.7f),W*.18f),Math.max(gauss(g-pp,W*.45f),gauss(g-(pp+W*.7f),W*.18f)));else if(u<.65f)v=gauss(g-pp,W*(.8f-(u-.35f)*1.5f));else{float d=(u-.65f)/.35f*W*2.2f;v=Math.max(gauss(g-(pp-d),W*.23f),gauss(g-(pp+d),W*.23f));}break;
        case 4:{float center=u*L,rad;if(u<.38f)rad=(u/.38f)*W*2.6f;else if(u<.72f)rad=W*2.6f;else rad=W*2.6f*(1-(u-.72f)/.28f);v=gauss(Math.abs(g-center)-rad,W*.18f);if(u>.55f&&u<.72f)v=Math.max(v,gauss(g-center,W*.55f));c=u<.5f?col:col2;break;}
        case 5:{float base=ping(t*24,L);for(int k=0;k<3;k++){float off=(k-1)*W*(1.2f+.7f*(float)Math.sin(u*PI*2+k));v=Math.max(v,gauss(g-(base+off),W*.24f));}if(u>.7f)v=Math.max(v,gauss(g-ping(t*34,L),W*.18f));c=rc101120(cyc+(int)Math.floor(u*3),id);break;}
        case 6:pp=u*L;if(u<.36f)v=block(Math.abs(g-pp),W*1.15f);else if(u<.63f){float d=(u-.36f)/.27f*W*2.2f;v=Math.max(block(Math.abs(g-(pp-d)),W*.55f),block(Math.abs(g-(pp+d)),W*.55f));}else if(u<.78f){pp=L-(u-.63f)/.15f*L*.3f;v=block(Math.abs(g-pp),W*.7f);}else{pp=L*.7f+(u-.78f)/.22f*L*.3f;v=gauss(g-pp,W*.3f);}c=u<.5f?col:col2;break;
        case 7:pp=u*L;if(u<.35f)v=(.5f+.5f*(float)Math.sin((g-pp)*.18f))*gauss(g-pp,W*2.8f);else if(u<.68f){int cell=(int)Math.floor((g-pp+L)/(W*.75f));v=(cell%2==0)?gauss(g-pp,W*2.5f):0;}else v=(.5f+.5f*(float)Math.sin((g-pp)*.28f))*gauss(g-pp,W*1.7f);c=u<.35f?col:u<.68f?col2:col3;break;
        case 8:{float p1=u*L,p2=Math.max(0,p1-W*2);if(u<.48f){v=Math.max(gauss(g-p1,W*.28f),gauss(g-p2,W*.28f));c=Math.abs(g-p1)<Math.abs(g-p2)?col:col2;}else if(u<.72f){v=Math.max(gauss(g-p1,W*.3f),gauss(g-p2,W*.3f));c=Math.abs(g-p1)<Math.abs(g-p2)?col2:col;}else{v=gauss(g-p1,W*.5f);c=col3;}break;}
        case 9:{float center=L*.5f,rad;if(u<.4f)rad=(u/.4f)*L*.42f;else if(u<.7f)rad=L*.42f;else rad=L*.42f-(u-.7f)/.3f*L*.25f;v=Math.max(gauss(g-(center-rad),W*.23f),gauss(g-(center+rad),W*.23f));if(u>.7f)v=Math.max(v,gauss(g-(L*.5f+(u-.7f)/.3f*L*.5f),W*.35f));c=u<.55f?col:col2;break;}
        case 10:{float[] stp={.05f,.13f,.23f,.35f,.49f,.62f,.74f,.88f,.98f};if(u<.6f){int n=Math.min(8,(int)Math.floor(u/.6f*9));pp=stp[n]*L;}else if(u<.72f){pp=L*.75f;v=Math.max(v,gauss(g-pp,W*1.3f));}else pp=L*.75f+(u-.72f)/.28f*L*.25f;v=Math.max(v,gauss(g-pp,W*.32f));c=u<.6f?col:u<.72f?col2:col3;break;}
        case 11:{float seg=L/10;int head=(int)Math.floor(u*13);if(u<.68f){int idx=(int)Math.floor(g/seg);float f=head-idx;v=(f>=0&&f<3)?1-f*.28f:.03f;}else{float p2=L-(u-.68f)/.32f*L;v=gauss(g-p2,W*.33f);}c=u<.68f?col:col2;break;}
        case 12:{float d=W*(.7f+1.4f*Math.abs((float)Math.sin(u*PI*2)));pp=u*L;v=Math.max(gauss(g-(pp-d),W*.24f),gauss(g-(pp+d),W*.24f));if(u>.55f&&u<.72f)v=Math.max(v,gauss(g-pp,W*.45f));c=u<.5f?col:col2;break;}
        case 13:{float left=L*.15f,right=L*.85f;if(u<.35f){float e=u/.35f;v=Math.max(block(Math.abs(g-(left+e*L*.2f)),W*.55f),block(Math.abs(g-(right-e*L*.2f)),W*.55f));}else if(u<.72f){pp=(u-.35f)/.37f*L;v=Math.max(.08f,gauss(g-pp,W*.34f));}else{float cut=(u-.72f)/.28f*L;v=g>cut?gauss(g-L*.8f,W*2.4f):.02f;}c=u<.5f?col:col2;break;}
        case 14:{int seed=(int)Math.floor(g/(W*.75f));float appear=hashf(seed*3.1f+cyc);if(u<.33f)v=appear<u/.33f?.35f+.65f*hashf(seed+8):0;else if(u<.66f){float center=L*.5f,x=center+(g-center)*(1-(u-.33f)/.33f);v=gauss(g-x,W*.22f);}else{pp=(u-.66f)/.34f*L;v=Math.max(gauss(g-pp,W*.28f),gauss(g-(pp-W*1.1f),W*.18f));}c=rc101120(cyc+seed,id);break;}
        case 15:{float[] j={.04f,.18f,.31f,.55f,.46f,.70f,.84f,.96f};if(u<.58f){float pos=u/.58f*7;int n=(int)Math.floor(pos);float f=pos-n;n=Math.min(n,7);pp=(j[n]*(1-f)+j[Math.min(n+1,7)]*f)*L;}else pp=L*.58f+(u-.58f)/.42f*L*.42f;v=gauss(g-pp,u<.58f?W*.28f:W*.4f);c=u<.58f?col:col2;break;}
        case 16:{float seg=L/6,shift=u*L;int[] cc={col,col2,col3};for(int k=0;k<3;k++){float x=mod(shift+k*seg*2,L),vv=block(Math.abs(g-x),W*.65f);if(vv>v){v=vv;c=cc[k];}}if(u>.72f){pp=L-(u-.72f)/.28f*L*.3f;float vv=gauss(g-pp,W*.32f);if(vv>v){v=vv;c=col2;}}break;}
        case 17:{float breath=.35f+.65f*(.5f-.5f*(float)Math.cos(u*PI*6));for(int k=0;k<4;k++){float x=mod(u*L-k*W*1.45f+L,L);v=Math.max(v,gauss(g-x,W*(.22f+.35f*breath)));}if(u>.62f&&u<.8f)v=Math.max(v,gauss(g-L*.72f,W*1.3f));if(u>.8f){float d=(u-.8f)/.2f*W*2;v=Math.max(gauss(g-(L*.72f-d),W*.28f),gauss(g-(L*.72f+d),W*.28f));}c=u<.5f?col:col2;break;}
        case 18:{float p1=u*L,p2=L-u*L;if(u<.48f)v=Math.max(gauss(g-p1,W*.3f),gauss(g-p2,W*.3f));else if(u<.7f)v=Math.max(gauss(g-(p1+W*1.3f),W*.23f),gauss(g-(p2-W*.4f),W*.42f));else{pp=L*.55f+(u-.7f)/.3f*L*.45f;v=gauss(g-pp,W*.36f);}c=u<.48f?col:u<.7f?col2:col3;break;}
        default:{float uu=mod(t,7.2f)/7.2f,lo=mod(uu*6,1);int st=(int)Math.floor(uu*6);int[] cc={col,col2,col3,col,col2,col3};c=cc[clampi(st,0,5)];if(st==0){pp=lo*L;v=gauss(g-pp,W*.36f);}else if(st==1){pp=lo*L;v=Math.max(gauss(g-(pp-W),W*.24f),gauss(g-(pp+W),W*.24f));}else if(st==2){float seg=L/8;int idx=(int)Math.floor(g/seg);v=idx<=Math.floor(lo*9)?1:.04f;}else if(st==3){float center=L*.5f,rad=lo*L*.45f;v=Math.max(gauss(g-(center-rad),W*.22f),gauss(g-(center+rad),W*.22f));}else if(st==4){pp=L-lo*L;v=gauss(g-pp,W*.4f);}else v=0;break;}
    }return new Sample(clamp(v),c);}
}
