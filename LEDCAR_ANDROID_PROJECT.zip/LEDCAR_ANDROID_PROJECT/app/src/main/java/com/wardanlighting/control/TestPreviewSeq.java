package com.wardanlighting.control;
import java.util.*;
public class TestPreviewSeq {
 static long hash(FirmwarePreview120.Frame4 f){long h=1469598103934665603L;for(int k=0;k<4;k++)for(int c:f.ch[k]){h^=c;h*=1099511628211L;}return h;}
 static String sig(int m){StringBuilder s=new StringBuilder();for(int t=0;t<40;t++){s.append(Long.toHexString(hash(FirmwarePreview120.render(m,t*173L,70)))).append(',');}return s.toString();}
 public static void main(String[]a){Map<String,List<Integer>> map=new HashMap<>();for(int m=1;m<=120;m++)map.computeIfAbsent(sig(m),x->new ArrayList<>()).add(m);for(var e:map.entrySet())if(e.getValue().size()>1)System.out.println(e.getValue());}
}
