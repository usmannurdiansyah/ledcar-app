
package com.wardanlighting.control;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {

    // BLE firmware
    private static final UUID SERVICE_FFE0 =
            UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    private static final UUID CHAR_FFE1 =
            UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");
    private static final String OTA_URL =
            "https://ledcar-ota.usmannurdiansyah.workers.dev";
    private static final int REQ_BT = 1001;

    // Colors
    private final int BG = Color.rgb(2, 8, 17);
    private final int BG2 = Color.rgb(4, 17, 31);
    private final int PANEL = Color.rgb(6, 26, 44);
    private final int PANEL2 = Color.rgb(9, 39, 61);
    private final int LINE = Color.rgb(17, 79, 111);
    private final int CYAN = Color.rgb(0, 200, 255);
    private final int CYAN2 = Color.rgb(95, 229, 255);
    private final int WHITE = Color.rgb(244, 250, 255);
    private final int MUTED = Color.rgb(132, 164, 184);
    private final int GREEN = Color.rgb(72, 232, 126);
    private final int RED = Color.rgb(255, 78, 94);
    private final int ORANGE = Color.rgb(255, 118, 22);

    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;

    private BluetoothAdapter btAdapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic ffe1;
    private boolean scanning = false;

    // CH1=1 CH2=2 ALL=3 CH3=4 CH4=5
    private int selectedChannel = 0x03;

    private int r = 0;
    private int g = 190;
    private int b = 255;
    private int speed = 70;
    private int brightness = 70;

    private LinearLayout appRoot;
    private FrameLayout contentHost;
    private TextView statusText;
    private TextView channelText;
    private PopupWindow drawer;

    private String modeSection = "210";
    private final List<CollectItem> collect = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("wardan_lighting", MODE_PRIVATE);
        loadPrefs();

        BluetoothManager bm =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        btAdapter = bm == null ? null : bm.getAdapter();

        buildApp();
    }

    // ============================================================
    // APP SHELL
    // ============================================================

    private void buildApp() {
        appRoot = new LinearLayout(this);
        appRoot.setOrientation(LinearLayout.VERTICAL);
        appRoot.setBackgroundColor(BG);

        appRoot.addView(buildHeader());
        appRoot.addView(buildTopChannelBar());

        contentHost = new FrameLayout(this);
        appRoot.addView(contentHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        appRoot.addView(buildBottomNav());

        setContentView(appRoot);
        showRgb();

        appRoot.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            v.setPadding(0, top, 0, 0);
            return insets;
        });
        appRoot.requestApplyInsets();
    }

    private View buildHeader() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(12), dp(8), dp(12), dp(7));
        wrap.setBackgroundColor(BG2);

        LinearLayout row = horizontal();
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView wl = tv("WL", 29, Typeface.BOLD, WHITE);
        row.addView(wl);

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(dp(10), 0, 0, 0);

        TextView n = tv("WARDAN LIGHTING", 16, Typeface.BOLD, CYAN2);
        n.setLetterSpacing(0.07f);
        statusText = tv("Belum terhubung", 10, Typeface.NORMAL, MUTED);
        brand.addView(n);
        brand.addView(statusText, lpMatchWrap(0, 2, 0, 0));

        row.addView(brand, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button ble = smallButton("BLE");
        ble.setOnClickListener(v -> connectBle());
        row.addView(ble);

        Button gear = smallButton("⚙");
        gear.setOnClickListener(v -> showDrawer());
        row.addView(gear, marginLeft(dp(6)));

        wrap.addView(row);

        TextView line = tv("LIGHTING YOUR RIDE", 9, Typeface.BOLD, MUTED);
        line.setLetterSpacing(0.18f);
        line.setGravity(Gravity.CENTER);
        wrap.addView(line, lpMatchWrap(0, 4, 0, 0));

        return wrap;
    }

    private View buildTopChannelBar() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(8), dp(6), dp(8), dp(6));

        LinearLayout info = horizontal();
        info.setGravity(Gravity.CENTER_VERTICAL);
        TextView a = tv("CHANNEL", 10, Typeface.BOLD, MUTED);
        info.addView(a);

        channelText = tv(channelName(selectedChannel), 11, Typeface.BOLD, CYAN2);
        info.addView(channelText, marginLeft(dp(7)));
        outer.addView(info, lpMatchWrap(0, 0, 0, 5));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);

        LinearLayout row = horizontal();
        row.setPadding(dp(1), 0, dp(12), 0);

        row.addView(channelButton("LED1", 0x01));
        row.addView(channelButton("LED2", 0x02), marginLeft(dp(5)));
        row.addView(channelButton("LED3", 0x04), marginLeft(dp(5)));
        row.addView(channelButton("LED4", 0x05), marginLeft(dp(5)));
        row.addView(channelButton("ALL", 0x03), marginLeft(dp(5)));

        Button collectBtn = tabButton("Collect");
        collectBtn.setOnClickListener(v -> showCollect());
        row.addView(collectBtn, marginLeft(dp(5)));

        hsv.addView(row);
        outer.addView(hsv);

        return outer;
    }

    private View buildBottomNav() {
        LinearLayout nav = horizontal();
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(BG2);

        final int baseBottom = dp(9);
        nav.setPadding(dp(6), dp(6), dp(6), baseBottom);

        nav.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottom = insets.getSystemWindowInsetBottom();
            v.setPadding(dp(6), dp(6), dp(6), baseBottom + bottom);
            return insets;
        });
        nav.requestApplyInsets();

        Button rgb = navButton("◉\nRGB");
        Button mode = navButton("❄\nMode");
        Button collectB = navButton("☆\nCollect");
        Button set = navButton("⚙\nSet");

        rgb.setOnClickListener(v -> showRgb());
        mode.setOnClickListener(v -> showMode());
        collectB.setOnClickListener(v -> showCollect());
        set.setOnClickListener(v -> showDrawer());

        nav.addView(rgb, weight());
        nav.addView(mode, weight());
        nav.addView(collectB, weight());
        nav.addView(set, weight());

        return nav;
    }

    // ============================================================
    // RGB SCREEN — layout tetap gaya versi awal
    // ============================================================

    private void showRgb() {
        contentHost.removeAllViews();

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(13), dp(5), dp(13), dp(8));

        TextView h = sectionTitle("RGB");
        page.addView(h);

        HueWheel wheel = new HueWheel(this);
        page.addView(wheel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView rgbText = tv(
                String.format(Locale.US, "RGB %d  %d  %d", r, g, b),
                12, Typeface.BOLD, CYAN2);
        rgbText.setGravity(Gravity.CENTER);
        page.addView(rgbText);

        wheel.setListener((nr, ng, nb) -> {
            r = nr; g = ng; b = nb;
            rgbText.setText(String.format(
                    Locale.US, "RGB %d  %d  %d", r, g, b));
            sendRgb();
            savePrefs();
        });

        LinearLayout colors = horizontal();
        colors.addView(colorButton("R", 255, 0, 0), weight());
        colors.addView(colorButton("G", 0, 255, 0), weight());
        colors.addView(colorButton("B", 0, 0, 255), weight());
        colors.addView(colorButton("W", 255, 255, 255), weight());
        colors.addView(colorButton("O", 255, 60, 0), weight());
        page.addView(colors, lpMatchWrap(0, 4, 0, 3));

        page.addView(slider("Brightness", brightness, value -> {
            brightness = value;
            sendSimple(0x01, value);
            savePrefs();
        }));

        page.addView(slider("Speed", speed, value -> {
            speed = value;
            sendSimple(0x02, value);
            savePrefs();
        }));

        LinearLayout quick = horizontal();

        Button welcome = darkButton("WELCOME");
        welcome.setOnClickListener(v -> {
            modeSection = "WELCOME";
            showMode();
        });

        Button rem = darkButton("REM");
        rem.setOnClickListener(v -> {
            modeSection = "REM";
            showMode();
        });

        Button sen = darkButton("SEN");
        sen.setOnClickListener(v -> {
            modeSection = "SEN";
            showMode();
        });

        quick.addView(welcome, weight());
        quick.addView(rem, weight());
        quick.addView(sen, weight());

        page.addView(quick, lpMatchWrap(0, 4, 0, 4));

        Button ota = outlineButton("☁  UPDATE OTA");
        ota.setOnClickListener(v -> openOta());
        page.addView(ota);

        contentHost.addView(page);
    }

    // ============================================================
    // MODE SCREEN
    // 1 scroll vertical, selected channel from LED1-4/ALL,
    // preview each mode like app bawaan.
    // ============================================================

    private void showMode() {
        contentHost.removeAllViews();

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(10), dp(3), dp(10), dp(6));

        LinearLayout tabs = horizontal();
        tabs.addView(modeTab("210"), weight());
        tabs.addView(modeTab("REM"), weight());
        tabs.addView(modeTab("SEN"), weight());
        tabs.addView(modeTab("WELCOME"), weight());
        page.addView(tabs);

        LinearLayout chan = horizontal();
        chan.setGravity(Gravity.CENTER_VERTICAL);
        TextView c1 = tv("Target:", 11, Typeface.BOLD, MUTED);
        chan.addView(c1);
        TextView c2 = tv(channelName(selectedChannel), 12, Typeface.BOLD, CYAN2);
        chan.addView(c2, marginLeft(dp(6)));
        TextView tip = tv("  •  tap efek = langsung jalan", 10, Typeface.NORMAL, MUTED);
        chan.addView(tip);
        page.addView(chan, lpMatchWrap(0, 6, 0, 5));

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(true);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);

        if ("210".equals(modeSection)) {
            addModeRows(list, 1, 210, 0x03);
        } else if ("REM".equals(modeSection)) {
            addModeRows(list, 1, 10, 0x1A);
        } else if ("SEN".equals(modeSection)) {
            addModeRows(list, 1, 10, 0x19);
        } else {
            addModeRows(list, 0, 50, 0x18);
        }

        page.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        if ("210".equals(modeSection)) {
            Button auto = outlineButton("AUTO 255");
            auto.setOnClickListener(v -> sendMode(255));
            page.addView(auto, lpMatchWrap(0, 5, 0, 4));
        }

        page.addView(slider("Speed", speed, value -> {
            speed = value;
            if ("REM".equals(modeSection)) sendRemTarget(0x02, value);
            else sendSimple(0x02, value);
            savePrefs();
        }));

        page.addView(slider("Brightness", brightness, value -> {
            brightness = value;
            if ("REM".equals(modeSection)) sendRemTarget(0x01, value);
            else sendSimple(0x01, value);
            savePrefs();
        }));

        contentHost.addView(page);
    }

    private Button modeTab(String name) {
        Button b = tabButton(name);
        if (name.equals(modeSection)) {
            b.setBackground(roundRect(CYAN, 12, CYAN, 1));
            b.setTextColor(BG);
        }
        b.setOnClickListener(v -> {
            modeSection = name;
            showMode();
        });
        return b;
    }

    private void addModeRows(LinearLayout list, int start, int end, int command) {
        for (int mode = start; mode <= end; mode++) {
            final int m = mode;

            LinearLayout row = horizontal();
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(7), dp(8), dp(7));
            row.setBackground(roundRect(PANEL, 15, LINE, 1));

            TextView num = tv(String.valueOf(m), 22, Typeface.BOLD, WHITE);
            num.setGravity(Gravity.CENTER);
            row.addView(num, fixed(dp(52), dp(54)));

            EffectPreview preview = new EffectPreview(this, m);
            row.addView(preview, new LinearLayout.LayoutParams(
                    0, dp(54), 1f));

            TextView arrow = tv("›", 30, Typeface.NORMAL, CYAN2);
            arrow.setGravity(Gravity.CENTER);
            row.addView(arrow, fixed(dp(32), dp(54)));

            row.setOnClickListener(v -> {
                if (command == 0x03) sendMode(m);
                else sendSimple(command, m);
            });

            list.addView(row, lpMatchWrap(0, 0, 0, 6));
        }
    }

    // ============================================================
    // COLLECT
    // ============================================================

    private void showCollect() {
        contentHost.removeAllViews();

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(11), dp(5), dp(11), dp(7));

        LinearLayout head = horizontal();
        head.addView(sectionTitle("COLLECT"),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button add = smallButton("+ ADD");
        add.setOnClickListener(v -> addCollectDialog());
        head.addView(add);

        page.addView(head);

        TextView desc = tv(
                "Tambahkan efek. Setiap item menyimpan nomor, speed, dan brightness.",
                10, Typeface.NORMAL, MUTED);
        page.addView(desc, lpMatchWrap(0, 3, 0, 7));

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);

        if (collect.isEmpty()) {
            TextView e = tv("Belum ada efek.", 13, Typeface.BOLD, MUTED);
            e.setGravity(Gravity.CENTER);
            list.addView(e, lpMatchWrap(0, 30, 0, 0));
        } else {
            for (int i = 0; i < collect.size(); i++) {
                final int idx = i;
                CollectItem item = collect.get(i);

                LinearLayout row = horizontal();
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(9), dp(7), dp(7), dp(7));
                row.setBackground(roundRect(PANEL, 14, LINE, 1));

                TextView num = tv(String.valueOf(item.mode), 22, Typeface.BOLD, CYAN2);
                num.setGravity(Gravity.CENTER);
                row.addView(num, fixed(dp(50), dp(52)));

                EffectPreview p = new EffectPreview(this, item.mode);
                row.addView(p, new LinearLayout.LayoutParams(0, dp(52), 1f));

                TextView info = tv(
                        "S " + item.speed + "\nB " + item.brightness,
                        10, Typeface.BOLD, WHITE);
                info.setGravity(Gravity.CENTER);
                row.addView(info, fixed(dp(58), dp(52)));

                Button x = smallButton("×");
                x.setOnClickListener(v -> {
                    collect.remove(idx);
                    saveCollect();
                    showCollect();
                });
                row.addView(x);

                row.setOnClickListener(v -> runCollect(item));

                list.addView(row, lpMatchWrap(0, 0, 0, 6));
            }
        }

        page.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        contentHost.addView(page);
    }

    private void addCollectDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(5), dp(16), dp(5));

        final EditText mode = new EditText(this);
        mode.setInputType(InputType.TYPE_CLASS_NUMBER);
        mode.setHint("Efek 1-210");
        mode.setText("1");
        box.addView(mode);

        TextView sText = new TextView(this);
        sText.setTextColor(Color.BLACK);
        sText.setText("Speed: " + speed);
        box.addView(sText);

        SeekBar s = new SeekBar(this);
        s.setMax(99);
        s.setProgress(speed - 1);
        s.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                sText.setText("Speed: " + (progress + 1));
            }
        });
        box.addView(s);

        TextView bText = new TextView(this);
        bText.setTextColor(Color.BLACK);
        bText.setText("Brightness: " + brightness);
        box.addView(bText);

        SeekBar br = new SeekBar(this);
        br.setMax(99);
        br.setProgress(brightness - 1);
        br.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                bText.setText("Brightness: " + (progress + 1));
            }
        });
        box.addView(br);

        new AlertDialog.Builder(this)
                .setTitle("Tambah efek")
                .setView(box)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Tambah", (d, w) -> {
                    int m;
                    try {
                        m = Integer.parseInt(mode.getText().toString().trim());
                    } catch (Exception e) {
                        m = 1;
                    }
                    if (m < 1) m = 1;
                    if (m > 210) m = 210;

                    collect.add(new CollectItem(
                            m,
                            s.getProgress() + 1,
                            br.getProgress() + 1));
                    saveCollect();
                    showCollect();
                })
                .show();
    }

    private void runCollect(CollectItem item) {
        speed = item.speed;
        brightness = item.brightness;

        sendSimple(0x02, speed);
        main.postDelayed(() -> sendSimple(0x01, brightness), 45);
        main.postDelayed(() -> sendMode(item.mode), 90);

        savePrefs();
        toast("Efek " + item.mode);
    }

    // ============================================================
    // SETTINGS DRAWER
    // ============================================================

    private void showDrawer() {
        if (drawer != null && drawer.isShowing()) {
            drawer.dismiss();
            return;
        }

        ScrollView scroll = new ScrollView(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(16), dp(14), dp(20));
        panel.setBackgroundColor(Color.BLACK);
        scroll.addView(panel);

        LinearLayout head = horizontal();
        Button back = smallButton("←");
        head.addView(back);
        TextView title = tv("Set Focus", 24, Typeface.NORMAL, WHITE);
        head.addView(title, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        panel.addView(head, lpMatchWrap(0, 0, 0, 12));

        panel.addView(settingsRow("Chip settings", "Jumlah LED", v -> ledCountDialog()));

        // K1 K2 K3
        LinearLayout kr = horizontal();
        kr.setGravity(Gravity.CENTER_VERTICAL);
        kr.addView(tv("Button", 17, Typeface.NORMAL, WHITE),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button k1 = blue("K1");
        Button k2 = blue("K2");
        Button k3 = blue("K3");
        k1.setOnClickListener(v -> sendSimple(0x11, 0));
        k2.setOnClickListener(v -> sendSimple(0x11, 1));
        k3.setOnClickListener(v -> sendSimple(0x11, 2));
        kr.addView(k1);
        kr.addView(k2, marginLeft(dp(6)));
        kr.addView(k3, marginLeft(dp(6)));
        panel.addView(kr, drawerRow());

        // Subarea
        LinearLayout sub = horizontal();
        sub.setGravity(Gravity.CENTER_VERTICAL);
        sub.addView(tv("Subarea", 17, Typeface.NORMAL, WHITE),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button l = blue("←");
        Button c = blue("■");
        Button rr = blue("→");

        l.setOnClickListener(v -> sendSubareaDouble(1));
        rr.setOnClickListener(v -> sendSubareaDouble(2));
        c.setOnClickListener(v -> sendSimple(0x14, 0));
        c.setOnLongClickListener(v -> {
            sendSubareaDouble(0);
            return true;
        });

        sub.addView(l);
        sub.addView(c, marginLeft(dp(6)));
        sub.addView(rr, marginLeft(dp(6)));
        panel.addView(sub, drawerRow());

        LinearLayout passRow = horizontal();
        passRow.setGravity(Gravity.CENTER_VERTICAL);
        passRow.addView(tv("Password Modul", 17, Typeface.NORMAL, WHITE),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Switch sw = new Switch(this);
        sw.setChecked(prefs.getBoolean("module_lock", false));
        sw.setOnCheckedChangeListener((buttonView, checked) -> {
            prefs.edit().putBoolean("module_lock", checked).apply();
            sendSimple(0x16, checked ? 1 : 0);
        });
        passRow.addView(sw);
        panel.addView(passRow, drawerRow());

        panel.addView(settingsRow(
                "Update OTA",
                "Buka halaman update Wardan Lighting",
                v -> openOta()));

        TextView noMusic = tv("Menu musik dihapus.", 11, Typeface.NORMAL, MUTED);
        panel.addView(noMusic, lpMatchWrap(0, 14, 0, 0));

        drawer = new PopupWindow(
                scroll,
                (int)(getResources().getDisplayMetrics().widthPixels * 0.84f),
                ViewGroup.LayoutParams.MATCH_PARENT,
                true);
        drawer.setOutsideTouchable(true);
        drawer.setBackgroundDrawable(roundRect(Color.BLACK, 0, LINE, 1));
        drawer.setElevation(dp(12));

        back.setOnClickListener(v -> drawer.dismiss());

        drawer.showAtLocation(appRoot, Gravity.RIGHT, 0, 0);
    }

    private View settingsRow(String title, String sub, View.OnClickListener l) {
        LinearLayout row = horizontal();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(13), dp(4), dp(13));

        LinearLayout tbox = new LinearLayout(this);
        tbox.setOrientation(LinearLayout.VERTICAL);
        tbox.addView(tv(title, 17, Typeface.NORMAL, WHITE));
        tbox.addView(tv(sub, 10, Typeface.NORMAL, MUTED));
        row.addView(tbox, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView a = tv("›", 30, Typeface.NORMAL, MUTED);
        row.addView(a);

        row.setOnClickListener(l);
        return row;
    }

    private void ledCountDialog() {
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setText(String.valueOf(prefs.getInt("led_count", 75)));

        new AlertDialog.Builder(this)
                .setTitle("Jumlah LED")
                .setView(e)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Terapkan", (d, w) -> {
                    int n;
                    try {
                        n = Integer.parseInt(e.getText().toString().trim());
                    } catch (Exception ex) {
                        n = 75;
                    }
                    if (n < 1) n = 1;
                    if (n > 1000) n = 1000;
                    prefs.edit().putInt("led_count", n).apply();
                    sendLedCount(n);
                }).show();
    }

    // ============================================================
    // BLE
    // ============================================================

    private void connectBle() {
        if (btAdapter == null) {
            toast("Bluetooth tidak tersedia");
            return;
        }

        if (!hasPermissions()) {
            requestBtPermissions();
            return;
        }

        if (!btAdapter.isEnabled()) {
            try {
                startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            } catch (Exception ignored) {}
            return;
        }

        scanner = btAdapter.getBluetoothLeScanner();
        if (scanner == null) {
            toast("BLE scanner tidak tersedia");
            return;
        }

        if (scanning) {
            stopScan();
            setStatus("Scan dihentikan", MUTED);
            return;
        }

        scanning = true;
        setStatus("Mencari LEDCAR...", CYAN2);

        try {
            scanner.startScan(scanCallback);
        } catch (SecurityException e) {
            requestBtPermissions();
            return;
        }

        main.postDelayed(() -> {
            if (scanning) {
                stopScan();
                setStatus("Belum ditemukan", RED);
            }
        }, 12000);
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice device = result.getDevice();
            String name = null;

            try {
                if (hasPermissions()) name = device.getName();
            } catch (SecurityException ignored) {}

            boolean nameMatch = name != null &&
                    (name.toUpperCase(Locale.ROOT).contains("LEDCAR") ||
                     name.toUpperCase(Locale.ROOT).contains("LEDLAMP") ||
                     name.toUpperCase(Locale.ROOT).contains("WARDAN"));

            boolean serviceMatch = false;
            if (result.getScanRecord() != null &&
                    result.getScanRecord().getServiceUuids() != null) {
                for (ParcelUuid u : result.getScanRecord().getServiceUuids()) {
                    if (SERVICE_FFE0.equals(u.getUuid())) {
                        serviceMatch = true;
                        break;
                    }
                }
            }

            if (nameMatch || serviceMatch) {
                stopScan();
                setStatus("Menghubungkan...", CYAN2);
                connectGatt(device);
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            scanning = false;
            setStatus("Scan gagal " + errorCode, RED);
        }
    };

    private void connectGatt(BluetoothDevice device) {
        if (!hasPermissions()) {
            requestBtPermissions();
            return;
        }

        try {
            if (gatt != null) {
                gatt.close();
                gatt = null;
            }
            ffe1 = null;
            gatt = device.connectGatt(
                    this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
        } catch (SecurityException e) {
            requestBtPermissions();
        }
    }

    private final BluetoothGattCallback gattCallback =
            new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(
                BluetoothGatt gattObj, int status, int newState) {

            if (newState == BluetoothProfile.STATE_CONNECTED) {
                setStatus("Terhubung • membaca service", GREEN);
                try {
                    gattObj.discoverServices();
                } catch (SecurityException e) {
                    setStatus("Izin Bluetooth diperlukan", RED);
                }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                ffe1 = null;
                setStatus("Terputus", RED);
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gattObj, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                setStatus("Service gagal", RED);
                return;
            }

            BluetoothGattService s = gattObj.getService(SERVICE_FFE0);
            if (s == null) {
                setStatus("FFE0 tidak ditemukan", RED);
                return;
            }

            ffe1 = s.getCharacteristic(CHAR_FFE1);
            if (ffe1 == null) {
                setStatus("FFE1 tidak ditemukan", RED);
                return;
            }

            setStatus("CONNECTED", GREEN);
        }
    };

    private void stopScan() {
        scanning = false;
        if (scanner != null && hasPermissions()) {
            try {
                scanner.stopScan(scanCallback);
            } catch (SecurityException ignored) {}
        }
    }

    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
            }, REQ_BT);
        } else {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION
            }, REQ_BT);
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT) {
            if (hasPermissions()) connectBle();
            else toast("Izin Bluetooth diperlukan");
        }
    }

    // ============================================================
    // Firmware packets
    // ============================================================

    private void sendMode(int mode) {
        sendPacket(0x03, mode, 0, 0, selectedChannel);
    }

    private void sendRgb() {
        sendPacket(0x07, r, g, b, selectedChannel);
    }

    private void sendSimple(int cmd, int value) {
        sendPacket(cmd, value, 0, 0, selectedChannel);
    }

    private void sendRemTarget(int cmd, int value) {
        byte[] p = packet();
        p[1] = (byte)cmd;
        p[2] = (byte)value;
        p[3] = 0x04;
        p[7] = (byte)selectedChannel;
        write(p);
    }

    private void sendLedCount(int n) {
        byte[] p = packet();
        p[1] = 0x05;
        p[3] = (byte)((n >> 8) & 0xFF);
        p[4] = (byte)(n & 0xFF);
        p[7] = 0x03;
        write(p);
    }

    private void sendSubareaDouble(int area) {
        sendPacket(0x14, area, 0, 0, selectedChannel);
        main.postDelayed(
                () -> sendPacket(0x14, area, 0, 0, selectedChannel),
                140);
    }

    private void sendPacket(int cmd, int v1, int v2, int v3, int channel) {
        byte[] p = packet();
        p[1] = (byte)cmd;
        p[2] = (byte)v1;
        p[3] = (byte)v2;
        p[4] = (byte)v3;
        p[7] = (byte)channel;
        write(p);
    }

    private byte[] packet() {
        byte[] p = new byte[9];
        p[0] = 0x7B;
        p[7] = 0x03;
        p[8] = (byte)0xBF;
        return p;
    }

    private void write(byte[] p) {
        if (gatt == null || ffe1 == null) {
            toast("Hubungkan modul dulu");
            return;
        }

        try {
            int props = ffe1.getProperties();
            int writeType =
                    (props & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                    ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                    : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;

            if (Build.VERSION.SDK_INT >= 33) {
                int rc = gatt.writeCharacteristic(ffe1, p, writeType);
                if (rc != 0) toast("BLE write gagal " + rc);
            } else {
                ffe1.setWriteType(writeType);
                ffe1.setValue(p);
                if (!gatt.writeCharacteristic(ffe1)) toast("BLE write gagal");
            }
        } catch (SecurityException e) {
            requestBtPermissions();
        }
    }

    // ============================================================
    // persistence
    // ============================================================

    private void loadPrefs() {
        selectedChannel = prefs.getInt("channel", 0x03);
        r = prefs.getInt("r", 0);
        g = prefs.getInt("g", 190);
        b = prefs.getInt("b", 255);
        speed = prefs.getInt("speed", 70);
        brightness = prefs.getInt("brightness", 70);

        collect.clear();
        String raw = prefs.getString("collect", "");
        if (raw != null && !raw.isEmpty()) {
            String[] rows = raw.split(";");
            for (String row : rows) {
                String[] p = row.split(",");
                if (p.length != 3) continue;
                try {
                    int m = Integer.parseInt(p[0]);
                    int s = Integer.parseInt(p[1]);
                    int br = Integer.parseInt(p[2]);
                    collect.add(new CollectItem(m, s, br));
                } catch (Exception ignored) {}
            }
        }
    }

    private void savePrefs() {
        prefs.edit()
                .putInt("channel", selectedChannel)
                .putInt("r", r)
                .putInt("g", g)
                .putInt("b", b)
                .putInt("speed", speed)
                .putInt("brightness", brightness)
                .apply();
    }

    private void saveCollect() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < collect.size(); i++) {
            if (i > 0) sb.append(";");
            CollectItem x = collect.get(i);
            sb.append(x.mode).append(",")
                    .append(x.speed).append(",")
                    .append(x.brightness);
        }
        prefs.edit().putString("collect", sb.toString()).apply();
    }

    // ============================================================
    // visual helpers
    // ============================================================

    private Button channelButton(String name, int code) {
        Button x = tabButton(name);

        if (selectedChannel == code) {
            x.setBackground(roundRect(CYAN, 11, CYAN, 1));
            x.setTextColor(BG);
        }

        x.setOnClickListener(v -> {
            selectedChannel = code;
            channelText.setText(channelName(code));
            savePrefs();

            // refresh only current screen style without changing design
            if (modeSection != null && contentHost != null) {
                showMode();
            }
        });

        return x;
    }

    private String channelName(int code) {
        if (code == 0x01) return "LED1";
        if (code == 0x02) return "LED2";
        if (code == 0x04) return "LED3";
        if (code == 0x05) return "LED4";
        return "ALL";
    }

    private Button colorButton(String name, int nr, int ng, int nb) {
        Button x = darkButton(name);
        x.setOnClickListener(v -> {
            r = nr; g = ng; b = nb;
            sendRgb();
            savePrefs();
        });
        return x;
    }

    private View slider(String name, int initial, IntListener listener) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        LinearLayout head = horizontal();
        TextView n = tv(name, 10, Typeface.BOLD, MUTED);
        TextView val = tv(String.valueOf(initial), 11, Typeface.BOLD, WHITE);
        head.addView(n, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(val);
        box.addView(head);

        SeekBar s = new SeekBar(this);
        s.setMax(99);
        s.setProgress(Math.max(0, Math.min(99, initial - 1)));
        s.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(
                    SeekBar seekBar, int progress, boolean fromUser) {
                int value = progress + 1;
                val.setText(String.valueOf(value));
                if (fromUser) listener.onValue(value);
            }
        });
        box.addView(s);

        return box;
    }

    private Button navButton(String text) {
        Button x = new Button(this);
        x.setText(text);
        x.setTextSize(10);
        x.setTextColor(WHITE);
        x.setTypeface(Typeface.DEFAULT_BOLD);
        x.setAllCaps(false);
        x.setGravity(Gravity.CENTER);
        x.setMinHeight(0);
        x.setMinimumHeight(0);
        x.setPadding(dp(4), dp(5), dp(4), dp(5));
        x.setBackgroundColor(Color.TRANSPARENT);
        return x;
    }

    private Button tabButton(String text) {
        Button x = new Button(this);
        x.setText(text);
        x.setTextSize(11);
        x.setTextColor(WHITE);
        x.setTypeface(Typeface.DEFAULT_BOLD);
        x.setAllCaps(false);
        x.setMinHeight(0);
        x.setMinimumHeight(0);
        x.setPadding(dp(13), dp(8), dp(13), dp(8));
        x.setBackground(roundRect(PANEL, 11, LINE, 1));
        return x;
    }

    private Button smallButton(String text) {
        Button x = new Button(this);
        x.setText(text);
        x.setTextSize(11);
        x.setTextColor(WHITE);
        x.setTypeface(Typeface.DEFAULT_BOLD);
        x.setAllCaps(false);
        x.setMinHeight(0);
        x.setMinimumHeight(0);
        x.setPadding(dp(10), dp(7), dp(10), dp(7));
        x.setBackground(roundRect(PANEL2, 11, LINE, 1));
        return x;
    }

    private Button darkButton(String text) {
        Button x = new Button(this);
        x.setText(text);
        x.setTextSize(10);
        x.setTextColor(WHITE);
        x.setTypeface(Typeface.DEFAULT_BOLD);
        x.setAllCaps(false);
        x.setMinHeight(0);
        x.setMinimumHeight(0);
        x.setPadding(dp(5), dp(8), dp(5), dp(8));
        x.setBackground(roundRect(PANEL2, 12, LINE, 1));
        return x;
    }

    private Button outlineButton(String text) {
        Button x = new Button(this);
        x.setText(text);
        x.setTextSize(11);
        x.setTextColor(CYAN2);
        x.setTypeface(Typeface.DEFAULT_BOLD);
        x.setAllCaps(false);
        x.setMinHeight(0);
        x.setMinimumHeight(0);
        x.setPadding(dp(8), dp(8), dp(8), dp(8));
        x.setBackground(roundRect(BG2, 12, CYAN, 1));
        return x;
    }

    private Button blue(String text) {
        Button x = new Button(this);
        x.setText(text);
        x.setTextSize(12);
        x.setTextColor(WHITE);
        x.setTypeface(Typeface.DEFAULT_BOLD);
        x.setAllCaps(false);
        x.setMinHeight(0);
        x.setMinimumHeight(0);
        x.setPadding(dp(10), dp(9), dp(10), dp(9));
        x.setBackground(roundRect(Color.rgb(0, 47, 255), 8,
                Color.rgb(0, 47, 255), 0));
        return x;
    }

    private TextView sectionTitle(String text) {
        TextView x = tv(text, 15, Typeface.BOLD, CYAN2);
        x.setLetterSpacing(0.08f);
        return x;
    }

    private TextView tv(String text, int sp, int style, int color) {
        TextView x = new TextView(this);
        x.setText(text);
        x.setTextSize(sp);
        x.setTextColor(color);
        x.setTypeface(Typeface.DEFAULT, style);
        return x;
    }

    private LinearLayout horizontal() {
        LinearLayout x = new LinearLayout(this);
        x.setOrientation(LinearLayout.HORIZONTAL);
        return x;
    }

    private GradientDrawable roundRect(
            int fill, int radius, int stroke, int strokeWidth) {
        GradientDrawable x = new GradientDrawable();
        x.setColor(fill);
        x.setCornerRadius(dp(radius));
        if (strokeWidth > 0) x.setStroke(dp(strokeWidth), stroke);
        return x;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private LinearLayout.LayoutParams marginLeft(int px) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        p.leftMargin = px;
        return p;
    }

    private LinearLayout.LayoutParams fixed(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private LinearLayout.LayoutParams drawerRow() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(2), 0, dp(2));
        return p;
    }

    private LinearLayout.LayoutParams lpMatchWrap(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void openOta() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(OTA_URL)));
        } catch (Exception e) {
            toast("Browser tidak tersedia");
        }
    }

    private void setStatus(String text, int color) {
        main.post(() -> {
            if (statusText != null) {
                statusText.setText(text);
                statusText.setTextColor(color);
            }
        });
    }

    private void toast(String text) {
        main.post(() -> Toast.makeText(
                this, text, Toast.LENGTH_SHORT).show());
    }

    @Override
    protected void onDestroy() {
        stopScan();
        if (gatt != null) {
            try {
                if (hasPermissions()) gatt.disconnect();
            } catch (SecurityException ignored) {}
            gatt.close();
            gatt = null;
        }
        super.onDestroy();
    }

    private interface IntListener {
        void onValue(int value);
    }

    private static abstract class SimpleSeek
            implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onProgressChanged(
                SeekBar seekBar, int progress, boolean fromUser) {}
        @Override public void onStartTrackingTouch(SeekBar seekBar) {}
        @Override public void onStopTrackingTouch(SeekBar seekBar) {}
    }

    private static final class CollectItem {
        final int mode;
        final int speed;
        final int brightness;

        CollectItem(int mode, int speed, int brightness) {
            this.mode = mode;
            this.speed = speed;
            this.brightness = brightness;
        }
    }

    // ============================================================
    // Preview strip. Not a second selector.
    // It only gives visual preview like APK bawaan.
    // ============================================================

    private final class EffectPreview extends View {
        private final int mode;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        EffectPreview(Context context, int mode) {
            super(context);
            this.mode = mode;
            setBackgroundColor(Color.TRANSPARENT);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            int w = getWidth();
            int h = getHeight();
            float y = h / 2f;
            float left = dp(4);
            float right = w - dp(4);

            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(dp(6));

            // deterministic preview families from mode number
            int family = Math.abs(mode) % 8;

            if (family == 0) {
                paint.setShader(new android.graphics.LinearGradient(
                        left, y, right, y,
                        new int[]{Color.RED, Color.YELLOW, Color.GREEN,
                                Color.CYAN, Color.BLUE, Color.MAGENTA},
                        null, Shader.TileMode.CLAMP));
                canvas.drawLine(left, y, right, y, paint);
                paint.setShader(null);

            } else if (family == 1) {
                paint.setColor(Color.rgb(235, 248, 255));
                canvas.drawLine(left, y, right * 0.62f, y, paint);
                paint.setColor(CYAN);
                canvas.drawLine(right * 0.62f, y, right, y, paint);

            } else if (family == 2) {
                for (int i = 0; i < 8; i++) {
                    paint.setColor(Color.HSVToColor(new float[]{
                            (mode * 17 + i * 43) % 360, 1f, 1f}));
                    float x1 = left + i * (right - left) / 8f;
                    float x2 = left + (i + 0.72f) * (right - left) / 8f;
                    canvas.drawLine(x1, y, x2, y, paint);
                }

            } else if (family == 3) {
                paint.setColor(ORANGE);
                for (int i = 0; i < 5; i++) {
                    float x = left + (right - left) * i / 4f;
                    canvas.drawCircle(x, y, dp(5), paint);
                }

            } else if (family == 4) {
                paint.setColor(Color.BLUE);
                canvas.drawLine(left, y, left + (right-left)*0.35f, y, paint);
                paint.setColor(WHITE);
                canvas.drawLine(left + (right-left)*0.35f, y,
                        left + (right-left)*0.68f, y, paint);
                paint.setColor(Color.RED);
                canvas.drawLine(left + (right-left)*0.68f, y, right, y, paint);

            } else if (family == 5) {
                paint.setColor(CYAN2);
                canvas.drawLine(left, y, right, y, paint);
                paint.setStrokeWidth(dp(2));
                paint.setColor(WHITE);
                for (int i = 0; i < 6; i++) {
                    float x = left + (right-left) * (i + 0.3f) / 6f;
                    canvas.drawCircle(x, y, dp(4), paint);
                }

            } else if (family == 6) {
                paint.setColor(Color.MAGENTA);
                paint.setStrokeWidth(dp(4));
                for (int i = 0; i < 7; i++) {
                    float x1 = left + (right-left)*i/7f;
                    float x2 = left + (right-left)*(i+0.45f)/7f;
                    canvas.drawLine(x1, y - dp(5), x2, y + dp(5), paint);
                }

            } else {
                paint.setColor(GREEN);
                paint.setStrokeWidth(dp(5));
                RectF r1 = new RectF(left, y-dp(5),
                        left+(right-left)*0.45f, y+dp(5));
                canvas.drawRoundRect(r1, dp(5), dp(5), paint);
                paint.setColor(ORANGE);
                RectF r2 = new RectF(
                        left+(right-left)*0.56f, y-dp(5),
                        right, y+dp(5));
                canvas.drawRoundRect(r2, dp(5), dp(5), paint);
            }

            paint.setShader(null);
        }
    }

    private final class HueWheel extends View {
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint center = new Paint(Paint.ANTI_ALIAS_FLAG);
        private HueListener listener;
        private float cx;
        private float cy;
        private float radius;

        HueWheel(Context context) {
            super(context);
            ring.setStyle(Paint.Style.STROKE);
            center.setStyle(Paint.Style.FILL);
            center.setColor(Color.rgb(r, g, b));
        }

        void setListener(HueListener listener) {
            this.listener = listener;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            cx = getWidth() / 2f;
            cy = getHeight() / 2f;
            radius = Math.min(getWidth(), getHeight()) * 0.31f;

            ring.setStrokeWidth(Math.min(getWidth(), getHeight()) * 0.13f);
            ring.setShader(new SweepGradient(
                    cx, cy,
                    new int[]{
                            Color.RED, Color.MAGENTA, Color.BLUE,
                            Color.CYAN, Color.GREEN, Color.YELLOW, Color.RED
                    },
                    null));

            canvas.drawCircle(cx, cy, radius, ring);

            center.setShader(null);
            canvas.drawCircle(cx, cy, radius * 0.38f, center);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (event.getAction() != MotionEvent.ACTION_DOWN &&
                    event.getAction() != MotionEvent.ACTION_MOVE) {
                return true;
            }

            float dx = event.getX() - cx;
            float dy = event.getY() - cy;
            float deg = (float)Math.toDegrees(Math.atan2(dy, dx)) + 90f;
            if (deg < 0) deg += 360f;

            int color = Color.HSVToColor(new float[]{deg, 1f, 1f});
            center.setColor(color);
            invalidate();

            if (listener != null) {
                listener.onColor(
                        Color.red(color),
                        Color.green(color),
                        Color.blue(color));
            }

            return true;
        }
    }

    private interface HueListener {
        void onColor(int r, int g, int b);
    }
}
