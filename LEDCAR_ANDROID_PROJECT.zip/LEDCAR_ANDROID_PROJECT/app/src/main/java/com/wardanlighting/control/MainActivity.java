package com.wardanlighting.control;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.VelocityTracker;
import android.widget.OverScroller;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {

    private static final UUID SERVICE_FFE0 = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    private static final UUID CHAR_FFE1 = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");
    private static final String OTA_URL = "https://ledcar-ota.usmannurdiansyah.workers.dev";
    private static final int REQ_BT = 1001;

    private final Handler main = new Handler(Looper.getMainLooper());
    private BluetoothAdapter btAdapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic ffe1;
    private boolean scanning = false;
    private boolean bleConnected = false;

    private SharedPreferences prefs;
    private FrameLayout safeRoot;
    private OriginalUiView ui;

    private int selectedChannel = 0x03; // ALL
    private int profile = 0; // 0 LEDCAR (CH1/CH2), 1 DMX (CH3/CH4)
    private int globalSpeed = 70;
    private int globalBrightness = 70;
    private int rgbR = 255, rgbG = 50, rgbB = 0;
    private boolean moduleLocked = false;

    private final ArrayList<CollectGroup> collectGroups = new ArrayList<>();
    private int collectRunGeneration = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("wardan_lighting", MODE_PRIVATE);
        loadState();
        loadCollectGroups();

        Window w = getWindow();
        w.setStatusBarColor(Color.BLACK);
        w.setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= 29) {
            w.setNavigationBarContrastEnforced(false);
            w.setStatusBarContrastEnforced(false);
        }
        enableImmersiveUi();

        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        btAdapter = manager != null ? manager.getAdapter() : null;

        showSplash();
    }


    private void enableImmersiveUi() {
        // V05: navigation bar Android tetap terlihat supaya tombol Home/Back
        // tidak tertutup aplikasi. Layout lain tetap persis V01.
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enableImmersiveUi();
    }

    // ---------------------------------------------------------------------
    // SAFE ROOT: seluruh UI berada DI ATAS tombol navigasi HP dan DI BAWAH status bar.
    // ---------------------------------------------------------------------
    private FrameLayout makeSafeRoot() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l = 0, t = 0, r = 0, b = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                l = bars.left; t = bars.top; r = bars.right; b = bars.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft();
                t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight();
                b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return insets;
        });
        root.requestApplyInsets();
        return root;
    }

    // ---------------------------------------------------------------------
    // SPLASH + PASSWORD / KUNCI GESER
    // ---------------------------------------------------------------------
    private void showSplash() {
        safeRoot = makeSafeRoot();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.rgb(0, 7, 18));
        box.setPadding(dp(22), dp(20), dp(22), dp(20));

        TextView wl = text("WL", 66, Color.WHITE, Typeface.BOLD);
        wl.setGravity(Gravity.CENTER);
        box.addView(wl);
        TextView title = text("WARDAN LIGHTING", 24, Color.rgb(80, 195, 255), Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.08f);
        box.addView(title);
        TextView sub = text("LIGHTING YOUR RIDE", 10, Color.rgb(150, 190, 220), Typeface.BOLD);
        sub.setGravity(Gravity.CENTER);
        sub.setLetterSpacing(0.16f);
        box.addView(sub, lp(-1, -2, 0, 7, 0, 0));

        safeRoot.addView(box, match());
        setContentView(safeRoot);
        main.postDelayed(() -> { if (prefs.getString("local_password", "").isEmpty()) showMain(); else showLock(); }, 350);
    }

    private void showLock() {
        safeRoot = makeSafeRoot();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(28), dp(60), dp(28), dp(25));
        box.setBackgroundColor(Color.rgb(0, 7, 18));

        TextView wl = text("WL", 58, Color.WHITE, Typeface.BOLD);
        wl.setGravity(Gravity.CENTER);
        box.addView(wl);
        TextView name = text("Wardan Lighting", 24, Color.WHITE, Typeface.BOLD);
        name.setGravity(Gravity.CENTER);
        box.addView(name, lp(-1, -2, 0, 2, 0, 26));

        TextView lockTitle = text("Geser untuk membuka", 14, Color.WHITE, Typeface.BOLD);
        lockTitle.setGravity(Gravity.CENTER);
        box.addView(lockTitle, lp(-1, -2, 0, 0, 0, 8));

        EditText pass = new EditText(this);
        pass.setHint("Password");
        pass.setHintTextColor(Color.rgb(130, 145, 160));
        pass.setTextColor(Color.WHITE);
        pass.setSingleLine(true);
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        pass.setBackground(round(Color.rgb(7, 21, 34), 12, Color.rgb(45, 83, 105), 1));
        pass.setPadding(dp(14), dp(11), dp(14), dp(11));
        box.addView(pass, lp(-1, -2, 0, 0, 0, 16));

        TextView sliderLabel = text("🔒     GESER KE KANAN     →", 13, Color.rgb(83, 194, 255), Typeface.BOLD);
        sliderLabel.setGravity(Gravity.CENTER);
        box.addView(sliderLabel);

        SeekBar unlock = new SeekBar(this);
        unlock.setMax(100);
        unlock.setProgress(0);
        unlock.setMinimumHeight(dp(64));
        unlock.setPadding(dp(4), dp(12), dp(4), dp(12));
        box.addView(unlock, lp(-1, dp(68), 0, 2, 0, 4));

        final boolean[] opening = {false};
        unlock.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            private void tryOpen(SeekBar seekBar) {
                if (opening[0] || seekBar.getProgress() < 92) return;
                String saved = prefs.getString("local_password", "");
                if (!saved.isEmpty() && !saved.equals(pass.getText().toString())) {
                    toast("Password salah");
                    seekBar.setProgress(0);
                    return;
                }
                opening[0] = true;
                sliderLabel.setText("TERBUKA ✓");
                main.postDelayed(MainActivity.this::showMain, 100);
            }

            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                sliderLabel.setText(progress >= 92 ? "LEPAS UNTUK MEMBUKA ✓" : "🔒     GESER KE KANAN     →");
                if (progress >= 98) tryOpen(seekBar);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                if (seekBar.getProgress() >= 92) tryOpen(seekBar);
                else {
                    seekBar.setProgress(0);
                    sliderLabel.setText("🔒     GESER KE KANAN     →");
                }
            }
        });

        safeRoot.addView(box, match());
        setContentView(safeRoot);
    }

    private void showMain() {
        safeRoot = makeSafeRoot();
        ui = new OriginalUiView(this);
        safeRoot.addView(ui, match());
        setContentView(safeRoot);
    }

    // ---------------------------------------------------------------------
    // ORIGINAL-LIKE UI: placement dan ikon mengikuti screenshot bawaan.
    // ---------------------------------------------------------------------

    private class OriginalUiView extends View {
        private static final float RW = 285f;
        private static final float RH = 610f;

        private final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint overlayPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Bitmap homeBmp;
        private final Bitmap settingsBmp;
        private final Bitmap collectBmp;
        private final Bitmap modeBmp;
        private final Bitmap otaBmp;

        // 0 HOME/RGB, 1 SETTINGS, 2 COLLECT, 3 MODE, 4 OTA
        private int screen = 0;
        boolean settingsOpen = false;

        private float downX, downY;
        private long downAt;
        private int modeFirst = 1;
        private int modeSelected = 1;
        private boolean modeAuto = true;
        // V21: Layout Mode 210 mengikuti referensi user: preview besar + AUTO + satu kartu mode per baris.
        private static final float MODE_PREVIEW_TOP = 112f;
        private static final float MODE_PREVIEW_BOTTOM = 246f;
        private static final float MODE_LIST_TOP = 252f;
        private static final float MODE_LIST_BOTTOM = 445f;
        private static final float MODE_ROW_H = 58f;
        private static final int MODE_COLS = 1;
        private float modeScrollY = 0f;
        private boolean modeScrolling = false;
        private boolean modeScrollMoved = false;
        private float modeLastY = 0f;
        private VelocityTracker modeVelocity;
        private final OverScroller modeScroller;
        // V20: frame preview Mode 1..210 diprecompute langsung dari firmware mayarota(5).ino.
        // Bukan animasi generik; warna/gerak mengikuti output engine firmware pada 4CH.
        private byte[] modeFirmwarePreview;
        private static final int MODE_FW_HEADER = 15;
        private static final int MODE_FW_FRAMES = 160;
        private static final int MODE_FW_SAMPLES = 12;
        private static final int MODE_FW_CHANNELS = 4;
        private static final int MODE_FW_FRAME_MS = 50;
        private boolean lampOn = true;
        private boolean passwordDragging = false;
        private int dragSlider = 0; // 1 home bri, 2 mode speed, 3 mode bri, 4 collect speed, 5 collect bri
        private long lastSliderSendAt = 0L;

        // V06: Collect list benar-benar dinamis; 5 baris terlihat, sisanya scroll.
        private boolean collectScrolling = false;
        private boolean collectScrollMoved = false;
        private float collectLastY = 0f;
        private float collectDownY = 0f;
        private float collectScrollOffset = 0f;
        private int collectFirst = 0;
        // Posisi persis 5 kartu Collect pada skin 282x610.
        // 5 kartu terlihat sekaligus; item ke-6 dst dicapai dengan swipe vertikal.
        private static final float COLLECT_ROW_H = 50.0f;
        private static final float COLLECT_LIST_TOP = 76.0f;
        private static final float COLLECT_LIST_BOTTOM = 326.0f;

        private float passwordDragX = 0f;
        private boolean colorWheelDragging = false;
        private long lastColorSendAt = 0L;

        OriginalUiView(Context c) {
            super(c);
            modeScroller = new OverScroller(c);
            modeFirmwarePreview = loadModeFirmwarePreview();
            // Hardware rendering tetap aktif supaya pergantian menu ringan/responsif.
            homeBmp = decodeUi("ui_home");
            settingsBmp = decodeUi("ui_settings");
            collectBmp = decodeUi("ui_collect");
            modeBmp = decodeUi("ui_mode");
            otaBmp = decodeUi("ui_ota");
        }

        private byte[] loadModeFirmwarePreview() {
            try (InputStream in = getAssets().open("mode210_preview.bin");
                 ByteArrayOutputStream out = new ByteArrayOutputStream(3300000)) {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                byte[] data = out.toByteArray();
                if (data.length < MODE_FW_HEADER || data[0] != 'W' || data[1] != 'L' || data[2] != 'P' || data[3] != 'V') return null;
                return data;
            } catch (Exception e) {
                return null;
            }
        }

        private Bitmap decodeUi(String name) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inPreferredConfig = Bitmap.Config.RGB_565;
            o.inScaled = false;
            int id = getResources().getIdentifier(name, "drawable", getPackageName());
            return BitmapFactory.decodeResource(getResources(), id, o);
        }

        float sx() { return getWidth() / RW; }
        float sy() { return getHeight() / RH; }
        float X(float x) { return x * sx(); }
        float Y(float y) { return y * sy(); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            Bitmap b = homeBmp;
            if (screen == 1) b = settingsBmp;
            else if (screen == 2) b = collectBmp;
            else if (screen == 3) b = modeBmp;
            else if (screen == 4) b = otaBmp;

            if (b != null) {
                c.drawBitmap(b, null, new RectF(0, 0, getWidth(), getHeight()), bitmapPaint);
            } else {
                c.drawColor(Color.rgb(0, 9, 20));
            }

            // Hapus jam/icon status-bar yang memang sudah tercetak di bitmap skin.
            // Status-bar Android asli tetap tampil di atasnya, jadi tidak dobel/ngbayang.
            drawStatusBarCleanup(c);

            if (screen == 0) {
                clearHomeSliderGhost(c);
                drawHomeChannelOverlay(c);
                drawColorWheelSelector(c);
                drawCleanSlider(c, 44f, 236f, 385.5f, globalBrightness, false);
            }
            if (screen == 1) drawPasswordSwitch(c);
            if (screen == 2) {
                clearCollectSliderGhost(c);
                // Selalu gambar daftar Collect dari data asli, bukan 5 contoh yang menempel di bitmap.
                // Dengan begitu item 6,7,...10 dst benar-benar bisa dilihat, dijalankan, dan dihapus.
                drawCollectDynamicList(c);
                drawCleanSlider(c, 61f, 231f, 459.7f, globalSpeed, true);
                drawCleanSlider(c, 61f, 231f, 508.8f, globalBrightness, true);
            }
            if (screen == 3) {
                clearModeGhost(c);
                drawModeSingleList(c);
                drawModeChannelOverlay(c);
                drawCleanSlider(c, 58f, 230f, 471.3f, globalSpeed, true);
                drawCleanSlider(c, 58f, 230f, 519.6f, globalBrightness, true);
            }

            // Small connected indicator uses the existing logo/header area without adding a new button.
            if (screen == 0 && bleConnected) {
                overlayPaint.setColor(Color.rgb(0, 235, 150));
                c.drawCircle(X(273), Y(14), X(3.3f), overlayPaint);
            }
        }


        private static final float COLOR_CX = 143f;
        private static final float COLOR_CY = 228f;
        private static final float COLOR_R = 78f;

        private boolean isOnColorWheel(float x, float y) {
            float dx = x - COLOR_CX;
            float dy = y - COLOR_CY;
            float r = (float)Math.sqrt(dx * dx + dy * dy);
            return r >= 55f && r <= 104f;
        }

        private void updateColorFromWheel(float x, float y, boolean forceSend) {
            double deg = Math.toDegrees(Math.atan2(y - COLOR_CY, x - COLOR_CX));
            float hue = (float)(240.0 - deg);
            while (hue < 0f) hue += 360f;
            while (hue >= 360f) hue -= 360f;

            int color = Color.HSVToColor(new float[]{hue, 1f, 1f});
            rgbR = Color.red(color);
            rgbG = Color.green(color);
            rgbB = Color.blue(color);

            long now = System.currentTimeMillis();
            if (forceSend || now - lastColorSendAt >= 28L) {
                lastColorSendAt = now;
                sendRgb(rgbR, rgbG, rgbB, selectedChannel);
            }
            invalidate();
        }

        private void drawColorWheelSelector(Canvas c) {
            float[] hsv = new float[3];
            Color.RGBToHSV(rgbR, rgbG, rgbB, hsv);
            double rad = Math.toRadians(240.0 - hsv[0]);
            float px = COLOR_CX + (float)Math.cos(rad) * COLOR_R;
            float py = COLOR_CY + (float)Math.sin(rad) * COLOR_R;

            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.BLACK);
            c.drawCircle(X(px), Y(py), X(6.2f), p);
            p.setColor(Color.WHITE);
            c.drawCircle(X(px), Y(py), X(4.1f), p);
        }

        private void drawHomeChannelOverlay(Canvas c) {
            // Tutup total tab bawaan yang tercetak di bitmap supaya highlight ALL lama
            // tidak terlihat lagi di belakang tab LED1-LED4/ALL/Collect.
            Paint cover = new Paint(Paint.ANTI_ALIAS_FLAG);
            cover.setColor(Color.rgb(0, 12, 24));
            c.drawRoundRect(new RectF(X(5),Y(78),X(280),Y(129)),X(7),Y(7),cover);

            final float y1 = 81f, y2 = 113f;
            final float[] cuts = {14f, 57f, 100f, 143f, 186f, 229f, 272f};
            final String[] labels = {"LED1","LED2","LED3","LED4","ALL","Collect"};
            final int[] codes = {0x01,0x02,0x04,0x05,0x03,-1};

            Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
            bg.setColor(Color.rgb(1, 17, 30));
            c.drawRoundRect(new RectF(X(cuts[0]),Y(y1),X(cuts[6]),Y(y2)),X(6),Y(6),bg);

            Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
            border.setStyle(Paint.Style.STROKE);
            border.setStrokeWidth(Math.max(1.2f, X(0.8f)));
            border.setColor(Color.rgb(70, 115, 145));
            c.drawRoundRect(new RectF(X(cuts[0]),Y(y1),X(cuts[6]),Y(y2)),X(6),Y(6),border);

            for (int i=0;i<6;i++) {
                boolean active = i < 5 && selectedChannel == codes[i];
                if (active) {
                    Paint hi = new Paint(Paint.ANTI_ALIAS_FLAG);
                    hi.setColor(Color.rgb(0, 132, 242));
                    c.drawRoundRect(new RectF(X(cuts[i]+1),Y(y1+1),X(cuts[i+1]-1),Y(y2-1)),
                            X(5),Y(5),hi);
                }
                if (i > 0) c.drawLine(X(cuts[i]),Y(y1+3),X(cuts[i]),Y(y2-3),border);
                drawText(c, labels[i], X((cuts[i]+cuts[i+1])/2f), Y(102f),
                        X(i==5 ? 7.4f : 7.8f), Color.WHITE, Paint.Align.CENTER, active);
            }
        }


        private void clearHomeSliderGhost(Canvas c) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.rgb(0, 14, 26));
            c.drawRoundRect(new RectF(X(34), Y(374), X(244), Y(401)), X(6), Y(6), p);
        }

        private void clearCollectSliderGhost(Canvas c) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.rgb(0, 14, 26));
            c.drawRoundRect(new RectF(X(48), Y(447), X(243), Y(475)), X(5), Y(5), p);
            c.drawRoundRect(new RectF(X(48), Y(496), X(243), Y(524)), X(5), Y(5), p);
        }

        private void clearModeGhost(Canvas c) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.rgb(0, 12, 24));
            // Hilangkan dua kolom mode lama, glow sisi, panah lama, dan slider lama yang terlihat samar.
            c.drawRect(0, Y(68), getWidth(), Y(452), p);
            p.setColor(Color.rgb(0, 14, 26));
            c.drawRoundRect(new RectF(X(48), Y(458), X(243), Y(484)), X(5), Y(5), p);
            c.drawRoundRect(new RectF(X(48), Y(507), X(243), Y(533)), X(5), Y(5), p);
        }

        private void drawStatusBarCleanup(Canvas c) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(0, 13, 24));
            c.drawRect(0, 0, getWidth(), Y(20.5f), p);
        }

        private void drawCollectDynamicList(Canvas c) {
            // Hapus 5 contoh Collect bawaan skin sampai penuh, termasuk row ke-5.
            Paint cover = new Paint(Paint.ANTI_ALIAS_FLAG);
            cover.setColor(Color.rgb(0, 12, 24));
            c.drawRect(X(4), Y(69), X(281), Y(337), cover);

            int total = collectGroups.size();
            int maxFirst = Math.max(0, total - 5);
            collectFirst = clamp(collectFirst, 0, maxFirst);

            int save = c.save();
            c.clipRect(X(6), Y(COLLECT_LIST_TOP), X(279), Y(COLLECT_LIST_BOTTOM));

            for (int row = -1; row <= 5; row++) {
                int idx = collectFirst + row;
                if (idx < 0 || idx >= total) continue;

                float top = COLLECT_LIST_TOP + row * COLLECT_ROW_H + collectScrollOffset;
                if (top >= COLLECT_LIST_BOTTOM || top + 46f <= COLLECT_LIST_TOP) continue;

                CollectGroup g = collectGroups.get(idx);

                Paint card = new Paint(Paint.ANTI_ALIAS_FLAG);
                card.setColor(Color.rgb(2, 27, 45));
                c.drawRoundRect(new RectF(X(8), Y(top + 1), X(276), Y(top + 46)), X(5), Y(5), card);

                Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
                border.setStyle(Paint.Style.STROKE);
                border.setStrokeWidth(Math.max(0.9f, X(0.6f)));
                border.setColor(Color.rgb(28, 91, 125));
                c.drawRoundRect(new RectF(X(8), Y(top + 1), X(276), Y(top + 46)), X(5), Y(5), border);

                // Drag handle kiri.
                Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
                dot.setColor(Color.rgb(205, 220, 230));
                for (int rr = 0; rr < 3; rr++) {
                    c.drawCircle(X(20), Y(top + 17 + rr * 6), X(1.0f), dot);
                    c.drawCircle(X(24), Y(top + 17 + rr * 6), X(1.0f), dot);
                }

                drawText(c, String.valueOf(idx + 1), X(58), Y(top + 30),
                        X(11.5f), Color.WHITE, Paint.Align.CENTER, true);
                drawCollectPreview(c, g, top + 2f);
                drawText(c, "›", X(215), Y(top + 31),
                        X(16f), Color.WHITE, Paint.Align.CENTER, false);

                // Ikon sampah aktif. Area sentuhnya x >= 238.
                Paint trash = new Paint(Paint.ANTI_ALIAS_FLAG);
                trash.setStyle(Paint.Style.STROKE);
                trash.setStrokeWidth(Math.max(1.2f, X(0.8f)));
                trash.setColor(Color.rgb(220, 230, 238));
                c.drawRoundRect(new RectF(X(248), Y(top + 15), X(259), Y(top + 31)), X(1.5f), Y(1.5f), trash);
                c.drawLine(X(246), Y(top + 13), X(261), Y(top + 13), trash);
                c.drawLine(X(251), Y(top + 10), X(256), Y(top + 10), trash);
            }
            c.restoreToCount(save);

            // Scrollbar kecil di kanan hanya kalau jumlah Collect > 5.
            if (total > 5) {
                Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
                bar.setStrokeCap(Paint.Cap.ROUND);
                bar.setStrokeWidth(Math.max(2f, X(1.2f)));
                bar.setColor(Color.rgb(43, 79, 101));
                c.drawLine(X(279), Y(COLLECT_LIST_TOP + 4), X(279), Y(COLLECT_LIST_BOTTOM - 4), bar);

                float track = (COLLECT_LIST_BOTTOM - COLLECT_LIST_TOP - 8f);
                float thumb = Math.max(22f, track * (5f / total));
                float travel = Math.max(0f, track - thumb);
                float pos = maxFirst == 0 ? 0f : travel * (collectFirst / (float) maxFirst);
                bar.setStrokeWidth(Math.max(3f, X(1.8f)));
                bar.setColor(Color.rgb(0, 211, 255));
                c.drawLine(X(279), Y(COLLECT_LIST_TOP + 4 + pos),
                        X(279), Y(COLLECT_LIST_TOP + 4 + pos + thumb), bar);
            }
        }

        private void drawCollectPreview(Canvas c, CollectGroup g, float top) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            int[] colors = {
                    Color.rgb(0,225,255), Color.rgb(0,255,135),
                    Color.rgb(255,185,0), Color.rgb(255,55,135),
                    Color.rgb(115,80,255)
            };

            int n = Math.min(18, Math.max(6, g.modes.size() * 3));
            for (int i=0; i<n; i++) {
                int mode = g.modes.isEmpty() ? 1 : g.modes.get(i % g.modes.size());
                p.setColor(colors[Math.abs(mode) % colors.length]);
                float t = i / (float)Math.max(1, n-1);
                float x = 84f + t * 91f;
                float y = top + 21f
                        + (float)Math.sin((t * Math.PI * 2.0) + mode * 0.21) * 7f;
                c.drawCircle(X(x),Y(y),X(1.6f),p);
            }
        }

        private void drawModeChannelOverlay(Canvas c) {
            // V07: hapus total header LED1/LED2 bawaan termasuk glow di sisi.
            Paint cover=new Paint(Paint.ANTI_ALIAS_FLAG);
            cover.setColor(Color.rgb(0,12,24));
            c.drawRoundRect(new RectF(0,Y(68),getWidth(),Y(111)),X(7),Y(7),cover);

            final float y1=76f, y2=106f;
            final float[] cuts={8f,62f,116f,170f,224f,278f};
            final String[] labels={"CH1","CH2","CH3","CH4","ALL"};
            final int[] codes={0x01,0x02,0x04,0x05,0x03};
            Paint border=new Paint(Paint.ANTI_ALIAS_FLAG);
            border.setStyle(Paint.Style.STROKE);
            border.setStrokeWidth(Math.max(1.0f,X(0.65f)));
            border.setColor(Color.rgb(35,105,145));
            for(int i=0;i<5;i++){
                boolean active=selectedChannel==codes[i];
                Paint cell=new Paint(Paint.ANTI_ALIAS_FLAG);
                cell.setColor(active?Color.rgb(0,132,242):Color.rgb(1,20,34));
                c.drawRoundRect(new RectF(X(cuts[i]),Y(y1),X(cuts[i+1]-2),Y(y2)),X(5),Y(5),cell);
                c.drawRoundRect(new RectF(X(cuts[i]),Y(y1),X(cuts[i+1]-2),Y(y2)),X(5),Y(5),border);
                drawText(c,labels[i],X((cuts[i]+cuts[i+1]-2)/2f),Y(95f),X(7.6f),Color.WHITE,Paint.Align.CENTER,active);
            }
        }

        private int modeAutoPreviewMode() {
            long now = android.os.SystemClock.uptimeMillis();
            return 1 + (int)((now / 1450L) % 210L);
        }

        private String modeChannelName() {
            if (selectedChannel == 0x01) return "CH1";
            if (selectedChannel == 0x02) return "CH2";
            if (selectedChannel == 0x04) return "CH3";
            if (selectedChannel == 0x05) return "CH4";
            return "ALL";
        }

        private float modeMaxScroll() {
            // Satu row AUTO penuh + 210 row mode, satu mode per baris.
            int rows = 211;
            return Math.max(0f, rows * MODE_ROW_H - (MODE_LIST_BOTTOM - MODE_LIST_TOP));
        }

        private void drawModeActivePreview(Canvas c) {
            Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
            bg.setColor(Color.rgb(2, 27, 45));
            c.drawRoundRect(new RectF(X(8), Y(MODE_PREVIEW_TOP), X(276), Y(MODE_PREVIEW_BOTTOM)), X(7), Y(7), bg);

            Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
            border.setStyle(Paint.Style.STROKE);
            border.setStrokeWidth(Math.max(1.1f, X(0.8f)));
            border.setColor(Color.rgb(0, 204, 255));
            c.drawRoundRect(new RectF(X(8), Y(MODE_PREVIEW_TOP), X(276), Y(MODE_PREVIEW_BOTTOM)), X(7), Y(7), border);

            int previewMode = modeAuto ? modeAutoPreviewMode() : modeSelected;
            String title = modeAuto
                    ? "Preview aktif: " + modeChannelName() + " • AUTO → Mode " + previewMode
                    : "Preview aktif: " + modeChannelName() + " • Mode " + previewMode;
            drawText(c, title, X(15), Y(129), X(8.1f), Color.rgb(55, 215, 255), Paint.Align.LEFT, true);
            drawText(c, "scroll daftar tidak mengubah preview", X(15), Y(142), X(5.2f), Color.rgb(120, 150, 168), Paint.Align.LEFT, false);

            // Preview Canvas besar mengikuti mode aktif.
            drawEffectPreview(c, previewMode, 28f, 151f, 228f, 55f, false);

            String line1 = modeAuto ? "AUTO aktif • Mode " + previewMode : "Mode aktif • " + previewMode;
            drawText(c, line1, X(15), Y(221), X(5.8f), Color.rgb(150, 180, 198), Paint.Align.LEFT, false);
            drawText(c, "CH1/CH2 = alis  •  CH3/CH4 = lingkar", X(15), Y(236), X(5.6f), Color.rgb(120, 150, 168), Paint.Align.LEFT, false);
        }

        private void drawModeSingleList(Canvas c) {
            // Layout Mode 210 mengikuti APK master: preview besar, AUTO full-width,
            // lalu Mode 1..210 satu kartu per baris. Baris statis; hanya preview besar yang animasi firmware.
            Paint cover = new Paint(Paint.ANTI_ALIAS_FLAG);
            cover.setColor(Color.rgb(0,12,24));
            c.drawRoundRect(new RectF(0, Y(107), getWidth(), Y(449)), X(8), Y(8), cover);

            drawModeActivePreview(c);

            int save = c.save();
            c.clipRect(X(8), Y(MODE_LIST_TOP), X(276), Y(MODE_LIST_BOTTOM));

            final int totalRows = 211; // AUTO + Mode 1..210
            int firstRow = Math.max(0, (int)Math.floor(modeScrollY / MODE_ROW_H));
            int visibleRows = (int)Math.ceil((MODE_LIST_BOTTOM - MODE_LIST_TOP) / MODE_ROW_H) + 2;

            for (int rr = firstRow; rr < firstRow + visibleRows && rr < totalRows; rr++) {
                float top = MODE_LIST_TOP + rr * MODE_ROW_H - modeScrollY;
                boolean isAuto = rr == 0;
                boolean sel = isAuto ? modeAuto : (!modeAuto && modeSelected == rr);

                Paint card = new Paint(Paint.ANTI_ALIAS_FLAG);
                card.setColor(sel ? Color.rgb(0, 71, 105) : Color.rgb(2,27,45));
                c.drawRoundRect(new RectF(X(10),Y(top+3),X(274),Y(top+53)),X(6),Y(6),card);

                Paint cb = new Paint(Paint.ANTI_ALIAS_FLAG);
                cb.setStyle(Paint.Style.STROKE);
                cb.setStrokeWidth(Math.max(0.9f, X(0.7f)));
                cb.setColor(sel ? Color.rgb(0,220,255) : Color.rgb(18,70,100));
                c.drawRoundRect(new RectF(X(10),Y(top+3),X(274),Y(top+53)),X(6),Y(6),cb);

                if (isAuto) {
                    drawText(c,"AUTO",X(20),Y(top+23),X(8.4f),Color.WHITE,Paint.Align.LEFT,true);
                    drawText(c,"Mode berganti otomatis",X(66),Y(top+20),X(6.8f),Color.WHITE,Paint.Align.LEFT,true);
                    drawText(c,"Preview mengikuti mode aktif",X(66),Y(top+35),X(5.1f),Color.rgb(105,155,180),Paint.Align.LEFT,false);
                    int pm = modeAutoPreviewMode();
                    drawModeRowStaticGlyph(c, 218f, top+15f, 29f, 18f, sel);
                    drawText(c,"›",X(263),Y(top+31),X(13f),Color.WHITE,Paint.Align.CENTER,false);
                } else {
                    int mode = rr;
                    drawText(c,String.valueOf(mode),X(20),Y(top+31),X(10.2f),Color.WHITE,Paint.Align.LEFT,true);
                    drawText(c,"Mode " + mode,X(48),Y(top+21),X(7.2f),Color.WHITE,Paint.Align.LEFT,true);
                    drawText(c,"Ketuk untuk pilih",X(48),Y(top+38),X(4.8f),Color.rgb(105,145,165),Paint.Align.LEFT,false);
                    drawModeRowStaticGlyph(c,218f,top+16f,30f,18f,sel);
                    drawText(c,"›",X(263),Y(top+31),X(13f),Color.WHITE,Paint.Align.CENTER,false);
                }
            }
            c.restoreToCount(save);

            float max = modeMaxScroll();
            if (max > 0) {
                float trackTop = MODE_LIST_TOP + 3f, trackBottom = MODE_LIST_BOTTOM - 3f;
                float totalH = 211f * MODE_ROW_H;
                float thumbH = Math.max(22f,(trackBottom-trackTop)*(MODE_LIST_BOTTOM-MODE_LIST_TOP)/totalH);
                float thumbY = trackTop + (trackBottom-trackTop-thumbH) * (modeScrollY/max);
                Paint sb = new Paint(Paint.ANTI_ALIAS_FLAG);
                sb.setColor(Color.rgb(0,190,240));
                c.drawRoundRect(new RectF(X(277f),Y(thumbY),X(280f),Y(thumbY+thumbH)),X(1.5f),X(1.5f),sb);
            }
        }

        @Override public void computeScroll() {
            super.computeScroll();
            if (modeScroller.computeScrollOffset()) {
                modeScrollY = clampModeScroll(modeScroller.getCurrY() / 1000f);
                invalidate();
                postInvalidateOnAnimation();
            }
        }

        private float clampModeScroll(float v){
            return Math.max(0f, Math.min(modeMaxScroll(), v));
        }


        private void drawModeRowStaticGlyph(Canvas c, float left, float top, float width, float height, boolean selected) {
            // Baris mode sengaja statis seperti APK master: garis alis kecil + ring.
            // Animasi firmware hanya berjalan di kotak Preview aktif besar setelah mode dipilih.
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.SQUARE);
            p.setStrokeWidth(Math.max(1.0f, X(1.0f)));
            p.setColor(selected ? Color.rgb(0, 225, 255) : Color.rgb(0, 190, 240));

            float x1 = left + 1.0f;
            float y1 = top + height * 0.55f;
            float x2 = left + width * 0.54f;
            float y2 = top + height * 0.38f;
            c.drawLine(X(x1), Y(y1), X(x2), Y(y2), p);

            float cx = left + width * 0.78f;
            float cy = top + height * 0.52f;
            float rr = Math.min(width, height) * 0.28f;
            c.drawCircle(X(cx), Y(cy), X(rr), p);
        }

        private int modePreviewColor(int mode,int index) {
            int[][] palettes={
                    {Color.rgb(0,230,255),Color.rgb(0,255,135),Color.rgb(255,184,0),Color.rgb(255,50,130),Color.rgb(120,80,255),Color.WHITE},
                    {Color.rgb(255,45,90),Color.rgb(0,205,255),Color.rgb(0,255,135),Color.rgb(255,210,0),Color.rgb(255,75,30),Color.rgb(120,70,255)},
                    {Color.rgb(0,170,255),Color.rgb(35,220,255),Color.rgb(120,80,255),Color.rgb(255,50,160),Color.rgb(255,170,0),Color.WHITE}
            };
            int[] pal=palettes[Math.abs(mode)%palettes.length];
            return pal[Math.abs(index)%pal.length];
        }

        private int modeFirmwareRgb565(int mode, int frame, int channel, int sample) {
            byte[] d = modeFirmwarePreview;
            if (d == null || mode < 1 || mode > 210) return Color.BLACK;
            frame %= MODE_FW_FRAMES;
            if (frame < 0) frame += MODE_FW_FRAMES;
            channel = clamp(channel, 0, MODE_FW_CHANNELS - 1);
            sample = clamp(sample, 0, MODE_FW_SAMPLES - 1);
            int frameStride = MODE_FW_CHANNELS * MODE_FW_SAMPLES * 2;
            int modeStride = MODE_FW_FRAMES * frameStride;
            int off = MODE_FW_HEADER + (mode - 1) * modeStride + frame * frameStride
                    + channel * MODE_FW_SAMPLES * 2 + sample * 2;
            if (off + 1 >= d.length) return Color.BLACK;
            int v = (d[off] & 0xFF) | ((d[off + 1] & 0xFF) << 8);
            int r = ((v >> 11) & 0x1F) * 255 / 31;
            int g = ((v >> 5) & 0x3F) * 255 / 63;
            int b = (v & 0x1F) * 255 / 31;
            return Color.rgb(r, g, b);
        }

        private int modePreviewFrame() {
            long now = android.os.SystemClock.uptimeMillis();
            // Frame asset dibuat pada speed firmware default 75. Slider mengubah laju playback
            // secara proporsional tanpa mengubah bentuk frame sumber.
            float speedScale = Math.max(0.22f, globalSpeed / 75f);
            long scaled = (long)(now * speedScale);
            return (int)((scaled / MODE_FW_FRAME_MS) % MODE_FW_FRAMES);
        }

        private void drawLedSegment(Canvas c, Paint p, float x1, float y1, float x2, float y2, int color, float stroke) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.SQUARE);
            p.setStrokeWidth(Math.max(X(stroke), 1.0f));
            p.setColor(color);
            p.setAlpha(255);
            c.drawLine(X(x1), Y(y1), X(x2), Y(y2), p);
        }

        private void drawFirmwareEyebrow(Canvas c, Paint p, int mode, int frame, int channel,
                                         float xOuter, float yOuter, float xInner, float yInner,
                                         float segmentStroke, boolean reverseSamples) {
            final int n = MODE_FW_SAMPLES;
            for (int i = 0; i < n; i++) {
                int si = reverseSamples ? (n - 1 - i) : i;
                float q0 = i / (float)n;
                float q1 = (i + 0.72f) / (float)n;
                float ax = xOuter + (xInner - xOuter) * q0;
                float ay = yOuter + (yInner - yOuter) * q0;
                float bx = xOuter + (xInner - xOuter) * q1;
                float by = yOuter + (yInner - yOuter) * q1;
                int col = modeFirmwareRgb565(mode, frame, channel, si);
                drawLedSegment(c, p, ax, ay, bx, by, col, segmentStroke);
            }
        }

        private void drawFirmwareRing(Canvas c, Paint p, int mode, int frame, int channel,
                                      float cx, float cy, float radius, float stroke, boolean reverseSamples) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.BUTT);
            p.setStrokeWidth(Math.max(X(stroke), 1.0f));
            final float gap = 2.5f;
            final float span = 360f / MODE_FW_SAMPLES;
            RectF rr = new RectF(X(cx - radius), Y(cy - radius), X(cx + radius), Y(cy + radius));
            for (int i = 0; i < MODE_FW_SAMPLES; i++) {
                int si = reverseSamples ? (MODE_FW_SAMPLES - 1 - i) : i;
                p.setColor(modeFirmwareRgb565(mode, frame, channel, si));
                p.setAlpha(255);
                c.drawArc(rr, -90f + i * span + gap * .5f, span - gap, false, p);
            }
        }

        private void drawEffectPreview(Canvas c,int mode,float left,float top,float width,float height,boolean selected) {
            // V20 EXACT SOURCE PREVIEW:
            // frame warna/gerak berasal dari output engine firmware mayarota(5).ino,
            // disampling dari CH1..CH4. Bentuk fisik: CH1/CH2 = alis, CH3/CH4 = ring.
            int frame = modePreviewFrame();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            boolean big = width > 100f;
            float cx = left + width * .5f;
            float browY = top + height * (big ? .32f : .28f);
            float innerY = top + height * (big ? .43f : .40f);
            float outerPad = width * .10f;
            float centerGap = width * .07f;
            float browStroke = big ? 3.2f : 1.55f;

            // Alis kiri menurun ke tengah; alis kanan simetris naik ke luar.
            drawFirmwareEyebrow(c,p,mode,frame,0,
                    left+outerPad,browY,cx-centerGap,innerY,browStroke,false);
            drawFirmwareEyebrow(c,p,mode,frame,1,
                    left+width-outerPad,browY,cx+centerGap,innerY,browStroke,true);

            float ringY = top + height * (big ? .70f : .72f);
            float ringR = Math.min(width * (big ? .085f : .09f), height * (big ? .18f : .20f));
            float ringDx = width * .145f;
            float ringStroke = big ? 2.6f : 1.35f;
            drawFirmwareRing(c,p,mode,frame,2,cx-ringDx,ringY,ringR,ringStroke,false);
            drawFirmwareRing(c,p,mode,frame,3,cx+ringDx,ringY,ringR,ringStroke,true);

            if (selected) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(Math.max(1.0f, X(big ? .8f : .5f)));
                p.setColor(Color.rgb(0,225,255));
                p.setAlpha(180);
                c.drawRoundRect(new RectF(X(left),Y(top),X(left+width),Y(top+height)),X(2),Y(2),p);
            }

            // Gerak preview mengikuti frame firmware; repaint cukup 50ms sesuai asset.
            postInvalidateDelayed(MODE_FW_FRAME_MS);
        }

        private void drawSlider(Canvas c,float x1,float x2,float y,int value) {
            Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(Math.max(4f,Y(3.2f)));
            p.setColor(Color.rgb(115,145,160));
            c.drawLine(X(x1),Y(y),X(x2),Y(y),p);

            float pos=x1+(x2-x1)*(clamp(value,1,100)/100f);
            p.setColor(Color.rgb(0,225,255));
            c.drawLine(X(x1),Y(y),X(pos),Y(y),p);

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE);
            c.drawCircle(X(pos),Y(y),X(6.2f),p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f,X(0.8f)));
            p.setColor(Color.rgb(0,200,255));
            c.drawCircle(X(pos),Y(y),X(7.8f),p);
        }


        private void drawCleanSlider(Canvas c,float x1,float x2,float y,int value,boolean drawValue) {
            Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(0,14,26));
            c.drawRoundRect(new RectF(X(x1-8),Y(y-14),X(x2+10),Y(y+14)),X(5),Y(5),p);

            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(Math.max(4.0f,Y(3.1f)));
            p.setColor(Color.rgb(94,119,133));
            c.drawLine(X(x1),Y(y),X(x2),Y(y),p);

            float pos=x1+(x2-x1)*(clamp(value,1,100)/100f);
            p.setColor(Color.rgb(0,225,255));
            c.drawLine(X(x1),Y(y),X(pos),Y(y),p);

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE);
            c.drawCircle(X(pos),Y(y),X(6.2f),p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f,X(0.8f)));
            p.setColor(Color.rgb(0,200,255));
            c.drawCircle(X(pos),Y(y),X(7.6f),p);

            if(drawValue){
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.rgb(0,14,26));
                c.drawRect(X(241),Y(y-13),X(278),Y(y+13),p);
                drawText(c,String.valueOf(value),X(258),Y(y+6),
                        X(8.6f),Color.WHITE,Paint.Align.CENTER,false);
            }
        }

        private void drawPasswordSwitch(Canvas c) {
            final float x1=218f, x2=266f, y1=279f, y2=302f;
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            // Bersihkan switch yang sudah tercetak di skin supaya tombol tidak ngbayang.
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(0, 16, 25));
            c.drawRoundRect(new RectF(X(210),Y(274),X(272),Y(307)),X(5),Y(5),p);

            p.setColor(moduleLocked ? Color.rgb(0,190,92) : Color.rgb(55,68,78));
            c.drawRoundRect(new RectF(X(x1),Y(y1),X(x2),Y(y2)),X(12),Y(12),p);

            float knobX;
            if (passwordDragging) {
                knobX = Math.max(229f, Math.min(255f, passwordDragX));
            } else {
                knobX = moduleLocked ? 255f : 229f;
            }
            p.setColor(Color.WHITE);
            c.drawCircle(X(knobX),Y((y1+y2)/2f),X(9.2f),p);
        }

        private float rx(MotionEvent e) { return e.getX() / Math.max(1f, getWidth()) * RW; }
        private float ry(MotionEvent e) { return e.getY() / Math.max(1f, getHeight()) * RH; }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x = rx(e), y = ry(e);

            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                // V24: gesture baru selalu membuang lock slider lama.
                // Bug sebelumnya: dragSlider Mode 210 (2/3) tidak pernah di-reset saat ACTION_UP,
                // sehingga swipe berikutnya di daftar Mode 210 masih menggerakkan Speed/Brightness.
                dragSlider = 0;
                downX = x; downY = y; downAt = System.currentTimeMillis();

                if (screen == 0 && isOnColorWheel(x, y)) {
                    colorWheelDragging = true;
                    updateColorFromWheel(x, y, true);
                    return true;
                }

                if (screen == 1 && y >= 260 && y < 309 && x >= 205) {
                    passwordDragging = true;
                    passwordDragX = x;
                    invalidate();
                    return true;
                }

                if (screen == 0 && y >= 372 && y <= 410) {
                    dragSlider = 1; updateSliderDrag(x, true); return true;
                }
                if (screen == 3 && y >= MODE_LIST_TOP && y <= MODE_LIST_BOTTOM) {
                    dragSlider = 0;
                    modeScroller.forceFinished(true);
                    modeScrolling = true;
                    modeScrollMoved = false;
                    modeLastY = y;
                    if (modeVelocity != null) modeVelocity.recycle();
                    modeVelocity = VelocityTracker.obtain();
                    modeVelocity.addMovement(e);
                    return true;
                }
                if (screen == 3 && y >= 428 && y <= 489) {
                    dragSlider = 2; updateSliderDrag(x, true); return true;
                }
                if (screen == 3 && y > 489 && y <= 545) {
                    dragSlider = 3; updateSliderDrag(x, true); return true;
                }
                if (screen == 2 && y >= 445 && y <= 476) {
                    dragSlider = 4; updateSliderDrag(x, true); return true;
                }
                if (screen == 2 && y >= 494 && y <= 525) {
                    dragSlider = 5; updateSliderDrag(x, true); return true;
                }
                if (screen == 2 && y >= COLLECT_LIST_TOP && y <= COLLECT_LIST_BOTTOM) {
                    // Tangkap gesture list untuk semua jumlah Collect. Tap = run/delete, swipe = scroll.
                    collectScrolling = true;
                    collectScrollMoved = false;
                    collectLastY = y;
                    collectDownY = y;
                    return true;
                }
                if (screen == 3 && y >= 456 && y <= 488) {
                    dragSlider = 2; updateSliderDrag(x, true); return true;
                }
                if (screen == 3 && y >= 505 && y <= 536) {
                    dragSlider = 3; updateSliderDrag(x, true); return true;
                }
                return true;
            }

            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                if (colorWheelDragging) {
                    updateColorFromWheel(x, y, false);
                    return true;
                }
                if (passwordDragging) {
                    passwordDragX = x;
                    invalidate();
                    return true;
                }
                if (dragSlider != 0) {
                    updateSliderDrag(x, false);
                    return true;
                }
                if (modeScrolling) {
                    if (modeVelocity != null) modeVelocity.addMovement(e);
                    float delta = y - modeLastY;
                    modeLastY = y;
                    if (Math.abs(y-downY) > 3f) modeScrollMoved = true;
                    modeScrollY = clampModeScroll(modeScrollY - delta);
                    invalidate();
                    return true;
                }
                if (collectScrolling) {
                    float delta = y - collectLastY;
                    collectLastY = y;
                    if (Math.abs(y - collectDownY) > 3f) collectScrollMoved = true;

                    int maxFirst = Math.max(0, collectGroups.size() - 5);
                    if (maxFirst > 0) {
                        collectScrollOffset += delta;

                        // Geser satu item setiap melewati tinggi satu row.
                        while (collectScrollOffset <= -COLLECT_ROW_H && collectFirst < maxFirst) {
                            collectFirst++;
                            collectScrollOffset += COLLECT_ROW_H;
                        }
                        while (collectScrollOffset >= COLLECT_ROW_H && collectFirst > 0) {
                            collectFirst--;
                            collectScrollOffset -= COLLECT_ROW_H;
                        }

                        // Tahan di batas awal/akhir.
                        if (collectFirst == 0 && collectScrollOffset > 0f) collectScrollOffset = 0f;
                        if (collectFirst == maxFirst && collectScrollOffset < 0f) collectScrollOffset = 0f;
                    } else {
                        collectScrollOffset = 0f;
                    }
                    invalidate();
                    return true;
                }

                return true;
            }

            if (e.getAction() == MotionEvent.ACTION_CANCEL) {
                dragSlider = 0;
                colorWheelDragging = false;
                passwordDragging = false;
                modeScrolling = false;
                collectScrolling = false;
                if (modeVelocity != null) { modeVelocity.recycle(); modeVelocity = null; }
                invalidate();
                return true;
            }

            if (e.getAction() != MotionEvent.ACTION_UP) return true;

            float dx = x - downX;
            float dy = y - downY;
            long held = System.currentTimeMillis() - downAt;

            if (colorWheelDragging) {
                updateColorFromWheel(x, y, true);
                colorWheelDragging = false;
                saveState();
                invalidate();
                return true;
            }

            if (passwordDragging) {
                passwordDragging = false;
                moduleLocked = passwordDragX >= 242f;
                sendSimple(0x16,moduleLocked?1:0,0x03);
                saveState();
                invalidate();
                return true;
            }

            if (dragSlider != 0) {
                updateSliderDrag(x, true);
                dragSlider = 0;
                saveState();
                invalidate();
                return true;
            }

            if (modeScrolling) {
                modeScrolling = false;
                if (modeVelocity != null) modeVelocity.addMovement(e);
                if (!modeScrollMoved) {
                    int row=(int)Math.floor((modeScrollY + (y-MODE_LIST_TOP))/MODE_ROW_H);
                    if (row == 0) {
                        // AUTO hanya mengatur preview lokal; tidak mengirim command baru ke firmware.
                        modeAuto = true;
                    } else {
                        int mode = row; // V21: satu mode per baris.
                        if(mode>=1 && mode<=210){
                            modeAuto = false;
                            modeSelected=mode;
                            modeFirst=mode;
                            sendMode(modeSelected,selectedChannel);
                            saveState();
                        }
                    }
                } else if (modeVelocity != null) {
                    modeVelocity.computeCurrentVelocity(1000);
                    float vy=modeVelocity.getYVelocity() / Math.max(0.1f, sy());
                    // Posisi scroller memakai milli-design-unit; velocity ikut diskalakan 1000x.
                    // Hasilnya tetap meluncur sesudah jari dilepas lalu melambat alami.
                    modeScroller.fling(0, Math.round(modeScrollY*1000f), 0, Math.round(-vy*900f),
                            0,0,0,Math.round(modeMaxScroll()*1000f));
                    postInvalidateOnAnimation();
                }
                if(modeVelocity!=null){ modeVelocity.recycle(); modeVelocity=null; }
                invalidate();
                return true;
            }

            if (collectScrolling) {
                collectScrolling = false;
                int maxFirst = Math.max(0, collectGroups.size() - 5);

                if (collectScrollMoved && maxFirst > 0) {
                    // Swipe pendek pun pindah satu row, jadi Collect 6-10 mudah dicapai.
                    if (collectScrollOffset <= -(COLLECT_ROW_H * 0.22f) && collectFirst < maxFirst) {
                        collectFirst++;
                    } else if (collectScrollOffset >= (COLLECT_ROW_H * 0.22f) && collectFirst > 0) {
                        collectFirst--;
                    }
                } else if (!collectScrollMoved) {
                    int row = (int)Math.floor((y - COLLECT_LIST_TOP) / COLLECT_ROW_H);
                    row = clamp(row, 0, 4);
                    int idx = collectFirst + row;
                    if (idx >= 0 && idx < collectGroups.size()) {
                        if (x >= 238f) {
                            // Hapus Collect yang benar-benar sedang terlihat, termasuk Collect 6-10 dst.
                            collectRunGeneration++;
                            collectGroups.remove(idx);
                            saveCollectGroups();
                            maxFirst = Math.max(0, collectGroups.size() - 5);
                            collectFirst = clamp(collectFirst, 0, maxFirst);
                            toast("Collect " + (idx + 1) + " dihapus");
                        } else {
                            // Tap pada kartu menjalankan nomor Collect yang sedang terlihat.
                            runCollect(idx);
                        }
                    }
                }

                collectScrollOffset = 0f;
                invalidate();
                return true;
            }

            if (screen == 0) return touchHome(x, y, held);
            if (screen == 1) return touchSettings(x, y);
            if (screen == 2) return touchCollect(x, y);
            if (screen == 3) return touchMode(x, y, dy);
            if (screen == 4) return touchOta(x, y);
            return true;
        }

        private boolean touchHome(float x, float y, long held) {
            // Hamburger kiri atas = drawer channel + koneksi.
            if (x < 62 && y < 78) { showMainDrawer(); return true; }

            // Gear
            if (x > 225 && y < 78) { screen = 1; settingsOpen = true; invalidate(); return true; }

            // LED1 / LED2 / LED3 / LED4 / ALL / Collect.
            if (y >= 70 && y <= 128) {
                final float[] cuts={14f,57f,100f,143f,186f,229f,272f};
                final int[] codes={0x01,0x02,0x04,0x05,0x03};
                int idx=-1;
                for(int i=0;i<6;i++) if(x>=cuts[i] && x<cuts[i+1]) { idx=i; break; }
                if(idx==5){ screen=2; invalidate(); return true; }
                if(idx>=0 && idx<5){
                    selectedChannel=codes[idx];
                    saveState();
                    toast(idx==4?"ALL":("LED"+(idx+1)));
                    invalidate();
                    return true;
                }
            }

            // Center power = BLE connect first, then lamp ON/OFF.
            if (x >= 94 && x <= 191 && y >= 167 && y <= 290) {
                if (!bleConnected) connectLedcar();
                else {
                    lampOn = !lampOn;
                    sendSimple(0x04, lampOn ? 1 : 0, selectedChannel);
                    toast(lampOn ? "Lamp ON" : "Lamp OFF");
                }
                return true;
            }

            // Preset colors
            if (y >= 323 && y <= 365) {
                int[][] cs = {
                        {255,0,0}, {255,160,0}, {0,255,70},
                        {0,230,255}, {0,80,255}, {255,255,255}
                };
                float[] px = {20,49,77,105,134,163};
                for (int i=0;i<px.length;i++) {
                    if (Math.abs(x-px[i]) < 15) {
                        rgbR=cs[i][0]; rgbG=cs[i][1]; rgbB=cs[i][2];
                        sendRgb(rgbR,rgbG,rgbB,selectedChannel); saveState(); return true;
                    }
                }
            }

            // Plus color = custom RGB dialog
            if (x > 178 && y >= 323 && y <= 365) { showRgbDialog(); return true; }

            // Welcome / REM / SET 1-3 / OTA
            if (y >= 414 && y <= 474) {
                if (x < 143) showEffectDialog("WELCOME");
                else showEffectDialog("REM");
                return true;
            }
            if (y >= 480 && y <= 542) {
                if (x < 143) { screen = 1; settingsOpen = true; invalidate(); }
                else { screen = 4; invalidate(); }
                return true;
            }

            // Bottom nav
            if (y >= 548) {
                if (x < 72) { screen = 0; invalidate(); }
                else if (x < 143) { screen = 3; invalidate(); }
                else if (x < 214) { screen = 2; invalidate(); }
                else { screen = 1; settingsOpen = true; invalidate(); }
                return true;
            }
            return true;
        }

        private boolean touchSettings(float x, float y) {
            if (x < 42 && y < 76) { screen = 0; settingsOpen = false; invalidate(); return true; }

            if (y >= 68 && y < 120) { showLedCountDialog(); return true; }
            if (y >= 120 && y < 165) { toast("Timer"); return true; }

            // K1 K2 K3
            if (y >= 164 && y < 211) {
                if (x >= 135 && x < 173) sendSimple(0x11,0x00,0x03);
                else if (x >= 173 && x < 211) sendSimple(0x11,0x01,0x03);
                else if (x >= 211) sendSimple(0x11,0x02,0x03);
                return true;
            }

            // Subarea ← ■ →
            if (y >= 211 && y < 260) {
                if (x < 176) sendSubareaDouble(0x01);
                else if (x < 217) sendSimple(0x14,0x00,0x03);
                else sendSubareaDouble(0x02);
                return true;
            }

            if (y >= 260 && y < 309) {
                moduleLocked = !moduleLocked;
                sendSimple(0x16,moduleLocked?1:0,0x03);
                saveState(); invalidate(); return true;
            }

            if (y >= 309 && y < 356) { screen = 4; invalidate(); return true; }
            if (y >= 356 && y < 405) { toast("Skin restoration"); return true; }
            if (y >= 405 && y < 453) { toast("Change skin"); return true; }
            if (y >= 453 && y < 506) { resetAppSettings(); screen=0; settingsOpen=false; invalidate(); return true; }
            return true;
        }

        private boolean touchCollect(float x, float y) {
            if (x < 42 && y < 72) { screen = 0; invalidate(); return true; }
            // Area daftar Collect ditangani penuh oleh gesture onTouchEvent di atas.
            if (y >= 333 && y <= 438) { showCollectEditor(-1); return true; }
            if (y >= 548) {
                if (x < 72) screen=0;
                else if (x < 143) screen=3;
                else if (x < 214) screen=2;
                else {screen=1;settingsOpen=true;}
                invalidate(); return true;
            }
            return true;
        }

        private boolean touchMode(float x, float y, float dy) {
            if (x < 42 && y < 72) { screen = 0; invalidate(); return true; }
            if (x > 238 && y < 72) { screen = 1; settingsOpen=true; invalidate(); return true; }

            // Channel tabs LED1 LED2 LED3 LED4 ALL.
            if (y >= 68 && y <= 110) {
                final float[] cuts={16f,67f,118f,169f,220f,272f};
                final int[] codes={0x01,0x02,0x04,0x05,0x03};
                for(int i=0;i<5;i++){
                    if(x>=cuts[i] && x<cuts[i+1]){
                        selectedChannel=codes[i];
                        saveState();
                        invalidate();
                        return true;
                    }
                }
            }

            // Area daftar Mode 210 ditangani gesture satu-baris + momentum di onTouchEvent.
            if (y >= MODE_LIST_TOP && y <= MODE_LIST_BOTTOM) return true;

            if (y >= 548) {
                if (x < 72) screen=0;
                else if (x < 143) screen=3;
                else if (x < 214) screen=2;
                else {screen=1;settingsOpen=true;}
                invalidate(); return true;
            }
            return true;
        }

        private boolean touchOta(float x, float y) {
            if (x < 42 && y < 72) { screen = 0; invalidate(); return true; }
            if ((y >= 300 && y <= 380) || (y >= 430 && y <= 490)) {
                openOta();
                return true;
            }
            return true;
        }

        private void updateSliderDrag(float x, boolean forceSend) {
            float x1, x2;
            if (dragSlider == 1) { x1=44f; x2=236f; }
            else if (dragSlider == 4 || dragSlider == 5) { x1=61f; x2=231f; }
            else if (dragSlider == 2 || dragSlider == 3) { x1=58f; x2=230f; }
            else { x1=45f; x2=255f; }
            int value=clamp(Math.round((x-x1)/(x2-x1)*100f),1,100);

            boolean isSpeed = dragSlider==2 || dragSlider==4;
            if(isSpeed) globalSpeed=value; else globalBrightness=value;

            long now=System.currentTimeMillis();
            if(forceSend || now-lastSliderSendAt>=28L){
                lastSliderSendAt=now;
                if(isSpeed) sendSimple(0x02,globalSpeed,selectedChannel);
                else sendSimple(0x01,globalBrightness,selectedChannel);
            }
            invalidate();
        }

        private int wrap210(int v) {
            while (v < 1) v += 210;
            while (v > 210) v -= 210;
            return v;
        }
    }



    private void showMainDrawer() {
        // V17: hanya drawer hamburger yang diubah. Layout utama tidak disentuh.
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        final TechDrawerLayout drawer = new TechDrawerLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setPadding(dp(14), dp(10), dp(14), dp(18));
        drawer.setClipToPadding(false);

        DrawerHeaderView header = new DrawerHeaderView(this);
        drawer.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(176)));

        DrawerRowLayout connection = makeDrawerRow("CONNECTION", bleConnected ? "Koneksi\nTerhubung" : "Koneksi\nBelum terhubung", true, false);
        connection.setOnClickListener(v -> {
            d.dismiss();
            if (!bleConnected) connectLedcar();
            else toast("BLE sudah terhubung");
        });
        drawer.addView(connection);

        DrawerRowLayout home = makeDrawerRow("HOME", "Beranda", false, true);
        home.setOnClickListener(v -> {
            d.dismiss();
            if (ui != null) { ui.screen = 0; ui.settingsOpen = false; ui.invalidate(); }
        });
        drawer.addView(home);

        DrawerRowLayout mode210 = makeDrawerRow("MODE210", "Mode 210", false, false);
        mode210.setOnClickListener(v -> {
            d.dismiss();
            if (ui != null) { ui.screen = 3; ui.settingsOpen = false; ui.invalidate(); }
        });
        drawer.addView(mode210);

        DrawerRowLayout rem = makeDrawerRow("REM", "Mode REM", false, false);
        rem.setOnClickListener(v -> { d.dismiss(); showEffectDialog("REM"); });
        drawer.addView(rem);

        DrawerRowLayout sen = makeDrawerRow("SEN", "Mode SEN", false, false);
        sen.setOnClickListener(v -> { d.dismiss(); showEffectDialog("SEN"); });
        drawer.addView(sen);

        DrawerRowLayout settingsRow = makeDrawerRow("SETTINGS", "Pengaturan", false, false);
        settingsRow.setOnClickListener(v -> {
            d.dismiss();
            if (ui != null) { ui.screen = 1; ui.settingsOpen = true; ui.invalidate(); }
        });
        drawer.addView(settingsRow);

        d.setContentView(drawer);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setGravity(Gravity.LEFT | Gravity.TOP);
            android.view.WindowManager.LayoutParams lp = new android.view.WindowManager.LayoutParams();
            lp.copyFrom(w.getAttributes());
            lp.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.515f);
            lp.height = ViewGroup.LayoutParams.MATCH_PARENT;
            lp.dimAmount = 0.55f;
            w.setAttributes(lp);
            w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        d.setOnShowListener(x -> {
            drawer.setTranslationX(-drawer.getWidth());
            drawer.animate().translationX(0f).setDuration(240).start();
        });
        d.show();
        w = d.getWindow();
        if (w != null) {
            w.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.515f), ViewGroup.LayoutParams.MATCH_PARENT);
            w.setGravity(Gravity.LEFT | Gravity.TOP);
        }
    }

    private DrawerRowLayout makeDrawerRow(String type, String label, boolean connectionRow, boolean active) {
        DrawerRowLayout row = new DrawerRowLayout(this, connectionRow, active);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(connectionRow ? 88 : 74));
        rowLp.setMargins(dp(2), dp(5), dp(2), dp(5));
        row.setLayoutParams(rowLp);

        DrawerIconView icon = new DrawerIconView(this, type);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(connectionRow ? 62 : 54), dp(connectionRow ? 62 : 54));
        iconLp.setMargins(0, 0, dp(12), 0);
        row.addView(icon, iconLp);

        TextView tv = text(label, connectionRow ? 17 : 18, Color.WHITE, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setLineSpacing(0f, 1.0f);
        if (connectionRow) {
            android.text.SpannableString ss = new android.text.SpannableString(label);
            String target = bleConnected ? "Terhubung" : "Belum terhubung";
            int pos = label.indexOf(target);
            if (pos >= 0) ss.setSpan(new android.text.style.ForegroundColorSpan(
                    bleConnected ? Color.rgb(0, 245, 70) : Color.rgb(255, 120, 70)),
                    pos, pos + target.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            tv.setText(ss);
        }
        LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(tv, textLp);

        TextView arrow = text("›", 34, Color.rgb(0, 245, 110), Typeface.BOLD);
        arrow.setGravity(Gravity.CENTER);
        row.addView(arrow, new LinearLayout.LayoutParams(dp(26), ViewGroup.LayoutParams.MATCH_PARENT));
        return row;
    }

    private class TechDrawerLayout extends LinearLayout {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        TechDrawerLayout(Context c) {
            super(c);
            setWillNotDraw(false);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            p.setShader(new LinearGradient(0, 0, getWidth(), getHeight(),
                    new int[]{Color.rgb(0,18,31), Color.rgb(0,11,22), Color.rgb(0,17,27)},
                    null, Shader.TileMode.CLAMP));
            c.drawRect(0,0,getWidth(),getHeight(),p);
            p.setShader(null);

            // Garis aksen teknologi hijau seperti mockup final.
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(dp(1));
            line.setColor(Color.argb(150, 0, 220, 110));
            Path path = new Path();
            path.moveTo(0, dp(30)); path.lineTo(dp(55), dp(30)); path.lineTo(dp(78), dp(53)); path.lineTo(getWidth()-dp(12), dp(53));
            c.drawPath(path, line);
            path.reset();
            path.moveTo(0, getHeight()-dp(140)); path.lineTo(dp(44), getHeight()-dp(96)); path.lineTo(dp(44), getHeight()-dp(54)); path.lineTo(dp(92), getHeight()-dp(6));
            c.drawPath(path, line);
            path.reset();
            path.moveTo(0, getHeight()-dp(92)); path.lineTo(dp(24), getHeight()-dp(68)); path.lineTo(dp(24), getHeight()-dp(40)); path.lineTo(dp(62), getHeight()-dp(2));
            c.drawPath(path, line);

            // edge glow kanan
            p.setShader(new LinearGradient(getWidth()-dp(12),0,getWidth(),0,
                    new int[]{Color.TRANSPARENT, Color.argb(90,0,255,110), Color.rgb(0,245,120)}, null, Shader.TileMode.CLAMP));
            c.drawRect(getWidth()-dp(12),0,getWidth(),getHeight(),p);
            p.setShader(null);
        }
    }

    private class DrawerHeaderView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        DrawerHeaderView(Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            int w=getWidth(), h=getHeight();
            p.setShader(new LinearGradient(0,0,w,h,
                    new int[]{Color.rgb(0,25,39),Color.rgb(0,12,24),Color.rgb(0,29,39)},null,Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p); p.setShader(null);

            line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(dp(1)); line.setColor(Color.argb(150,0,230,120));
            Path q=new Path(); q.moveTo(0,dp(18)); q.lineTo(dp(55),dp(18)); q.lineTo(dp(72),dp(36)); q.lineTo(w-dp(24),dp(36)); q.lineTo(w,dp(12)); c.drawPath(q,line);
            q.reset(); q.moveTo(0,h-dp(10)); q.lineTo(dp(24),h-dp(10)); q.lineTo(dp(42),h-dp(28)); q.lineTo(w, h-dp(28)); c.drawPath(q,line);

            p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(dp(55));
            p.setShader(new LinearGradient(w*.34f,0,w*.66f,0,new int[]{Color.WHITE,Color.rgb(0,175,255),Color.rgb(15,85,255)},null,Shader.TileMode.CLAMP));
            c.drawText("WL", w/2f, dp(74), p); p.setShader(null);

            p.setColor(Color.WHITE); p.setTextSize(dp(19)); p.setLetterSpacing(.08f);
            c.drawText("WARDAN", w*.42f, dp(108), p);
            p.setColor(Color.rgb(0,190,255));
            c.drawText("LIGHTING", w*.70f, dp(108), p);
            p.setTextSize(dp(9)); p.setLetterSpacing(.18f);
            c.drawText("LIGHT UP YOUR RIDE!", w/2f, dp(128), p);
            p.setLetterSpacing(0f);
        }
    }

    private class DrawerRowLayout extends LinearLayout {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final boolean connection;
        private final boolean active;
        DrawerRowLayout(Context c, boolean connection, boolean active){
            super(c); this.connection=connection; this.active=active;
            setWillNotDraw(false); setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        }
        @Override protected void onDraw(Canvas c){
            float m=dp(1), r=dp(16);
            RectF rr=new RectF(m,m,getWidth()-m,getHeight()-m);
            if(connection || active){
                bg.setShadowLayer(dp(9),0,0,Color.argb(165,0,255,80));
                bg.setColor(active ? Color.rgb(0,65,45) : Color.rgb(0,25,35));
            } else {
                bg.clearShadowLayer(); bg.setColor(Color.rgb(0,24,36));
            }
            c.drawRoundRect(rr,r,r,bg);
            bg.clearShadowLayer(); bg.setStyle(Paint.Style.STROKE); bg.setStrokeWidth(dp(connection||active?2:1));
            bg.setColor((connection||active)?Color.rgb(0,245,100):Color.rgb(0,130,155));
            c.drawRoundRect(rr,r,r,bg); bg.setStyle(Paint.Style.FILL);
        }
    }

    private class DrawerIconView extends View {
        private final String kind;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        DrawerIconView(Context c,String kind){super(c);this.kind=kind;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f;
            if("CONNECTION".equals(kind)){
                float r=Math.min(w,h)*.43f;
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(6));
                p.setShader(new SweepGradient(cx,cy,new int[]{Color.MAGENTA,Color.RED,Color.YELLOW,Color.GREEN,Color.CYAN,Color.BLUE,Color.MAGENTA},null));
                c.drawCircle(cx,cy,r,p); p.setShader(null);
                p.setColor(Color.rgb(0,90,160)); p.setStyle(Paint.Style.FILL); c.drawCircle(cx,cy,r-dp(6),p);
                p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3));
                Path b=new Path(); b.moveTo(cx-dp(4),cy-dp(20)); b.lineTo(cx+dp(10),cy-dp(7)); b.lineTo(cx-dp(4),cy+dp(5)); b.lineTo(cx-dp(4),cy-dp(20));
                b.moveTo(cx-dp(4),cy+dp(5)); b.lineTo(cx+dp(10),cy+dp(18)); b.lineTo(cx-dp(4),cy+dp(30)); b.lineTo(cx-dp(4),cy+dp(5));
                b.moveTo(cx-dp(17),cy-dp(12)); b.lineTo(cx+dp(10),cy+dp(18));
                b.moveTo(cx-dp(17),cy+dp(20)); b.lineTo(cx+dp(10),cy-dp(7)); c.drawPath(b,p);
                return;
            }
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3)); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
            if("HOME".equals(kind)){
                p.setColor(Color.rgb(0,245,65)); Path a=new Path(); a.moveTo(dp(7),cy); a.lineTo(cx,dp(9)); a.lineTo(w-dp(7),cy); c.drawPath(a,p);
                c.drawRect(dp(14),cy, w-dp(14), h-dp(10),p); c.drawRect(cx-dp(5),h-dp(25),cx+dp(5),h-dp(10),p);
            } else if("MODE210".equals(kind)){
                p.setColor(Color.rgb(55,155,255));
                float[] ys={h*.28f,h*.5f,h*.72f}; float[] xs={w*.62f,w*.38f,w*.58f};
                for(int i=0;i<3;i++){ c.drawLine(dp(6),ys[i],w-dp(6),ys[i],p); p.setStyle(Paint.Style.FILL); c.drawCircle(xs[i],ys[i],dp(5),p); p.setStyle(Paint.Style.STROKE); }
            } else if("REM".equals(kind)){
                p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(255,15,28)); Path t=new Path(); t.moveTo(cx,dp(6)); t.lineTo(w-dp(5),h-dp(6)); t.lineTo(dp(5),h-dp(6)); t.close(); c.drawPath(t,p);
                p.setColor(Color.rgb(5,15,25)); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(28)); c.drawText("!",cx,cy+dp(12),p);
            } else if("SEN".equals(kind)){
                p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(255,165,0));
                Path l=new Path(); l.moveTo(dp(4),cy); l.lineTo(dp(19),cy-dp(13)); l.lineTo(dp(19),cy-dp(6)); l.lineTo(cx-dp(2),cy-dp(6)); l.lineTo(cx-dp(2),cy+dp(6)); l.lineTo(dp(19),cy+dp(6)); l.lineTo(dp(19),cy+dp(13)); l.close(); c.drawPath(l,p);
                Path rr=new Path(); rr.moveTo(w-dp(4),cy); rr.lineTo(w-dp(19),cy-dp(13)); rr.lineTo(w-dp(19),cy-dp(6)); rr.lineTo(cx+dp(2),cy-dp(6)); rr.lineTo(cx+dp(2),cy+dp(6)); rr.lineTo(w-dp(19),cy+dp(6)); rr.lineTo(w-dp(19),cy+dp(13)); rr.close(); c.drawPath(rr,p);
            } else {
                p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(38)); c.drawText("⚙",cx,cy+dp(14),p);
            }
        }
    }

    private void showRgbDialog() {
        final int[] r = {rgbR}, g = {rgbG}, b = {rgbB};
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18),dp(18),dp(18),dp(18));
        box.setBackground(round(Color.rgb(1,18,34),16,Color.rgb(12,121,220),1));

        TextView title = text("RGB",22,Color.WHITE,Typeface.BOLD);
        title.setGravity(Gravity.CENTER); box.addView(title);

        String[] names = {"R","G","B"};
        int[][] holder = {r,g,b};
        for (int i=0;i<3;i++) {
            TextView label = text(names[i] + ": " + holder[i][0],15,Color.WHITE,Typeface.NORMAL);
            box.addView(label);
            SeekBar s = new SeekBar(this); s.setMax(255); s.setProgress(holder[i][0]);
            final int idx=i;
            s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                public void onProgressChanged(SeekBar seek,int value,boolean from){
                    if(!from)return;
                    holder[idx][0]=value;
                    label.setText(names[idx]+": "+value);
                    rgbR=r[0];rgbG=g[0];rgbB=b[0];
                    sendRgb(rgbR,rgbG,rgbB,selectedChannel);saveState();
                }
                public void onStartTrackingTouch(SeekBar s){}
                public void onStopTrackingTouch(SeekBar s){}
            });
            box.addView(s);
        }
        new AlertDialog.Builder(this).setView(box).setPositiveButton("OK",null).show();
    }

    // ---------------------------------------------------------------------
    // Effect dialog: REM / SEN / WELCOME memakai kartu 2 kolom seperti Mode 210.
    // Pemilihan tetap langsung dikirim seperti sistem lama; tombol SIMPAN menutup dialog.
    // ---------------------------------------------------------------------
    private void showEffectDialog(String initialCategory) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(16), dp(14), dp(12));
        root.setBackground(round(Color.rgb(0,7,20), 0, Color.TRANSPARENT, 0));

        TextView title = text("Pilih Efek", 22, Color.WHITE, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, lp(-1,-2,0,0,0,10));

        final String[] categories = {"REM", "SEN", "WELCOME"};
        final String[] current = {("REM".equals(initialCategory) || "SEN".equals(initialCategory) || "WELCOME".equals(initialCategory)) ? initialCategory : "REM"};
        final int[] selected = {1, 1, 0}; // REM, SEN, WELCOME

        LinearLayout tabs = row();
        final Button[] tabButtons = new Button[categories.length];
        for (int i=0;i<categories.length;i++) {
            final int idx=i;
            Button b=darkButton(categories[i]);
            b.setTextSize(14);
            tabButtons[i]=b;
            tabs.addView(b, weight());
            b.setOnClickListener(v->{
                current[0]=categories[idx];
                updateEffectTabStyles(tabButtons,categories,current[0]);
            });
        }
        root.addView(tabs, lp(-1,-2,0,0,0,10));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setUseDefaultMargins(false);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        scroll.addView(grid, new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1f));

        Runnable rebuildGrid = () -> buildEffectCategoryGrid(grid,current[0],selected,scroll);
        for (int i=0;i<categories.length;i++) {
            final int idx=i;
            tabButtons[i].setOnClickListener(v->{
                current[0]=categories[idx];
                updateEffectTabStyles(tabButtons,categories,current[0]);
                rebuildGrid.run();
            });
        }
        updateEffectTabStyles(tabButtons,categories,current[0]);
        rebuildGrid.run();

        TextView speedText=text("Speed: "+globalSpeed,15,Color.WHITE,Typeface.NORMAL);
        root.addView(speedText, lp(-1,-2,0,8,0,0));
        SeekBar speed=new SeekBar(this); speed.setMax(99); speed.setProgress(globalSpeed-1);
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int prog,boolean from){
                if(from){
                    globalSpeed=prog+1;
                    speedText.setText("Speed: "+globalSpeed);
                    if("REM".equals(current[0])) sendRemTarget(0x02,globalSpeed);
                    else sendSimple(0x02,globalSpeed,selectedChannel);
                    saveState();
                }
            }
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        });
        root.addView(speed);

        TextView briText=text("Brightness: "+globalBrightness,15,Color.WHITE,Typeface.NORMAL);
        root.addView(briText);
        SeekBar bri=new SeekBar(this); bri.setMax(99); bri.setProgress(globalBrightness-1);
        bri.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int prog,boolean from){
                if(from){
                    globalBrightness=prog+1;
                    briText.setText("Brightness: "+globalBrightness);
                    if("REM".equals(current[0])) sendRemTarget(0x01,globalBrightness);
                    else sendSimple(0x01,globalBrightness,selectedChannel);
                    saveState();
                }
            }
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        });
        root.addView(bri);

        LinearLayout saveRow = row();
        saveRow.setGravity(Gravity.CENTER);
        Button save=blueButton("SIMPAN");
        LinearLayout.LayoutParams saveLp=new LinearLayout.LayoutParams(0,dp(50),0.72f);
        save.setTextSize(16);
        save.setOnClickListener(v->dialog.dismiss());
        saveRow.addView(save,saveLp);
        root.addView(saveRow,lp(-1,-2,0,8,0,0));

        dialog.setContentView(root);
        dialog.show();
        if (dialog.getWindow()!=null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setBackgroundDrawable(round(Color.TRANSPARENT,0,Color.TRANSPARENT,0));
        }
    }

    private void updateEffectTabStyles(Button[] buttons,String[] categories,String active) {
        for (int i=0;i<buttons.length;i++) {
            boolean on=categories[i].equals(active);
            buttons[i].setTextColor(Color.WHITE);
            buttons[i].setBackground(round(on?Color.rgb(8,150,225):Color.rgb(22,30,38),
                    9,on?Color.rgb(0,205,255):Color.rgb(80,100,115),1));
        }
    }

    private int effectCategoryIndex(String category) {
        if ("REM".equals(category)) return 0;
        if ("SEN".equals(category)) return 1;
        return 2;
    }

    private void buildEffectCategoryGrid(GridLayout grid,String category,int[] selected,ScrollView scroll) {
        grid.removeAllViews();
        final int min="WELCOME".equals(category)?0:1;
        final int max="WELCOME".equals(category)?50:10;
        final int catIdx=effectCategoryIndex(category);

        for (int value=min; value<=max; value++) {
            final int effectValue=value;
            LinearLayout card=new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(10),dp(8),dp(10),dp(8));
            boolean chosen=selected[catIdx]==effectValue;
            card.setBackground(round(Color.rgb(1,20,34),10,
                    chosen?Color.rgb(0,205,255):Color.rgb(35,91,125),chosen?2:1));

            LinearLayout head=row();
            head.setGravity(Gravity.CENTER_VERTICAL);
            TextView number=text(String.format(Locale.US,"%02d",effectValue),16,Color.WHITE,Typeface.BOLD);
            head.addView(number,new LinearLayout.LayoutParams(0,-2,1f));
            TextView marker=text(chosen?"●":"○",18,chosen?Color.rgb(0,220,255):Color.rgb(95,120,135),Typeface.BOLD);
            marker.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);
            head.addView(marker,new LinearLayout.LayoutParams(dp(28),-2));
            card.addView(head,new LinearLayout.LayoutParams(-1,-2));

            // Preview diperbesar dan dianimasikan real-time dari Canvas; tidak memakai GIF/video.
            EffectPreviewView preview=new EffectPreviewView(this,category,effectValue);
            card.addView(preview,new LinearLayout.LayoutParams(-1,dp(72)));

            TextView name=text(effectCardName(category,effectValue),12,Color.WHITE,Typeface.NORMAL);
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(1);
            card.addView(name,new LinearLayout.LayoutParams(-1,-2));

            GridLayout.LayoutParams gp=new GridLayout.LayoutParams();
            gp.width=0;
            gp.height=dp(132);
            gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);
            gp.setMargins(dp(3),dp(3),dp(3),dp(3));
            card.setTag(effectValue);
            grid.addView(card,gp);

            card.setOnClickListener(v->{
                selected[catIdx]=effectValue;
                sendCategoryValue(category,effectValue,true);
                updateEffectGridSelection(grid,selected[catIdx]);
            });
        }
    }


    private void updateEffectGridSelection(GridLayout grid,int selectedValue) {
        for(int i=0;i<grid.getChildCount();i++){
            View child=grid.getChildAt(i);
            Object tag=child.getTag();
            int value=tag instanceof Integer?(Integer)tag:-999;
            boolean chosen=value==selectedValue;
            child.setBackground(round(Color.rgb(1,20,34),10,
                    chosen?Color.rgb(0,205,255):Color.rgb(35,91,125),chosen?2:1));
            if(child instanceof LinearLayout){
                LinearLayout card=(LinearLayout)child;
                if(card.getChildCount()>0 && card.getChildAt(0) instanceof LinearLayout){
                    LinearLayout head=(LinearLayout)card.getChildAt(0);
                    if(head.getChildCount()>1 && head.getChildAt(1) instanceof TextView){
                        TextView marker=(TextView)head.getChildAt(1);
                        marker.setText(chosen?"●":"○");
                        marker.setTextColor(chosen?Color.rgb(0,220,255):Color.rgb(95,120,135));
                    }
                }
            }
        }
    }

    private String effectCardName(String category,int value) {
        if ("REM".equals(category)) return "REM "+value;
        if ("SEN".equals(category)) return "SEN "+value;
        return value==0?"WELCOME OFF":"WELCOME "+value;
    }

    private class EffectPreviewView extends View {
        private final String category;
        private final int value;
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path=new Path();

        EffectPreviewView(Context c,String category,int value){
            super(c);
            this.category=category;
            this.value=value;
            setWillNotDraw(false);
        }

        private int previewColor(int index){
            if("REM".equals(category)) {
                int[] c={Color.rgb(255,35,45),Color.rgb(255,95,35),Color.WHITE};
                return c[Math.abs(index)%c.length];
            }
            if("SEN".equals(category)) {
                int[] c={Color.rgb(255,145,0),Color.rgb(255,205,0),Color.rgb(255,65,0)};
                return c[Math.abs(index)%c.length];
            }
            int[] c={Color.rgb(255,45,90),Color.rgb(120,70,255),Color.rgb(0,205,255),Color.rgb(0,255,135),Color.rgb(255,210,0),Color.rgb(255,75,30)};
            return c[Math.abs(index)%c.length];
        }

        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float w=getWidth(),h=getHeight();
            if(w<=0||h<=0)return;

            // Latar mini-preview agar icon terlihat penuh tetapi tetap ringan.
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(0,11,22));
            c.drawRoundRect(new RectF(0,h*.05f,w,h*.95f),h*.12f,h*.12f,p);

            final long now=android.os.SystemClock.uptimeMillis();
            final float phase=(now%4000L)/4000f;
            final float fast=(now%1600L)/1600f;
            final int pattern=Math.abs(value)%8;
            final int n=14;
            final float left=w*.06f;
            final float right=w*.94f;
            final float span=right-left;
            final float cy=h*.52f;

            if("WELCOME".equals(category) && value==0){
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(Math.max(2f,h*.045f));
                p.setColor(Color.rgb(70,90,105));
                c.drawRoundRect(new RectF(left,h*.38f,right,h*.66f),h*.08f,h*.08f,p);
                p.setStyle(Paint.Style.FILL);
                postInvalidateDelayed(80);
                return;
            }

            switch(pattern){
                case 0: { // sapuan blok kiri -> kanan
                    float head=(fast*1.25f-.12f)*span+left;
                    for(int i=0;i<n;i++){
                        float x=left+span*i/(n-1f);
                        float d=Math.abs(x-head)/(span*.28f);
                        int a=(int)(255f*Math.max(0f,1f-d));
                        p.setColor(previewColor(i+value));
                        p.setAlpha(Math.max(35,a));
                        c.drawRoundRect(new RectF(x-h*.035f,h*.34f,x+h*.035f,h*.70f),h*.025f,h*.025f,p);
                    }
                    break;
                }
                case 1: { // titik/meteor bergerak
                    float head=left+span*fast;
                    for(int i=0;i<n;i++){
                        float x=left+span*i/(n-1f);
                        float d=Math.abs(x-head)/(span*.34f);
                        float a=Math.max(0f,1f-d);
                        p.setColor(previewColor(value+i));
                        p.setAlpha((int)(45+210*a));
                        c.drawCircle(x,cy,Math.max(2f,h*(.035f+.055f*a)),p);
                    }
                    break;
                }
                case 2: { // equalizer hidup
                    for(int i=0;i<10;i++){
                        float x=left+span*i/9f;
                        float amp=.18f+.30f*(.5f+.5f*(float)Math.sin(i*.9f+phase*6.283f*2f+value));
                        p.setColor(previewColor(i+value));
                        p.setAlpha(235);
                        c.drawRoundRect(new RectF(x-h*.035f,cy-h*amp,x+h*.035f,cy+h*amp),h*.025f,h*.025f,p);
                    }
                    break;
                }
                case 3: { // strobo kiri-kanan
                    boolean swap=((now/180L)+value)%2==0;
                    p.setAlpha(255);
                    p.setColor(previewColor(value+(swap?0:1)));
                    c.drawRoundRect(new RectF(left,h*.32f,w*.47f,h*.72f),h*.06f,h*.06f,p);
                    p.setColor(previewColor(value+(swap?2:0)));
                    c.drawRoundRect(new RectF(w*.53f,h*.32f,right,h*.72f),h*.06f,h*.06f,p);
                    break;
                }
                case 4: { // gelombang
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(Math.max(2.5f,h*.055f));
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setColor(previewColor(value));
                    p.setAlpha(245);
                    path.reset();
                    for(int i=0;i<=24;i++){
                        float t=i/24f;
                        float x=left+span*t;
                        float y=cy+(float)Math.sin(t*6.283f*2f-phase*6.283f*2f+value*.35f)*h*.18f;
                        if(i==0)path.moveTo(x,y); else path.lineTo(x,y);
                    }
                    c.drawPath(path,p);
                    p.setStyle(Paint.Style.FILL);
                    break;
                }
                case 5: { // center-out
                    float grow=(float)(.5-.5*Math.cos(phase*6.283));
                    float half=span*.48f*grow;
                    p.setColor(previewColor(value));
                    p.setAlpha(245);
                    c.drawRoundRect(new RectF(w*.5f-half,h*.37f,w*.5f+half,h*.68f),h*.055f,h*.055f,p);
                    break;
                }
                case 6: { // ping-pong head + trail
                    float q=phase<.5f?phase*2f:(1f-phase)*2f;
                    float head=left+span*q;
                    for(int i=0;i<n;i++){
                        float x=left+span*i/(n-1f);
                        float d=Math.abs(x-head)/(span*.26f);
                        float a=Math.max(0f,1f-d);
                        p.setColor(previewColor(value+i/4));
                        p.setAlpha((int)(30+225*a));
                        c.drawCircle(x,cy,Math.max(1.5f,h*(.025f+.055f*a)),p);
                    }
                    break;
                }
                default: { // rainbow / multi color berjalan
                    for(int i=0;i<n;i++){
                        float x=left+span*i/(n-1f);
                        p.setColor(previewColor(i+value+(int)(phase*12f)));
                        p.setAlpha(245);
                        float y=cy+(float)Math.sin(i*.62f+phase*6.283f*2f)*h*.14f;
                        c.drawCircle(x,y,h*.055f,p);
                    }
                    break;
                }
            }
            p.setAlpha(255);
            p.setStyle(Paint.Style.FILL);
            postInvalidateDelayed(33);
        }
    }

    private void sendCategoryValue(String cat,int value,boolean leftPicker) {
        if ("210".equals(cat)) {
            int ch;
            if (profile==0) ch=leftPicker?0x01:0x02; else ch=leftPicker?0x04:0x05;
            sendMode(value,ch);
        } else if ("REM".equals(cat)) sendSimple(0x1A,value,0x03);
        else if ("SEN".equals(cat)) sendSimple(0x19,value,0x03);
        else sendSimple(0x18,value,0x03);
    }

    // ---------------------------------------------------------------------
    // Collect: satu Collect berisi BANYAK mode. Contoh Collect 1 = 1,2,3,4,5.
    // ---------------------------------------------------------------------
    private void showCollectEditor(int editIndex) {
        Dialog d=new Dialog(this); d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(18)); root.setBackgroundColor(Color.rgb(2,9,20));
        TextView title=text(editIndex>=0?"Edit Collect "+(editIndex+1):"Tambah Collect",22,Color.WHITE,Typeface.BOLD); title.setGravity(Gravity.CENTER);root.addView(title,lp(-1,-2,0,0,0,12));

        ArrayList<Integer> pending=new ArrayList<>();
        int initSpeed=globalSpeed, initBri=globalBrightness;
        if(editIndex>=0&&editIndex<collectGroups.size()) { CollectGroup old=collectGroups.get(editIndex);pending.addAll(old.modes);initSpeed=old.speed;initBri=old.brightness; }
        TextView list=text("Mode: "+modeListString(pending),15,Color.rgb(160,210,240),Typeface.BOLD);root.addView(list,lp(-1,-2,0,0,0,8));

        NumberPicker picker=picker(1,210,1);root.addView(picker,new LinearLayout.LayoutParams(-1,0,1f));
        LinearLayout editBtns=row(); Button add=blueButton("+ ADD MODE");Button undo=darkButton("HAPUS TERAKHIR"); editBtns.addView(add,weight());editBtns.addView(undo,weight());root.addView(editBtns);
        add.setOnClickListener(v->{ if(pending.size()<20){pending.add(picker.getValue());list.setText("Mode: "+modeListString(pending));} else toast("Maksimal 20 mode per Collect");});
        undo.setOnClickListener(v->{if(!pending.isEmpty()){pending.remove(pending.size()-1);list.setText("Mode: "+modeListString(pending));}});

        final int[] speedVal={initSpeed}; final int[] briVal={initBri};
        TextView st=text("Speed: "+speedVal[0],14,Color.WHITE,Typeface.NORMAL);root.addView(st);SeekBar ss=new SeekBar(this);ss.setMax(99);ss.setProgress(speedVal[0]-1);root.addView(ss);
        ss.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){speedVal[0]=p+1;st.setText("Speed: "+speedVal[0]);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        TextView bt=text("Brightness: "+briVal[0],14,Color.WHITE,Typeface.NORMAL);root.addView(bt);SeekBar bs=new SeekBar(this);bs.setMax(99);bs.setProgress(briVal[0]-1);root.addView(bs);
        bs.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){briVal[0]=p+1;bt.setText("Brightness: "+briVal[0]);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});

        LinearLayout bottom=row();Button cancel=darkButton("BATAL");Button save=blueButton("SIMPAN COLLECT");bottom.addView(cancel,weight());bottom.addView(save,weight());root.addView(bottom,lp(-1,-2,0,8,0,0));
        cancel.setOnClickListener(v->d.dismiss());
        save.setOnClickListener(v->{ if(pending.isEmpty()) pending.add(picker.getValue()); CollectGroup cg=new CollectGroup(pending,speedVal[0],briVal[0]); if(editIndex>=0&&editIndex<collectGroups.size()) collectGroups.set(editIndex,cg); else collectGroups.add(cg); saveCollectGroups(); if(ui!=null)ui.invalidate(); d.dismiss();});
        d.setContentView(root);d.show();if(d.getWindow()!=null){d.getWindow().setLayout(-1,-1);d.getWindow().setBackgroundDrawable(round(Color.TRANSPARENT,0,Color.TRANSPARENT,0));}
    }

    private void runCollect(int index) {
        if(index<0||index>=collectGroups.size())return;
        CollectGroup g=collectGroups.get(index);
        if(g.modes.isEmpty())return;
        int gen=++collectRunGeneration;
        sendSimple(0x02,g.speed,0x03);
        main.postDelayed(()->sendSimple(0x01,g.brightness,0x03),70);
        for(int i=0;i<g.modes.size();i++){
            final int mode=g.modes.get(i); final int delay=180+i*3000;
            main.postDelayed(()->{if(gen==collectRunGeneration)sendMode(mode,0x03);},delay);
        }
        toast("Collect "+(index+1)+" berjalan: "+modeListString(g.modes));
    }

    // ---------------------------------------------------------------------
    // Settings actions
    // ---------------------------------------------------------------------
    private void showLedCountDialog() {
        EditText input=new EditText(this);input.setInputType(InputType.TYPE_CLASS_NUMBER);input.setText(String.valueOf(prefs.getInt("led_count",75)));input.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("Chip settings - jumlah LED").setView(input).setNegativeButton("Batal",null).setPositiveButton("Terapkan",(d,w)->{
            try{int count=clamp(Integer.parseInt(input.getText().toString().trim()),1,1000);prefs.edit().putInt("led_count",count).apply();sendLedCount(count);toast("Jumlah LED: "+count);}catch(Exception e){toast("Jumlah LED tidak valid");}
        }).show();
    }

    private void resetAppSettings() {
        prefs.edit().remove("collect_groups").remove("speed").remove("brightness").remove("rgb_r").remove("rgb_g").remove("rgb_b").apply();
        collectGroups.clear();globalSpeed=70;globalBrightness=70;rgbR=255;rgbG=50;rgbB=0;selectedChannel=0x03;profile=0;
        if(ui!=null){ui.settingsOpen=false;ui.invalidate();}toast("Pengaturan aplikasi direset");
    }

    private void openOta() {
        try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(OTA_URL)));}catch(Exception e){toast("Browser tidak tersedia");}
    }

    // ---------------------------------------------------------------------
    // BLE
    // ---------------------------------------------------------------------
    private void connectLedcar() {
        if(btAdapter==null){toast("Bluetooth tidak tersedia");return;}
        if(!hasBtPermissions()){requestBtPermissions();return;}
        if(!btAdapter.isEnabled()){toast("Aktifkan Bluetooth");try{startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));}catch(Exception ignored){}return;}
        scanner=btAdapter.getBluetoothLeScanner();if(scanner==null){toast("BLE scanner tidak tersedia");return;}
        if(scanning)return;scanning=true;toast("Mencari LEDCAR-02-9931...");
        try{scanner.startScan(scanCallback);}catch(SecurityException e){requestBtPermissions();return;}
        main.postDelayed(()->{if(scanning){stopScan();toast("LEDCAR belum ditemukan");}},12000);
    }

    private final ScanCallback scanCallback=new ScanCallback(){
        @Override public void onScanResult(int callbackType,ScanResult result){
            BluetoothDevice device=result.getDevice();String name=null;
            try{if(hasBtPermissions())name=device.getName();}catch(SecurityException ignored){}
            boolean nm=name!=null&&(name.toUpperCase(Locale.ROOT).contains("LEDCAR")||name.toUpperCase(Locale.ROOT).contains("LEDLAMP")||name.toUpperCase(Locale.ROOT).contains("WARDAN"));
            boolean svc=false;if(result.getScanRecord()!=null&&result.getScanRecord().getServiceUuids()!=null){for(ParcelUuid u:result.getScanRecord().getServiceUuids()){if(SERVICE_FFE0.equals(u.getUuid())){svc=true;break;}}}
            if(nm||svc){stopScan();connectGatt(device);}
        }
        @Override public void onScanFailed(int errorCode){scanning=false;toast("Scan BLE gagal: "+errorCode);}
    };

    private void connectGatt(BluetoothDevice d){
        if(!hasBtPermissions()){requestBtPermissions();return;}
        try{if(gatt!=null){gatt.close();gatt=null;}ffe1=null;gatt=d.connectGatt(this,false,gattCallback,BluetoothDevice.TRANSPORT_LE);}catch(SecurityException e){requestBtPermissions();}
    }

    private final BluetoothGattCallback gattCallback=new BluetoothGattCallback(){
        @Override public void onConnectionStateChange(BluetoothGatt g,int status,int newState){
            if(newState==BluetoothProfile.STATE_CONNECTED){bleConnected=true;main.post(()->{if(ui!=null)ui.invalidate();toast("LEDCAR terhubung");});try{g.discoverServices();}catch(SecurityException ignored){}}
            else if(newState==BluetoothProfile.STATE_DISCONNECTED){bleConnected=false;ffe1=null;main.post(()->{if(ui!=null)ui.invalidate();toast("LEDCAR terputus");});}
        }
        @Override public void onServicesDiscovered(BluetoothGatt g,int status){if(status==BluetoothGatt.GATT_SUCCESS){BluetoothGattService s=g.getService(SERVICE_FFE0);if(s!=null)ffe1=s.getCharacteristic(CHAR_FFE1);main.post(()->{if(ffe1!=null)toast("FFE1 siap");else toast("FFE1 tidak ditemukan");});}}
    };

    private void disconnectBle(){stopScan();bleConnected=false;collectRunGeneration++;if(gatt!=null){try{if(hasBtPermissions())gatt.disconnect();}catch(SecurityException ignored){}try{gatt.close();}catch(Exception ignored){}gatt=null;}ffe1=null;if(ui!=null)ui.invalidate();}
    private void stopScan(){scanning=false;if(scanner!=null&&hasBtPermissions()){try{scanner.stopScan(scanCallback);}catch(SecurityException ignored){}}}
    private boolean hasBtPermissions(){if(Build.VERSION.SDK_INT>=31)return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
    private void requestBtPermissions(){if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ_BT);}
    @Override public void onRequestPermissionsResult(int req,String[] permissions,int[] grants){super.onRequestPermissionsResult(req,permissions,grants);if(req==REQ_BT){if(hasBtPermissions())connectLedcar();else toast("Izin Bluetooth diperlukan");}}

    // ---------------------------------------------------------------------
    // Firmware packet helpers - sesuai mayarota(1).ino
    // ---------------------------------------------------------------------
    private byte[] packet(){byte[] p=new byte[9];p[0]=0x7B;p[7]=0x03;p[8]=(byte)0xBF;return p;}
    private void sendMode(int mode,int ch){sendSimple(0x03,mode,ch);}
    private void sendRgb(int r,int g,int b,int ch){byte[] p=packet();p[1]=0x07;p[2]=(byte)r;p[3]=(byte)g;p[4]=(byte)b;p[7]=(byte)ch;write(p);}
    private void sendSimple(int cmd,int value,int ch){byte[] p=packet();p[1]=(byte)cmd;p[2]=(byte)value;p[7]=(byte)ch;write(p);}
    private void sendRemTarget(int cmd,int value){byte[] p=packet();p[1]=(byte)cmd;p[2]=(byte)value;p[3]=0x04;p[7]=(byte)0x03;write(p);}
    private void sendLedCount(int count){byte[] p=packet();p[1]=0x05;p[3]=(byte)((count>>8)&0xFF);p[4]=(byte)(count&0xFF);p[7]=0x03;write(p);}
    private void sendSubareaDouble(int area){sendSimple(0x14,area,0x03);main.postDelayed(()->sendSimple(0x14,area,0x03),140);}
    private void write(byte[] data){
        if(gatt==null||ffe1==null){toast("Tekan ▶ untuk hubungkan modul");return;}
        try{int props=ffe1.getProperties();int wt=(props&BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)!=0?BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE:BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;if(Build.VERSION.SDK_INT>=33){int rc=gatt.writeCharacteristic(ffe1,data,wt);if(rc!=0)toast("BLE write gagal: "+rc);}else{ffe1.setWriteType(wt);ffe1.setValue(data);if(!gatt.writeCharacteristic(ffe1))toast("BLE write gagal");}}catch(SecurityException e){requestBtPermissions();}catch(Exception e){toast("Gagal kirim BLE");}
    }

    // ---------------------------------------------------------------------
    // Persistence
    // ---------------------------------------------------------------------
    private void loadState(){selectedChannel=prefs.getInt("channel",0x03);profile=prefs.getInt("profile",0);globalSpeed=prefs.getInt("speed",70);globalBrightness=prefs.getInt("brightness",70);rgbR=prefs.getInt("rgb_r",255);rgbG=prefs.getInt("rgb_g",50);rgbB=prefs.getInt("rgb_b",0);moduleLocked=prefs.getBoolean("module_lock",false);}
    private void saveState(){prefs.edit().putInt("channel",selectedChannel).putInt("profile",profile).putInt("speed",globalSpeed).putInt("brightness",globalBrightness).putInt("rgb_r",rgbR).putInt("rgb_g",rgbG).putInt("rgb_b",rgbB).putBoolean("module_lock",moduleLocked).apply();}
    private void loadCollectGroups(){collectGroups.clear();String raw=prefs.getString("collect_groups","");if(raw==null||raw.isEmpty())return;String[] groups=raw.split("#");for(String s:groups){String[] parts=s.split("\\|");if(parts.length!=3)continue;try{ArrayList<Integer> modes=new ArrayList<>();for(String m:parts[0].split(",")){int v=Integer.parseInt(m);if(v>=1&&v<=210)modes.add(v);}int sp=clamp(Integer.parseInt(parts[1]),1,100),br=clamp(Integer.parseInt(parts[2]),1,100);if(!modes.isEmpty())collectGroups.add(new CollectGroup(modes,sp,br));}catch(Exception ignored){}}}
    private void saveCollectGroups(){StringBuilder out=new StringBuilder();for(int i=0;i<collectGroups.size();i++){if(i>0)out.append('#');CollectGroup g=collectGroups.get(i);for(int j=0;j<g.modes.size();j++){if(j>0)out.append(',');out.append(g.modes.get(j));}out.append('|').append(g.speed).append('|').append(g.brightness);}prefs.edit().putString("collect_groups",out.toString()).apply();}
    private String modeListString(List<Integer> modes){if(modes==null||modes.isEmpty())return "-";StringBuilder s=new StringBuilder();for(int i=0;i<modes.size();i++){if(i>0)s.append(" • ");s.append(modes.get(i));}return s.toString();}
    private static class CollectGroup{final ArrayList<Integer> modes;final int speed,brightness;CollectGroup(List<Integer> m,int s,int b){modes=new ArrayList<>(m);speed=s;brightness=b;}}

    // ---------------------------------------------------------------------
    // Drawing helpers
    // ---------------------------------------------------------------------
    private void drawText(Canvas c,String text,float x,float y,float size,int color,Paint.Align align,boolean bold){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);q.setColor(color);q.setTextSize(size);q.setTextAlign(align);q.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(text,x,y,q);}
    private void drawBack(Canvas c,float x,float y){Paint q=linePaint(Color.WHITE,5f);Path path=new Path();path.moveTo(x+16*scaleX(),y-30*scaleY());path.lineTo(x-16*scaleX(),y);path.lineTo(x+16*scaleX(),y+30*scaleY());c.drawPath(path,q);}
    private float scaleX(){return ui==null?1f:ui.sx();}private float scaleY(){return ui==null?1f:ui.sy();}
    private Paint linePaint(int color,float width){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);q.setColor(color);q.setStyle(Paint.Style.STROKE);q.setStrokeCap(Paint.Cap.ROUND);q.setStrokeJoin(Paint.Join.ROUND);q.setStrokeWidth(width*scaleX());return q;}
    private void drawPlayPause(Canvas c,float x,float y,boolean pause){Paint q=linePaint(Color.WHITE,4f);c.drawCircle(x,y,25*scaleX(),q);if(pause){c.drawLine(x-7*scaleX(),y-12*scaleY(),x-7*scaleX(),y+12*scaleY(),q);c.drawLine(x+7*scaleX(),y-12*scaleY(),x+7*scaleX(),y+12*scaleY(),q);}else{Path t=new Path();t.moveTo(x-7*scaleX(),y-13*scaleY());t.lineTo(x+13*scaleX(),y);t.lineTo(x-7*scaleX(),y+13*scaleY());t.close();c.drawPath(t,q);}}
    private void drawGear(Canvas c,float x,float y,float r,int color){Paint q=linePaint(color,3f);c.drawCircle(x,y,r*0.55f,q);c.drawCircle(x,y,r*0.95f,q);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=x+(float)Math.cos(a)*r*0.95f,y1=y+(float)Math.sin(a)*r*0.95f;float x2=x+(float)Math.cos(a)*r*1.2f,y2=y+(float)Math.sin(a)*r*1.2f;c.drawLine(x1,y1,x2,y2,q);}}
    private void drawRotate(Canvas c,float x,float y){Paint q=linePaint(Color.WHITE,5f);RectF r=new RectF(x-25*scaleX(),y-25*scaleY(),x+25*scaleX(),y+25*scaleY());c.drawArc(r,25,260,false,q);Path a=new Path();a.moveTo(x+22*scaleX(),y-23*scaleY());a.lineTo(x+7*scaleX(),y-25*scaleY());a.lineTo(x+18*scaleX(),y-9*scaleY());c.drawPath(a,q);}
    private void drawChevron(Canvas c,float x,float y){Paint q=linePaint(Color.rgb(110,110,110),2f);Path p=new Path();p.moveTo(x-8*scaleX(),y-12*scaleY());p.lineTo(x+5*scaleX(),y);p.lineTo(x-8*scaleX(),y+12*scaleY());c.drawPath(p,q);}
    private void drawArrow(Canvas c,float x,float y,boolean right){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);q.setColor(Color.WHITE);q.setStyle(Paint.Style.FILL);float s=right?1:-1;Path p=new Path();p.moveTo(x+s*25*scaleX(),y);p.lineTo(x-s*5*scaleX(),y-22*scaleY());p.lineTo(x-s*5*scaleX(),y-10*scaleY());p.lineTo(x-s*28*scaleX(),y-10*scaleY());p.lineTo(x-s*28*scaleX(),y+10*scaleY());p.lineTo(x-s*5*scaleX(),y+10*scaleY());p.lineTo(x-s*5*scaleX(),y+22*scaleY());p.close();c.drawPath(p,q);}
    private void drawToggle(Canvas c,float x,float y,boolean on){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);q.setColor(on?Color.GREEN:Color.DKGRAY);c.drawRoundRect(new RectF(x-52*scaleX(),y-22*scaleY(),x+52*scaleX(),y+22*scaleY()),22*scaleY(),22*scaleY(),q);q.setColor(Color.WHITE);c.drawCircle(x+(on?29:-29)*scaleX(),y,20*scaleY(),q);}
    private void drawRgbIcon(Canvas c,float x,float y,float r){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);int[] cs={Color.WHITE,Color.LTGRAY,Color.DKGRAY,Color.WHITE};q.setShader(new SweepGradient(x,y,cs,null));c.drawCircle(x,y,r,q);q.setShader(null);}
    private void drawSnowflake(Canvas c,float x,float y,float r,int color){Paint q=linePaint(color,2.5f);for(int i=0;i<6;i++){double a=i*Math.PI/3;float x2=x+(float)Math.cos(a)*r,y2=y+(float)Math.sin(a)*r;c.drawLine(x,y,x2,y2,q);}}
    private void drawCustomIcon(Canvas c,float x,float y,float r,int color){Paint q=linePaint(color,2.5f);c.drawCircle(x,y,r,q);c.drawLine(x-r*.45f,y+r*.35f,x+r*.45f,y-r*.45f,q);}

    // ---------------------------------------------------------------------
    // Android UI helpers
    // ---------------------------------------------------------------------
    private TextView text(String s,int sp,int color,int style){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setTypeface(Typeface.create("sans",style));return t;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
    private LinearLayout.LayoutParams weight(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f);p.setMargins(dp(2),0,dp(2),0);return p;}
    private FrameLayout.LayoutParams match(){return new FrameLayout.LayoutParams(-1,-1);}
    private LinearLayout.LayoutParams lp(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
    private Button darkButton(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(dp(8),dp(9),dp(8),dp(9));b.setBackground(round(Color.rgb(22,30,38),8,Color.rgb(80,100,115),1));return b;}
    private Button blueButton(String s){Button b=darkButton(s);b.setBackground(round(Color.rgb(8,150,225),8,Color.rgb(8,150,225),1));return b;}
    private NumberPicker picker(int min,int max,int value){NumberPicker n=new NumberPicker(this);n.setMinValue(min);n.setMaxValue(max);n.setValue(value);n.setWrapSelectorWheel(false);n.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);if(Build.VERSION.SDK_INT>=29)n.setTextColor(Color.WHITE);return n;}
    private GradientDrawable round(int fill,int radiusDp,int stroke,int strokeDp){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radiusDp));if(strokeDp>0)d.setStroke(dp(strokeDp),stroke);return d;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private int clamp(int v,int min,int max){return Math.max(min,Math.min(max,v));}
    private void toast(String s){main.post(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}

    @Override protected void onDestroy(){disconnectBle();super.onDestroy();}
}
