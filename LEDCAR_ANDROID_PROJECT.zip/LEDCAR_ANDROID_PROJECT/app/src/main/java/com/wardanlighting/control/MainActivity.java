package com.wardanlighting.control;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {

    private static final UUID SERVICE_FFE0 = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    private static final UUID CHAR_FFE1 = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");
    private static final String OTA_URL = "https://ledcar-ota.usmannurdiansyah.workers.dev";
    private static final int REQ_BT = 1001;

    private final Handler main = new Handler(Looper.getMainLooper());
    private BluetoothAdapter btAdapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic ffe1;
    private boolean scanning = false;
    private boolean bleConnected = false;

    private SharedPreferences prefs;
    private FrameLayout safeRoot;
    private OriginalUiView ui;

    private int selectedChannel = 0x03; // ALL
    private int profile = 0; // 0 LEDCAR (CH1/CH2), 1 DMX (CH3/CH4)
    private int globalSpeed = 70;
    private int globalBrightness = 70;
    private int rgbR = 255, rgbG = 50, rgbB = 0;
    private boolean moduleLocked = false;

    private final ArrayList<CollectGroup> collectGroups = new ArrayList<>();
    private int collectRunGeneration = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("wardan_lighting", MODE_PRIVATE);
        loadState();
        loadCollectGroups();

        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(149, 151, 158));
        w.setNavigationBarColor(Color.rgb(31, 17, 61));
        if (Build.VERSION.SDK_INT >= 29) {
            w.setNavigationBarContrastEnforced(false);
            w.setStatusBarContrastEnforced(false);
        }

        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        btAdapter = manager != null ? manager.getAdapter() : null;

        showSplash();
    }

    // ---------------------------------------------------------------------
    // SAFE ROOT: seluruh UI berada DI ATAS tombol navigasi HP dan DI BAWAH status bar.
    // ---------------------------------------------------------------------
    private FrameLayout makeSafeRoot() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l = 0, t = 0, r = 0, b = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                l = bars.left; t = bars.top; r = bars.right; b = bars.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft();
                t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight();
                b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return insets;
        });
        root.requestApplyInsets();
        return root;
    }

    // ---------------------------------------------------------------------
    // SPLASH + PASSWORD / KUNCI GESER
    // ---------------------------------------------------------------------
    private void showSplash() {
        safeRoot = makeSafeRoot();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.rgb(0, 7, 18));
        box.setPadding(dp(22), dp(20), dp(22), dp(20));

        TextView wl = text("WL", 66, Color.WHITE, Typeface.BOLD);
        wl.setGravity(Gravity.CENTER);
        box.addView(wl);
        TextView title = text("WARDAN LIGHTING", 24, Color.rgb(80, 195, 255), Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.08f);
        box.addView(title);
        TextView sub = text("LIGHTING YOUR RIDE", 10, Color.rgb(150, 190, 220), Typeface.BOLD);
        sub.setGravity(Gravity.CENTER);
        sub.setLetterSpacing(0.16f);
        box.addView(sub, lp(-1, -2, 0, 7, 0, 0));

        safeRoot.addView(box, match());
        setContentView(safeRoot);
        main.postDelayed(this::showLock, 650);
    }

    private void showLock() {
        safeRoot = makeSafeRoot();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(28), dp(60), dp(28), dp(25));
        box.setBackgroundColor(Color.rgb(0, 7, 18));

        TextView wl = text("WL", 58, Color.WHITE, Typeface.BOLD);
        wl.setGravity(Gravity.CENTER);
        box.addView(wl);
        TextView name = text("Wardan Lighting", 24, Color.WHITE, Typeface.BOLD);
        name.setGravity(Gravity.CENTER);
        box.addView(name, lp(-1, -2, 0, 2, 0, 26));

        TextView lockTitle = text("Geser untuk membuka", 14, Color.WHITE, Typeface.BOLD);
        lockTitle.setGravity(Gravity.CENTER);
        box.addView(lockTitle, lp(-1, -2, 0, 0, 0, 8));

        EditText pass = new EditText(this);
        pass.setHint("Password");
        pass.setHintTextColor(Color.rgb(130, 145, 160));
        pass.setTextColor(Color.WHITE);
        pass.setSingleLine(true);
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        pass.setBackground(round(Color.rgb(7, 21, 34), 12, Color.rgb(45, 83, 105), 1));
        pass.setPadding(dp(14), dp(11), dp(14), dp(11));
        box.addView(pass, lp(-1, -2, 0, 0, 0, 16));

        TextView sliderLabel = text("🔒     GESER KE KANAN     →", 13, Color.rgb(83, 194, 255), Typeface.BOLD);
        sliderLabel.setGravity(Gravity.CENTER);
        box.addView(sliderLabel);

        SeekBar unlock = new SeekBar(this);
        unlock.setMax(100);
        unlock.setProgress(0);
        box.addView(unlock, lp(-1, -2, 0, 0, 0, 4));

        unlock.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                if (seekBar.getProgress() < 88) { seekBar.setProgress(0); return; }
                String saved = prefs.getString("local_password", "");
                if (!saved.isEmpty() && !saved.equals(pass.getText().toString())) {
                    toast("Password salah");
                    seekBar.setProgress(0);
                    return;
                }
                showMain();
            }
        });

        safeRoot.addView(box, match());
        setContentView(safeRoot);
    }

    private void showMain() {
        safeRoot = makeSafeRoot();
        ui = new OriginalUiView(this);
        safeRoot.addView(ui, match());
        setContentView(safeRoot);
    }

    // ---------------------------------------------------------------------
    // ORIGINAL-LIKE UI: placement dan ikon mengikuti screenshot bawaan.
    // ---------------------------------------------------------------------
    private class OriginalUiView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int screen = 0; // 0 MODE, 1 RGB, 2 CUSTOM, 3 COLLECT
        private boolean settingsOpen = false;
        private int touchDownX, touchDownY;

        OriginalUiView(Context c) {
            super(c);
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(3f);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            setFocusable(true);
        }

        float sx() { return getWidth() / 690f; }
        float sy() { return getHeight() / 1389f; }
        float X(float ref) { return ref * sx(); }
        float Y(float ref) { return ref * sy(); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            drawSpaceBackground(c);
            if (screen == 0) drawModeHome(c);
            else if (screen == 1) drawRgb(c, false);
            else if (screen == 2) drawRgb(c, true);
            else drawCollect(c);
            drawBottomNav(c);
            if (settingsOpen) drawSettings(c);
        }

        private void drawSpaceBackground(Canvas c) {
            LinearGradient g = new LinearGradient(0, 0, 0, getHeight(),
                    new int[]{Color.rgb(0, 4, 18), Color.rgb(1, 15, 54), Color.rgb(0, 117, 190), Color.rgb(187, 220, 238)},
                    new float[]{0f, 0.38f, 0.72f, 1f}, Shader.TileMode.CLAMP);
            p.setShader(g);
            c.drawRect(0, 0, getWidth(), getHeight(), p);
            p.setShader(null);

            // stars - deterministic
            p.setColor(Color.argb(100, 255, 255, 255));
            for (int i = 0; i < 70; i++) {
                float xx = ((i * 97) % 683) / 690f * getWidth();
                float yy = ((i * 53 + 17) % 650) / 1389f * getHeight();
                float rr = 0.6f + (i % 3) * 0.45f;
                c.drawCircle(xx, yy, rr * sx(), p);
            }

            // bright earth / cloud horizon in lower half
            RadialGradient earth = new RadialGradient(X(580), Y(1180), X(430),
                    new int[]{Color.argb(220, 245, 250, 255), Color.argb(115, 110, 190, 240), Color.argb(0, 0, 70, 170)},
                    new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP);
            p.setShader(earth);
            c.drawOval(new RectF(X(40), Y(900), X(900), Y(1510)), p);
            p.setShader(null);
        }

        private void drawModeHome(Canvas c) {
            drawTop(c, screen == 3);
            drawBack(c, X(45), Y(42));
            drawPlayPause(c, X(42), Y(112), bleConnected);
            drawRotate(c, X(644), Y(118));

            // plus tile, same placement as screenshot
            p.setColor(Color.argb(145, 4, 15, 55));
            c.drawRoundRect(new RectF(X(64), Y(180), X(312), Y(326)), X(18), X(18), p);
            stroke.setColor(Color.WHITE); stroke.setStrokeWidth(X(5));
            c.drawLine(X(188), Y(230), X(188), Y(278), stroke);
            c.drawLine(X(164), Y(254), X(212), Y(254), stroke);
        }

        private void drawTop(Canvas c, boolean collectSelected) {
            float y1 = Y(10), y2 = Y(75);
            float x0 = X(96), total = X(499), each = total / 4f;
            String[] tabs = profile == 0
                    ? new String[]{"LED1", "ALL", "LED2", "Collect"}
                    : new String[]{"LED3", "ALL", "LED4", "Collect"};
            int[] codes = profile == 0
                    ? new int[]{0x01, 0x03, 0x02, -1}
                    : new int[]{0x04, 0x03, 0x05, -1};

            for (int i = 0; i < 4; i++) {
                float l = x0 + i * each;
                boolean selected = collectSelected ? i == 3 : (codes[i] == selectedChannel);
                p.setColor(selected ? Color.WHITE : Color.argb(160, 0, 0, 0));
                c.drawRect(l, y1, l + each, y2, p);
                stroke.setColor(Color.WHITE); stroke.setStrokeWidth(X(1.6f));
                c.drawRect(l, y1, l + each, y2, stroke);
                drawText(c, tabs[i], l + each/2f, Y(53), X(27), selected ? Color.BLACK : Color.WHITE, Paint.Align.CENTER, false);
            }
            drawGear(c, X(645), Y(42), X(28), Color.WHITE);
        }

        private void drawBottomNav(Canvas c) {
            float top = Y(1274);
            p.setColor(Color.argb(28, 0, 0, 0));
            c.drawRect(0, top, getWidth(), getHeight(), p);
            float[] xs = {X(86), X(260), X(431), X(607)};
            String[] labels = {"RGB", "Mode", "Custom", "Set"};
            int active = screen == 1 ? 0 : screen == 0 ? 1 : screen == 2 ? 2 : screen == 3 ? 1 : -1;
            for (int i=0;i<4;i++) {
                int color = i == active ? Color.rgb(24, 33, 245) : Color.rgb(18,18,18);
                if (i==0) drawRgbIcon(c, xs[i], Y(1323), X(26));
                else if (i==1) drawSnowflake(c, xs[i], Y(1320), X(26), i==active?Color.BLUE:Color.rgb(30,30,30));
                else if (i==2) drawCustomIcon(c, xs[i], Y(1320), X(25), i==active?Color.BLUE:Color.rgb(35,35,35));
                else drawGear(c, xs[i], Y(1320), X(26), i==active?Color.BLUE:Color.rgb(35,35,35));
                drawText(c, labels[i], xs[i], Y(1370), X(25), color, Paint.Align.CENTER, false);
            }
        }

        private void drawRgb(Canvas c, boolean custom) {
            drawTop(c, false);
            drawBack(c, X(45), Y(42));
            drawPlayPause(c, X(42), Y(112), bleConnected);
            drawRotate(c, X(644), Y(118));

            float cx = X(345), cy = Y(470), radius = X(165);
            int[] colors = {Color.RED, Color.MAGENTA, Color.BLUE, Color.CYAN, Color.GREEN, Color.YELLOW, Color.RED};
            p.setShader(new SweepGradient(cx, cy, colors, null));
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(X(55));
            c.drawCircle(cx, cy, radius, p);
            p.setShader(null); p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(110, 0, 0, 0));
            c.drawCircle(cx, cy, X(87), p);
            p.setColor(Color.rgb(rgbR, rgbG, rgbB));
            c.drawCircle(cx, cy, X(40), p);

            drawText(c, custom ? "Custom Color" : "RGB", X(345), Y(705), X(31), Color.WHITE, Paint.Align.CENTER, true);
            drawSliderVisual(c, "Speed", globalSpeed, Y(850), Color.GREEN);
            drawSliderVisual(c, "Brightness", globalBrightness, Y(1010), Color.WHITE);
        }

        private void drawSliderVisual(Canvas c, String label, int value, float y, int accent) {
            float l=X(64), r=X(626), yy=y;
            p.setColor(Color.argb(210,255,255,255));
            c.drawRoundRect(new RectF(l, yy, r, yy+Y(14)), Y(7), Y(7), p);
            p.setColor(accent);
            float fill = l + (r-l) * (value/100f);
            c.drawRoundRect(new RectF(l, yy, fill, yy+Y(14)), Y(7), Y(7), p);
            p.setColor(Color.WHITE);
            c.drawCircle(fill, yy+Y(7), X(20), p);
            drawText(c, label + ": " + value, X(345), yy+Y(65), X(28), Color.WHITE, Paint.Align.CENTER, false);
        }

        private void drawCollect(Canvas c) {
            drawTop(c, true);
            drawBack(c, X(45), Y(42));
            drawPlayPause(c, X(42), Y(112), bleConnected);
            drawRotate(c, X(644), Y(118));
            drawText(c, "COLLECT", X(345), Y(155), X(34), Color.WHITE, Paint.Align.CENTER, true);

            float y = Y(205);
            if (collectGroups.isEmpty()) {
                drawText(c, "Belum ada Collect", X(345), Y(370), X(27), Color.WHITE, Paint.Align.CENTER, false);
            }
            int max = Math.min(8, collectGroups.size());
            for (int i=0;i<max;i++) {
                CollectGroup g = collectGroups.get(i);
                p.setColor(Color.argb(145, 0, 5, 25));
                c.drawRoundRect(new RectF(X(52), y, X(638), y+Y(92)), X(14), X(14), p);
                stroke.setColor(Color.argb(180,255,255,255)); stroke.setStrokeWidth(X(1));
                c.drawRoundRect(new RectF(X(52), y, X(638), y+Y(92)), X(14), X(14), stroke);
                drawText(c, "Collect " + (i+1), X(78), y+Y(34), X(24), Color.WHITE, Paint.Align.LEFT, true);
                drawText(c, modeListString(g.modes), X(78), y+Y(67), X(19), Color.rgb(205,220,235), Paint.Align.LEFT, false);
                drawText(c, "▶", X(572), y+Y(50), X(27), Color.WHITE, Paint.Align.CENTER, true);
                drawText(c, "×", X(615), y+Y(50), X(31), Color.rgb(255,95,95), Paint.Align.CENTER, false);
                y += Y(105);
            }

            p.setColor(Color.argb(170, 0, 30, 80));
            c.drawRoundRect(new RectF(X(150), Y(1150), X(540), Y(1220)), X(12), X(12), p);
            stroke.setColor(Color.WHITE); stroke.setStrokeWidth(X(1.5f));
            c.drawRoundRect(new RectF(X(150), Y(1150), X(540), Y(1220)), X(12), X(12), stroke);
            drawText(c, "+   ADD COLLECT", X(345), Y(1196), X(24), Color.WHITE, Paint.Align.CENTER, true);
        }

        private void drawSettings(Canvas c) {
            float left = X(245);
            p.setColor(Color.BLACK);
            c.drawRect(left, 0, getWidth(), getHeight(), p);
            drawText(c, "Set Focus", X(468), Y(103), X(34), Color.WHITE, Paint.Align.CENTER, false);
            stroke.setColor(Color.rgb(145,145,145)); stroke.setStrokeWidth(X(1));
            c.drawLine(left, Y(160), getWidth(), Y(160), stroke);

            drawDrawerRow(c, "Chip settings", 160);
            drawDrawerRow(c, "Timer", 242);

            // Button row
            float y1=Y(324), y2=Y(420);
            drawText(c, "Button", X(252), Y(383), X(31), Color.WHITE, Paint.Align.LEFT, false);
            drawBlueKey(c, "K1", 410, 337); drawBlueKey(c, "K2", 494, 337); drawBlueKey(c, "K3", 578, 337);
            c.drawLine(left, y2, getWidth(), y2, stroke);

            // Subarea row
            drawText(c, "Subarea", X(252), Y(475), X(30), Color.WHITE, Paint.Align.LEFT, false);
            drawArrow(c, X(430), Y(468), false);
            p.setColor(Color.WHITE); c.drawRect(X(494),Y(447),X(535),Y(488),p);
            drawArrow(c, X(603), Y(468), true);
            c.drawLine(left, Y(520), getWidth(), Y(520), stroke);

            drawText(c, "Password", X(252), Y(573), X(30), Color.WHITE, Paint.Align.LEFT, false);
            drawToggle(c, X(585), Y(561), moduleLocked);
            c.drawLine(left, Y(615), getWidth(), Y(615), stroke);

            drawDrawerRow(c, "Update OTA", 615);
            drawDrawerRow(c, "Reset", 697);
        }

        private void drawDrawerRow(Canvas c, String label, int refY) {
            float top=Y(refY), bottom=Y(refY+82);
            drawText(c, label, X(252), top+Y(52), X(30), Color.WHITE, Paint.Align.LEFT, false);
            drawChevron(c, X(667), top+Y(41));
            stroke.setColor(Color.rgb(145,145,145)); stroke.setStrokeWidth(X(1));
            c.drawLine(X(245), bottom, getWidth(), bottom, stroke);
        }

        private void drawBlueKey(Canvas c, String label, float rx, float ry) {
            p.setColor(Color.rgb(0,0,255));
            c.drawRoundRect(new RectF(X(rx),Y(ry),X(rx+65),Y(ry+65)), X(9), X(9), p);
            drawText(c,label,X(rx+32.5f),Y(ry+44),X(27),Color.WHITE,Paint.Align.CENTER,false);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float rx = e.getX() / Math.max(1f, getWidth()) * 690f;
            float ry = e.getY() / Math.max(1f, getHeight()) * 1389f;
            if (e.getAction()==MotionEvent.ACTION_DOWN) {
                touchDownX=(int)rx; touchDownY=(int)ry;
                return true;
            }
            if (e.getAction()!=MotionEvent.ACTION_UP) return true;

            if (settingsOpen) {
                handleSettingsTap(rx, ry);
                return true;
            }

            // Top gear / rotate / play / back
            if (rx > 595 && ry < 88) { settingsOpen=true; invalidate(); return true; }
            if (rx > 595 && ry >= 88 && ry < 180) { profile = 1-profile; selectedChannel=0x03; saveState(); invalidate(); toast(profile==0?"Profil LEDCAR":"Profil DMX"); return true; }
            if (rx < 88 && ry >= 75 && ry < 172) { if (bleConnected) disconnectBle(); else connectLedcar(); invalidate(); return true; }
            if (rx < 88 && ry < 75) { disconnectBle(); toast("Terputus"); return true; }

            // top tabs
            if (ry >= 8 && ry <= 78 && rx >= 96 && rx <= 595) {
                float each=499f/4f;
                int idx=(int)((rx-96)/each);
                if (idx==3) { screen=3; invalidate(); return true; }
                int[] codes = profile==0 ? new int[]{0x01,0x03,0x02} : new int[]{0x04,0x03,0x05};
                if (idx>=0 && idx<3) { selectedChannel=codes[idx]; saveState(); invalidate(); }
                return true;
            }

            // big plus = effect scroll
            if (screen==0 && rx>=55 && rx<=325 && ry>=165 && ry<=345) { showEffectDialog("210"); return true; }

            // RGB wheel direct color
            if ((screen==1 || screen==2) && ry>270 && ry<700) {
                float dx=rx-345, dy=ry-470;
                float dist=(float)Math.sqrt(dx*dx+dy*dy);
                if (dist>80 && dist<220) {
                    float hue=(float)Math.toDegrees(Math.atan2(dy,dx))+90f;
                    while (hue<0) hue+=360f;
                    int color=Color.HSVToColor(new float[]{hue,1f,1f});
                    rgbR=Color.red(color); rgbG=Color.green(color); rgbB=Color.blue(color);
                    sendRgb(rgbR,rgbG,rgbB,selectedChannel); saveState(); invalidate();
                    return true;
                }
            }

            // slider touches
            if ((screen==1 || screen==2) && rx>=60 && rx<=630) {
                if (ry>=820 && ry<=910) { globalSpeed=clamp((int)((rx-64)/(626-64)*100),1,100); sendSimple(0x02,globalSpeed,selectedChannel); saveState(); invalidate(); return true; }
                if (ry>=980 && ry<=1080) { globalBrightness=clamp((int)((rx-64)/(626-64)*100),1,100); sendSimple(0x01,globalBrightness,selectedChannel); saveState(); invalidate(); return true; }
            }

            // collect list
            if (screen==3) {
                if (ry>=1140 && ry<=1230) { showCollectEditor(-1); return true; }
                if (ry>=195 && ry<1100) {
                    int idx=(int)((ry-205)/105f);
                    if (idx>=0 && idx<collectGroups.size()) {
                        float within=(ry-205)-idx*105f;
                        if (within>=0 && within<=92) {
                            if (rx>595) { collectGroups.remove(idx); saveCollectGroups(); invalidate(); }
                            else { runCollect(idx); }
                            return true;
                        }
                    }
                }
            }

            // bottom nav
            if (ry >= 1255) {
                int idx=(int)(rx / (690f/4f));
                if (idx==0) screen=1;
                else if (idx==1) screen=0;
                else if (idx==2) screen=2;
                else { settingsOpen=true; }
                invalidate();
                return true;
            }
            return true;
        }

        private void handleSettingsTap(float rx,float ry) {
            if (rx<245) { settingsOpen=false; invalidate(); return; }
            if (ry>=160 && ry<242) { showLedCountDialog(); return; }
            if (ry>=242 && ry<324) { toast("Timer tidak mengubah firmware"); return; }
            if (ry>=324 && ry<420) {
                if (rx>=390 && rx<485) sendSimple(0x11,0x00,0x03);
                else if (rx>=485 && rx<570) sendSimple(0x11,0x01,0x03);
                else if (rx>=570) sendSimple(0x11,0x02,0x03);
                return;
            }
            if (ry>=420 && ry<520) {
                if (rx<475) sendSubareaDouble(0x01);
                else if (rx<565) sendSimple(0x14,0x00,0x03);
                else sendSubareaDouble(0x02);
                return;
            }
            if (ry>=520 && ry<615) { moduleLocked=!moduleLocked; sendSimple(0x16,moduleLocked?1:0,0x03); saveState(); invalidate(); return; }
            if (ry>=615 && ry<697) { openOta(); return; }
            if (ry>=697 && ry<779) { resetAppSettings(); return; }
        }
    }

    // ---------------------------------------------------------------------
    // Effect scroll dialog: 210 / REM / SEN / Welcome. Value change = langsung jalan.
    // ---------------------------------------------------------------------
    private void showEffectDialog(String initialCategory) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackground(round(Color.rgb(0,7,20), 0, Color.TRANSPARENT, 0));

        TextView title = text("Pilih Efek", 22, Color.WHITE, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, lp(-1,-2,0,4,0,9));

        LinearLayout cats = row();
        String[] labels={"210","REM","SEN","WELCOME"};
        final String[] current={initialCategory};
        final NumberPicker[] leftRef={null};
        final NumberPicker[] rightRef={null};
        final TextView[] leftLabel={null};
        final TextView[] rightLabel={null};
        for (String label:labels) {
            Button b=darkButton(label);
            cats.addView(b, weight());
            b.setOnClickListener(v->{ current[0]=label; configurePickers(current[0],leftRef[0],rightRef[0],leftLabel[0],rightLabel[0]); });
        }
        root.addView(cats, lp(-1,-2,0,0,0,12));

        LinearLayout labelsRow=row();
        TextView ll=text(profile==0?"LED1":"LED3",18,Color.WHITE,Typeface.NORMAL);
        TextView rl=text(profile==0?"LED2":"LED4",18,Color.WHITE,Typeface.NORMAL);
        ll.setGravity(Gravity.CENTER); rl.setGravity(Gravity.CENTER);
        labelsRow.addView(ll,weight()); labelsRow.addView(rl,weight());
        root.addView(labelsRow);
        leftLabel[0]=ll; rightLabel[0]=rl;

        LinearLayout pickRow=row();
        NumberPicker lpick=picker(1,210,1); NumberPicker rpick=picker(1,210,1);
        leftRef[0]=lpick; rightRef[0]=rpick;
        pickRow.addView(lpick,weight()); pickRow.addView(rpick,weight());
        root.addView(pickRow,new LinearLayout.LayoutParams(-1,0,1f));

        lpick.setOnValueChangedListener((p,o,n)->sendCategoryValue(current[0],n,true));
        rpick.setOnValueChangedListener((p,o,n)->sendCategoryValue(current[0],n,false));

        TextView speedText=text("Speed: "+globalSpeed,15,Color.WHITE,Typeface.NORMAL);
        root.addView(speedText);
        SeekBar speed=new SeekBar(this); speed.setMax(99); speed.setProgress(globalSpeed-1);
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int prog,boolean from){ if(from){globalSpeed=prog+1;speedText.setText("Speed: "+globalSpeed); if("REM".equals(current[0])) sendRemTarget(0x02,globalSpeed); else sendSimple(0x02,globalSpeed,selectedChannel);saveState();}}
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
        });
        root.addView(speed);

        TextView briText=text("Brightness: "+globalBrightness,15,Color.WHITE,Typeface.NORMAL);
        root.addView(briText);
        SeekBar bri=new SeekBar(this); bri.setMax(99); bri.setProgress(globalBrightness-1);
        bri.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int prog,boolean from){ if(from){globalBrightness=prog+1;briText.setText("Brightness: "+globalBrightness); if("REM".equals(current[0])) sendRemTarget(0x01,globalBrightness); else sendSimple(0x01,globalBrightness,selectedChannel);saveState();}}
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
        });
        root.addView(bri);

        LinearLayout bottom=row();
        Button cancel=darkButton("CANCELLED"); Button confirm=blueButton("CONFIRM");
        cancel.setOnClickListener(v->dialog.dismiss()); confirm.setOnClickListener(v->dialog.dismiss());
        bottom.addView(cancel,weight()); bottom.addView(confirm,weight());
        root.addView(bottom,lp(-1,-2,0,10,0,0));

        dialog.setContentView(root);
        dialog.show();
        if (dialog.getWindow()!=null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setBackgroundDrawable(round(Color.TRANSPARENT,0,Color.TRANSPARENT,0));
        }
        configurePickers(current[0],lpick,rpick,ll,rl);
    }

    private void configurePickers(String cat, NumberPicker l, NumberPicker r, TextView ll, TextView rl) {
        if (l==null||r==null) return;
        if ("210".equals(cat)) {
            l.setMinValue(1);l.setMaxValue(210);r.setMinValue(1);r.setMaxValue(210);r.setVisibility(View.VISIBLE);rl.setVisibility(View.VISIBLE);
            ll.setText(profile==0?"LED1":"LED3");rl.setText(profile==0?"LED2":"LED4");
        } else if ("WELCOME".equals(cat)) {
            l.setMinValue(0);l.setMaxValue(50);l.setValue(0);r.setVisibility(View.INVISIBLE);rl.setVisibility(View.INVISIBLE);ll.setText("WELCOME");
        } else {
            l.setMinValue(1);l.setMaxValue(10);l.setValue(1);r.setVisibility(View.INVISIBLE);rl.setVisibility(View.INVISIBLE);ll.setText(cat);
        }
    }

    private void sendCategoryValue(String cat,int value,boolean leftPicker) {
        if ("210".equals(cat)) {
            int ch;
            if (profile==0) ch=leftPicker?0x01:0x02; else ch=leftPicker?0x04:0x05;
            sendMode(value,ch);
        } else if ("REM".equals(cat)) sendSimple(0x1A,value,0x03);
        else if ("SEN".equals(cat)) sendSimple(0x19,value,0x03);
        else sendSimple(0x18,value,0x03);
    }

    // ---------------------------------------------------------------------
    // Collect: satu Collect berisi BANYAK mode. Contoh Collect 1 = 1,2,3,4,5.
    // ---------------------------------------------------------------------
    private void showCollectEditor(int editIndex) {
        Dialog d=new Dialog(this); d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(18)); root.setBackgroundColor(Color.rgb(2,9,20));
        TextView title=text(editIndex>=0?"Edit Collect "+(editIndex+1):"Tambah Collect",22,Color.WHITE,Typeface.BOLD); title.setGravity(Gravity.CENTER);root.addView(title,lp(-1,-2,0,0,0,12));

        ArrayList<Integer> pending=new ArrayList<>();
        int initSpeed=globalSpeed, initBri=globalBrightness;
        if(editIndex>=0&&editIndex<collectGroups.size()) { CollectGroup old=collectGroups.get(editIndex);pending.addAll(old.modes);initSpeed=old.speed;initBri=old.brightness; }
        TextView list=text("Mode: "+modeListString(pending),15,Color.rgb(160,210,240),Typeface.BOLD);root.addView(list,lp(-1,-2,0,0,0,8));

        NumberPicker picker=picker(1,210,1);root.addView(picker,new LinearLayout.LayoutParams(-1,0,1f));
        LinearLayout editBtns=row(); Button add=blueButton("+ ADD MODE");Button undo=darkButton("HAPUS TERAKHIR"); editBtns.addView(add,weight());editBtns.addView(undo,weight());root.addView(editBtns);
        add.setOnClickListener(v->{ if(pending.size()<20){pending.add(picker.getValue());list.setText("Mode: "+modeListString(pending));} else toast("Maksimal 20 mode per Collect");});
        undo.setOnClickListener(v->{if(!pending.isEmpty()){pending.remove(pending.size()-1);list.setText("Mode: "+modeListString(pending));}});

        final int[] speedVal={initSpeed}; final int[] briVal={initBri};
        TextView st=text("Speed: "+speedVal[0],14,Color.WHITE,Typeface.NORMAL);root.addView(st);SeekBar ss=new SeekBar(this);ss.setMax(99);ss.setProgress(speedVal[0]-1);root.addView(ss);
        ss.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){speedVal[0]=p+1;st.setText("Speed: "+speedVal[0]);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        TextView bt=text("Brightness: "+briVal[0],14,Color.WHITE,Typeface.NORMAL);root.addView(bt);SeekBar bs=new SeekBar(this);bs.setMax(99);bs.setProgress(briVal[0]-1);root.addView(bs);
        bs.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){briVal[0]=p+1;bt.setText("Brightness: "+briVal[0]);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});

        LinearLayout bottom=row();Button cancel=darkButton("BATAL");Button save=blueButton("SIMPAN COLLECT");bottom.addView(cancel,weight());bottom.addView(save,weight());root.addView(bottom,lp(-1,-2,0,8,0,0));
        cancel.setOnClickListener(v->d.dismiss());
        save.setOnClickListener(v->{ if(pending.isEmpty()) pending.add(picker.getValue()); CollectGroup cg=new CollectGroup(pending,speedVal[0],briVal[0]); if(editIndex>=0&&editIndex<collectGroups.size()) collectGroups.set(editIndex,cg); else collectGroups.add(cg); saveCollectGroups(); if(ui!=null)ui.invalidate(); d.dismiss();});
        d.setContentView(root);d.show();if(d.getWindow()!=null){d.getWindow().setLayout(-1,-1);d.getWindow().setBackgroundDrawable(round(Color.TRANSPARENT,0,Color.TRANSPARENT,0));}
    }

    private void runCollect(int index) {
        if(index<0||index>=collectGroups.size())return;
        CollectGroup g=collectGroups.get(index);
        if(g.modes.isEmpty())return;
        int gen=++collectRunGeneration;
        sendSimple(0x02,g.speed,0x03);
        main.postDelayed(()->sendSimple(0x01,g.brightness,0x03),70);
        for(int i=0;i<g.modes.size();i++){
            final int mode=g.modes.get(i); final int delay=180+i*3000;
            main.postDelayed(()->{if(gen==collectRunGeneration)sendMode(mode,0x03);},delay);
        }
        toast("Collect "+(index+1)+" berjalan: "+modeListString(g.modes));
    }

    // ---------------------------------------------------------------------
    // Settings actions
    // ---------------------------------------------------------------------
    private void showLedCountDialog() {
        EditText input=new EditText(this);input.setInputType(InputType.TYPE_CLASS_NUMBER);input.setText(String.valueOf(prefs.getInt("led_count",75)));input.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("Chip settings - jumlah LED").setView(input).setNegativeButton("Batal",null).setPositiveButton("Terapkan",(d,w)->{
            try{int count=clamp(Integer.parseInt(input.getText().toString().trim()),1,1000);prefs.edit().putInt("led_count",count).apply();sendLedCount(count);toast("Jumlah LED: "+count);}catch(Exception e){toast("Jumlah LED tidak valid");}
        }).show();
    }

    private void resetAppSettings() {
        prefs.edit().remove("collect_groups").remove("speed").remove("brightness").remove("rgb_r").remove("rgb_g").remove("rgb_b").apply();
        collectGroups.clear();globalSpeed=70;globalBrightness=70;rgbR=255;rgbG=50;rgbB=0;selectedChannel=0x03;profile=0;
        if(ui!=null){ui.settingsOpen=false;ui.invalidate();}toast("Pengaturan aplikasi direset");
    }

    private void openOta() {
        try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(OTA_URL)));}catch(Exception e){toast("Browser tidak tersedia");}
    }

    // ---------------------------------------------------------------------
    // BLE
    // ---------------------------------------------------------------------
    private void connectLedcar() {
        if(btAdapter==null){toast("Bluetooth tidak tersedia");return;}
        if(!hasBtPermissions()){requestBtPermissions();return;}
        if(!btAdapter.isEnabled()){toast("Aktifkan Bluetooth");try{startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));}catch(Exception ignored){}return;}
        scanner=btAdapter.getBluetoothLeScanner();if(scanner==null){toast("BLE scanner tidak tersedia");return;}
        if(scanning)return;scanning=true;toast("Mencari LEDCAR-02-9931...");
        try{scanner.startScan(scanCallback);}catch(SecurityException e){requestBtPermissions();return;}
        main.postDelayed(()->{if(scanning){stopScan();toast("LEDCAR belum ditemukan");}},12000);
    }

    private final ScanCallback scanCallback=new ScanCallback(){
        @Override public void onScanResult(int callbackType,ScanResult result){
            BluetoothDevice device=result.getDevice();String name=null;
            try{if(hasBtPermissions())name=device.getName();}catch(SecurityException ignored){}
            boolean nm=name!=null&&(name.toUpperCase(Locale.ROOT).contains("LEDCAR")||name.toUpperCase(Locale.ROOT).contains("LEDLAMP")||name.toUpperCase(Locale.ROOT).contains("WARDAN"));
            boolean svc=false;if(result.getScanRecord()!=null&&result.getScanRecord().getServiceUuids()!=null){for(ParcelUuid u:result.getScanRecord().getServiceUuids()){if(SERVICE_FFE0.equals(u.getUuid())){svc=true;break;}}}
            if(nm||svc){stopScan();connectGatt(device);}
        }
        @Override public void onScanFailed(int errorCode){scanning=false;toast("Scan BLE gagal: "+errorCode);}
    };

    private void connectGatt(BluetoothDevice d){
        if(!hasBtPermissions()){requestBtPermissions();return;}
        try{if(gatt!=null){gatt.close();gatt=null;}ffe1=null;gatt=d.connectGatt(this,false,gattCallback,BluetoothDevice.TRANSPORT_LE);}catch(SecurityException e){requestBtPermissions();}
    }

    private final BluetoothGattCallback gattCallback=new BluetoothGattCallback(){
        @Override public void onConnectionStateChange(BluetoothGatt g,int status,int newState){
            if(newState==BluetoothProfile.STATE_CONNECTED){bleConnected=true;main.post(()->{if(ui!=null)ui.invalidate();toast("LEDCAR terhubung");});try{g.discoverServices();}catch(SecurityException ignored){}}
            else if(newState==BluetoothProfile.STATE_DISCONNECTED){bleConnected=false;ffe1=null;main.post(()->{if(ui!=null)ui.invalidate();toast("LEDCAR terputus");});}
        }
        @Override public void onServicesDiscovered(BluetoothGatt g,int status){if(status==BluetoothGatt.GATT_SUCCESS){BluetoothGattService s=g.getService(SERVICE_FFE0);if(s!=null)ffe1=s.getCharacteristic(CHAR_FFE1);main.post(()->{if(ffe1!=null)toast("FFE1 siap");else toast("FFE1 tidak ditemukan");});}}
    };

    private void disconnectBle(){stopScan();bleConnected=false;collectRunGeneration++;if(gatt!=null){try{if(hasBtPermissions())gatt.disconnect();}catch(SecurityException ignored){}try{gatt.close();}catch(Exception ignored){}gatt=null;}ffe1=null;if(ui!=null)ui.invalidate();}
    private void stopScan(){scanning=false;if(scanner!=null&&hasBtPermissions()){try{scanner.stopScan(scanCallback);}catch(SecurityException ignored){}}}
    private boolean hasBtPermissions(){if(Build.VERSION.SDK_INT>=31)return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
    private void requestBtPermissions(){if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ_BT);}
    @Override public void onRequestPermissionsResult(int req,String[] permissions,int[] grants){super.onRequestPermissionsResult(req,permissions,grants);if(req==REQ_BT){if(hasBtPermissions())connectLedcar();else toast("Izin Bluetooth diperlukan");}}

    // ---------------------------------------------------------------------
    // Firmware packet helpers - sesuai mayarota(1).ino
    // ---------------------------------------------------------------------
    private byte[] packet(){byte[] p=new byte[9];p[0]=0x7B;p[7]=0x03;p[8]=(byte)0xBF;return p;}
    private void sendMode(int mode,int ch){sendSimple(0x03,mode,ch);}
    private void sendRgb(int r,int g,int b,int ch){byte[] p=packet();p[1]=0x07;p[2]=(byte)r;p[3]=(byte)g;p[4]=(byte)b;p[7]=(byte)ch;write(p);}
    private void sendSimple(int cmd,int value,int ch){byte[] p=packet();p[1]=(byte)cmd;p[2]=(byte)value;p[7]=(byte)ch;write(p);}
    private void sendRemTarget(int cmd,int value){byte[] p=packet();p[1]=(byte)cmd;p[2]=(byte)value;p[3]=0x04;p[7]=(byte)0x03;write(p);}
    private void sendLedCount(int count){byte[] p=packet();p[1]=0x05;p[3]=(byte)((count>>8)&0xFF);p[4]=(byte)(count&0xFF);p[7]=0x03;write(p);}
    private void sendSubareaDouble(int area){sendSimple(0x14,area,0x03);main.postDelayed(()->sendSimple(0x14,area,0x03),140);}
    private void write(byte[] data){
        if(gatt==null||ffe1==null){toast("Tekan ▶ untuk hubungkan modul");return;}
        try{int props=ffe1.getProperties();int wt=(props&BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)!=0?BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE:BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;if(Build.VERSION.SDK_INT>=33){int rc=gatt.writeCharacteristic(ffe1,data,wt);if(rc!=0)toast("BLE write gagal: "+rc);}else{ffe1.setWriteType(wt);ffe1.setValue(data);if(!gatt.writeCharacteristic(ffe1))toast("BLE write gagal");}}catch(SecurityException e){requestBtPermissions();}catch(Exception e){toast("Gagal kirim BLE");}
    }

    // ---------------------------------------------------------------------
    // Persistence
    // ---------------------------------------------------------------------
    private void loadState(){selectedChannel=prefs.getInt("channel",0x03);profile=prefs.getInt("profile",0);globalSpeed=prefs.getInt("speed",70);globalBrightness=prefs.getInt("brightness",70);rgbR=prefs.getInt("rgb_r",255);rgbG=prefs.getInt("rgb_g",50);rgbB=prefs.getInt("rgb_b",0);moduleLocked=prefs.getBoolean("module_lock",false);}
    private void saveState(){prefs.edit().putInt("channel",selectedChannel).putInt("profile",profile).putInt("speed",globalSpeed).putInt("brightness",globalBrightness).putInt("rgb_r",rgbR).putInt("rgb_g",rgbG).putInt("rgb_b",rgbB).putBoolean("module_lock",moduleLocked).apply();}
    private void loadCollectGroups(){collectGroups.clear();String raw=prefs.getString("collect_groups","");if(raw==null||raw.isEmpty())return;String[] groups=raw.split("#");for(String s:groups){String[] parts=s.split("\\|");if(parts.length!=3)continue;try{ArrayList<Integer> modes=new ArrayList<>();for(String m:parts[0].split(",")){int v=Integer.parseInt(m);if(v>=1&&v<=210)modes.add(v);}int sp=clamp(Integer.parseInt(parts[1]),1,100),br=clamp(Integer.parseInt(parts[2]),1,100);if(!modes.isEmpty())collectGroups.add(new CollectGroup(modes,sp,br));}catch(Exception ignored){}}}
    private void saveCollectGroups(){StringBuilder out=new StringBuilder();for(int i=0;i<collectGroups.size();i++){if(i>0)out.append('#');CollectGroup g=collectGroups.get(i);for(int j=0;j<g.modes.size();j++){if(j>0)out.append(',');out.append(g.modes.get(j));}out.append('|').append(g.speed).append('|').append(g.brightness);}prefs.edit().putString("collect_groups",out.toString()).apply();}
    private String modeListString(List<Integer> modes){if(modes==null||modes.isEmpty())return "-";StringBuilder s=new StringBuilder();for(int i=0;i<modes.size();i++){if(i>0)s.append(" • ");s.append(modes.get(i));}return s.toString();}
    private static class CollectGroup{final ArrayList<Integer> modes;final int speed,brightness;CollectGroup(List<Integer> m,int s,int b){modes=new ArrayList<>(m);speed=s;brightness=b;}}

    // ---------------------------------------------------------------------
    // Drawing helpers
    // ---------------------------------------------------------------------
    private void drawText(Canvas c,String text,float x,float y,float size,int color,Paint.Align align,boolean bold){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);q.setColor(color);q.setTextSize(size);q.setTextAlign(align);q.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(text,x,y,q);}
    private void drawBack(Canvas c,float x,float y){Paint q=linePaint(Color.WHITE,5f);Path path=new Path();path.moveTo(x+16*scaleX(),y-30*scaleY());path.lineTo(x-16*scaleX(),y);path.lineTo(x+16*scaleX(),y+30*scaleY());c.drawPath(path,q);}
    private float scaleX(){return ui==null?1f:ui.sx();}private float scaleY(){return ui==null?1f:ui.sy();}
    private Paint linePaint(int color,float width){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);q.setColor(color);q.setStyle(Paint.Style.STROKE);q.setStrokeCap(Paint.Cap.ROUND);q.setStrokeJoin(Paint.Join.ROUND);q.setStrokeWidth(width*scaleX());return q;}
    private void drawPlayPause(Canvas c,float x,float y,boolean pause){Paint q=linePaint(Color.WHITE,4f);c.drawCircle(x,y,25*scaleX(),q);if(pause){c.drawLine(x-7*scaleX(),y-12*scaleY(),x-7*scaleX(),y+12*scaleY(),q);c.drawLine(x+7*scaleX(),y-12*scaleY(),x+7*scaleX(),y+12*scaleY(),q);}else{Path t=new Path();t.moveTo(x-7*scaleX(),y-13*scaleY());t.lineTo(x+13*scaleX(),y);t.lineTo(x-7*scaleX(),y+13*scaleY());t.close();c.drawPath(t,q);}}
    private void drawGear(Canvas c,float x,float y,float r,int color){Paint q=linePaint(color,3f);c.drawCircle(x,y,r*0.55f,q);c.drawCircle(x,y,r*0.95f,q);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=x+(float)Math.cos(a)*r*0.95f,y1=y+(float)Math.sin(a)*r*0.95f;float x2=x+(float)Math.cos(a)*r*1.2f,y2=y+(float)Math.sin(a)*r*1.2f;c.drawLine(x1,y1,x2,y2,q);}}
    private void drawRotate(Canvas c,float x,float y){Paint q=linePaint(Color.WHITE,5f);RectF r=new RectF(x-25*scaleX(),y-25*scaleY(),x+25*scaleX(),y+25*scaleY());c.drawArc(r,25,260,false,q);Path a=new Path();a.moveTo(x+22*scaleX(),y-23*scaleY());a.lineTo(x+7*scaleX(),y-25*scaleY());a.lineTo(x+18*scaleX(),y-9*scaleY());c.drawPath(a,q);}
    private void drawChevron(Canvas c,float x,float y){Paint q=linePaint(Color.rgb(110,110,110),2f);Path p=new Path();p.moveTo(x-8*scaleX(),y-12*scaleY());p.lineTo(x+5*scaleX(),y);p.lineTo(x-8*scaleX(),y+12*scaleY());c.drawPath(p,q);}
    private void drawArrow(Canvas c,float x,float y,boolean right){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);q.setColor(Color.WHITE);q.setStyle(Paint.Style.FILL);float s=right?1:-1;Path p=new Path();p.moveTo(x+s*25*scaleX(),y);p.lineTo(x-s*5*scaleX(),y-22*scaleY());p.lineTo(x-s*5*scaleX(),y-10*scaleY());p.lineTo(x-s*28*scaleX(),y-10*scaleY());p.lineTo(x-s*28*scaleX(),y+10*scaleY());p.lineTo(x-s*5*scaleX(),y+10*scaleY());p.lineTo(x-s*5*scaleX(),y+22*scaleY());p.close();c.drawPath(p,q);}
    private void drawToggle(Canvas c,float x,float y,boolean on){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);q.setColor(on?Color.GREEN:Color.DKGRAY);c.drawRoundRect(new RectF(x-52*scaleX(),y-22*scaleY(),x+52*scaleX(),y+22*scaleY()),22*scaleY(),22*scaleY(),q);q.setColor(Color.WHITE);c.drawCircle(x+(on?29:-29)*scaleX(),y,20*scaleY(),q);}
    private void drawRgbIcon(Canvas c,float x,float y,float r){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);int[] cs={Color.WHITE,Color.LTGRAY,Color.DKGRAY,Color.WHITE};q.setShader(new SweepGradient(x,y,cs,null));c.drawCircle(x,y,r,q);q.setShader(null);}
    private void drawSnowflake(Canvas c,float x,float y,float r,int color){Paint q=linePaint(color,2.5f);for(int i=0;i<6;i++){double a=i*Math.PI/3;float x2=x+(float)Math.cos(a)*r,y2=y+(float)Math.sin(a)*r;c.drawLine(x,y,x2,y2,q);}}
    private void drawCustomIcon(Canvas c,float x,float y,float r,int color){Paint q=linePaint(color,2.5f);c.drawCircle(x,y,r,q);c.drawLine(x-r*.45f,y+r*.35f,x+r*.45f,y-r*.45f,q);}

    // ---------------------------------------------------------------------
    // Android UI helpers
    // ---------------------------------------------------------------------
    private TextView text(String s,int sp,int color,int style){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setTypeface(Typeface.create("sans",style));return t;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
    private LinearLayout.LayoutParams weight(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f);p.setMargins(dp(2),0,dp(2),0);return p;}
    private FrameLayout.LayoutParams match(){return new FrameLayout.LayoutParams(-1,-1);}
    private LinearLayout.LayoutParams lp(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
    private Button darkButton(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(dp(8),dp(9),dp(8),dp(9));b.setBackground(round(Color.rgb(22,30,38),8,Color.rgb(80,100,115),1));return b;}
    private Button blueButton(String s){Button b=darkButton(s);b.setBackground(round(Color.rgb(8,150,225),8,Color.rgb(8,150,225),1));return b;}
    private NumberPicker picker(int min,int max,int value){NumberPicker n=new NumberPicker(this);n.setMinValue(min);n.setMaxValue(max);n.setValue(value);n.setWrapSelectorWheel(false);n.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);if(Build.VERSION.SDK_INT>=29)n.setTextColor(Color.WHITE);return n;}
    private GradientDrawable round(int fill,int radiusDp,int stroke,int strokeDp){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radiusDp));if(strokeDp>0)d.setStroke(dp(strokeDp),stroke);return d;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private int clamp(int v,int min,int max){return Math.max(min,Math.min(max,v));}
    private void toast(String s){main.post(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}

    @Override protected void onDestroy(){disconnectBle();super.onDestroy();}
}
