package com.wardanlighting.control;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {

    private static final UUID SERVICE_FFE0 = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    private static final UUID CHAR_FFE1 = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");
    private static final String OTA_URL = "https://ledcar-ota.usmannurdiansyah.workers.dev";
    private static final int REQ_BT = 1001;

    private final Handler main = new Handler(Looper.getMainLooper());
    private BluetoothAdapter btAdapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic ffe1;
    private boolean scanning = false;
    private boolean bleConnected = false;

    private SharedPreferences prefs;
    private FrameLayout safeRoot;
    private OriginalUiView ui;

    private int selectedChannel = 0x03; // ALL
    private int profile = 0; // 0 LEDCAR (CH1/CH2), 1 DMX (CH3/CH4)
    private int globalSpeed = 70;
    private int globalBrightness = 70;
    private int rgbR = 255, rgbG = 50, rgbB = 0;
    private boolean moduleLocked = false;

    private final ArrayList<CollectGroup> collectGroups = new ArrayList<>();
    private int collectRunGeneration = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("wardan_lighting", MODE_PRIVATE);
        loadState();
        loadCollectGroups();

        Window w = getWindow();
        w.setStatusBarColor(Color.BLACK);
        w.setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= 29) {
            w.setNavigationBarContrastEnforced(false);
            w.setStatusBarContrastEnforced(false);
        }
        enableImmersiveUi();

        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        btAdapter = manager != null ? manager.getAdapter() : null;

        showSplash();
    }


    private void enableImmersiveUi() {
        // V03: status bar tetap fullscreen seperti V02,
        // tetapi navigation bar HP jangan disembunyikan / ditimpa aplikasi.
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enableImmersiveUi();
    }

    // ---------------------------------------------------------------------
    // SAFE ROOT: seluruh UI berada DI ATAS tombol navigasi HP dan DI BAWAH status bar.
    // ---------------------------------------------------------------------
    private FrameLayout makeSafeRoot() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l = 0, t = 0, r = 0, b = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                l = bars.left; t = bars.top; r = bars.right; b = bars.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft();
                t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight();
                b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return insets;
        });
        root.requestApplyInsets();
        root.post(root::requestApplyInsets);
        return root;
    }

    // ---------------------------------------------------------------------
    // SPLASH + PASSWORD / KUNCI GESER
    // ---------------------------------------------------------------------
    private void showSplash() {
        safeRoot = makeSafeRoot();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.rgb(0, 7, 18));
        box.setPadding(dp(22), dp(20), dp(22), dp(20));

        TextView wl = text("WL", 66, Color.WHITE, Typeface.BOLD);
        wl.setGravity(Gravity.CENTER);
        box.addView(wl);
        TextView title = text("WARDAN LIGHTING", 24, Color.rgb(80, 195, 255), Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.08f);
        box.addView(title);
        TextView sub = text("LIGHTING YOUR RIDE", 10, Color.rgb(150, 190, 220), Typeface.BOLD);
        sub.setGravity(Gravity.CENTER);
        sub.setLetterSpacing(0.16f);
        box.addView(sub, lp(-1, -2, 0, 7, 0, 0));

        safeRoot.addView(box, match());
        setContentView(safeRoot);
        main.postDelayed(() -> { if (prefs.getString("local_password", "").isEmpty()) showMain(); else showLock(); }, 350);
    }

    private void showLock() {
        safeRoot = makeSafeRoot();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(28), dp(60), dp(28), dp(25));
        box.setBackgroundColor(Color.rgb(0, 7, 18));

        TextView wl = text("WL", 58, Color.WHITE, Typeface.BOLD);
        wl.setGravity(Gravity.CENTER);
        box.addView(wl);
        TextView name = text("Wardan Lighting", 24, Color.WHITE, Typeface.BOLD);
        name.setGravity(Gravity.CENTER);
        box.addView(name, lp(-1, -2, 0, 2, 0, 26));

        TextView lockTitle = text("Geser untuk membuka", 14, Color.WHITE, Typeface.BOLD);
        lockTitle.setGravity(Gravity.CENTER);
        box.addView(lockTitle, lp(-1, -2, 0, 0, 0, 8));

        EditText pass = new EditText(this);
        pass.setHint("Password");
        pass.setHintTextColor(Color.rgb(130, 145, 160));
        pass.setTextColor(Color.WHITE);
        pass.setSingleLine(true);
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        pass.setBackground(round(Color.rgb(7, 21, 34), 12, Color.rgb(45, 83, 105), 1));
        pass.setPadding(dp(14), dp(11), dp(14), dp(11));
        box.addView(pass, lp(-1, -2, 0, 0, 0, 16));

        TextView sliderLabel = text("🔒     GESER KE KANAN     →", 13, Color.rgb(83, 194, 255), Typeface.BOLD);
        sliderLabel.setGravity(Gravity.CENTER);
        box.addView(sliderLabel);

        SeekBar unlock = new SeekBar(this);
        unlock.setMax(100);
        unlock.setProgress(0);
        unlock.setMinimumHeight(dp(64));
        unlock.setPadding(dp(4), dp(12), dp(4), dp(12));
        box.addView(unlock, lp(-1, dp(68), 0, 2, 0, 4));

        final boolean[] opening = {false};
        unlock.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            private void tryOpen(SeekBar seekBar) {
                if (opening[0] || seekBar.getProgress() < 92) return;
                String saved = prefs.getString("local_password", "");
                if (!saved.isEmpty() && !saved.equals(pass.getText().toString())) {
                    toast("Password salah");
                    seekBar.setProgress(0);
                    return;
                }
                opening[0] = true;
                sliderLabel.setText("TERBUKA ✓");
                main.postDelayed(MainActivity.this::showMain, 100);
            }

            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                sliderLabel.setText(progress >= 92 ? "LEPAS UNTUK MEMBUKA ✓" : "🔒     GESER KE KANAN     →");
                if (progress >= 98) tryOpen(seekBar);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                if (seekBar.getProgress() >= 92) tryOpen(seekBar);
                else {
                    seekBar.setProgress(0);
                    sliderLabel.setText("🔒     GESER KE KANAN     →");
                }
            }
        });

        safeRoot.addView(box, match());
        setContentView(safeRoot);
    }

    private void showMain() {
        safeRoot = makeSafeRoot();
        ui = new OriginalUiView(this);
        safeRoot.addView(ui, match());
        setContentView(safeRoot);
    }

    // ---------------------------------------------------------------------
    // ORIGINAL-LIKE UI: placement dan ikon mengikuti screenshot bawaan.
    // ---------------------------------------------------------------------

    private class OriginalUiView extends View {
        private static final float RW = 285f;
        private static final float RH = 610f;

        private final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint overlayPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Bitmap homeBmp;
        private final Bitmap settingsBmp;
        private final Bitmap collectBmp;
        private final Bitmap modeBmp;
        private final Bitmap otaBmp;

        // 0 HOME/RGB, 1 SETTINGS, 2 COLLECT, 3 MODE, 4 OTA
        private int screen = 0;
        boolean settingsOpen = false;

        private float downX, downY;
        private long downAt;
        private int modeFirst = 1;
        private int modeSelected = 1;
        private boolean lampOn = true;
        private boolean passwordDragging = false;
        private int dragSlider = 0; // 1 home bri, 2 mode speed, 3 mode bri, 4 collect speed, 5 collect bri
        private long lastSliderSendAt = 0L;

        // V02: smooth single-list Mode 1..210.
        private boolean modeScrolling = false;
        private boolean modeScrollMoved = false;
        private float modeLastY = 0f;
        private float modeDownY = 0f;
        private float modeScrollOffset = 0f;
        private static final float MODE_ROW_H = 43.0f;
        private static final float MODE_LIST_TOP = 112.0f;
        private static final float MODE_LIST_BOTTOM = 444.0f;

        // V03: Collect dinamis. Maksimal 5 terlihat, sisanya scroll ke bawah.
        private boolean collectScrolling = false;
        private boolean collectScrollMoved = false;
        private float collectLastY = 0f;
        private float collectDownY = 0f;
        private float collectScrollOffset = 0f;
        private int collectFirst = 0;
        private static final float COLLECT_ROW_H = 45.2f;
        private static final float COLLECT_LIST_TOP = 70.0f;
        private static final float COLLECT_LIST_BOTTOM = 296.0f;
        private float passwordDragX = 0f;
        private boolean colorWheelDragging = false;
        private long lastColorSendAt = 0L;

        OriginalUiView(Context c) {
            super(c);
            // Hardware rendering tetap aktif supaya pergantian menu ringan/responsif.
            homeBmp = decodeUi("ui_home");
            settingsBmp = decodeUi("ui_settings");
            collectBmp = decodeUi("ui_collect");
            modeBmp = decodeUi("ui_mode");
            otaBmp = decodeUi("ui_ota");
        }

        private Bitmap decodeUi(String name) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inPreferredConfig = Bitmap.Config.RGB_565;
            o.inScaled = false;
            int id = getResources().getIdentifier(name, "drawable", getPackageName());
            return BitmapFactory.decodeResource(getResources(), id, o);
        }

        float sx() { return getWidth() / RW; }
        float sy() { return getHeight() / RH; }
        float X(float x) { return x * sx(); }
        float Y(float y) { return y * sy(); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            Bitmap b = homeBmp;
            if (screen == 1) b = settingsBmp;
            else if (screen == 2) b = collectBmp;
            else if (screen == 3) b = modeBmp;
            else if (screen == 4) b = otaBmp;

            if (b != null) {
                c.drawBitmap(b, null, new RectF(0, 0, getWidth(), getHeight()), bitmapPaint);
            } else {
                c.drawColor(Color.rgb(0, 9, 20));
            }

            if (screen == 0) {
                drawHomeChannelOverlay(c);
                drawColorWheelSelector(c);
                drawLiveSlider(c, 44f, 236f, 385.5f, globalBrightness, 141.7f, true);
            }
            if (screen == 1) drawPasswordSwitch(c);
            if (screen == 2) {
                drawCollectDynamicList(c);
                drawLiveSlider(c, 61f, 231f, 459.7f, globalSpeed, 134.8f, true);
                drawLiveSlider(c, 61f, 231f, 508.8f, globalBrightness, 134.7f, true);
            }
            if (screen == 3) {
                drawModeSingleList(c);
                drawModeChannelOverlay(c);
                drawLiveSlider(c, 58f, 230f, 471.3f, globalSpeed, 132.7f, true);
                drawLiveSlider(c, 58f, 230f, 519.6f, globalBrightness, 132.7f, true);
            }

            // Small connected indicator uses the existing logo/header area without adding a new button.
            if (screen == 0 && bleConnected) {
                overlayPaint.setColor(Color.rgb(0, 235, 150));
                c.drawCircle(X(273), Y(14), X(3.3f), overlayPaint);
            }
        }


        private static final float COLOR_CX = 143f;
        private static final float COLOR_CY = 228f;
        private static final float COLOR_R = 78f;

        private boolean isOnColorWheel(float x, float y) {
            float dx = x - COLOR_CX;
            float dy = y - COLOR_CY;
            float r = (float)Math.sqrt(dx * dx + dy * dy);
            return r >= 55f && r <= 104f;
        }

        private void updateColorFromWheel(float x, float y, boolean forceSend) {
            double deg = Math.toDegrees(Math.atan2(y - COLOR_CY, x - COLOR_CX));
            float hue = (float)(240.0 - deg);
            while (hue < 0f) hue += 360f;
            while (hue >= 360f) hue -= 360f;

            int color = Color.HSVToColor(new float[]{hue, 1f, 1f});
            rgbR = Color.red(color);
            rgbG = Color.green(color);
            rgbB = Color.blue(color);

            long now = System.currentTimeMillis();
            if (forceSend || now - lastColorSendAt >= 28L) {
                lastColorSendAt = now;
                sendRgb(rgbR, rgbG, rgbB, selectedChannel);
            }
            invalidate();
        }

        private void drawColorWheelSelector(Canvas c) {
            float[] hsv = new float[3];
            Color.RGBToHSV(rgbR, rgbG, rgbB, hsv);
            double rad = Math.toRadians(240.0 - hsv[0]);
            float px = COLOR_CX + (float)Math.cos(rad) * COLOR_R;
            float py = COLOR_CY + (float)Math.sin(rad) * COLOR_R;

            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.BLACK);
            c.drawCircle(X(px), Y(py), X(6.2f), p);
            p.setColor(Color.WHITE);
            c.drawCircle(X(px), Y(py), X(4.1f), p);
        }

        private void drawHomeChannelOverlay(Canvas c) {
            // V02: cover FULL old LED1/ALL/LED2/Collect artwork so nothing "ngbayang".
            Paint cover = new Paint(Paint.ANTI_ALIAS_FLAG);
            cover.setColor(Color.rgb(0, 12, 24));
            c.drawRoundRect(new RectF(X(5),Y(78),X(280),Y(129)),X(7),Y(7),cover);

            final float y1 = 82f, y2 = 119f;
            final float[] cuts = {8f, 53f, 98f, 143f, 188f, 233f, 278f};
            final String[] labels = {"LED1","LED2","LED3","LED4","ALL","Collect"};
            final int[] codes = {0x01,0x02,0x04,0x05,0x03,-1};

            Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
            border.setStyle(Paint.Style.STROKE);
            border.setStrokeWidth(Math.max(1.0f, X(0.65f)));
            border.setColor(Color.rgb(58, 112, 145));
            c.drawRoundRect(new RectF(X(cuts[0]),Y(y1),X(cuts[6]),Y(y2)),X(6),Y(6),border);

            for (int i=0;i<6;i++) {
                boolean active = i < 5 && selectedChannel == codes[i];
                Paint cell = new Paint(Paint.ANTI_ALIAS_FLAG);
                cell.setColor(active ? Color.rgb(0,132,242) : Color.rgb(1,18,31));
                c.drawRoundRect(new RectF(X(cuts[i]+0.7f),Y(y1+0.7f),X(cuts[i+1]-0.7f),Y(y2-0.7f)),
                        X(4.5f),Y(4.5f),cell);

                if (i > 0) c.drawLine(X(cuts[i]),Y(y1+3),X(cuts[i]),Y(y2-3),border);
                drawText(c, labels[i], X((cuts[i]+cuts[i+1])/2f), Y(105f),
                        X(i==5 ? 6.6f : 7.0f), Color.WHITE, Paint.Align.CENTER, active);
            }
        }

        private void drawCollectDynamicList(Canvas c) {
            // V03: tutup lima baris statis bawaan, lalu gambar sesuai data Collect sebenarnya.
            Paint cover = new Paint(Paint.ANTI_ALIAS_FLAG);
            cover.setColor(Color.rgb(0, 12, 24));
            c.drawRoundRect(new RectF(X(5),Y(67),X(280),Y(299)),X(6),Y(6),cover);

            int save = c.save();
            c.clipRect(X(6),Y(COLLECT_LIST_TOP),X(279),Y(COLLECT_LIST_BOTTOM));

            int total = collectGroups.size();
            int maxFirst = Math.max(0, total - 5);
            if (collectFirst > maxFirst) collectFirst = maxFirst;
            if (collectFirst < 0) collectFirst = 0;

            for (int row=-1; row<=5; row++) {
                int idx = collectFirst + row;
                if (idx < 0 || idx >= total) continue;

                float top = COLLECT_LIST_TOP + row * COLLECT_ROW_H + collectScrollOffset;
                if (top > COLLECT_LIST_BOTTOM || top + 41f < COLLECT_LIST_TOP) continue;

                CollectGroup g = collectGroups.get(idx);

                Paint card = new Paint(Paint.ANTI_ALIAS_FLAG);
                card.setColor(Color.rgb(2, 27, 45));
                c.drawRoundRect(new RectF(X(8),Y(top+1),X(276),Y(top+42)),X(5),Y(5),card);

                Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
                border.setStyle(Paint.Style.STROKE);
                border.setStrokeWidth(Math.max(0.9f,X(0.6f)));
                border.setColor(Color.rgb(28, 91, 125));
                c.drawRoundRect(new RectF(X(8),Y(top+1),X(276),Y(top+42)),X(5),Y(5),border);

                // Nomor Collect.
                drawText(c, String.valueOf(idx+1), X(58), Y(top+28),
                        X(11.5f), Color.WHITE, Paint.Align.CENTER, true);

                // Preview sederhana berdasarkan mode yang tersimpan.
                drawCollectPreview(c, g, top);

                // Panah jalankan.
                drawText(c, "›", X(215), Y(top+29),
                        X(16f), Color.WHITE, Paint.Align.CENTER, false);

                // Ikon hapus sederhana, area sentuh tetap besar.
                Paint trash = new Paint(Paint.ANTI_ALIAS_FLAG);
                trash.setStyle(Paint.Style.STROKE);
                trash.setStrokeWidth(Math.max(1.2f, X(0.8f)));
                trash.setColor(Color.rgb(220,230,238));
                c.drawRect(X(249),Y(top+14),X(258),Y(top+28),trash);
                c.drawLine(X(247),Y(top+12),X(260),Y(top+12),trash);
                c.drawLine(X(251),Y(top+9),X(256),Y(top+9),trash);
            }

            c.restoreToCount(save);
        }

        private void drawCollectPreview(Canvas c, CollectGroup g, float top) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            int[] colors = {
                    Color.rgb(0,225,255), Color.rgb(0,255,135),
                    Color.rgb(255,185,0), Color.rgb(255,55,135),
                    Color.rgb(115,80,255)
            };

            int n = Math.min(18, Math.max(6, g.modes.size() * 3));
            for (int i=0; i<n; i++) {
                int mode = g.modes.isEmpty() ? 1 : g.modes.get(i % g.modes.size());
                p.setColor(colors[Math.abs(mode) % colors.length]);

                float t = i / (float)Math.max(1, n-1);
                float x = 84f + t * 91f;
                float y = top + 21f
                        + (float)Math.sin((t * Math.PI * 2.0) + mode * 0.21) * 7f;
                c.drawCircle(X(x),Y(y),X(1.6f),p);
            }
        }

        private void drawModeChannelOverlay(Canvas c) {
            // V02: first erase original LED1/LED2 header completely.
            Paint cover=new Paint(Paint.ANTI_ALIAS_FLAG);
            cover.setColor(Color.rgb(0,12,24));
            c.drawRoundRect(new RectF(X(5),Y(72),X(279),Y(110)),X(6),Y(6),cover);

            final float y1=76f, y2=106f;
            final float[] cuts={8f,62f,116f,170f,224f,278f};
            final String[] labels={"LED1","LED2","LED3","LED4","ALL"};
            final int[] codes={0x01,0x02,0x04,0x05,0x03};

            Paint border=new Paint(Paint.ANTI_ALIAS_FLAG);
            border.setStyle(Paint.Style.STROKE);
            border.setStrokeWidth(Math.max(1.0f,X(0.65f)));
            border.setColor(Color.rgb(35,105,145));

            for(int i=0;i<5;i++){
                boolean active=selectedChannel==codes[i];
                Paint cell=new Paint(Paint.ANTI_ALIAS_FLAG);
                cell.setColor(active?Color.rgb(0,132,242):Color.rgb(1,20,34));
                c.drawRoundRect(new RectF(X(cuts[i]),Y(y1),X(cuts[i+1]-2),Y(y2)),
                        X(5),Y(5),cell);
                c.drawRoundRect(new RectF(X(cuts[i]),Y(y1),X(cuts[i+1]-2),Y(y2)),
                        X(5),Y(5),border);
                drawText(c,labels[i],X((cuts[i]+cuts[i+1]-2)/2f),Y(95f),
                        X(7.6f),Color.WHITE,Paint.Align.CENTER,active);
            }
        }

        private void drawModeSingleList(Canvas c) {
            // V02: erase ALL original two-column mode artwork/arrows first.
            Paint cover=new Paint(Paint.ANTI_ALIAS_FLAG);
            cover.setColor(Color.rgb(0,12,24));
            c.drawRoundRect(new RectF(X(4),Y(108),X(280),Y(447)),X(7),Y(7),cover);

            Paint frame=new Paint(Paint.ANTI_ALIAS_FLAG);
            frame.setStyle(Paint.Style.STROKE);
            frame.setStrokeWidth(Math.max(1.0f,X(0.65f)));
            frame.setColor(Color.rgb(21,89,130));
            c.drawRoundRect(new RectF(X(8),Y(111),X(276),Y(445)),X(7),Y(7),frame);

            int save=c.save();
            c.clipRect(X(9),Y(MODE_LIST_TOP),X(275),Y(MODE_LIST_BOTTOM));

            // Draw an extra row above/below so drag is visually continuous.
            for(int i=-1;i<=8;i++){
                int mode=wrap210(modeFirst+i);
                float top=MODE_LIST_TOP + i*MODE_ROW_H + modeScrollOffset;
                if(top > MODE_LIST_BOTTOM || top+38f < MODE_LIST_TOP) continue;

                boolean sel=mode==modeSelected;
                Paint card=new Paint(Paint.ANTI_ALIAS_FLAG);
                card.setColor(sel?Color.rgb(0,92,205):Color.rgb(2,27,45));
                c.drawRoundRect(new RectF(X(14),Y(top+2),X(270),Y(top+39)),X(6),Y(6),card);

                Paint cb=new Paint(Paint.ANTI_ALIAS_FLAG);
                cb.setStyle(Paint.Style.STROKE);
                cb.setStrokeWidth(Math.max(0.9f,X(0.6f)));
                cb.setColor(sel?Color.rgb(35,190,255):Color.rgb(18,70,100));
                c.drawRoundRect(new RectF(X(14),Y(top+2),X(270),Y(top+39)),X(6),Y(6),cb);

                drawEffectPreview(c, mode, 27f, top+9f, 150f, 24f, sel);
                drawText(c,String.valueOf(mode),X(239f),Y(top+28f),
                        X(11.5f),Color.WHITE,Paint.Align.CENTER,true);
            }
            c.restoreToCount(save);
        }

        private void drawEffectPreview(Canvas c,int mode,float left,float top,float width,float height,boolean selected) {
            Paint dot=new Paint(Paint.ANTI_ALIAS_FLAG);
            int[] palette={
                    Color.rgb(0,230,255), Color.rgb(0,255,135), Color.rgb(255,184,0),
                    Color.rgb(255,50,130), Color.rgb(120,80,255), Color.WHITE
            };
            dot.setColor(selected?Color.WHITE:palette[mode%palette.length]);
            final int count=18;
            for(int i=0;i<count;i++){
                float t=i/(float)(count-1);
                float x=left+t*width;
                double a=(t*2.0*Math.PI*(1+(mode%3))) + (mode%11)*0.37;
                float wave=(float)Math.sin(a);
                float y=top+height/2f-wave*(height*0.38f);
                float pulse=0.75f+0.25f*(float)Math.sin((i+mode)*0.65);
                c.drawCircle(X(x),Y(y),X(1.7f*pulse),dot);
            }
        }

        private void drawLiveSlider(Canvas c,float x1,float x2,float y,int value,float oldKnobX,boolean drawValue) {
            // V02: erase the baked-in track + fixed knob before drawing the live one.
            Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(0,14,26));
            c.drawRoundRect(new RectF(X(x1-4),Y(y-10),X(x2+5),Y(y+10)),X(5),Y(5),p);

            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(Math.max(4.0f,Y(3.1f)));
            p.setColor(Color.rgb(94,119,133));
            c.drawLine(X(x1),Y(y),X(x2),Y(y),p);

            float pos=x1+(x2-x1)*(clamp(value,1,100)/100f);
            p.setColor(Color.rgb(0,225,255));
            c.drawLine(X(x1),Y(y),X(pos),Y(y),p);

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE);
            c.drawCircle(X(pos),Y(y),X(6.2f),p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f,X(0.8f)));
            p.setColor(Color.rgb(0,200,255));
            c.drawCircle(X(pos),Y(y),X(7.6f),p);

            if(drawValue){
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.rgb(0,14,26));
                c.drawRect(X(241),Y(y-13),X(278),Y(y+13),p);
                drawText(c,String.valueOf(value),X(258),Y(y+6),
                        X(8.6f),Color.WHITE,Paint.Align.CENTER,false);
            }
        }


        private void drawPasswordSwitch(Canvas c) {
            // V02: erase the original static green switch first => no shadow/double switch.
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(0,14,24));
            c.drawRoundRect(new RectF(X(213),Y(280),X(272),Y(310)),X(5),Y(5),p);

            final float x1=218f, x2=266f, y1=284f, y2=306f;
            p.setColor(moduleLocked ? Color.rgb(0,190,92) : Color.rgb(68,82,92));
            c.drawRoundRect(new RectF(X(x1),Y(y1),X(x2),Y(y2)),X(12),Y(12),p);

            float knobX;
            if (passwordDragging) {
                knobX = Math.max(229f, Math.min(255f, passwordDragX));
            } else {
                knobX = moduleLocked ? 255f : 229f;
            }
            p.setColor(Color.WHITE);
            c.drawCircle(X(knobX),Y((y1+y2)/2f),X(9.0f),p);
        }

        private float rx(MotionEvent e) { return e.getX() / Math.max(1f, getWidth()) * RW; }
        private float ry(MotionEvent e) { return e.getY() / Math.max(1f, getHeight()) * RH; }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x = rx(e), y = ry(e);

            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX = x; downY = y; downAt = System.currentTimeMillis();

                if (screen == 0 && isOnColorWheel(x, y)) {
                    colorWheelDragging = true;
                    updateColorFromWheel(x, y, true);
                    return true;
                }

                if (screen == 1 && y >= 260 && y < 309 && x >= 205) {
                    passwordDragging = true;
                    passwordDragX = x;
                    invalidate();
                    return true;
                }

                if (screen == 0 && y >= 372 && y <= 400) {
                    dragSlider = 1; updateSliderDrag(x, true); return true;
                }
                if (screen == 3 && y >= 456 && y <= 490) {
                    dragSlider = 2; updateSliderDrag(x, true); return true;
                }
                if (screen == 3 && y >= 504 && y <= 538) {
                    dragSlider = 3; updateSliderDrag(x, true); return true;
                }
                if (screen == 2 && y >= 445 && y <= 476) {
                    dragSlider = 4; updateSliderDrag(x, true); return true;
                }
                if (screen == 2 && y >= 494 && y <= 525) {
                    dragSlider = 5; updateSliderDrag(x, true); return true;
                }

                if (screen == 3 && y >= MODE_LIST_TOP && y <= MODE_LIST_BOTTOM) {
                    modeScrolling = true;
                    modeScrollMoved = false;
                    modeLastY = y;
                    modeDownY = y;
                    return true;
                }

                if (screen == 2 && y >= COLLECT_LIST_TOP && y <= COLLECT_LIST_BOTTOM) {
                    collectScrolling = true;
                    collectScrollMoved = false;
                    collectLastY = y;
                    collectDownY = y;
                    return true;
                }
                return true;
            }

            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                if (colorWheelDragging) {
                    updateColorFromWheel(x, y, false);
                    return true;
                }
                if (passwordDragging) {
                    passwordDragX = x;
                    invalidate();
                    return true;
                }
                if (dragSlider != 0) {
                    updateSliderDrag(x, false);
                    return true;
                }
                if (modeScrolling) {
                    float delta = y - modeLastY;
                    modeLastY = y;
                    if (Math.abs(y - modeDownY) > 4f) modeScrollMoved = true;
                    modeScrollOffset += delta;

                    while (modeScrollOffset <= -MODE_ROW_H) {
                        modeFirst = wrap210(modeFirst + 1);
                        modeScrollOffset += MODE_ROW_H;
                    }
                    while (modeScrollOffset >= MODE_ROW_H) {
                        modeFirst = wrap210(modeFirst - 1);
                        modeScrollOffset -= MODE_ROW_H;
                    }
                    invalidate();
                    return true;
                }

                if (collectScrolling) {
                    float delta = y - collectLastY;
                    collectLastY = y;
                    if (Math.abs(y - collectDownY) > 4f) collectScrollMoved = true;

                    int maxFirst = Math.max(0, collectGroups.size() - 5);
                    collectScrollOffset += delta;

                    while (collectScrollOffset <= -COLLECT_ROW_H && collectFirst < maxFirst) {
                        collectFirst++;
                        collectScrollOffset += COLLECT_ROW_H;
                    }
                    while (collectScrollOffset >= COLLECT_ROW_H && collectFirst > 0) {
                        collectFirst--;
                        collectScrollOffset -= COLLECT_ROW_H;
                    }

                    if (collectFirst == 0 && collectScrollOffset > 0f) collectScrollOffset = 0f;
                    if (collectFirst == maxFirst && collectScrollOffset < 0f) collectScrollOffset = 0f;

                    invalidate();
                    return true;
                }
                return true;
            }

            if (e.getAction() != MotionEvent.ACTION_UP) return true;

            float dx = x - downX;
            float dy = y - downY;
            long held = System.currentTimeMillis() - downAt;

            if (colorWheelDragging) {
                updateColorFromWheel(x, y, true);
                colorWheelDragging = false;
                saveState();
                invalidate();
                return true;
            }

            if (passwordDragging) {
                passwordDragging = false;
                moduleLocked = passwordDragX >= 242f;
                sendSimple(0x16,moduleLocked?1:0,0x03);
                saveState();
                invalidate();
                return true;
            }

            if (dragSlider != 0) {
                updateSliderDrag(x, true);
                dragSlider = 0;
                saveState();
                invalidate();
                return true;
            }

            if (modeScrolling) {
                modeScrolling = false;
                if (!modeScrollMoved) {
                    int row = (int)Math.floor((y - MODE_LIST_TOP - modeScrollOffset) / MODE_ROW_H);
                    row = clamp(row, 0, 7);
                    modeSelected = wrap210(modeFirst + row);
                    sendMode(modeSelected, selectedChannel);
                }
                // snap cleanly after finger release; scrolling itself followed the finger during MOVE.
                modeScrollOffset = 0f;
                invalidate();
                return true;
            }

            if (collectScrolling) {
                collectScrolling = false;

                if (!collectScrollMoved) {
                    int row = (int)Math.floor((y - COLLECT_LIST_TOP - collectScrollOffset) / COLLECT_ROW_H);
                    row = clamp(row, 0, 4);
                    int idx = collectFirst + row;

                    if (idx >= 0 && idx < collectGroups.size()) {
                        if (x >= 238f) {
                            // V03: hapus langsung. Tidak ada konfirmasi.
                            collectRunGeneration++;
                            collectGroups.remove(idx);
                            saveCollectGroups();

                            int maxFirst = Math.max(0, collectGroups.size() - 5);
                            if (collectFirst > maxFirst) collectFirst = maxFirst;

                            collectScrollOffset = 0f;
                            invalidate();
                            return true;
                        } else {
                            runCollect(idx);
                            collectScrollOffset = 0f;
                            invalidate();
                            return true;
                        }
                    }
                }

                collectScrollOffset = 0f;
                invalidate();
                return true;
            }

            if (screen == 0) return touchHome(x, y, held);
            if (screen == 1) return touchSettings(x, y);
            if (screen == 2) return touchCollect(x, y);
            if (screen == 3) return touchMode(x, y, dy);
            if (screen == 4) return touchOta(x, y);
            return true;
        }

        private boolean touchHome(float x, float y, long held) {
            // Hamburger kiri atas = drawer channel + koneksi.
            if (x < 62 && y < 78) { showMainDrawer(); return true; }

            // Gear
            if (x > 225 && y < 78) { screen = 1; settingsOpen = true; invalidate(); return true; }

            // LED1 / LED2 / LED3 / LED4 / ALL / Collect.
            if (y >= 70 && y <= 128) {
                final float[] cuts={14f,57f,100f,143f,186f,229f,272f};
                final int[] codes={0x01,0x02,0x04,0x05,0x03};
                int idx=-1;
                for(int i=0;i<6;i++) if(x>=cuts[i] && x<cuts[i+1]) { idx=i; break; }
                if(idx==5){ screen=2; invalidate(); return true; }
                if(idx>=0 && idx<5){
                    selectedChannel=codes[idx];
                    saveState();
                    toast(idx==4?"ALL":("LED"+(idx+1)));
                    invalidate();
                    return true;
                }
            }

            // Center power = BLE connect first, then lamp ON/OFF.
            if (x >= 94 && x <= 191 && y >= 167 && y <= 290) {
                if (!bleConnected) connectLedcar();
                else {
                    lampOn = !lampOn;
                    sendSimple(0x04, lampOn ? 1 : 0, selectedChannel);
                    toast(lampOn ? "Lamp ON" : "Lamp OFF");
                }
                return true;
            }

            // Preset colors
            if (y >= 323 && y <= 365) {
                int[][] cs = {
                        {255,0,0}, {255,160,0}, {0,255,70},
                        {0,230,255}, {0,80,255}, {255,255,255}
                };
                float[] px = {20,49,77,105,134,163};
                for (int i=0;i<px.length;i++) {
                    if (Math.abs(x-px[i]) < 15) {
                        rgbR=cs[i][0]; rgbG=cs[i][1]; rgbB=cs[i][2];
                        sendRgb(rgbR,rgbG,rgbB,selectedChannel); saveState(); return true;
                    }
                }
            }

            // Plus color = custom RGB dialog
            if (x > 178 && y >= 323 && y <= 365) { showRgbDialog(); return true; }

            // Welcome / REM / SET 1-3 / OTA
            if (y >= 414 && y <= 474) {
                if (x < 143) showEffectDialog("WELCOME");
                else showEffectDialog("REM");
                return true;
            }
            if (y >= 480 && y <= 542) {
                if (x < 143) { screen = 1; settingsOpen = true; invalidate(); }
                else { screen = 4; invalidate(); }
                return true;
            }

            // Bottom nav
            if (y >= 548) {
                if (x < 72) { screen = 0; invalidate(); }
                else if (x < 143) { screen = 3; invalidate(); }
                else if (x < 214) { screen = 2; invalidate(); }
                else { screen = 1; settingsOpen = true; invalidate(); }
                return true;
            }
            return true;
        }

        private boolean touchSettings(float x, float y) {
            if (x < 42 && y < 76) { screen = 0; settingsOpen = false; invalidate(); return true; }

            if (y >= 68 && y < 120) { showLedCountDialog(); return true; }
            if (y >= 120 && y < 165) { toast("Timer"); return true; }

            // K1 K2 K3
            if (y >= 164 && y < 211) {
                if (x >= 135 && x < 173) sendSimple(0x11,0x00,0x03);
                else if (x >= 173 && x < 211) sendSimple(0x11,0x01,0x03);
                else if (x >= 211) sendSimple(0x11,0x02,0x03);
                return true;
            }

            // Subarea ← ■ →
            if (y >= 211 && y < 260) {
                if (x < 176) sendSubareaDouble(0x01);
                else if (x < 217) sendSimple(0x14,0x00,0x03);
                else sendSubareaDouble(0x02);
                return true;
            }

            if (y >= 260 && y < 309) {
                moduleLocked = !moduleLocked;
                sendSimple(0x16,moduleLocked?1:0,0x03);
                saveState(); invalidate(); return true;
            }

            if (y >= 309 && y < 356) { screen = 4; invalidate(); return true; }
            if (y >= 356 && y < 405) { toast("Skin restoration"); return true; }
            if (y >= 405 && y < 453) { toast("Change skin"); return true; }
            if (y >= 453 && y < 506) { resetAppSettings(); screen=0; settingsOpen=false; invalidate(); return true; }
            return true;
        }

        private boolean touchCollect(float x, float y) {
            if (x < 42 && y < 72) { screen = 0; invalidate(); return true; }

            // V03: baris Collect ditangani oleh gesture dinamis di onTouchEvent.
            // Tombol Tambah tetap pada area asli V02.
            if (y >= 299 && y <= 421) { showCollectEditor(-1); return true; }

            if (y >= 548) {
                if (x < 72) screen=0;
                else if (x < 143) screen=3;
                else if (x < 214) screen=2;
                else {screen=1;settingsOpen=true;}
                invalidate(); return true;
            }
            return true;
        }

        private boolean touchMode(float x, float y, float dy) {
            if (x < 42 && y < 72) { screen = 0; invalidate(); return true; }
            if (x > 238 && y < 72) { screen = 1; settingsOpen=true; invalidate(); return true; }

            // Channel tabs LED1 LED2 LED3 LED4 ALL.
            if (y >= 68 && y <= 110) {
                final float[] cuts={16f,67f,118f,169f,220f,272f};
                final int[] codes={0x01,0x02,0x04,0x05,0x03};
                for(int i=0;i<5;i++){
                    if(x>=cuts[i] && x<cuts[i+1]){
                        selectedChannel=codes[i];
                        saveState();
                        invalidate();
                        return true;
                    }
                }
            }

            if (y >= 548) {
                if (x < 72) screen=0;
                else if (x < 143) screen=3;
                else if (x < 214) screen=2;
                else {screen=1;settingsOpen=true;}
                invalidate(); return true;
            }
            return true;
        }

        private boolean touchOta(float x, float y) {
            if (x < 42 && y < 72) { screen = 0; invalidate(); return true; }
            if ((y >= 300 && y <= 380) || (y >= 430 && y <= 490)) {
                openOta();
                return true;
            }
            return true;
        }

        private void updateSliderDrag(float x, boolean forceSend) {
            float x1, x2;
            if (dragSlider == 1) { x1=44f; x2=236f; }
            else if (dragSlider == 2 || dragSlider == 3) { x1=58f; x2=230f; }
            else { x1=61f; x2=231f; }
            int value=clamp(Math.round((x-x1)/(x2-x1)*100f),1,100);

            boolean isSpeed = dragSlider==2 || dragSlider==4;
            if(isSpeed) globalSpeed=value; else globalBrightness=value;

            long now=System.currentTimeMillis();
            if(forceSend || now-lastSliderSendAt>=28L){
                lastSliderSendAt=now;
                if(isSpeed) sendSimple(0x02,globalSpeed,selectedChannel);
                else sendSimple(0x01,globalBrightness,selectedChannel);
            }
            invalidate();
        }

        private int wrap210(int v) {
            while (v < 1) v += 210;
            while (v > 210) v -= 210;
            return v;
        }
    }



    private void showMainDrawer() {
        final String[] items = {
                bleConnected ? "BLE: Terhubung" : "Hubungkan BLE",
                "ALL",
                "LED1",
                "LED2",
                "LED3",
                "LED4",
                "Pengaturan"
        };
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Wardan Lighting")
                .setItems(items, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            if (!bleConnected) connectLedcar();
                            else toast("BLE sudah terhubung");
                            break;
                        case 1:
                            selectedChannel = 0x03; saveState();
                            if (ui != null) ui.invalidate();
                            break;
                        case 2:
                            selectedChannel = 0x01; saveState();
                            if (ui != null) ui.invalidate();
                            break;
                        case 3:
                            selectedChannel = 0x02; saveState();
                            if (ui != null) ui.invalidate();
                            break;
                        case 4:
                            selectedChannel = 0x04; saveState();
                            if (ui != null) ui.invalidate();
                            break;
                        case 5:
                            selectedChannel = 0x05; saveState();
                            if (ui != null) ui.invalidate();
                            break;
                        case 6:
                            if (ui != null) { ui.screen = 1; ui.settingsOpen = true; ui.invalidate(); }
                            break;
                    }
                })
                .create();
        d.show();
    }

    private void showRgbDialog() {
        final int[] r = {rgbR}, g = {rgbG}, b = {rgbB};
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18),dp(18),dp(18),dp(18));
        box.setBackground(round(Color.rgb(1,18,34),16,Color.rgb(12,121,220),1));

        TextView title = text("RGB",22,Color.WHITE,Typeface.BOLD);
        title.setGravity(Gravity.CENTER); box.addView(title);

        String[] names = {"R","G","B"};
        int[][] holder = {r,g,b};
        for (int i=0;i<3;i++) {
            TextView label = text(names[i] + ": " + holder[i][0],15,Color.WHITE,Typeface.NORMAL);
            box.addView(label);
            SeekBar s = new SeekBar(this); s.setMax(255); s.setProgress(holder[i][0]);
            final int idx=i;
            s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                public void onProgressChanged(SeekBar seek,int value,boolean from){
                    if(!from)return;
                    holder[idx][0]=value;
                    label.setText(names[idx]+": "+value);
                    rgbR=r[0];rgbG=g[0];rgbB=b[0];
                    sendRgb(rgbR,rgbG,rgbB,selectedChannel);saveState();
                }
                public void onStartTrackingTouch(SeekBar s){}
                public void onStopTrackingTouch(SeekBar s){}
            });
            box.addView(s);
        }
        new AlertDialog.Builder(this).setView(box).setPositiveButton("OK",null).show();
    }

    // ---------------------------------------------------------------------
    // Effect scroll dialog: 210 / REM / SEN / Welcome. Value change = langsung jalan.
    // ---------------------------------------------------------------------
    private void showEffectDialog(String initialCategory) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackground(round(Color.rgb(0,7,20), 0, Color.TRANSPARENT, 0));

        TextView title = text("Pilih Efek", 22, Color.WHITE, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, lp(-1,-2,0,4,0,9));

        LinearLayout cats = row();
        String[] labels={"210","REM","SEN","WELCOME"};
        final String[] current={initialCategory};
        final NumberPicker[] leftRef={null};
        final NumberPicker[] rightRef={null};
        final TextView[] leftLabel={null};
        final TextView[] rightLabel={null};
        for (String label:labels) {
            Button b=darkButton(label);
            cats.addView(b, weight());
            b.setOnClickListener(v->{ current[0]=label; configurePickers(current[0],leftRef[0],rightRef[0],leftLabel[0],rightLabel[0]); });
        }
        root.addView(cats, lp(-1,-2,0,0,0,12));

        LinearLayout labelsRow=row();
        TextView ll=text(profile==0?"LED1":"LED3",18,Color.WHITE,Typeface.NORMAL);
        TextView rl=text(profile==0?"LED2":"LED4",18,Color.WHITE,Typeface.NORMAL);
        ll.setGravity(Gravity.CENTER); rl.setGravity(Gravity.CENTER);
        labelsRow.addView(ll,weight()); labelsRow.addView(rl,weight());
        root.addView(labelsRow);
        leftLabel[0]=ll; rightLabel[0]=rl;

        LinearLayout pickRow=row();
        NumberPicker lpick=picker(1,210,1); NumberPicker rpick=picker(1,210,1);
        leftRef[0]=lpick; rightRef[0]=rpick;
        pickRow.addView(lpick,weight()); pickRow.addView(rpick,weight());
        root.addView(pickRow,new LinearLayout.LayoutParams(-1,0,1f));

        lpick.setOnValueChangedListener((p,o,n)->sendCategoryValue(current[0],n,true));
        rpick.setOnValueChangedListener((p,o,n)->sendCategoryValue(current[0],n,false));

        TextView speedText=text("Speed: "+globalSpeed,15,Color.WHITE,Typeface.NORMAL);
        root.addView(speedText);
        SeekBar speed=new SeekBar(this); speed.setMax(99); speed.setProgress(globalSpeed-1);
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int prog,boolean from){ if(from){globalSpeed=prog+1;speedText.setText("Speed: "+globalSpeed); if("REM".equals(current[0])) sendRemTarget(0x02,globalSpeed); else sendSimple(0x02,globalSpeed,selectedChannel);saveState();}}
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
        });
        root.addView(speed);

        TextView briText=text("Brightness: "+globalBrightness,15,Color.WHITE,Typeface.NORMAL);
        root.addView(briText);
        SeekBar bri=new SeekBar(this); bri.setMax(99); bri.setProgress(globalBrightness-1);
        bri.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int prog,boolean from){ if(from){globalBrightness=prog+1;briText.setText("Brightness: "+globalBrightness); if("REM".equals(current[0])) sendRemTarget(0x01,globalBrightness); else sendSimple(0x01,globalBrightness,selectedChannel);saveState();}}
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
        });
        root.addView(bri);

        LinearLayout bottom=row();
        Button cancel=darkButton("CANCELLED"); Button confirm=blueButton("CONFIRM");
        cancel.setOnClickListener(v->dialog.dismiss()); confirm.setOnClickListener(v->dialog.dismiss());
        bottom.addView(cancel,weight()); bottom.addView(confirm,weight());
        root.addView(bottom,lp(-1,-2,0,10,0,0));

        dialog.setContentView(root);
        dialog.show();
        if (dialog.getWindow()!=null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setBackgroundDrawable(round(Color.TRANSPARENT,0,Color.TRANSPARENT,0));
        }
        configurePickers(current[0],lpick,rpick,ll,rl);
    }

    private void configurePickers(String cat, NumberPicker l, NumberPicker r, TextView ll, TextView rl) {
        if (l==null||r==null) return;
        if ("210".equals(cat)) {
            l.setMinValue(1);l.setMaxValue(210);r.setMinValue(1);r.setMaxValue(210);r.setVisibility(View.VISIBLE);rl.setVisibility(View.VISIBLE);
            ll.setText(profile==0?"LED1":"LED3");rl.setText(profile==0?"LED2":"LED4");
        } else if ("WELCOME".equals(cat)) {
            l.setMinValue(0);l.setMaxValue(50);l.setValue(0);r.setVisibility(View.INVISIBLE);rl.setVisibility(View.INVISIBLE);ll.setText("WELCOME");
        } else {
            l.setMinValue(1);l.setMaxValue(10);l.setValue(1);r.setVisibility(View.INVISIBLE);rl.setVisibility(View.INVISIBLE);ll.setText(cat);
        }
    }

    private void sendCategoryValue(String cat,int value,boolean leftPicker) {
        if ("210".equals(cat)) {
            int ch;
            if (profile==0) ch=leftPicker?0x01:0x02; else ch=leftPicker?0x04:0x05;
            sendMode(value,ch);
        } else if ("REM".equals(cat)) sendSimple(0x1A,value,0x03);
        else if ("SEN".equals(cat)) sendSimple(0x19,value,0x03);
        else sendSimple(0x18,value,0x03);
    }

    // ---------------------------------------------------------------------
    // Collect: satu Collect berisi BANYAK mode. Contoh Collect 1 = 1,2,3,4,5.
    // ---------------------------------------------------------------------
    private void showCollectEditor(int editIndex) {
        Dialog d=new Dialog(this); d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(18)); root.setBackgroundColor(Color.rgb(2,9,20));
        TextView title=text(editIndex>=0?"Edit Collect "+(editIndex+1):"Tambah Collect",22,Color.WHITE,Typeface.BOLD); title.setGravity(Gravity.CENTER);root.addView(title,lp(-1,-2,0,0,0,12));

        ArrayList<Integer> pending=new ArrayList<>();
        int initSpeed=globalSpeed, initBri=globalBrightness;
        if(editIndex>=0&&editIndex<collectGroups.size()) { CollectGroup old=collectGroups.get(editIndex);pending.addAll(old.modes);initSpeed=old.speed;initBri=old.brightness; }
        TextView list=text("Mode: "+modeListString(pending),15,Color.rgb(160,210,240),Typeface.BOLD);root.addView(list,lp(-1,-2,0,0,0,8));

        NumberPicker picker=picker(1,210,1);root.addView(picker,new LinearLayout.LayoutParams(-1,0,1f));
        LinearLayout editBtns=row(); Button add=blueButton("+ ADD MODE");Button undo=darkButton("HAPUS TERAKHIR"); editBtns.addView(add,weight());editBtns.addView(undo,weight());root.addView(editBtns);
        add.setOnClickListener(v->{ if(pending.size()<20){pending.add(picker.getValue());list.setText("Mode: "+modeListString(pending));} else toast("Maksimal 20 mode per Collect");});
        undo.setOnClickListener(v->{if(!pending.isEmpty()){pending.remove(pending.size()-1);list.setText("Mode: "+modeListString(pending));}});

        final int[] speedVal={initSpeed}; final int[] briVal={initBri};
        TextView st=text("Speed: "+speedVal[0],14,Color.WHITE,Typeface.NORMAL);root.addView(st);SeekBar ss=new SeekBar(this);ss.setMax(99);ss.setProgress(speedVal[0]-1);root.addView(ss);
        ss.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){speedVal[0]=p+1;st.setText("Speed: "+speedVal[0]);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        TextView bt=text("Brightness: "+briVal[0],14,Color.WHITE,Typeface.NORMAL);root.addView(bt);SeekBar bs=new SeekBar(this);bs.setMax(99);bs.setProgress(briVal[0]-1);root.addView(bs);
        bs.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){briVal[0]=p+1;bt.setText("Brightness: "+briVal[0]);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});

        LinearLayout bottom=row();Button cancel=darkButton("BATAL");Button save=blueButton("SIMPAN COLLECT");bottom.addView(cancel,weight());bottom.addView(save,weight());root.addView(bottom,lp(-1,-2,0,8,0,0));
        cancel.setOnClickListener(v->d.dismiss());
        save.setOnClickListener(v->{ if(pending.isEmpty()) pending.add(picker.getValue()); CollectGroup cg=new CollectGroup(pending,speedVal[0],briVal[0]); if(editIndex>=0&&editIndex<collectGroups.size()) collectGroups.set(editIndex,cg); else collectGroups.add(cg); saveCollectGroups(); if(ui!=null)ui.invalidate(); d.dismiss();});
        d.setContentView(root);d.show();if(d.getWindow()!=null){d.getWindow().setLayout(-1,-1);d.getWindow().setBackgroundDrawable(round(Color.TRANSPARENT,0,Color.TRANSPARENT,0));}
    }

    private void runCollect(int index) {
        if(index<0||index>=collectGroups.size())return;
        CollectGroup g=collectGroups.get(index);
        if(g.modes.isEmpty())return;
        int gen=++collectRunGeneration;
        sendSimple(0x02,g.speed,0x03);
        main.postDelayed(()->sendSimple(0x01,g.brightness,0x03),70);
        for(int i=0;i<g.modes.size();i++){
            final int mode=g.modes.get(i); final int delay=180+i*3000;
            main.postDelayed(()->{if(gen==collectRunGeneration)sendMode(mode,0x03);},delay);
        }
        toast("Collect "+(index+1)+" berjalan: "+modeListString(g.modes));
    }

    // ---------------------------------------------------------------------
    // Settings actions
    // ---------------------------------------------------------------------
    private void showLedCountDialog() {
        EditText input=new EditText(this);input.setInputType(InputType.TYPE_CLASS_NUMBER);input.setText(String.valueOf(prefs.getInt("led_count",75)));input.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("Chip settings - jumlah LED").setView(input).setNegativeButton("Batal",null).setPositiveButton("Terapkan",(d,w)->{
            try{int count=clamp(Integer.parseInt(input.getText().toString().trim()),1,1000);prefs.edit().putInt("led_count",count).apply();sendLedCount(count);toast("Jumlah LED: "+count);}catch(Exception e){toast("Jumlah LED tidak valid");}
        }).show();
    }

    private void resetAppSettings() {
        prefs.edit().remove("collect_groups").remove("speed").remove("brightness").remove("rgb_r").remove("rgb_g").remove("rgb_b").apply();
        collectGroups.clear();globalSpeed=70;globalBrightness=70;rgbR=255;rgbG=50;rgbB=0;selectedChannel=0x03;profile=0;
        if(ui!=null){ui.settingsOpen=false;ui.invalidate();}toast("Pengaturan aplikasi direset");
    }

    private void openOta() {
        try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(OTA_URL)));}catch(Exception e){toast("Browser tidak tersedia");}
    }

    // ---------------------------------------------------------------------
    // BLE
    // ---------------------------------------------------------------------
    private void connectLedcar() {
        if(btAdapter==null){toast("Bluetooth tidak tersedia");return;}
        if(!hasBtPermissions()){requestBtPermissions();return;}
        if(!btAdapter.isEnabled()){toast("Aktifkan Bluetooth");try{startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));}catch(Exception ignored){}return;}
        scanner=btAdapter.getBluetoothLeScanner();if(scanner==null){toast("BLE scanner tidak tersedia");return;}
        if(scanning)return;scanning=true;toast("Mencari LEDCAR-02-9931...");
        try{scanner.startScan(scanCallback);}catch(SecurityException e){requestBtPermissions();return;}
        main.postDelayed(()->{if(scanning){stopScan();toast("LEDCAR belum ditemukan");}},12000);
    }

    private final ScanCallback scanCallback=new ScanCallback(){
        @Override public void onScanResult(int callbackType,ScanResult result){
            BluetoothDevice device=result.getDevice();String name=null;
            try{if(hasBtPermissions())name=device.getName();}catch(SecurityException ignored){}
            boolean nm=name!=null&&(name.toUpperCase(Locale.ROOT).contains("LEDCAR")||name.toUpperCase(Locale.ROOT).contains("LEDLAMP")||name.toUpperCase(Locale.ROOT).contains("WARDAN"));
            boolean svc=false;if(result.getScanRecord()!=null&&result.getScanRecord().getServiceUuids()!=null){for(ParcelUuid u:result.getScanRecord().getServiceUuids()){if(SERVICE_FFE0.equals(u.getUuid())){svc=true;break;}}}
            if(nm||svc){stopScan();connectGatt(device);}
        }
        @Override public void onScanFailed(int errorCode){scanning=false;toast("Scan BLE gagal: "+errorCode);}
    };

    private void connectGatt(BluetoothDevice d){
        if(!hasBtPermissions()){requestBtPermissions();return;}
        try{if(gatt!=null){gatt.close();gatt=null;}ffe1=null;gatt=d.connectGatt(this,false,gattCallback,BluetoothDevice.TRANSPORT_LE);}catch(SecurityException e){requestBtPermissions();}
    }

    private final BluetoothGattCallback gattCallback=new BluetoothGattCallback(){
        @Override public void onConnectionStateChange(BluetoothGatt g,int status,int newState){
            if(newState==BluetoothProfile.STATE_CONNECTED){bleConnected=true;main.post(()->{if(ui!=null)ui.invalidate();toast("LEDCAR terhubung");});try{g.discoverServices();}catch(SecurityException ignored){}}
            else if(newState==BluetoothProfile.STATE_DISCONNECTED){bleConnected=false;ffe1=null;main.post(()->{if(ui!=null)ui.invalidate();toast("LEDCAR terputus");});}
        }
        @Override public void onServicesDiscovered(BluetoothGatt g,int status){if(status==BluetoothGatt.GATT_SUCCESS){BluetoothGattService s=g.getService(SERVICE_FFE0);if(s!=null)ffe1=s.getCharacteristic(CHAR_FFE1);main.post(()->{if(ffe1!=null)toast("FFE1 siap");else toast("FFE1 tidak ditemukan");});}}
    };

    private void disconnectBle(){stopScan();bleConnected=false;collectRunGeneration++;if(gatt!=null){try{if(hasBtPermissions())gatt.disconnect();}catch(SecurityException ignored){}try{gatt.close();}catch(Exception ignored){}gatt=null;}ffe1=null;if(ui!=null)ui.invalidate();}
    private void stopScan(){scanning=false;if(scanner!=null&&hasBtPermissions()){try{scanner.stopScan(scanCallback);}catch(SecurityException ignored){}}}
    private boolean hasBtPermissions(){if(Build.VERSION.SDK_INT>=31)return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
    private void requestBtPermissions(){if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ_BT);}
    @Override public void onRequestPermissionsResult(int req,String[] permissions,int[] grants){super.onRequestPermissionsResult(req,permissions,grants);if(req==REQ_BT){if(hasBtPermissions())connectLedcar();else toast("Izin Bluetooth diperlukan");}}

    // ---------------------------------------------------------------------
    // Firmware packet helpers - sesuai mayarota(1).ino
    // ---------------------------------------------------------------------
    private byte[] packet(){byte[] p=new byte[9];p[0]=0x7B;p[7]=0x03;p[8]=(byte)0xBF;return p;}
    private void sendMode(int mode,int ch){sendSimple(0x03,mode,ch);}
    private void sendRgb(int r,int g,int b,int ch){byte[] p=packet();p[1]=0x07;p[2]=(byte)r;p[3]=(byte)g;p[4]=(byte)b;p[7]=(byte)ch;write(p);}
    private void sendSimple(int cmd,int value,int ch){byte[] p=packet();p[1]=(byte)cmd;p[2]=(byte)value;p[7]=(byte)ch;write(p);}
    private void sendRemTarget(int cmd,int value){byte[] p=packet();p[1]=(byte)cmd;p[2]=(byte)value;p[3]=0x04;p[7]=(byte)0x03;write(p);}
    private void sendLedCount(int count){byte[] p=packet();p[1]=0x05;p[3]=(byte)((count>>8)&0xFF);p[4]=(byte)(count&0xFF);p[7]=0x03;write(p);}
    private void sendSubareaDouble(int area){sendSimple(0x14,area,0x03);main.postDelayed(()->sendSimple(0x14,area,0x03),140);}
    private void write(byte[] data){
        if(gatt==null||ffe1==null){toast("Tekan ▶ untuk hubungkan modul");return;}
        try{int props=ffe1.getProperties();int wt=(props&BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)!=0?BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE:BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;if(Build.VERSION.SDK_INT>=33){int rc=gatt.writeCharacteristic(ffe1,data,wt);if(rc!=0)toast("BLE write gagal: "+rc);}else{ffe1.setWriteType(wt);ffe1.setValue(data);if(!gatt.writeCharacteristic(ffe1))toast("BLE write gagal");}}catch(SecurityException e){requestBtPermissions();}catch(Exception e){toast("Gagal kirim BLE");}
    }

    // ---------------------------------------------------------------------
    // Persistence
    // ---------------------------------------------------------------------
    private void loadState(){selectedChannel=prefs.getInt("channel",0x03);profile=prefs.getInt("profile",0);globalSpeed=prefs.getInt("speed",70);globalBrightness=prefs.getInt("brightness",70);rgbR=prefs.getInt("rgb_r",255);rgbG=prefs.getInt("rgb_g",50);rgbB=prefs.getInt("rgb_b",0);moduleLocked=prefs.getBoolean("module_lock",false);}
    private void saveState(){prefs.edit().putInt("channel",selectedChannel).putInt("profile",profile).putInt("speed",globalSpeed).putInt("brightness",globalBrightness).putInt("rgb_r",rgbR).putInt("rgb_g",rgbG).putInt("rgb_b",rgbB).putBoolean("module_lock",moduleLocked).apply();}
    private void loadCollectGroups(){collectGroups.clear();String raw=prefs.getString("collect_groups","");if(raw==null||raw.isEmpty())return;String[] groups=raw.split("#");for(String s:groups){String[] parts=s.split("\\|");if(parts.length!=3)continue;try{ArrayList<Integer> modes=new ArrayList<>();for(String m:parts[0].split(",")){int v=Integer.parseInt(m);if(v>=1&&v<=210)modes.add(v);}int sp=clamp(Integer.parseInt(parts[1]),1,100),br=clamp(Integer.parseInt(parts[2]),1,100);if(!modes.isEmpty())collectGroups.add(new CollectGroup(modes,sp,br));}catch(Exception ignored){}}}
    private void saveCollectGroups(){StringBuilder out=new StringBuilder();for(int i=0;i<collectGroups.size();i++){if(i>0)out.append('#');CollectGroup g=collectGroups.get(i);for(int j=0;j<g.modes.size();j++){if(j>0)out.append(',');out.append(g.modes.get(j));}out.append('|').append(g.speed).append('|').append(g.brightness);}prefs.edit().putString("collect_groups",out.toString()).apply();}
    private String modeListString(List<Integer> modes){if(modes==null||modes.isEmpty())return "-";StringBuilder s=new StringBuilder();for(int i=0;i<modes.size();i++){if(i>0)s.append(" • ");s.append(modes.get(i));}return s.toString();}
    private static class CollectGroup{final ArrayList<Integer> modes;final int speed,brightness;CollectGroup(List<Integer> m,int s,int b){modes=new ArrayList<>(m);speed=s;brightness=b;}}

    // ---------------------------------------------------------------------
    // Drawing helpers
    // ---------------------------------------------------------------------
    private void drawText(Canvas c,String text,float x,float y,float size,int color,Paint.Align align,boolean bold){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);q.setColor(color);q.setTextSize(size);q.setTextAlign(align);q.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(text,x,y,q);}
    private void drawBack(Canvas c,float x,float y){Paint q=linePaint(Color.WHITE,5f);Path path=new Path();path.moveTo(x+16*scaleX(),y-30*scaleY());path.lineTo(x-16*scaleX(),y);path.lineTo(x+16*scaleX(),y+30*scaleY());c.drawPath(path,q);}
    private float scaleX(){return ui==null?1f:ui.sx();}private float scaleY(){return ui==null?1f:ui.sy();}
    private Paint linePaint(int color,float width){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);q.setColor(color);q.setStyle(Paint.Style.STROKE);q.setStrokeCap(Paint.Cap.ROUND);q.setStrokeJoin(Paint.Join.ROUND);q.setStrokeWidth(width*scaleX());return q;}
    private void drawPlayPause(Canvas c,float x,float y,boolean pause){Paint q=linePaint(Color.WHITE,4f);c.drawCircle(x,y,25*scaleX(),q);if(pause){c.drawLine(x-7*scaleX(),y-12*scaleY(),x-7*scaleX(),y+12*scaleY(),q);c.drawLine(x+7*scaleX(),y-12*scaleY(),x+7*scaleX(),y+12*scaleY(),q);}else{Path t=new Path();t.moveTo(x-7*scaleX(),y-13*scaleY());t.lineTo(x+13*scaleX(),y);t.lineTo(x-7*scaleX(),y+13*scaleY());t.close();c.drawPath(t,q);}}
    private void drawGear(Canvas c,float x,float y,float r,int color){Paint q=linePaint(color,3f);c.drawCircle(x,y,r*0.55f,q);c.drawCircle(x,y,r*0.95f,q);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=x+(float)Math.cos(a)*r*0.95f,y1=y+(float)Math.sin(a)*r*0.95f;float x2=x+(float)Math.cos(a)*r*1.2f,y2=y+(float)Math.sin(a)*r*1.2f;c.drawLine(x1,y1,x2,y2,q);}}
    private void drawRotate(Canvas c,float x,float y){Paint q=linePaint(Color.WHITE,5f);RectF r=new RectF(x-25*scaleX(),y-25*scaleY(),x+25*scaleX(),y+25*scaleY());c.drawArc(r,25,260,false,q);Path a=new Path();a.moveTo(x+22*scaleX(),y-23*scaleY());a.lineTo(x+7*scaleX(),y-25*scaleY());a.lineTo(x+18*scaleX(),y-9*scaleY());c.drawPath(a,q);}
    private void drawChevron(Canvas c,float x,float y){Paint q=linePaint(Color.rgb(110,110,110),2f);Path p=new Path();p.moveTo(x-8*scaleX(),y-12*scaleY());p.lineTo(x+5*scaleX(),y);p.lineTo(x-8*scaleX(),y+12*scaleY());c.drawPath(p,q);}
    private void drawArrow(Canvas c,float x,float y,boolean right){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);q.setColor(Color.WHITE);q.setStyle(Paint.Style.FILL);float s=right?1:-1;Path p=new Path();p.moveTo(x+s*25*scaleX(),y);p.lineTo(x-s*5*scaleX(),y-22*scaleY());p.lineTo(x-s*5*scaleX(),y-10*scaleY());p.lineTo(x-s*28*scaleX(),y-10*scaleY());p.lineTo(x-s*28*scaleX(),y+10*scaleY());p.lineTo(x-s*5*scaleX(),y+10*scaleY());p.lineTo(x-s*5*scaleX(),y+22*scaleY());p.close();c.drawPath(p,q);}
    private void drawToggle(Canvas c,float x,float y,boolean on){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);q.setColor(on?Color.GREEN:Color.DKGRAY);c.drawRoundRect(new RectF(x-52*scaleX(),y-22*scaleY(),x+52*scaleX(),y+22*scaleY()),22*scaleY(),22*scaleY(),q);q.setColor(Color.WHITE);c.drawCircle(x+(on?29:-29)*scaleX(),y,20*scaleY(),q);}
    private void drawRgbIcon(Canvas c,float x,float y,float r){Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);int[] cs={Color.WHITE,Color.LTGRAY,Color.DKGRAY,Color.WHITE};q.setShader(new SweepGradient(x,y,cs,null));c.drawCircle(x,y,r,q);q.setShader(null);}
    private void drawSnowflake(Canvas c,float x,float y,float r,int color){Paint q=linePaint(color,2.5f);for(int i=0;i<6;i++){double a=i*Math.PI/3;float x2=x+(float)Math.cos(a)*r,y2=y+(float)Math.sin(a)*r;c.drawLine(x,y,x2,y2,q);}}
    private void drawCustomIcon(Canvas c,float x,float y,float r,int color){Paint q=linePaint(color,2.5f);c.drawCircle(x,y,r,q);c.drawLine(x-r*.45f,y+r*.35f,x+r*.45f,y-r*.45f,q);}

    // ---------------------------------------------------------------------
    // Android UI helpers
    // ---------------------------------------------------------------------
    private TextView text(String s,int sp,int color,int style){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setTypeface(Typeface.create("sans",style));return t;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
    private LinearLayout.LayoutParams weight(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f);p.setMargins(dp(2),0,dp(2),0);return p;}
    private FrameLayout.LayoutParams match(){return new FrameLayout.LayoutParams(-1,-1);}
    private LinearLayout.LayoutParams lp(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
    private Button darkButton(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(dp(8),dp(9),dp(8),dp(9));b.setBackground(round(Color.rgb(22,30,38),8,Color.rgb(80,100,115),1));return b;}
    private Button blueButton(String s){Button b=darkButton(s);b.setBackground(round(Color.rgb(8,150,225),8,Color.rgb(8,150,225),1));return b;}
    private NumberPicker picker(int min,int max,int value){NumberPicker n=new NumberPicker(this);n.setMinValue(min);n.setMaxValue(max);n.setValue(value);n.setWrapSelectorWheel(false);n.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);if(Build.VERSION.SDK_INT>=29)n.setTextColor(Color.WHITE);return n;}
    private GradientDrawable round(int fill,int radiusDp,int stroke,int strokeDp){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radiusDp));if(strokeDp>0)d.setStroke(dp(strokeDp),stroke);return d;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private int clamp(int v,int min,int max){return Math.max(min,Math.min(max,v));}
    private void toast(String s){main.post(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}

    @Override protected void onDestroy(){disconnectBle();super.onDestroy();}
}
