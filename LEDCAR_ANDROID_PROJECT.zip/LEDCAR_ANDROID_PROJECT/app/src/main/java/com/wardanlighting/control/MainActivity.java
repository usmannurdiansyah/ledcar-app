package com.wardanlighting.control;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {

    private static final UUID SERVICE_FFE0 =
            UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    private static final UUID CHAR_FFE1 =
            UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");

    private static final String OTA_URL =
            "https://ledcar-ota.usmannurdiansyah.workers.dev";

    private static final int REQ_BT = 1001;

    private final Handler main = new Handler(Looper.getMainLooper());

    private BluetoothAdapter btAdapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic ffe1;
    private boolean scanning = false;

    private SharedPreferences prefs;

    // Firmware channel codes:
    // CH1=0x01, CH2=0x02, ALL=0x03, CH3=0x04, CH4=0x05
    private int selectedChannel = 0x03;

    private int rgbR = 0;
    private int rgbG = 190;
    private int rgbB = 255;
    private int globalSpeed = 70;
    private int globalBrightness = 70;

    private String selectedProfile = "LEDCAR";
    private String modeSection = "210";
    private int selected210 = 1;
    private int selectedRem = 1;
    private int selectedSen = 1;
    private int selectedWelcome = 0;

    private LinearLayout appRoot;
    private FrameLayout contentHost;
    private TextView statusText;
    private TextView channelLabel;
    private TextView profileLabel;
    private TextView titleLabel;
    private PopupWindow settingsPopup;

    private final List<CollectItem> collectItems = new ArrayList<>();
    private final List<Button> channelButtons = new ArrayList<>();

    private final int BG = Color.rgb(2, 10, 18);
    private final int BG2 = Color.rgb(4, 20, 34);
    private final int PANEL = Color.rgb(7, 29, 47);
    private final int PANEL2 = Color.rgb(10, 42, 65);
    private final int CYAN = Color.rgb(0, 191, 255);
    private final int CYAN2 = Color.rgb(91, 225, 255);
    private final int WHITE = Color.rgb(242, 249, 255);
    private final int MUTED = Color.rgb(133, 163, 181);
    private final int LINE = Color.rgb(20, 86, 118);
    private final int GREEN = Color.rgb(63, 225, 122);
    private final int RED = Color.rgb(255, 73, 89);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("wardan_lighting", MODE_PRIVATE);
        loadState();
        loadCollect();

        BluetoothManager manager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        btAdapter = manager != null ? manager.getAdapter() : null;

        showSplash();
    }

    // ---------------------------------------------------------------------
    // SPLASH + LOCAL APP LOCK
    // ---------------------------------------------------------------------

    private void showSplash() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(26), dp(26), dp(26), dp(26));
        root.setBackgroundColor(BG);

        TextView wl = tv("WL", 68, Typeface.BOLD, WHITE);
        wl.setGravity(Gravity.CENTER);
        root.addView(wl);

        TextView name = tv("WARDAN LIGHTING", 25, Typeface.BOLD, CYAN2);
        name.setGravity(Gravity.CENTER);
        name.setLetterSpacing(0.08f);
        root.addView(name, lpMatchWrap(0, 8, 0, 0));

        TextView tagline = tv("LIGHTING YOUR RIDE", 11, Typeface.BOLD, MUTED);
        tagline.setGravity(Gravity.CENTER);
        tagline.setLetterSpacing(0.18f);
        root.addView(tagline, lpMatchWrap(0, 8, 0, 0));

        setContentView(root);
        main.postDelayed(this::showLockScreen, 900);
    }

    private void showLockScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(45), dp(24), dp(24));
        root.setBackgroundColor(BG);

        TextView wl = tv("WL", 62, Typeface.BOLD, WHITE);
        wl.setGravity(Gravity.CENTER);
        root.addView(wl);

        TextView name = tv("Wardan Lighting", 23, Typeface.BOLD, CYAN2);
        name.setGravity(Gravity.CENTER);
        root.addView(name, lpMatchWrap(0, 4, 0, 24));

        TextView hint = tv("Geser kunci untuk membuka", 14, Typeface.BOLD, WHITE);
        hint.setGravity(Gravity.CENTER);
        root.addView(hint, lpMatchWrap(0, 0, 0, 12));

        final EditText password = new EditText(this);
        password.setHint("Password");
        password.setHintTextColor(MUTED);
        password.setTextColor(WHITE);
        password.setSingleLine(true);
        password.setInputType(InputType.TYPE_CLASS_TEXT |
                InputType.TYPE_TEXT_VARIATION_PASSWORD);
        password.setBackground(roundRect(PANEL, 14, LINE, 1));
        password.setPadding(dp(14), dp(12), dp(14), dp(12));
        root.addView(password, lpMatchWrap(0, 0, 0, 18));

        TextView slideText = tv("🔒   GESER UNTUK MEMBUKA   →", 14, Typeface.BOLD, CYAN2);
        slideText.setGravity(Gravity.CENTER);
        root.addView(slideText, lpMatchWrap(0, 0, 0, 7));

        SeekBar unlock = new SeekBar(this);
        unlock.setMax(100);
        unlock.setProgress(0);
        root.addView(unlock, lpMatchWrap(0, 0, 0, 8));

        TextView passInfo = tv(
                prefs.getString("local_password", "").isEmpty()
                        ? "Password aplikasi belum dibuat. Geser saja untuk masuk."
                        : "Masukkan password lalu geser sampai ujung.",
                11, Typeface.NORMAL, MUTED);
        passInfo.setGravity(Gravity.CENTER);
        root.addView(passInfo);

        unlock.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (seekBar.getProgress() < 90) {
                    seekBar.setProgress(0);
                    return;
                }

                String saved = prefs.getString("local_password", "");
                String typed = password.getText().toString();

                if (!saved.isEmpty() && !saved.equals(typed)) {
                    toast("Password salah");
                    seekBar.setProgress(0);
                    return;
                }

                buildMainApp();
            }
        });

        setContentView(root);
    }

    // ---------------------------------------------------------------------
    // MAIN APP SHELL
    // ---------------------------------------------------------------------

    private void buildMainApp() {
        appRoot = new LinearLayout(this);
        appRoot.setOrientation(LinearLayout.VERTICAL);
        appRoot.setBackgroundColor(BG);

        appRoot.addView(buildHeader());
        appRoot.addView(buildProfileBar());
        appRoot.addView(buildChannelBar());

        contentHost = new FrameLayout(this);
        LinearLayout.LayoutParams contentParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        appRoot.addView(contentHost, contentParams);

        appRoot.addView(buildBottomNav());

        setContentView(appRoot);
        showRgbScreen();
    }

    private View buildHeader() {
        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(12), dp(8), dp(10), dp(8));
        header.setBackgroundColor(BG2);

        TextView logo = tv("WL", 26, Typeface.BOLD, WHITE);
        header.addView(logo);

        LinearLayout middle = new LinearLayout(this);
        middle.setOrientation(LinearLayout.VERTICAL);
        middle.setPadding(dp(9), 0, dp(8), 0);

        titleLabel = tv("Wardan Lighting", 15, Typeface.BOLD, CYAN2);
        statusText = tv("Belum terhubung", 10, Typeface.NORMAL, MUTED);
        middle.addView(titleLabel);
        middle.addView(statusText);
        header.addView(middle, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button connect = compactButton("BLE");
        connect.setOnClickListener(v -> connectLedcar());
        header.addView(connect);

        Button power = compactButton("⏻");
        power.setOnClickListener(v -> sendSimple(0x04, 0x01));
        power.setOnLongClickListener(v -> {
            sendSimple(0x04, 0x00);
            toast("Power OFF");
            return true;
        });
        header.addView(power, marginLeft(dp(5)));

        Button settings = compactButton("⚙");
        settings.setOnClickListener(v -> showSettingsDrawer());
        header.addView(settings, marginLeft(dp(5)));

        return header;
    }

    private View buildProfileBar() {
        LinearLayout row = horizontal();
        row.setPadding(dp(9), dp(7), dp(9), dp(4));
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView label = tv("Profil", 11, Typeface.BOLD, MUTED);
        row.addView(label);

        Button ledcar = tabButton("LEDCAR");
        Button dmx = tabButton("DMX");

        ledcar.setOnClickListener(v -> {
            selectedProfile = "LEDCAR";
            prefs.edit().putString("profile", selectedProfile).apply();
            profileLabel.setText("LEDCAR + DMX dalam satu aplikasi");
        });
        dmx.setOnClickListener(v -> {
            selectedProfile = "DMX";
            prefs.edit().putString("profile", selectedProfile).apply();
            profileLabel.setText("DMX + LEDCAR dalam satu aplikasi");
        });

        row.addView(ledcar, marginLeft(dp(9)));
        row.addView(dmx, marginLeft(dp(5)));

        profileLabel = tv(
                selectedProfile.equals("DMX")
                        ? "DMX + LEDCAR dalam satu aplikasi"
                        : "LEDCAR + DMX dalam satu aplikasi",
                10, Typeface.NORMAL, MUTED);
        row.addView(profileLabel, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        return row;
    }

    private View buildChannelBar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(8), dp(3), dp(8), dp(5));

        LinearLayout top = horizontal();
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView s = tv("Channel:", 10, Typeface.BOLD, MUTED);
        top.addView(s);

        channelLabel = tv(channelName(selectedChannel), 11, Typeface.BOLD, CYAN2);
        top.addView(channelLabel, marginLeft(dp(7)));

        wrap.addView(top, lpMatchWrap(0, 0, 0, 4));

        channelButtons.clear();

        LinearLayout row = horizontal();
        row.setGravity(Gravity.CENTER);

        row.addView(channelButton("LED1", 0x01), weightButton());
        row.addView(channelButton("LED2", 0x02), weightButton());
        row.addView(channelButton("LED3", 0x04), weightButton());
        row.addView(channelButton("LED4", 0x05), weightButton());
        row.addView(channelButton("ALL", 0x03), weightButton());

        wrap.addView(row);

        return wrap;
    }

    private View buildBottomNav() {
        LinearLayout nav = horizontal();
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(6), dp(6), dp(6), dp(8));
        nav.setBackgroundColor(BG2);

        // Safe area bawah untuk Android 15/16: menu tidak tertutup navigation bar.
        nav.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottomInset = insets.getSystemWindowInsetBottom();
            v.setPadding(dp(6), dp(6), dp(6), dp(8) + bottomInset);
            return insets;
        });
        nav.requestApplyInsets();

        Button rgb = navButton("◉\nRGB");
        rgb.setOnClickListener(v -> showRgbScreen());

        Button mode = navButton("❄\nMode");
        mode.setOnClickListener(v -> showModeScreen());

        Button collect = navButton("☆\nCollect");
        collect.setOnClickListener(v -> showCollectScreen());

        Button set = navButton("⚙\nSet");
        set.setOnClickListener(v -> showSettingsDrawer());

        nav.addView(rgb, weightButton());
        nav.addView(mode, weightButton());
        nav.addView(collect, weightButton());
        nav.addView(set, weightButton());

        return nav;
    }

    // ---------------------------------------------------------------------
    // RGB SCREEN
    // ---------------------------------------------------------------------

    private void showRgbScreen() {
        contentHost.removeAllViews();

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(6), dp(14), dp(10));

        TextView heading = sectionTitle("RGB / WARNA DASAR");
        page.addView(heading);

        HueWheelView wheel = new HueWheelView(this);
        LinearLayout.LayoutParams wheelParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        wheelParams.setMargins(0, dp(6), 0, dp(5));
        page.addView(wheel, wheelParams);

        TextView colorValue = tv(
                String.format(Locale.US, "RGB %d, %d, %d", rgbR, rgbG, rgbB),
                12, Typeface.BOLD, CYAN2);
        colorValue.setGravity(Gravity.CENTER);
        page.addView(colorValue, lpMatchWrap(0, 2, 0, 4));

        wheel.setOnColorChangedListener((r, g, b) -> {
            rgbR = r;
            rgbG = g;
            rgbB = b;
            colorValue.setText(String.format(
                    Locale.US, "RGB %d, %d, %d", r, g, b));
            sendRgb(r, g, b);
        });

        LinearLayout presets = horizontal();
        presets.addView(colorPreset("MERAH", 255, 0, 0), weightButton());
        presets.addView(colorPreset("HIJAU", 0, 255, 0), weightButton());
        presets.addView(colorPreset("BIRU", 0, 0, 255), weightButton());
        presets.addView(colorPreset("PUTIH", 255, 255, 255), weightButton());
        presets.addView(colorPreset("ORANGE", 255, 50, 0), weightButton());
        page.addView(presets, lpMatchWrap(0, 4, 0, 5));

        page.addView(makeSliderRow(
                "Brightness", globalBrightness, 1, 100,
                value -> {
                    globalBrightness = value;
                    sendSimple(0x01, value);
                    saveLive();
                }));

        page.addView(makeSliderRow(
                "Speed", globalSpeed, 1, 100,
                value -> {
                    globalSpeed = value;
                    sendSimple(0x02, value);
                    saveLive();
                }));

        LinearLayout quick = horizontal();

        Button welcome = darkButton("WELCOME");
        welcome.setOnClickListener(v -> {
            modeSection = "WELCOME";
            showModeScreen();
        });

        Button rem = darkButton("REM");
        rem.setOnClickListener(v -> {
            modeSection = "REM";
            showModeScreen();
        });

        Button sen = darkButton("SEN");
        sen.setOnClickListener(v -> {
            modeSection = "SEN";
            showModeScreen();
        });

        quick.addView(welcome, weightButton());
        quick.addView(rem, weightButton());
        quick.addView(sen, weightButton());
        page.addView(quick, lpMatchWrap(0, 5, 0, 5));

        Button ota = outlineButton("☁  UPDATE OTA");
        ota.setOnClickListener(v -> openOta());
        page.addView(ota);

        contentHost.addView(page);
    }

    // ---------------------------------------------------------------------
    // MODE / REM / SEN / WELCOME — SCROLL LANGSUNG JALAN
    // ---------------------------------------------------------------------

    private void showModeScreen() {
        contentHost.removeAllViews();

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(10), dp(4), dp(10), dp(6));

        LinearLayout tabs = horizontal();

        Button m210 = modeTab("210");
        Button rem = modeTab("REM");
        Button sen = modeTab("SEN");
        Button welcome = modeTab("WELCOME");

        m210.setOnClickListener(v -> { modeSection = "210"; showModeScreen(); });
        rem.setOnClickListener(v -> { modeSection = "REM"; showModeScreen(); });
        sen.setOnClickListener(v -> { modeSection = "SEN"; showModeScreen(); });
        welcome.setOnClickListener(v -> { modeSection = "WELCOME"; showModeScreen(); });

        tabs.addView(m210, weightButton());
        tabs.addView(rem, weightButton());
        tabs.addView(sen, weightButton());
        tabs.addView(welcome, weightButton());
        page.addView(tabs);

        TextView info = tv(sectionTitleText(), 12, Typeface.BOLD, CYAN2);
        info.setGravity(Gravity.CENTER);
        page.addView(info, lpMatchWrap(0, 5, 0, 2));

        if ("210".equals(modeSection)) {
            TextView help = tv(
                    "Pilih channel di atas, lalu tap efek. Satu scroll untuk efek 1–210.",
                    10, Typeface.NORMAL, MUTED);
            help.setGravity(Gravity.CENTER);
            page.addView(help, lpMatchWrap(0, 0, 0, 4));

            final ScrollView effectScroll = new ScrollView(this);
            effectScroll.setFillViewport(true);
            effectScroll.setVerticalScrollBarEnabled(false);

            LinearLayout list = new LinearLayout(this);
            list.setOrientation(LinearLayout.VERTICAL);
            list.setPadding(0, dp(2), 0, dp(3));

            final List<View> cards = new ArrayList<>();
            final List<Integer> cardModes = new ArrayList<>();

            for (int mode = 1; mode <= 210; mode += 2) {
                LinearLayout row = horizontal();
                row.setGravity(Gravity.CENTER);

                final int leftMode = mode;
                View leftCard = makeEffectCard(leftMode, leftMode == selected210);
                cards.add(leftCard);
                cardModes.add(leftMode);
                leftCard.setOnClickListener(v -> {
                    selected210 = leftMode;
                    sendMode(leftMode);
                    saveLive();
                    refreshEffectCardSelection(cards, cardModes);
                });
                row.addView(leftCard, effectCardParams());

                int rightMode = mode + 1;
                if (rightMode <= 210) {
                    final int rm = rightMode;
                    View rightCard = makeEffectCard(rm, rm == selected210);
                    cards.add(rightCard);
                    cardModes.add(rm);
                    rightCard.setOnClickListener(v -> {
                        selected210 = rm;
                        sendMode(rm);
                        saveLive();
                        refreshEffectCardSelection(cards, cardModes);
                    });
                    row.addView(rightCard, effectCardParams());
                } else {
                    View spacer = new View(this);
                    row.addView(spacer, effectCardParams());
                }

                list.addView(row);
            }

            effectScroll.addView(list);

            LinearLayout.LayoutParams scrollParams =
                    new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            scrollParams.setMargins(0, dp(1), 0, dp(4));
            page.addView(effectScroll, scrollParams);

            int rowIndex = (selected210 - 1) / 2;
            effectScroll.post(() ->
                    effectScroll.scrollTo(0, Math.max(0, rowIndex * dp(92) - dp(18))));

            LinearLayout tools = horizontal();

            Button auto = compactButton("AUTO");
            auto.setOnClickListener(v -> {
                sendModeAuto();
                toast("AUTO aktif");
            });
            tools.addView(auto, weightButton());

            TextView selected = tv(
                    "Efek " + selected210,
                    11, Typeface.BOLD, CYAN2);
            selected.setGravity(Gravity.CENTER);
            tools.addView(selected, weightButton());

            page.addView(tools, lpMatchWrap(0, 0, 0, 3));

        } else {
            TextView sub = tv(
                    "Geser angka. Setiap perubahan langsung dikirim ke firmware.",
                    10, Typeface.NORMAL, MUTED);
            sub.setGravity(Gravity.CENTER);
            page.addView(sub, lpMatchWrap(0, 0, 0, 4));

            NumberPicker picker = new NumberPicker(this);
            picker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
            picker.setWrapSelectorWheel(false);
            picker.setBackground(roundRect(PANEL, 18, LINE, 1));

            if ("REM".equals(modeSection)) {
                picker.setMinValue(1);
                picker.setMaxValue(10);
                picker.setValue(selectedRem);
            } else if ("SEN".equals(modeSection)) {
                picker.setMinValue(1);
                picker.setMaxValue(10);
                picker.setValue(selectedSen);
            } else {
                picker.setMinValue(0);
                picker.setMaxValue(50);
                picker.setValue(selectedWelcome);
            }

            picker.setOnValueChangedListener((p, oldVal, newVal) -> {
                if ("REM".equals(modeSection)) {
                    selectedRem = newVal;
                    sendSimple(0x1A, newVal);
                } else if ("SEN".equals(modeSection)) {
                    selectedSen = newVal;
                    sendSimple(0x19, newVal);
                } else {
                    selectedWelcome = newVal;
                    sendSimple(0x18, newVal);
                }
                saveLive();
            });

            LinearLayout.LayoutParams pickerParams =
                    new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            pickerParams.setMargins(dp(22), dp(5), dp(22), dp(6));
            page.addView(picker, pickerParams);

            if ("SEN".equals(modeSection)) {
                Button variant = outlineButton("A / B  — ulangi nomor SEN yang sama");
                variant.setOnClickListener(v -> sendSimple(0x19, selectedSen));
                page.addView(variant, lpMatchWrap(0, 0, 0, 5));
            }
        }

        page.addView(makeSliderRow(
                "Speed", globalSpeed, 1, 100,
                value -> {
                    globalSpeed = value;
                    if ("REM".equals(modeSection)) sendRemTarget(0x02, value);
                    else sendSimple(0x02, value);
                    saveLive();
                }));

        page.addView(makeSliderRow(
                "Brightness", globalBrightness, 1, 100,
                value -> {
                    globalBrightness = value;
                    if ("REM".equals(modeSection)) sendRemTarget(0x01, value);
                    else sendSimple(0x01, value);
                    saveLive();
                }));

        contentHost.addView(page);
    }

    private LinearLayout.LayoutParams effectCardParams() {
        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(0, dp(86), 1f);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        return p;
    }

    private View makeEffectCard(int mode, boolean selected) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(5), dp(4), dp(5), dp(4));
        card.setBackground(roundRect(
                selected ? PANEL2 : PANEL,
                15,
                selected ? CYAN : LINE,
                selected ? 2 : 1));

        EffectPreviewView preview = new EffectPreviewView(this, mode);
        card.addView(preview, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView number = tv(String.valueOf(mode), 12,
                selected ? Typeface.BOLD : Typeface.NORMAL,
                selected ? CYAN2 : WHITE);
        number.setGravity(Gravity.CENTER);
        card.addView(number, lpMatchWrap(0, 1, 0, 0));

        return card;
    }

    private void refreshEffectCardSelection(
            List<View> cards,
            List<Integer> modes) {

        for (int i = 0; i < cards.size(); i++) {
            boolean active = modes.get(i) == selected210;
            View card = cards.get(i);

            card.setBackground(roundRect(
                    active ? PANEL2 : PANEL,
                    15,
                    active ? CYAN : LINE,
                    active ? 2 : 1));

            if (card instanceof LinearLayout) {
                LinearLayout box = (LinearLayout) card;
                if (box.getChildCount() > 1 &&
                        box.getChildAt(1) instanceof TextView) {
                    TextView number = (TextView) box.getChildAt(1);
                    number.setTextColor(active ? CYAN2 : WHITE);
                    number.setTypeface(
                            Typeface.DEFAULT,
                            active ? Typeface.BOLD : Typeface.NORMAL);
                }
            }
        }
    }

    private String sectionTitleText() {
        if ("210".equals(modeSection)) return "EFEK 1–210";
        if ("REM".equals(modeSection)) return "REM 1–10";
        if ("SEN".equals(modeSection)) return "SEN 1–10";
        return "WELCOME 0–50";
    }

    // ---------------------------------------------------------------------
    // COLLECT
    // ---------------------------------------------------------------------

    private void showCollectScreen() {
        contentHost.removeAllViews();

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(12), dp(6), dp(12), dp(8));

        LinearLayout head = horizontal();
        TextView title = sectionTitle("COLLECT");
        head.addView(title, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button add = compactButton("+ ADD");
        add.setOnClickListener(v -> showAddCollectDialog());
        head.addView(add);
        page.addView(head);

        TextView help = tv(
                "Tambah efek dulu. Setiap item menyimpan nomor efek, speed, dan brightness. Tap item untuk langsung menjalankan.",
                10, Typeface.NORMAL, MUTED);
        page.addView(help, lpMatchWrap(0, 4, 0, 7));

        ScrollView scroller = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroller.addView(list);

        if (collectItems.isEmpty()) {
            TextView empty = tv("Belum ada efek di Collect.", 13, Typeface.BOLD, MUTED);
            empty.setGravity(Gravity.CENTER);
            list.addView(empty, lpMatchWrap(0, 30, 0, 0));
        } else {
            for (int i = 0; i < collectItems.size(); i++) {
                final int index = i;
                CollectItem item = collectItems.get(i);

                LinearLayout row = horizontal();
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(10), dp(8), dp(8), dp(8));
                row.setBackground(roundRect(PANEL, 14, LINE, 1));

                TextView number = tv(String.valueOf(item.mode), 24, Typeface.BOLD, CYAN2);
                number.setGravity(Gravity.CENTER);
                row.addView(number, fixed(dp(56), dp(52)));

                LinearLayout info = new LinearLayout(this);
                info.setOrientation(LinearLayout.VERTICAL);
                TextView line1 = tv(
                        "Speed " + item.speed + "   •   Brightness " + item.brightness,
                        12, Typeface.BOLD, WHITE);
                TextView line2 = tv("Tap untuk jalankan", 10, Typeface.NORMAL, MUTED);
                info.addView(line1);
                info.addView(line2);
                row.addView(info, new LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                Button del = compactButton("×");
                del.setOnClickListener(v -> {
                    collectItems.remove(index);
                    saveCollect();
                    showCollectScreen();
                });
                row.addView(del);

                row.setOnClickListener(v -> runCollectItem(item));

                list.addView(row, lpMatchWrap(0, 0, 0, 7));
            }
        }

        page.addView(scroller, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        contentHost.addView(page);
    }

    private void showAddCollectDialog() {
        if (collectItems.size() >= 50) {
            toast("Collect maksimal 50 efek");
            return;
        }

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(5));

        TextView t1 = tv("Nomor efek 1–210", 12, Typeface.BOLD, Color.BLACK);
        box.addView(t1);

        NumberPicker mode = new NumberPicker(this);
        mode.setMinValue(1);
        mode.setMaxValue(210);
        mode.setValue(selected210);
        mode.setWrapSelectorWheel(false);
        mode.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        box.addView(mode, lpMatchWrap(0, 0, 0, 8));

        TextView speedText = tv("Speed: " + globalSpeed, 12, Typeface.BOLD, Color.BLACK);
        box.addView(speedText);

        SeekBar speed = new SeekBar(this);
        speed.setMax(99);
        speed.setProgress(globalSpeed - 1);
        speed.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                speedText.setText("Speed: " + (progress + 1));
            }
        });
        box.addView(speed);

        TextView brightText = tv(
                "Brightness: " + globalBrightness,
                12, Typeface.BOLD, Color.BLACK);
        box.addView(brightText);

        SeekBar bright = new SeekBar(this);
        bright.setMax(99);
        bright.setProgress(globalBrightness - 1);
        bright.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                brightText.setText("Brightness: " + (progress + 1));
            }
        });
        box.addView(bright);

        new AlertDialog.Builder(this)
                .setTitle("Tambah ke Collect")
                .setView(box)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Tambah", (d, which) -> {
                    CollectItem item = new CollectItem(
                            mode.getValue(),
                            speed.getProgress() + 1,
                            bright.getProgress() + 1);
                    collectItems.add(item);
                    saveCollect();
                    showCollectScreen();
                })
                .show();
    }

    private void runCollectItem(CollectItem item) {
        globalSpeed = item.speed;
        globalBrightness = item.brightness;
        selected210 = item.mode;

        sendSimple(0x02, item.speed);
        main.postDelayed(() -> sendSimple(0x01, item.brightness), 50);
        main.postDelayed(() -> sendMode(item.mode), 100);

        saveLive();
        toast("Efek " + item.mode + " dijalankan");
    }

    // ---------------------------------------------------------------------
    // SETTINGS DRAWER — kanan
    // ---------------------------------------------------------------------

    private void showSettingsDrawer() {
        if (settingsPopup != null && settingsPopup.isShowing()) {
            settingsPopup.dismiss();
            return;
        }

        ScrollView scroller = new ScrollView(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(16), dp(14), dp(20));
        panel.setBackgroundColor(Color.BLACK);
        scroller.addView(panel);

        LinearLayout head = horizontal();
        Button close = compactButton("←");
        close.setOnClickListener(v -> settingsPopup.dismiss());
        head.addView(close);

        TextView title = tv("Set Focus", 24, Typeface.NORMAL, WHITE);
        title.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(title, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        panel.addView(head, lpMatchWrap(0, 0, 0, 12));

        panel.addView(settingsRow("Chip settings", "Jumlah LED", v -> showLedCountDialog()));

        LinearLayout kRow = horizontal();
        TextView kTitle = tv("Button", 17, Typeface.NORMAL, WHITE);
        kRow.addView(kTitle, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button k1 = blueSquare("K1");
        Button k2 = blueSquare("K2");
        Button k3 = blueSquare("K3");

        k1.setOnClickListener(v -> sendSimple(0x11, 0x00));
        k2.setOnClickListener(v -> sendSimple(0x11, 0x01));
        k3.setOnClickListener(v -> sendSimple(0x11, 0x02));

        kRow.addView(k1);
        kRow.addView(k2, marginLeft(dp(6)));
        kRow.addView(k3, marginLeft(dp(6)));
        panel.addView(kRow, drawerRowParams());

        LinearLayout sub = horizontal();
        TextView subTitle = tv("Subarea", 17, Typeface.NORMAL, WHITE);
        sub.addView(subTitle, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button left = blueSquare("←");
        Button box = blueSquare("■");
        Button right = blueSquare("→");

        // Firmware: left=0x01, box=0x00, right=0x02.
        // Left/right firmware expects a double-tap; one app click sends two packets.
        left.setOnClickListener(v -> sendSubareaDouble(0x01));
        right.setOnClickListener(v -> sendSubareaDouble(0x02));

        // Box single = toggle REM CH3+CH4.
        box.setOnClickListener(v -> sendSimple(0x14, 0x00));

        // Box double in firmware = SEN kembali ALL 4CH.
        box.setOnLongClickListener(v -> {
            sendSubareaDouble(0x00);
            toast("SEN kembali ALL 4CH");
            return true;
        });

        sub.addView(left);
        sub.addView(box, marginLeft(dp(6)));
        sub.addView(right, marginLeft(dp(6)));
        panel.addView(sub, drawerRowParams());

        TextView subHint = tv(
                "←/→ = area SEN • ■ tap = REM CH3+CH4 • ■ tahan = SEN ALL 4CH",
                10, Typeface.NORMAL, MUTED);
        panel.addView(subHint, lpMatchWrap(0, -3, 0, 9));

        LinearLayout lockRow = horizontal();
        lockRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView lockTitle = tv("Password Modul", 17, Typeface.NORMAL, WHITE);
        lockRow.addView(lockTitle, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Switch moduleLock = new Switch(this);
        moduleLock.setChecked(prefs.getBoolean("module_lock", false));
        moduleLock.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean("module_lock", isChecked).apply();
            sendSimple(0x16, isChecked ? 1 : 0);
        });
        lockRow.addView(moduleLock);
        panel.addView(lockRow, drawerRowParams());

        panel.addView(settingsRow(
                "Password Aplikasi", "Atur kunci lokal", v -> showSetPasswordDialog()));

        panel.addView(settingsRow(
                "Update OTA", "Buka halaman OTA resmi", v -> openOta()));

        TextView noMusic = tv(
                "Menu musik tidak dipakai.",
                11, Typeface.NORMAL, MUTED);
        panel.addView(noMusic, lpMatchWrap(0, 12, 0, 0));

        TextView version = tv(
                "Wardan Lighting  •  v0.9.0",
                11, Typeface.BOLD, CYAN2);
        version.setGravity(Gravity.CENTER);
        panel.addView(version, lpMatchWrap(0, 22, 0, 0));

        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.82f);
        settingsPopup = new PopupWindow(
                scroller,
                width,
                ViewGroup.LayoutParams.MATCH_PARENT,
                true);
        settingsPopup.setOutsideTouchable(true);
        settingsPopup.setBackgroundDrawable(roundRect(Color.BLACK, 0, LINE, 1));
        settingsPopup.setElevation(dp(12));
        settingsPopup.showAtLocation(appRoot, Gravity.RIGHT, 0, 0);
    }

    private View settingsRow(String title, String subtitle, View.OnClickListener listener) {
        LinearLayout row = horizontal();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(13), dp(4), dp(13));

        LinearLayout textBox = new LinearLayout(this);
        textBox.setOrientation(LinearLayout.VERTICAL);

        TextView t = tv(title, 17, Typeface.NORMAL, WHITE);
        TextView s = tv(subtitle, 10, Typeface.NORMAL, MUTED);
        textBox.addView(t);
        textBox.addView(s);

        row.addView(textBox, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView arrow = tv("›", 30, Typeface.NORMAL, MUTED);
        row.addView(arrow);

        row.setBackground(bottomLineDrawable());
        row.setOnClickListener(listener);
        return row;
    }

    private void showLedCountDialog() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(prefs.getInt("led_count", 75)));
        input.setSelectAllOnFocus(true);

        new AlertDialog.Builder(this)
                .setTitle("Chip settings — jumlah LED")
                .setView(input)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Terapkan", (d, which) -> {
                    try {
                        int count = Integer.parseInt(input.getText().toString().trim());
                        if (count < 1) count = 1;
                        if (count > 1000) count = 1000;
                        prefs.edit().putInt("led_count", count).apply();
                        sendLedCount(count);
                        toast("Jumlah LED: " + count);
                    } catch (Exception e) {
                        toast("Jumlah LED tidak valid");
                    }
                })
                .show();
    }

    private void showSetPasswordDialog() {
        final EditText input = new EditText(this);
        input.setHint("Password baru");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT |
                InputType.TYPE_TEXT_VARIATION_PASSWORD);

        new AlertDialog.Builder(this)
                .setTitle("Password aplikasi")
                .setMessage("Kosongkan untuk menonaktifkan password lokal.")
                .setView(input)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Simpan", (d, which) -> {
                    prefs.edit().putString(
                            "local_password",
                            input.getText().toString()).apply();
                    toast("Password aplikasi disimpan");
                })
                .show();
    }

    // ---------------------------------------------------------------------
    // BLE
    // ---------------------------------------------------------------------

    private void connectLedcar() {
        if (btAdapter == null) {
            toast("Bluetooth tidak tersedia");
            return;
        }

        if (!hasBluetoothPermissions()) {
            requestBluetoothPermissions();
            return;
        }

        if (!btAdapter.isEnabled()) {
            toast("Aktifkan Bluetooth terlebih dahulu");
            try {
                startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            } catch (Exception ignored) {}
            return;
        }

        scanner = btAdapter.getBluetoothLeScanner();
        if (scanner == null) {
            toast("BLE scanner tidak tersedia");
            return;
        }

        if (scanning) {
            stopScan();
            setStatus("Scan dihentikan", MUTED);
            return;
        }

        scanning = true;
        setStatus("Mencari LEDCAR...", CYAN2);

        try {
            scanner.startScan(scanCallback);
        } catch (SecurityException e) {
            requestBluetoothPermissions();
            return;
        }

        main.postDelayed(() -> {
            if (scanning) {
                stopScan();
                setStatus("LEDCAR belum ditemukan", RED);
            }
        }, 12000);
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice device = result.getDevice();
            String name = null;

            try {
                if (hasBluetoothPermissions()) name = device.getName();
            } catch (SecurityException ignored) {}

            boolean nameMatch = name != null &&
                    (name.toUpperCase(Locale.ROOT).contains("LEDCAR") ||
                     name.toUpperCase(Locale.ROOT).contains("LEDLAMP") ||
                     name.toUpperCase(Locale.ROOT).contains("WARDAN"));

            boolean serviceMatch = false;
            if (result.getScanRecord() != null &&
                    result.getScanRecord().getServiceUuids() != null) {
                for (ParcelUuid uuid : result.getScanRecord().getServiceUuids()) {
                    if (SERVICE_FFE0.equals(uuid.getUuid())) {
                        serviceMatch = true;
                        break;
                    }
                }
            }

            if (nameMatch || serviceMatch) {
                stopScan();
                final String displayName =
                        name != null ? name : "LEDCAR";

                main.post(() -> {
                    titleLabel.setText("Wardan Lighting");
                    setStatus("Menghubungkan " + displayName + "...", CYAN2);
                });

                connectGatt(device);
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            scanning = false;
            main.post(() -> setStatus(
                    "Scan BLE gagal: " + errorCode, RED));
        }
    };

    private void connectGatt(BluetoothDevice device) {
        if (!hasBluetoothPermissions()) {
            requestBluetoothPermissions();
            return;
        }

        try {
            if (gatt != null) {
                gatt.close();
                gatt = null;
            }

            ffe1 = null;

            gatt = device.connectGatt(
                    this,
                    false,
                    gattCallback,
                    BluetoothDevice.TRANSPORT_LE);

        } catch (SecurityException e) {
            requestBluetoothPermissions();
        }
    }

    private final BluetoothGattCallback gattCallback =
            new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(
                BluetoothGatt g,
                int status,
                int newState) {

            if (newState == BluetoothProfile.STATE_CONNECTED) {
                main.post(() -> setStatus(
                        "Terhubung • membaca service", GREEN));
                try {
                    g.discoverServices();
                } catch (SecurityException e) {
                    main.post(() -> setStatus(
                            "Izin Bluetooth diperlukan", RED));
                }

            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                ffe1 = null;
                main.post(() -> setStatus("Terputus", RED));
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                main.post(() -> setStatus(
                        "Gagal membaca service", RED));
                return;
            }

            BluetoothGattService service = g.getService(SERVICE_FFE0);

            if (service == null) {
                main.post(() -> setStatus(
                        "FFE0 tidak ditemukan", RED));
                return;
            }

            ffe1 = service.getCharacteristic(CHAR_FFE1);

            if (ffe1 == null) {
                main.post(() -> setStatus(
                        "FFE1 tidak ditemukan", RED));
                return;
            }

            main.post(() -> setStatus(
                    "CONNECTED • LEDCAR-02-9931", GREEN));
        }
    };

    private void stopScan() {
        scanning = false;

        if (scanner != null && hasBluetoothPermissions()) {
            try {
                scanner.stopScan(scanCallback);
            } catch (SecurityException ignored) {}
        }
    }

    private boolean hasBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED;
        }

        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(
                    new String[] {
                            Manifest.permission.BLUETOOTH_SCAN,
                            Manifest.permission.BLUETOOTH_CONNECT
                    },
                    REQ_BT);
        } else {
            requestPermissions(
                    new String[] {
                            Manifest.permission.ACCESS_FINE_LOCATION
                    },
                    REQ_BT);
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults);

        if (requestCode == REQ_BT) {
            if (hasBluetoothPermissions()) connectLedcar();
            else toast("Izin Bluetooth diperlukan");
        }
    }

    // ---------------------------------------------------------------------
    // FIRMWARE PACKETS
    // ---------------------------------------------------------------------

    private void sendMode(int mode) {
        sendPacket(0x03, mode, 0, 0, selectedChannel);
    }

    private void sendModeAuto() {
        sendPacket(0x03, 0xFF, 0, 0, selectedChannel);
    }

    private void sendRgb(int r, int g, int b) {
        sendPacket(0x07, r, g, b, selectedChannel);
    }

    private void sendSimple(int cmd, int value) {
        sendPacket(cmd, value, 0, 0, selectedChannel);
    }

    private void sendRemTarget(int cmd, int value) {
        // Firmware mengenali p[3] == 0x04 sebagai target REM.
        byte[] packet = basePacket();
        packet[1] = (byte) (cmd & 0xFF);
        packet[2] = (byte) (value & 0xFF);
        packet[3] = 0x04;
        packet[7] = (byte) (selectedChannel & 0xFF);
        writePacket(packet);
    }

    private void sendLedCount(int count) {
        byte[] packet = basePacket();
        packet[1] = 0x05;
        packet[2] = 0x00;
        packet[3] = (byte) ((count >> 8) & 0xFF);
        packet[4] = (byte) (count & 0xFF);
        packet[7] = 0x03;
        writePacket(packet);
    }

    private void sendSubareaDouble(int area) {
        sendPacket(0x14, area, 0, 0, selectedChannel);
        main.postDelayed(
                () -> sendPacket(0x14, area, 0, 0, selectedChannel),
                140);
    }

    private void sendPacket(
            int cmd,
            int v1,
            int v2,
            int v3,
            int channel) {

        byte[] p = basePacket();
        p[1] = (byte) (cmd & 0xFF);
        p[2] = (byte) (v1 & 0xFF);
        p[3] = (byte) (v2 & 0xFF);
        p[4] = (byte) (v3 & 0xFF);
        p[7] = (byte) (channel & 0xFF);

        writePacket(p);
    }

    private byte[] basePacket() {
        byte[] p = new byte[9];
        p[0] = 0x7B;
        p[1] = 0;
        p[2] = 0;
        p[3] = 0;
        p[4] = 0;
        p[5] = 0;
        p[6] = 0;
        p[7] = 0x03;
        p[8] = (byte) 0xBF;
        return p;
    }

    private void writePacket(byte[] packet) {
        if (gatt == null || ffe1 == null) {
            toast("Hubungkan modul dulu");
            return;
        }

        try {
            int props = ffe1.getProperties();

            int writeType =
                    (props & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                            ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                            : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;

            if (Build.VERSION.SDK_INT >= 33) {
                int rc = gatt.writeCharacteristic(
                        ffe1,
                        packet,
                        writeType);

                if (rc != 0) toast("BLE write gagal: " + rc);

            } else {
                ffe1.setWriteType(writeType);
                ffe1.setValue(packet);

                boolean ok = gatt.writeCharacteristic(ffe1);

                if (!ok) toast("BLE write gagal");
            }

        } catch (SecurityException e) {
            requestBluetoothPermissions();

        } catch (Exception e) {
            toast("Gagal kirim BLE");
        }
    }

    // ---------------------------------------------------------------------
    // OTA
    // ---------------------------------------------------------------------

    private void openOta() {
        try {
            startActivity(new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse(OTA_URL)));

        } catch (Exception e) {
            toast("Browser tidak tersedia");
        }
    }

    // ---------------------------------------------------------------------
    // PERSISTENCE
    // ---------------------------------------------------------------------

    private void loadState() {
        selectedProfile = prefs.getString("profile", "LEDCAR");
        selectedChannel = prefs.getInt("channel", 0x03);

        rgbR = prefs.getInt("rgb_r", 0);
        rgbG = prefs.getInt("rgb_g", 190);
        rgbB = prefs.getInt("rgb_b", 255);

        globalSpeed = prefs.getInt("speed", 70);
        globalBrightness = prefs.getInt("brightness", 70);

        selected210 = prefs.getInt("mode210", 1);
        selectedRem = prefs.getInt("rem", 1);
        selectedSen = prefs.getInt("sen", 1);
        selectedWelcome = prefs.getInt("welcome", 0);
    }

    private void saveLive() {
        prefs.edit()
                .putInt("channel", selectedChannel)
                .putInt("rgb_r", rgbR)
                .putInt("rgb_g", rgbG)
                .putInt("rgb_b", rgbB)
                .putInt("speed", globalSpeed)
                .putInt("brightness", globalBrightness)
                .putInt("mode210", selected210)
                .putInt("rem", selectedRem)
                .putInt("sen", selectedSen)
                .putInt("welcome", selectedWelcome)
                .apply();
    }

    private void loadCollect() {
        collectItems.clear();

        String raw = prefs.getString("collect", "");
        if (raw == null || raw.trim().isEmpty()) return;

        String[] rows = raw.split(";");

        for (String row : rows) {
            String[] p = row.split(",");

            if (p.length != 3) continue;

            try {
                int mode = Integer.parseInt(p[0]);
                int speed = Integer.parseInt(p[1]);
                int brightness = Integer.parseInt(p[2]);

                if (mode >= 1 && mode <= 210) {
                    collectItems.add(new CollectItem(
                            mode,
                            clamp(speed, 1, 100),
                            clamp(brightness, 1, 100)));
                }

            } catch (Exception ignored) {}
        }
    }

    private void saveCollect() {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < collectItems.size(); i++) {
            CollectItem item = collectItems.get(i);

            if (i > 0) sb.append(";");

            sb.append(item.mode)
                    .append(",")
                    .append(item.speed)
                    .append(",")
                    .append(item.brightness);
        }

        prefs.edit().putString("collect", sb.toString()).apply();
    }

    // ---------------------------------------------------------------------
    // UI HELPERS
    // ---------------------------------------------------------------------

    private Button channelButton(String name, int code) {
        Button b = tabButton(name);
        b.setTag(code);
        b.setTextSize(10);
        b.setPadding(dp(2), dp(9), dp(2), dp(9));
        channelButtons.add(b);

        b.setOnClickListener(v -> {
            selectedChannel = code;
            channelLabel.setText(channelName(code));
            prefs.edit().putInt("channel", code).apply();
            updateChannelButtonStyles();
        });

        updateOneChannelButtonStyle(b, code == selectedChannel);
        return b;
    }

    private void updateChannelButtonStyles() {
        for (Button b : channelButtons) {
            Object tag = b.getTag();
            int code = tag instanceof Integer ? (Integer) tag : 0x03;
            updateOneChannelButtonStyle(b, code == selectedChannel);
        }
    }

    private void updateOneChannelButtonStyle(Button b, boolean selected) {
        if (selected) {
            b.setBackground(roundRect(CYAN, 10, CYAN, 1));
            b.setTextColor(BG);
        } else {
            b.setBackground(roundRect(PANEL, 10, LINE, 1));
            b.setTextColor(WHITE);
        }
    }

    private String channelName(int code) {
        if (code == 0x01) return "LED1";
        if (code == 0x02) return "LED2";
        if (code == 0x04) return "LED3";
        if (code == 0x05) return "LED4";
        return "ALL";
    }

    private Button colorPreset(String label, int r, int g, int b) {
        Button btn = darkButton(label);

        btn.setOnClickListener(v -> {
            rgbR = r;
            rgbG = g;
            rgbB = b;
            sendRgb(r, g, b);
            saveLive();
        });

        return btn;
    }

    private View makeSliderRow(
            String label,
            int initial,
            int min,
            int max,
            IntValue listener) {

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(2), 0, dp(2));

        LinearLayout head = horizontal();

        TextView name = tv(label, 11, Typeface.BOLD, MUTED);
        head.addView(name, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView value = tv(String.valueOf(initial), 12, Typeface.BOLD, WHITE);
        head.addView(value);

        box.addView(head);

        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(initial - min);

        seek.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(
                    SeekBar seekBar,
                    int progress,
                    boolean fromUser) {

                int actual = progress + min;
                value.setText(String.valueOf(actual));

                if (fromUser) listener.onValue(actual);
            }
        });

        box.addView(seek);

        return box;
    }

    private LinearLayout horizontal() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }

    private TextView sectionTitle(String text) {
        TextView t = tv(text, 15, Typeface.BOLD, CYAN2);
        t.setLetterSpacing(0.08f);
        return t;
    }

    private Button navButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setTextColor(WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(5), dp(6), dp(5), dp(6));
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private Button tabButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setTextColor(WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(11), dp(8), dp(11), dp(8));
        b.setBackground(roundRect(PANEL, 10, LINE, 1));
        return b;
    }

    private Button modeTab(String text) {
        Button b = tabButton(text);

        if (text.equals(modeSection)) {
            b.setBackground(roundRect(CYAN, 10, CYAN, 1));
            b.setTextColor(BG);
        }

        return b;
    }

    private Button compactButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setTextColor(WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(10), dp(8), dp(10), dp(8));
        b.setBackground(roundRect(PANEL2, 12, LINE, 1));
        return b;
    }

    private Button darkButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(10);
        b.setTextColor(WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(4), dp(8), dp(4), dp(8));
        b.setBackground(roundRect(PANEL2, 12, LINE, 1));
        return b;
    }

    private Button outlineButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setTextColor(CYAN2);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(8), dp(9), dp(8), dp(9));
        b.setBackground(roundRect(BG2, 12, CYAN, 1));
        return b;
    }

    private Button blueSquare(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setTextColor(WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(9), dp(9), dp(9), dp(9));
        b.setBackground(roundRect(Color.rgb(0, 41, 255), 8, Color.rgb(0, 41, 255), 0));
        return b;
    }

    private TextView tv(String text, int sp, int style, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, style);
        return t;
    }

    private GradientDrawable roundRect(
            int fill,
            int radiusDp,
            int stroke,
            int strokeDp) {

        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));

        if (strokeDp > 0) {
            d.setStroke(dp(strokeDp), stroke);
        }

        return d;
    }

    private GradientDrawable bottomLineDrawable() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.BLACK);
        d.setStroke(dp(1), Color.rgb(70, 70, 70));
        return d;
    }

    private LinearLayout.LayoutParams lpMatchWrap(
            int l, int t, int r, int b) {

        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);

        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private LinearLayout.LayoutParams weightButton() {
        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1f);

        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private LinearLayout.LayoutParams marginLeft(int left) {
        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);

        p.leftMargin = left;
        return p;
    }

    private LinearLayout.LayoutParams fixed(int width, int height) {
        return new LinearLayout.LayoutParams(width, height);
    }

    private LinearLayout.LayoutParams drawerRowParams() {
        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(2), 0, dp(2));
        return p;
    }

    private int dp(int value) {
        return (int) (
                value *
                getResources().getDisplayMetrics().density +
                0.5f);
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private void setStatus(String text, int color) {
        main.post(() -> {
            if (statusText != null) {
                statusText.setText(text);
                statusText.setTextColor(color);
            }
        });
    }

    private void toast(String text) {
        main.post(() ->
                Toast.makeText(
                        this,
                        text,
                        Toast.LENGTH_SHORT).show());
    }

    @Override
    protected void onDestroy() {
        stopScan();

        if (gatt != null) {
            try {
                if (hasBluetoothPermissions()) {
                    gatt.disconnect();
                }
            } catch (SecurityException ignored) {}

            gatt.close();
            gatt = null;
        }

        super.onDestroy();
    }

    // ---------------------------------------------------------------------
    // TYPES
    // ---------------------------------------------------------------------

    private interface IntValue {
        void onValue(int value);
    }

    private static abstract class SimpleSeek
            implements SeekBar.OnSeekBarChangeListener {

        @Override
        public void onProgressChanged(
                SeekBar seekBar,
                int progress,
                boolean fromUser) {}

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {}

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {}
    }

    private static final class CollectItem {
        final int mode;
        final int speed;
        final int brightness;

        CollectItem(int mode, int speed, int brightness) {
            this.mode = mode;
            this.speed = speed;
            this.brightness = brightness;
        }
    }

    // ---------------------------------------------------------------------
    // LIGHTWEIGHT EFFECT PREVIEW
    // One renderer, 210 visual variations; no bitmap assets required.
    // ---------------------------------------------------------------------

    private static final class EffectPreviewView extends View {
        private final int mode;
        private final Paint onPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint offPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        EffectPreviewView(Context context, int mode) {
            super(context);
            this.mode = mode;
            onPaint.setStyle(Paint.Style.FILL);
            offPaint.setStyle(Paint.Style.FILL);
            offPaint.setColor(Color.rgb(35, 55, 66));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            int points = 24;
            float left = w * 0.09f;
            float right = w * 0.91f;
            float mid = h * 0.50f;
            float amp = h * 0.28f;
            float radius = Math.max(2.2f, Math.min(w, h) * 0.035f);

            float hue = (mode * 37f) % 360f;
            int lit = Color.HSVToColor(new float[]{hue, 0.92f, 1.0f});
            int lit2 = Color.HSVToColor(new float[]{(hue + 78f) % 360f, 0.90f, 1.0f});

            int family = (mode - 1) % 8;
            int phase = (mode / 8) % points;

            for (int i = 0; i < points; i++) {
                float t = i / (float) (points - 1);
                float x = left + (right - left) * t;
                float y;

                switch (family) {
                    case 0:
                        y = mid + (float) Math.sin(t * Math.PI * 4.0) * amp;
                        break;
                    case 1:
                        y = mid + (float) Math.sin(t * Math.PI * 3.0 + 1.0) * amp;
                        break;
                    case 2:
                        y = h * (0.22f + 0.56f * t);
                        break;
                    case 3:
                        y = h * (0.78f - 0.56f * t);
                        break;
                    case 4:
                        y = (i % 6 < 3) ? h * 0.32f : h * 0.68f;
                        break;
                    case 5:
                        y = mid + Math.abs(0.5f - t) * amp * 1.7f - amp * 0.45f;
                        break;
                    case 6:
                        y = mid + (float) Math.sin(t * Math.PI * 6.0) * amp * 0.65f;
                        break;
                    default:
                        y = mid + (float) Math.cos(t * Math.PI * 2.0) * amp;
                        break;
                }

                int dist = Math.abs(i - phase);
                dist = Math.min(dist, points - dist);

                boolean active;
                if (family <= 1) {
                    active = true;
                } else if (family <= 3) {
                    active = dist <= 4;
                } else if (family == 4) {
                    active = ((i + mode) % 5) < 3;
                } else if (family == 5) {
                    active = i > points / 3 && i < points * 2 / 3;
                } else if (family == 6) {
                    active = ((i + mode) % 3) != 0;
                } else {
                    active = i <= phase;
                }

                if (active) {
                    onPaint.setColor((i % 5 == 0) ? lit2 : lit);
                    canvas.drawCircle(x, y, radius, onPaint);
                } else {
                    canvas.drawCircle(x, y, radius * 0.88f, offPaint);
                }
            }
        }
    }

    // ---------------------------------------------------------------------
    // SIMPLE HUE WHEEL
    // ---------------------------------------------------------------------

    private static final class HueWheelView extends View {

        interface OnColorChangedListener {
            void onColorChanged(int r, int g, int b);
        }

        private Paint ringPaint;
        private Paint centerPaint;
        private OnColorChangedListener listener;
        private float centerX;
        private float centerY;
        private float ringRadius;
        private float ringWidth;

        HueWheelView(Context context) {
            super(context);

            ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            ringPaint.setStyle(Paint.Style.STROKE);

            centerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            centerPaint.setStyle(Paint.Style.FILL);
            centerPaint.setColor(Color.rgb(0, 190, 255));

            setMinimumHeight(220);
        }

        void setOnColorChangedListener(OnColorChangedListener listener) {
            this.listener = listener;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            int w = getWidth();
            int h = getHeight();

            centerX = w / 2f;
            centerY = h / 2f;

            ringRadius = Math.min(w, h) * 0.30f;
            ringWidth = Math.min(w, h) * 0.12f;

            ringPaint.setStrokeWidth(ringWidth);

            int[] colors = new int[] {
                    Color.RED,
                    Color.MAGENTA,
                    Color.BLUE,
                    Color.CYAN,
                    Color.GREEN,
                    Color.YELLOW,
                    Color.RED
            };

            float[] pos = new float[] {
                    0f, 0.16f, 0.33f, 0.50f, 0.66f, 0.83f, 1f
            };

            ringPaint.setShader(new SweepGradient(
                    centerX,
                    centerY,
                    colors,
                    pos));

            canvas.drawCircle(
                    centerX,
                    centerY,
                    ringRadius,
                    ringPaint);

            canvas.drawCircle(
                    centerX,
                    centerY,
                    ringRadius * 0.38f,
                    centerPaint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (event.getAction() != MotionEvent.ACTION_DOWN &&
                    event.getAction() != MotionEvent.ACTION_MOVE) {
                return true;
            }

            float dx = event.getX() - centerX;
            float dy = event.getY() - centerY;

            double angle = Math.atan2(dy, dx);
            float degrees = (float) Math.toDegrees(angle);

            degrees += 90f;
            if (degrees < 0) degrees += 360f;

            float hue = (degrees + 360f) % 360f;

            int color = Color.HSVToColor(
                    new float[] { hue, 1f, 1f });

            centerPaint.setColor(color);
            invalidate();

            if (listener != null) {
                listener.onColorChanged(
                        Color.red(color),
                        Color.green(color),
                        Color.blue(color));
            }

            return true;
        }
    }
}
