package com.wardanlighting.control;

/** Lightweight procedural previews for modes 121–200. No recorded LED frames are bundled. */
final class FirmwareCanvas121200 {
    private static final int N=FirmwarePreview120.N;
    private static final int BLACK=FirmwarePreview120.BLACK;
    private static final float PI=(float)Math.PI;

    private FirmwareCanvas121200() {}

    static FirmwarePreview120.Frame4 render(int mode,long elapsedMs,int speed){
        FirmwarePreview120.Frame4 frame=new FirmwarePreview120.Frame4();
        if(mode<121||mode>200)return frame;
        int index=mode-121;
        int family=index/10,variant=index%10;
        float delay=50f-(Math.max(1,Math.min(100,speed))-1)*45f/99f;
        float time=(elapsedMs*.001f)*(25f/Math.max(5f,delay));
        float rate=.18f+variant*.027f;
        float phase=fract(time*rate);
        int cycle=(int)Math.floor(time*rate);
        int ca=hsv((mode*37f+cycle*29f)%360f);
        int cb=hsv((mode*37f+125f+cycle*29f)%360f);

        for(int i=0;i<N;i++){
            float x=i/(float)(N-1);
            // Each decade has its own motion; each mode varies width, pace,
            // direction, palette and number of pulses.
            float left=effect(family,variant,phase,x,time);
            float right=effect(family,variant,fract(phase+.43f),1f-x,time);
            frame.ch[0][i]=lit(ca,left);
            frame.ch[1][i]=lit(cb,right);
            frame.ch[2][i]=frame.ch[0][i];
            frame.ch[3][i]=frame.ch[1][i];
        }
        // Both modes join the four light sections into one flowing route.
        if(mode==185||mode==186){
            float path=fract(time*(mode==185?.12f:.16f));
            boolean reverse=(mode==185&&((int)(time*.12f)&1)!=0);
            int color=hsv((time*27f+mode*37f)%360f);
            int[] order={0,2,3,1};
            for(int ch=0;ch<4;ch++)for(int i=0;i<N;i++){
                float x=(ch*N+i)/(float)(N*4-1);
                float head=reverse?1f-path:path;
                frame.ch[order[ch]][i]=lit(color,gauss(x-head,.04f));
            }
        }
        return frame;
    }

    private static float effect(int family,int v,float phase,float x,float time){
        float width=.042f+.009f*(v%5);
        float k=1f+(v%3);
        switch(family){
            case 0: return Math.max(gauss(x-phase,width),
                    gauss(x-fract(phase+.34f),width*.60f)*.65f);
            case 1: return Math.max(gauss(x-(.5f+phase*.5f),width),
                    gauss(x-(.5f-phase*.5f),width));
            case 2: return gauss(x-(.5f+.43f*(float)Math.sin(phase*2f*PI)),width);
            case 3: return Math.max(gauss(x-phase,width),
                    gauss(x-(1f-phase),width*.75f));
            case 4: return .3f+.7f*(.5f+.5f*(float)Math.sin(x*PI*(5f+k)-time*(2f+v*.2f)));
            case 5: {
                int block=(int)(x*(4+v%5));
                int selected=(int)(phase*(4+v%5));
                return selected==block?.9f:gauss(x-phase,width)*.65f;
            }
            case 6: return Math.max(gauss(x-fract(phase+.13f),width),
                    gauss(x-fract(phase+.57f),width*.75f)*.8f);
            default: {
                float center=(float)Math.sin(time*(.7f+v*.04f))* .35f+.5f;
                float radius=(.10f+.30f*phase);
                return Math.max(gauss(x-center-radius,width),
                        gauss(x-center+radius,width));
            }
        }
    }

    private static float gauss(float d,float width){return (float)Math.exp(-.5f*d*d/(width*width));}
    private static float fract(float v){return v-(float)Math.floor(v);}
    private static int lit(int color,float amount){
        float v=Math.max(0f,Math.min(1f,amount));
        if(v<.04f)return BLACK;
        int r=Math.round(((color>>16)&255)*v),g=Math.round(((color>>8)&255)*v),b=Math.round((color&255)*v);
        return 0xFF000000|(r<<16)|(g<<8)|b;
    }
    private static int hsv(float h){
        float x=h/60f;
        int segment=(int)x;
        float f=x-segment;
        float k=1f-Math.abs((x%2f)-1f);
        int a=255,b=Math.round(k*255f);
        switch(segment%6){
            case 0:return 0xFF000000|(a<<16)|(b<<8);
            case 1:return 0xFF000000|(b<<16)|(a<<8);
            case 2:return 0xFF000000|(a<<8)|b;
            case 3:return 0xFF000000|(b<<8)|a;
            case 4:return 0xFF000000|(b<<16)|a;
            default:return 0xFF000000|(a<<16)|b;
        }
    }
}
