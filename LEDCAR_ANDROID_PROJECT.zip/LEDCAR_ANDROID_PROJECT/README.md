# Wardan Lighting Android Project — Firmware Sync Fix

Basis UI: Wardan Lighting original-style assets.

Perbaikan versi 1.1:
- UI rendering ARGB_8888 supaya lebih tajam dan mengurangi efek ngebayang.
- Navigation bar HP tetap aman; menu bawah aplikasi diberi safe-area.
- Password/lock switch tidak dobel lagi dan bisa tap atau drag untuk ON/OFF.
- BLE TX queue 32 ms agar command cepat tidak saling tindih.
- Chip settings 1–1000 LED dikirim langsung dan dicegah saat module lock aktif.
- Mode 210: LED1 / LED2 / LED3 / LED4 / ALL, satu scroll 1..210.
- RGB wheel dan preset warna diperbaiki hitbox-nya.
- Welcome 0–50, SEN 1–10, REM 1–10 sesuai command firmware.
- K1/K2/K3, Subarea, lock, lamp ON/OFF, speed/brightness, RGB, chip count tetap memakai protokol 9-byte FFE1.
