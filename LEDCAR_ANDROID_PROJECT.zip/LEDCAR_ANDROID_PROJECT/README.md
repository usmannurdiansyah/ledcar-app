# Wardan Lighting Android App

Tahap awal aplikasi baru Wardan Lighting untuk firmware `mayarota(1).ino`.

## Identitas
- Nama aplikasi: **Wardan Lighting**
- Logo singkat: **WL**

## BLE firmware
- Device: `LEDCAR-02-9931`
- Service: `0000FFE0-0000-1000-8000-00805F9B34FB`
- Characteristic: `0000FFE1-0000-1000-8000-00805F9B34FB`
- Packet: 9 byte, `0x7B ... 0xBF`

## Yang sudah dibuat
- Splash + kunci geser + password lokal opsional
- Profil LEDCAR + DMX dalam satu aplikasi
- Channel LED1 / ALL / LED2 / LED3 / LED4
- RGB / warna dasar
- Mode 1–210 via scroll NumberPicker, langsung berjalan
- AUTO mode
- REM 1–10 via scroll, langsung berjalan
- SEN 1–10 via scroll, langsung berjalan
- Welcome 0–50 via scroll, langsung berjalan
- Collect: tambah efek + speed + brightness, simpan lokal, tap untuk jalankan
- K1 / K2 / K3
- Subarea kiri / kotak / kanan sesuai firmware
- Chip settings jumlah LED
- Password modul
- Update OTA membuka:
  `https://ledcar-ota.usmannurdiansyah.workers.dev`
- Tidak ada menu musik
- Bottom menu: RGB / Mode / Collect / Set

## Catatan subarea
- Kiri mengirim `0x14 / 0x01` dua kali
- Kotak tap mengirim `0x14 / 0x00` satu kali
- Kotak tahan mengirim `0x14 / 0x00` dua kali
- Kanan mengirim `0x14 / 0x02` dua kali

## Build GitHub
Workflow lama `build-apk.yml` masih bisa dipakai karena ZIP tetap memakai folder root:
`LEDCAR_ANDROID_PROJECT`
