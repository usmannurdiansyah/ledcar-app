# Wardan Lighting Android App

Tahap awal aplikasi baru Wardan Lighting untuk firmware `mayarota(1).ino`.

## Identitas
- Nama aplikasi: **Wardan Lighting**
- Logo singkat: **WL**

## BLE firmware
- Device: `LEDCAR-02-9931`
- Service: `0000FFE0-0000-1000-8000-00805F9B34FB`
- Characteristic: `0000FFE1-0000-1000-8000-00805F9B34FB`
- Packet: 9 byte, `0x7B ... 0xBF`

## Yang sudah dibuat
- Splash + kunci geser + password lokal opsional
- Profil LEDCAR + DMX dalam satu aplikasi
- Channel LED1 / ALL / LED2 / LED3 / LED4
- RGB / warna dasar
- Mode 1–210 satu kolom: hanya daftar yang scroll, preview 4CH tetap diam
- Preview bentuk 2 alis + 2 lingkaran, tanpa bintik LED
- Tap mode baru mengubah preview dan mengirim mode ke modul
- AUTO ditempatkan sebelum Mode 1; mengirim 0xFF dan preview mengikuti Mode 5–9 tiap ±10 detik
- REM 1–10 via scroll, langsung berjalan
- SEN 1–10 via scroll, langsung berjalan
- Welcome 0–50 via scroll, langsung berjalan
- Collect: tambah efek + speed + brightness, simpan lokal, tap untuk jalankan
- K1 / K2 / K3
- Subarea kiri / kotak / kanan sesuai firmware
- Chip settings jumlah LED
- Password modul
- Update OTA membuka:
  `https://ledcar-ota.usmannurdiansyah.workers.dev`
- Tidak ada menu musik
- Bottom menu: RGB / Mode / Collect / Set

## Catatan subarea
- Kiri mengirim `0x14 / 0x01` dua kali
- Kotak tap mengirim `0x14 / 0x00` satu kali
- Kotak tahan mengirim `0x14 / 0x00` dua kali
- Kanan mengirim `0x14 / 0x02` dua kali

## Build GitHub
Workflow lama `build-apk.yml` masih bisa dipakai karena ZIP tetap memakai folder root:
`LEDCAR_ANDROID_PROJECT`

## V18 firmware preview 1–120
- Preview Mode 1–120 is procedural and derived from the attached production firmware `mayarota(3).ino` (SHA-256: be5b009f01f2e4267d5b18af9e0ee9bde3d55c78e11f5f1887c3a41df4aeb923).
- Virtual renderer uses 75 source samples and draws them as continuous eyebrow/ring light, not LED dots.
- Physical preview mapping follows firmware batches, including special Mode 31, Mode 51, and Mode 101–120 mappings.
- AUTO preview follows the firmware 10-second sequencer and Mode 5–9 cycle.
- Scrolling the mode list does not change the active preview; tapping a mode does.
