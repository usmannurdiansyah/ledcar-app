# LEDCAR Android App

Aplikasi Android baru untuk controller LEDCAR ESP32-C3 via Bluetooth BLE.

## BLE
- Service: `0000FFE0-0000-1000-8000-00805F9B34FB`
- Characteristic: `0000FFE1-0000-1000-8000-00805F9B34FB`
- Packet 9 byte: header `0x7B`, tail `0xBF`

## Menu
- LED 1 / LED 2 / LED 3 / LED 4 / ALL
- Brightness
- Speed
- Mode 1–210
- RGB
- Welcome
- SEN
- REM
- Set 1–3
- Power ON/OFF
- Update OTA membuka:
  `https://ledcar-ota.usmannurdiansyah.workers.dev`

## Build
Project ini sengaja tanpa Gradle wrapper. Workflow GitHub memakai Gradle 8.7.
