# Wardan Lighting

Basis UI dipertahankan pada gaya versi awal Wardan Lighting.

Perubahan utama:
- Channel selector: LED1 / LED2 / LED3 / LED4 / ALL / Collect
- Mode 1-210: satu scroll vertikal
- Setiap baris mode memiliki preview strip
- Tap mode langsung kirim ke channel yang aktif
- REM / SEN / WELCOME juga scroll langsung jalan
- Collect: add efek + speed + brightness
- K1 K2 K3
- Subarea kiri / tengah / kanan
- Update OTA
- Bottom navigation memakai safe-area Android
- Tidak ada menu musik
